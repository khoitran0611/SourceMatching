﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.DutchAutionServices
{
    public class DutchAuctionJob : Job
    {
        private readonly RepositoryFactory _repositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            DutchAuction4NormalProduct();

            DutchAuction4CompositeProduct();
        }

        #region Private Methods
        private void DutchAuction4NormalProduct()
        {
            Log.Info("Find Dutch Auction Just Closed to restart again");
            IList<DutchAuctionDefine> auctionDefines = new List<DutchAuctionDefine>(_repositoryFactory.GetDutchAuctionDefineRepository().Find(new DutchAuctionsJustTimeOutSpecification()));

            if (auctionDefines.Count <= 0)
            {
                Log.Info("Not found Dutch Auction Running Timeout");
                return;
            }

            Log.Info(string.Format("Found {0} Dutch Auctions Running Timeout", auctionDefines.Count));
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                foreach (DutchAuctionDefine daDef in auctionDefines)
                {
                    _repositoryFactory.GetDutchAuctionDefineRepository().Refresh(daDef);

                    DateTime newStartAt = DateTime.Now.Date;
                    newStartAt = newStartAt.AddHours(DateTime.Now.Hour);
                    daDef.StartAt = newStartAt;

                    int startAtMinutes = DateTime.Now.Minute + 1;
                    daDef.StartTime = startAtMinutes;

                    DateTime newStAt = newStartAt.AddMinutes(startAtMinutes);
                    DateTime newCloseAt = newStAt.AddMinutes(daDef.ClockRunningTime);
                    daDef.ClosedAt = newCloseAt.Date.AddHours(newCloseAt.Hour);
                    daDef.ClosedTime = newCloseAt.Minute;

                    _repositoryFactory.GetDutchAuctionDefineRepository().Store(daDef);
                }
                transactionManager.CommitTransaction();
            }
            catch (Exception exception)
            {
                transactionManager.RollbackTransaction();
                Log.Info(exception.Message);
            }

            Log.Info("Finish Find Dutch Auction");
        }

        private void DutchAuction4CompositeProduct()
        {
            Log.Info("Find Dutch Auction for Composite Product Just Closed to restart again");
            IList<DutchAuction4CompositeProduct> auctionDefines = Logistics.Data.Services.DutchAuctionServices.GetDutchAuction4CompositeProductJustTimeOut();

            if (auctionDefines.Count <= 0)
            {
                Log.Info("Not found Dutch Auction for Composite Product Running Timeout");
                return;
            }

            Log.Info(string.Format("Found {0} Dutch Auctions for Composite Product Running Timeout", auctionDefines.Count));
            foreach (DutchAuction4CompositeProduct daDef in auctionDefines)
            {
                try
                {
                    _repositoryFactory.GetDutchAuction4CompositeProductRepository().Refresh(daDef);

                    int clockRunningTime = daDef.ClockRunningTime;
                    if (clockRunningTime <= 0) clockRunningTime = (int)(daDef.CloseAt - daDef.StartAt).TotalMinutes;

                    daDef.StartAt = DateTime.Now.AddMinutes(1);
                    daDef.CloseAt = daDef.StartAt.AddMinutes(clockRunningTime);

                    if (daDef.CloseAt.Date > daDef.ToDate.Date) continue;

                    daDef.ClockRunningTime = clockRunningTime;
                    Logistics.Data.Services.DutchAuctionServices.UpdateDutchAuction4CompositeProd(daDef);
                    Log.Info(string.Format("----> Composite Product ->  Already reset auction time for : {0}", daDef.Uid));
                }
                catch (Exception exception)
                {
                    Log.Error(exception);
                }

            }

            Log.Info("Finish Find Dutch Auction for Composite Product");
        }

        //private static decimal CalculateTheNewPrice(DutchAuctionDefine auctionDefine)
        //{
        //    decimal maxPrice = auctionDefine.MaxPrice;
        //    decimal minPrice = auctionDefine.MinPrice;
        //    decimal priceDistance = maxPrice - minPrice;

        //    DateTime startAt = auctionDefine.StartAt;
        //    startAt = startAt.AddMinutes(auctionDefine.StartTime);

        //    DateTime closedAt = auctionDefine.ClosedAt;
        //    closedAt = closedAt.AddMinutes(auctionDefine.ClosedTime);
        //    var minuteDistance = (int)((TimeSpan)(closedAt - startAt)).TotalMinutes;

        //    Log.Info(string.Format("The price decrement per minutes: {0} for Dutch Auction Id: {1}", priceDistance / minuteDistance, auctionDefine.Uid.ToString()));
        //    return (priceDistance / minuteDistance);
        //}

        #endregion
    }
}
