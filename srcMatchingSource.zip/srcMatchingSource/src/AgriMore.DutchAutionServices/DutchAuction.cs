﻿using System.ComponentModel;
using System.ServiceProcess;
using System.Threading;
using log4net;

namespace AgriMore.DutchAutionServices
{
    [RunInstaller(true)]
    public class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            // This call is required by the Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitComponent call 
            //string keyName = "AgriMORESchedulerAutoRestart";
            //string assemblyLocation = Assembly.GetExecutingAssembly().Location;  // Or the EXE path.

            //// Set Auto-start.
            //Util.SetAutoStart(keyName, assemblyLocation);
        }

        private void InitializeComponent()
        {
            var serviceInstall = new ServiceInstaller();
            var serviceProcessInstall = new ServiceProcessInstaller();

            //serviceInstall.ServiceName = "AgriMOREDutchAuction"; // this must match the ServiceName specified in WindowsService1.
            //serviceInstall.DisplayName = "AgriMORE Dutch Auction"; // this will be displayed in the Services Manager.
            //serviceInstall.Description = "AgriMORE applications";

            serviceInstall.ServiceName = "AgriMOREDutchAuction - Foodtworks"; // this must match the ServiceName specified in WindowsService1.
            serviceInstall.DisplayName = "AgriMORE Dutch Auction - Foodtworks"; // this will be displayed in the Services Manager.
            serviceInstall.Description = "AgriMORE applications";
            serviceInstall.StartType = ServiceStartMode.Automatic;
            this.Installers.Add(serviceInstall);

            serviceProcessInstall.Account = System.ServiceProcess.ServiceAccount.LocalSystem; // run under the system account.
            serviceProcessInstall.Password = null;
            serviceProcessInstall.Username = null;
            this.Installers.Add(serviceProcessInstall);
        }
    }

    public partial class DutchAuction : ServiceBase
    {
        private Job _dutchAuctionJob;
        private Timer _dutchAuctionStateTimer;
        private TimerCallback _dutchAuctionDelegate;
        private static readonly ILog Log = LogManager.GetLogger("GeneralLog");

        public DutchAuction()
        {
            InitializeComponent();
            log4net.Config.XmlConfigurator.Configure();
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            Log.Info("AgriMORE DutchAuction Service OnStart");

            _dutchAuctionJob = new DutchAuctionJob();

#if DEBUG
            _dutchAuctionJob.Execute(null);
#else
            _dutchAuctionDelegate = new TimerCallback(_dutchAuctionJob.Execute);
            _dutchAuctionStateTimer = new Timer(_dutchAuctionDelegate, this, 1000, 60000);
#endif
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            Log.Info("AgriMORE Dutch Auction Service OnStop");
            _dutchAuctionStateTimer.Dispose();
        }
    }
}
