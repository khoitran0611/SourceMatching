using System;

namespace Agrimore.ForecastServices
{
    public class MappingCategory : Mapping
    {
        public MappingCategory()
        {
            base.Initialize("category");
        }

        public int this[string key]
        {
            get { return Convert.ToInt32(base[key]); }
        }
    }
}
