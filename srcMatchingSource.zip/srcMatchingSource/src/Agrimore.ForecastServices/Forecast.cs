using System;
using System.ComponentModel;
using System.ServiceProcess;
using log4net;
using System.Configuration;
using System.Threading;

namespace Agrimore.ForecastServices
{
    [RunInstaller(true)]
    public class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            // This call is required by the Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitComponent call 
            //string keyName = "AgriMORESchedulerAutoRestart";
            //string assemblyLocation = Assembly.GetExecutingAssembly().Location;  // Or the EXE path.

            //// Set Auto-start.
            //Util.SetAutoStart(keyName, assemblyLocation);
        }

        private void InitializeComponent()
        {
            var serviceInstall = new ServiceInstaller();
            var serviceProcessInstall = new ServiceProcessInstaller();

            serviceInstall.ServiceName = "AgriMOREForecast"; // this must match the ServiceName specified in WindowsService1.
            serviceInstall.DisplayName = "AgriMORE Forecast"; // this will be displayed in the Services Manager.
            serviceInstall.Description = "AgriMORE applications";

            //serviceInstall.ServiceName = "AgriMOREForecast4Abbott"; // this must match the ServiceName specified in WindowsService1.
            //serviceInstall.DisplayName = "AgriMORE Forecast 4 Abbott"; // this will be displayed in the Services Manager.
            //serviceInstall.Description = "AgriMORE applications";
            serviceInstall.StartType = ServiceStartMode.Automatic;
            this.Installers.Add(serviceInstall);

            serviceProcessInstall.Account = System.ServiceProcess.ServiceAccount.LocalSystem; // run under the system account.
            serviceProcessInstall.Password = null;
            serviceProcessInstall.Username = null;
            this.Installers.Add(serviceProcessInstall);
        }
    }

    public partial class Forecast : ServiceBase
    {
        private Job _job,  _forcReminderJob;
        private Timer _stateTimer,_forcReminderStateTimer;
        private TimerCallback _timerDelegate,  _forcReminderDelegate;
        private static readonly ILog Log = LogManager.GetLogger("GeneralLog");

        public Forecast()
        {
            InitializeComponent();
            log4net.Config.XmlConfigurator.Configure();
        }

#if DEBUG
        public void Run()
        {
            OnStart(null);
        }
#endif

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            Log.Info("AgriMORE Forecast Service OnStart");
            int timerInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimerInterval"]) * 5;

            //_job = new ForecastJob();
            _forcReminderJob = new ForecastReminderJob();

#if DEBUG
            //_job.Execute(null);
            _forcReminderJob.Execute(null);
#else
            //_timerDelegate = new TimerCallback(_job.Execute);
            //_stateTimer = new Timer(_timerDelegate, this, 1000, timerInterval * 24);

            _forcReminderDelegate = new TimerCallback(_forcReminderJob.Execute);
            _forcReminderStateTimer = new Timer(_forcReminderDelegate, this, 1000, timerInterval * 12);
#endif
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            Log.Info("AgriMORE Forecast Service OnStop");
            //_stateTimer.Dispose();
            _forcReminderStateTimer.Dispose();
        }
    }
}
