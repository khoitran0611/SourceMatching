using System;

namespace Agrimore.ForecastServices
{
    public class MappingUom : Mapping
    {
        public MappingUom()
        {
            base.Initialize("uom");
        }

        public int this[string key]
        {
            get { return Convert.ToInt32(base[key]); }
        }
    }
}
