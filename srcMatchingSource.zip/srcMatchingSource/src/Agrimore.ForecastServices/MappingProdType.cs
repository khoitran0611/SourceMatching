using System;

namespace Agrimore.ForecastServices
{
    public class MappingProdType : Mapping
    {
        public MappingProdType()
        {
            base.Initialize("ProdType");
        }

        public int this[string key]
        {
            get { return Convert.ToInt32(base[key]); }
        }
    }
}
