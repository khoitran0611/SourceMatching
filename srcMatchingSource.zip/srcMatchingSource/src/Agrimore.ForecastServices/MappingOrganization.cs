using System;
using System.Collections.Generic;
using System.Text;

namespace Agrimore.ForecastServices
{
    public class MappingOrganization : Mapping
    {
        public MappingOrganization()
        {
            base.Initialize("organization");
        }

        public string this[string key]
        {
            get { return Convert.ToString(base[key]); }
        }
    }
}
