﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace Agrimore.ForecastServices
{
    public class DutchAuctionJob : Job
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            log.Info("Find Dutch Auction Just Closed to restart again");
            IList<DutchAuctionDefine> auctionDefines = new List<DutchAuctionDefine>(repositoryFactory.GetDutchAuctionDefineRepository().Find(
                new DutchAuctionsJustTimeOutSpecification()));
            //new DutchAuctionsRunningSpecification()));

            if (auctionDefines.Count <= 0)
            {
                log.Info("Not found Dutch Auction Running Timeout");
                return;
            }

            log.Info(string.Format("Found {0} Dutch Auctions Running Timeout", auctionDefines.Count));
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                foreach (DutchAuctionDefine daDef in auctionDefines)
                {
                    repositoryFactory.GetDutchAuctionDefineRepository().Refresh(daDef);

                    DateTime newStartAt = DateTime.Now.Date;
                    newStartAt = newStartAt.AddHours(DateTime.Now.Hour);
                    daDef.StartAt = newStartAt;
                    daDef.StartTime = DateTime.Now.Minute;

                    DateTime newStAt = newStartAt.AddMinutes(DateTime.Now.Minute);
                    DateTime newCloseAt = newStAt.AddMinutes(daDef.ClockRunningTime);
                    daDef.ClosedAt = newCloseAt.Date.AddHours(newCloseAt.Hour);
                    daDef.ClosedTime = newCloseAt.Minute;

                    repositoryFactory.GetDutchAuctionDefineRepository().Store(daDef);
                }
                transactionManager.CommitTransaction();
            }
            catch (Exception exception)
            {
                transactionManager.RollbackTransaction();
                log.Info(exception.Message);
            }

            log.Info("Find Dutch Auction Just Closed");
        }

        #region Private Methods
        private static decimal CalculateTheNewPrice(DutchAuctionDefine auctionDefine)
        {
            decimal maxPrice = auctionDefine.MaxPrice;
            decimal minPrice = auctionDefine.MinPrice;
            decimal priceDistance = maxPrice - minPrice;

            DateTime startAt = auctionDefine.StartAt;
            startAt = startAt.AddMinutes(auctionDefine.StartTime);

            DateTime closedAt = auctionDefine.ClosedAt;
            closedAt = closedAt.AddMinutes(auctionDefine.ClosedTime);
            var minuteDistance = (int)((TimeSpan)(closedAt - startAt)).TotalMinutes;

            log.Info(string.Format("The price decrement per minutes: {0} for Dutch Auction Id: {1}", priceDistance / minuteDistance, auctionDefine.Uid.ToString()));
            return (priceDistance / minuteDistance);
        }

        #endregion
    }
}
