using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using System.Data;

namespace Agrimore.ForecastServices
{
    public class PackagingJob : Job
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            int endOfDayManifestTime = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EndOfDayManifestTime"]);
            if (DateTime.Now.Hour != endOfDayManifestTime) return;

            log.Info("Check and update Packaging value");
            string ftpUrl = System.Configuration.ConfigurationManager.AppSettings["FtpUrlProductPackaging"];
            string ftpUser = System.Configuration.ConfigurationManager.AppSettings["FtpProdPackUser"];
            string ftpPassword = System.Configuration.ConfigurationManager.AppSettings["FtpProdPackPassword"];

            string forecastFile = GetFile(ftpUrl, ftpUser, ftpPassword, "Packaging");

            if (string.IsNullOrEmpty(forecastFile))
            {
                log.Info("Can not dowload an Packaging file");
                return;
            }

            UTF8Encoding enc = new UTF8Encoding();
            string[] result = File.ReadAllLines(forecastFile, Encoding.Default);
            FileStream fs = new FileStream(forecastFile, FileMode.Create);
            BinaryWriter br = new BinaryWriter(fs, Encoding.UTF8);

            for (int t = 0; t < result.Length; t++)
            {
                byte[] buffer = enc.GetBytes(result[t]);
                br.Write(buffer);
            }
            br.Flush(); br.Close(); fs.Close();

            DataSet dsForecasts = new DataSet("Packaging");
            dsForecasts.ReadXml(forecastFile);

            DataRow[] rows = dsForecasts.Tables["Packaging"].Select("TradingID is not NULL");

            for (int i = 0; i < rows.Length; i++)
            {
                Packaging pack = MapToPackaging(rows[i]);
                if (pack == null) continue;

                TransactionManager transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    repositoryFactory.GetPackagingRepository().Add(pack);
                    transactionManager.CommitTransaction();
                }
                catch (ArgumentNullException exception)
                {
                    transactionManager.RollbackTransaction();
                    log.Debug(exception.Message);
                }
                catch (ArgumentException exception)
                {
                    transactionManager.RollbackTransaction();
                    log.Debug(exception.Message);
                }
            }
            dsForecasts.Dispose();
            log.Info("Finish check update Packaging value");
        }

        private Packaging MapToPackaging(DataRow row)
        {
            try
            {
                //int geenTekId = Convert.ToInt32(row["TradingID"]);
                long chainEntityId = Convert.ToInt64(row["TradingID"]);
                log.Info(string.Format("Chain EntityId {0}", chainEntityId));
                //ICollection<Organization> orgs = repositoryFactory.GetOrganizationRepository().Find(new OrganizationByGreenTekIdSpecification(geenTekId));
                ChainEntity chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(chainEntityId);

                if (chainEntity == null)
                {
                    log.Info(string.Format("Can not found Chain Entity! Chain Entity Id {0}", chainEntityId));
                    return null;
                }

                if (chainEntity.Organizations == null || chainEntity.Organizations.Count <= 0)
                {
                    log.Info(string.Format("Can not found SAL Organization! Chain Entity Id {0}", chainEntityId));
                    return null;
                }

                Organization slOrg = null;
                var tradingTypes = new string[] { "SAL", "BUY", "TRD" };
                foreach (Organization org in chainEntity.Organizations) if (tradingTypes.Contains(org.BusinessType)) slOrg = org;
                if (slOrg == null)
                {
                    log.Info(string.Format("Can not found SAL Organization! Chain Entity Id {0}", chainEntityId));
                    return null;
                }

                string tradingName = Convert.ToString(row["TradingCorp"]);
                int packagingCode = Convert.ToInt32(row["Packaging_Code"]);
                int productId = Convert.ToInt32(row["Product"]);
                int colorId = Convert.ToInt32(row["Colour"]);
                int catTypeId = Convert.ToInt32(row["CategoryType"]);
                int categoryId = Convert.ToInt32(row["Category"]);
                string packagingDesc = Convert.ToString(row["Packaging_Description"]);

                log.Info(string.Format("Find item: TradingId {0}, Packaging Code {1}, ProductId {2}, ColorId {3}, Category Type {4}, Category {5}",
                        slOrg.Uid, packagingCode, productId, colorId, catTypeId, categoryId));

                ICollection<Packaging> packaging = repositoryFactory.GetPackagingRepository().Find(
                    new GetOnePackagingSpecification(packagingCode, productId, colorId, catTypeId, categoryId, slOrg.Uid));
                if (packaging != null && packaging.Count > 0)
                {
                    log.Info(string.Format("Already exist item: TradingId {0}, Packaging Code {1}, ProductId {2}, ColorId {3}, Category Type {4}, Category {5}",
                        slOrg.Uid, packagingCode, productId, colorId, catTypeId, categoryId));
                    return null;
                }

                Packaging pack = new Packaging(packagingCode, packagingDesc, productId, colorId, catTypeId, categoryId, slOrg.Uid);
                return pack;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                return null;
            }
        }
    }
}
