﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace Agrimore.ForecastServices
{
    public class ForecastReminderJob : Job
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            if (DateTime.Now.Hour != 6) return;//6 o'clock
            SendPriceUpdateReminder();

            string dayOfWeek = Convert.ToString(DateTime.Now.DayOfWeek);

            log.Info("Check Product Forecast to send alert email");
            ICollection<ForecastReminderDefine> reminderDefines = repositoryFactory.GetForecastReminderDefineRepository().AsCollection();

            foreach (ForecastReminderDefine reminderDefine in reminderDefines)
            {
                if (reminderDefine.OnlyForHarvestDays)
                {
                    foreach (var grower in reminderDefine.Growers)
                    {
                        var harvestDays = repositoryFactory.GetHarvestDayRepository().Find(new HarvestDaysForSendMail(grower.Uid));
                        string dateTime = HarvestDaysE.GetToDay();

                        foreach (var item in harvestDays)
                        {
                            if (item.DayOfWeek.Contains(HarvestDaysE.AllDays))
                            {
                                //Send email
                                ICollection<ProductSupplyForecast> productSupplyForecasts = repositoryFactory.GetProductSuppyForecastRepository().Find(
                                    new ForecastSupplyInPeriodSpecification(grower.Uid, item.FromDate, item.ToDate));

                                if (productSupplyForecasts == null || productSupplyForecasts.Count <= 0)
                                    SendAlertEmail(item.FromDate, item.ToDate, grower, reminderDefine);
                            }
                            else if (item.DayOfWeek.Contains(dateTime))
                            {
                                List<DateTime> listDateTime = new List<DateTime>();
                                if (!string.IsNullOrEmpty(item.OthersDay))
                                {
                                    string[] listOtherDays = item.OthersDay.Split(',');
                                    DateTime tempDateTime = DateTime.Now;
                                    if (listOtherDays.Length > 0)
                                    {
                                        for (int i = 0; i < listOtherDays.Length; i++)
                                        {
                                            if (DateTime.TryParse(listOtherDays[i], out tempDateTime))
                                            {
                                                listDateTime.Add(tempDateTime);
                                            }
                                        }
                                    }
                                }
                                for (int i = 0; i <= 7; i++)
                                {
                                    string reDateTime = HarvestDaysE.GetDay(item.FromDate.AddDays(i));
                                    if (item.DayOfWeek.Contains(reDateTime) || item.DayOfWeek.Contains(HarvestDaysE.WeekDays))
                                    {
                                        listDateTime.Add(item.FromDate.AddDays(i));
                                    }
                                }
                                if (listDateTime.Count > 0)
                                {
                                    bool isSendMail = false;
                                    foreach (var d in listDateTime)
                                    {
                                        if (DateTime.Now.Day == d.Day && DateTime.Now.Month == d.Month && DateTime.Now.Year == d.Year)
                                        {
                                            isSendMail = true;
                                        }
                                    }
                                    if (isSendMail)
                                    {
                                        //Send email
                                        ICollection<ProductSupplyForecast> productSupplyForecasts = repositoryFactory.GetProductSuppyForecastRepository().Find(
                                   new ForecastSupplyInPeriodSpecification(grower.Uid, item.FromDate, item.ToDate));

                                        if (productSupplyForecasts == null || productSupplyForecasts.Count <= 0)
                                            SendAlertEmail(item.FromDate, item.ToDate, grower, reminderDefine);
                                    }
                                }

                            }
                        }
                    }
                }
                else
                {
                    if (reminderDefine.FromDate <= DateTime.Now && reminderDefine.ToDate >= DateTime.Now && (reminderDefine.ReminderOn.Equals(dayOfWeek) || reminderDefine.ReminderOn.Equals("Everyday")))
                    {
                        DateTime fromDate = GetFirstDateOfNextWeek(DateTime.Now);
                        DateTime toDate = fromDate.AddDays(reminderDefine.ReminderPeriod * 7 - 1);

                        foreach (var grower in reminderDefine.Growers)
                        {
                            ICollection<ProductSupplyForecast> productSupplyForecasts = repositoryFactory.GetProductSuppyForecastRepository().Find(
                                new ForecastSupplyInPeriodSpecification(grower.Uid, fromDate, toDate));

                            if (productSupplyForecasts == null || productSupplyForecasts.Count <= 0)
                                SendAlertEmail(fromDate, toDate, grower, reminderDefine);
                        }
                    }
                }
            }

            log.Info("Finish check Product Forecast to send alert email");
        }

        private static DateTime GetFirstDateOfNextWeek(DateTime curDate)
        {
            DayOfWeek day = curDate.DayOfWeek;
            int days = day - DayOfWeek.Monday;
            DateTime start = DateTime.Now.AddDays(-days);
            return start.AddDays(7);
        }

        private void SendAlertEmail(DateTime fromDate, DateTime toDate, Organization grower, ForecastReminderDefine reminderDefine)
        {
            var listEmails = reminderDefine.Emails;
            ForecastReminderDefineEmail forecastReminderDefineEmail = null;
            //Default Enlish
            string language = LanguageE.English;
            var chain = grower.ChainEntities[0];
            if (!string.IsNullOrEmpty(grower.ChainEntities[0].PreferredLanguage))
            {
                language = chain.PreferredLanguage;
            }
            foreach (var email in listEmails)
            {
                if (email.LanguageCode.Equals(language, StringComparison.OrdinalIgnoreCase))
                {
                    forecastReminderDefineEmail = email;
                }
            }
            if (forecastReminderDefineEmail != null)
            {
                string emailSubject = forecastReminderDefineEmail.EmailSubject;
                emailSubject = emailSubject.Replace("${ToDayDate}", DateTime.Now.ToString("dd/MM/yyyy"));
                emailSubject = emailSubject.Replace("${FromDate}", fromDate.ToString("dd/MM/yyyy"));
                emailSubject = emailSubject.Replace("${ToDate}", toDate.ToString("dd/MM/yyyy"));
                emailSubject = emailSubject.Replace("${CompanyName}", grower.Name);


                string emailBody = forecastReminderDefineEmail.EmailBody;
                emailBody = emailBody.Replace("${ToDayDate}", DateTime.Now.ToString("dd/MM/yyyy"));
                emailBody = emailBody.Replace("${FromDate}", fromDate.ToString("dd/MM/yyyy"));
                emailBody = emailBody.Replace("${ToDate}", toDate.ToString("dd/MM/yyyy"));
                emailBody = emailBody.Replace("${CompanyName}", grower.Name);

                string toEmail = chain.ReminderEmail;

                if (!string.IsNullOrEmpty(grower.Email)) toEmail += "," + grower.Email;

                EmailSender.SendMail(emailSubject, emailBody, toEmail, reminderDefine.CcEmail);
            }
        }


        public void SendPriceUpdateReminder()
        {
            var listShippedProducts = repositoryFactory.GetProductSuppyForecastRepository().Find(new ProductSupplyForecastShipped());
            var listPriceUpdateReminderEmails = repositoryFactory.GetPriceUpdateReminderDefineRepository();

            foreach (var shippedProduct in listShippedProducts)
            {
                if (!string.IsNullOrEmpty(shippedProduct.PurchaseOrgId))
                {
                    var buyer = repositoryFactory.GetOrganizationRepository().GetOne(shippedProduct.PurchaseOrgId);
                    if (buyer != null)
                    {
                        foreach (var email in listPriceUpdateReminderEmails)
                        {
                            if (email.Buyers.Contains(buyer))
                            {
                                //Send email to buyer
                                SendAlertEmail(buyer, email);
                            }
                        }
                    }
                }
            }
        }

        private void SendAlertEmail(Organization buyer, PriceUpdateReminderDefine email)
        {
            PriceUpdateReminderDefineEmail priceUpdateReminderDefineEmail = null;
            string language = LanguageE.English;
            var chain = buyer.ChainEntities[0];
            if (!string.IsNullOrEmpty(buyer.ChainEntities[0].PreferredLanguage))
            {
                language = chain.PreferredLanguage;
            }
            foreach (var em in email.Emails)
            {
                if (em.LanguageCode.Equals(language, StringComparison.OrdinalIgnoreCase))
                {
                    priceUpdateReminderDefineEmail = em;
                }
            }
            if (priceUpdateReminderDefineEmail != null)
            {
                string emailSubject = priceUpdateReminderDefineEmail.EmailSubject;
                emailSubject = emailSubject.Replace("${ToDayDate}", DateTime.Now.ToString("dd/MM/yyyy"));


                string emailBody = priceUpdateReminderDefineEmail.EmailBody;
                emailBody = emailBody.Replace("${ToDayDate}", DateTime.Now.ToString("dd/MM/yyyy"));

                string toEmail = chain.PriceUpdateReminderEmail;

                if (!string.IsNullOrEmpty(buyer.Email)) toEmail += "," + buyer.Email;

                EmailSender.SendMail(emailSubject, emailBody, toEmail, email.CcEmail);
            }
        }
    }
}
