using System;

namespace Agrimore.ForecastServices
{
    public class MappingColor : Mapping
    {
        public MappingColor()
        {
            base.Initialize("color");
        }

        public int this[string key]
        {
            get { return Convert.ToInt32(base[key]); }
        }
    }
}
