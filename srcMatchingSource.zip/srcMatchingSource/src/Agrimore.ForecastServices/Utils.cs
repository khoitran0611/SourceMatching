﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agrimore.ForecastServices
{
    public class LanguageE
    {
        public static string English = "en-US";
        public static string Dutch = "nl-NL";
        public static string German = "de-DE";
    }

    public class HarvestDaysE
    {
        public static string AllDays = "AllDays";
        public static string Monday = "Monday";
        public static string WeekDays = "WeekDays";
        public static string Tuesday = "Tuesday";
        public static string Wednesday = "Wednesday";
        public static string Thursday = "Thursday";
        public static string Friday = "Friday";
        public static string Saturday = "Saturday";
        public static string Sunday = "Sunday";

        public static string GetToDay()
        {
            DateTime dt = DateTime.Now;
            if (dt.DayOfWeek == DayOfWeek.Monday)
            {
                return Monday;
            }
            if (dt.DayOfWeek == DayOfWeek.Tuesday)
            {
                return Tuesday;
            }
            if (dt.DayOfWeek == DayOfWeek.Wednesday)
            {
                return Wednesday;
            }
            if (dt.DayOfWeek == DayOfWeek.Thursday)
            {
                return Thursday;
            }
            if (dt.DayOfWeek == DayOfWeek.Friday)
            {
                return Friday;
            }
            if (dt.DayOfWeek == DayOfWeek.Saturday)
            {
                return Saturday;
            }
            if (dt.DayOfWeek == DayOfWeek.Sunday)
            {
                return Sunday;
            }
            return "";
        }

        public static string GetDay(DateTime dt)
        {
            if (dt.DayOfWeek == DayOfWeek.Monday)
            {
                return Monday;
            }
            if (dt.DayOfWeek == DayOfWeek.Tuesday)
            {
                return Tuesday;
            }
            if (dt.DayOfWeek == DayOfWeek.Wednesday)
            {
                return Wednesday;
            }
            if (dt.DayOfWeek == DayOfWeek.Thursday)
            {
                return Thursday;
            }
            if (dt.DayOfWeek == DayOfWeek.Friday)
            {
                return Friday;
            }
            if (dt.DayOfWeek == DayOfWeek.Saturday)
            {
                return Saturday;
            }
            if (dt.DayOfWeek == DayOfWeek.Sunday)
            {
                return Sunday;
            }
            return "";
        }
    }
}
