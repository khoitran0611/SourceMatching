using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Configuration;
using AgriMore.Logistics.Domain;
using System.Data;
using System.IO;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Repository;

namespace Agrimore.ForecastServices
{
    public class EmailSender
    {
        public static void SendMail(string subject, string body, string to, string ccs)
        {
            string username = ConfigurationManager.AppSettings["smtp.username"];
            SmtpClient smtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtp.host"],
                int.Parse(ConfigurationManager.AppSettings["smtp.port"]));

            smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"]);

            if (!string.IsNullOrEmpty(username))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential(username,
                    ConfigurationManager.AppSettings["smtp.password"]);
            }

            MailMessage message = new MailMessage(ConfigurationManager.AppSettings["smtp.from"], to);

            message.Subject = subject;
            message.Body = body;

            if (!string.IsNullOrEmpty(ccs))
            {
                string[] ccAddress = ccs.Split(',');
                for (int i = 0; i < ccAddress.Length; i++) if (!string.IsNullOrEmpty(ccAddress[i])) message.CC.Add(ccAddress[i]);
            }

            smtpClient.Send(message);
        }

        public static string SendAlertEmail(ProductSupplyForecast prdSf)
        {
            // ReSharper disable AssignNullToNotNullAttribute
            string mailContentPath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "AlertEmail.xml");
            // ReSharper restore AssignNullToNotNullAttribute

            DataSet alertEmail = new DataSet("AlertEmail");
            alertEmail.ReadXml(mailContentPath);
            DataRow[] rows = alertEmail.Tables["AlertEmail"].Select();

            string strSubject = Convert.ToString(rows[0]["subject"]);
            string strBody = Convert.ToString(rows[0]["body"]);

            strBody = strBody.Replace("${Product}", prdSf.Species.Name);
            strBody = strBody.Replace("${Colour}", prdSf.Color.Name);
            strBody = strBody.Replace("${CategoryType}", prdSf.CategoryType.Name);
            strBody = strBody.Replace("${Category}", prdSf.Category.Name);
            strBody = strBody.Replace("${Supplier}", prdSf.Organization.Name);
            strBody = strBody.Replace("${DeliveryDate}", prdSf.AvailableDate.ToString("dd/MM/yyyy"));

            SendMail(strSubject, strBody, GetAdminUserEmails(), string.Empty);
            return strBody;
        }

        private static string GetAdminUserEmails()
        {
            string userEmails = string.Empty;
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            string[] userIds = System.Configuration.ConfigurationManager.AppSettings["AdminUsers"].Split(',');

            foreach (string userId in userIds)
            {
                ICollection<User> users = repositoryFactory.GetUserRepository().Find(new UserByUserNameSpecification(userId));
                if (users != null && users.Count > 0) foreach (User user in users) if (!string.IsNullOrEmpty(user.Email)) userEmails += user.Email + ",";
            }

            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }
    }
}
