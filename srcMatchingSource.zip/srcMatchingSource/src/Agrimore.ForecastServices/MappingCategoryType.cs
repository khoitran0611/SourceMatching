using System;

namespace Agrimore.ForecastServices
{
    public class MappingCategoryType : Mapping
    {
        public MappingCategoryType()
        {
            base.Initialize("categoryType");
        }

        public int this[string key]
        {
            get { return Convert.ToInt32(base[key]); }
        }
    }
}
