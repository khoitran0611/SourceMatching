using System;
using System.IO;
using System.Data;
using System.Collections.Generic;

namespace Agrimore.ForecastServices
{
    public abstract class Mapping
    {
        protected IDictionary<string, object> dictionary;

        public virtual void Initialize(string tableName)
        {
            string dataFile = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "GreenTekMapping.xml");
            DataSet dsData = new DataSet(tableName);
            dsData.ReadXml(dataFile);

            dictionary = new Dictionary<string, object>();
            DataRow[] rows = dsData.Tables[tableName].Select("ID is not NULL");
            foreach (DataRow t in rows)
            {
                string key = Convert.ToString(t["Name"]);
                if (!dictionary.ContainsKey(key)) dictionary.Add(key, t["ID"]);
            }

            dsData.Dispose();
        }

        public virtual object this[string key]
        {
            get { return dictionary[key]; }
        }

        public virtual bool ContainsKey(string key)
        {
            return dictionary.ContainsKey(key);
        }
    }
}
