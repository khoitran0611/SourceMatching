using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using System.Data;

namespace Agrimore.ForecastServices
{
    public class ArticleCodeJob : Job
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        public override void Run()
        {
            int endOfDayManifestTime = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EndOfDayManifestTime"]);
            if (DateTime.Now.Hour != endOfDayManifestTime) return;

            log.Info("Check and update article value");
            string ftpUrl = System.Configuration.ConfigurationManager.AppSettings["FtpUrlArticleCode"];
            string ftpUser = System.Configuration.ConfigurationManager.AppSettings["FtpUser"];
            string ftpPassword = System.Configuration.ConfigurationManager.AppSettings["FtpPassword"];

            string articleCodeFile = GetFile(ftpUrl, ftpUser, ftpPassword, string.Empty);

            if (string.IsNullOrEmpty(articleCodeFile))
            {
                log.Info("Can not dowload an forecast file");
                return;
            }

            DataSet dsArticles = new DataSet("Artikel");
            dsArticles.ReadXml(articleCodeFile);

            DataRow[] rows = dsArticles.Tables["Artikel"].Select("Afnemer_ID is not NULL");
            for (int i = 0; i < rows.Length; i++)
            {
                ArticleCode artCode = MappingArticleCode(rows[i]);

                if (artCode == null) continue;
                TransactionManager transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    repositoryFactory.GetArticleCodeRepository().Add(artCode);
                    transactionManager.CommitTransaction();
                }
                catch (ArgumentNullException exception)
                {
                    transactionManager.RollbackTransaction();
                    log.Debug(exception.Message);
                }
                catch (ArgumentException exception)
                {
                    transactionManager.RollbackTransaction();
                    log.Debug(exception.Message);
                }
            }

            log.Info("Finish check update article code");
        }

        private ArticleCode MappingArticleCode(DataRow row)
        {
            int greenTekId = Convert.ToInt32(row["Afnemer_ID"]);
            string tradingOrgName = Convert.ToString(row["Afnemer"]);
            string articleCode = Convert.ToString(row["Artikel_ID"]);
            string articleDesc = Convert.ToString(row["Artikel_Omschrijving"]);
            int totalAmount = Convert.ToInt32(row["Stuks"]);

            ICollection<ArticleCode> artCodes = repositoryFactory.GetArticleCodeRepository().Find(
                new ArticleCodeByGreenTekIdAndCodeSpecification(greenTekId, articleCode));
            if (artCodes != null && artCodes.Count > 0)
            {
                log.Info(string.Format("Green Tek Id: {0} and Article Code: {1} is already exist!", greenTekId, articleCode));
                return null;
            }

            ICollection<Organization> orgs = repositoryFactory.GetOrganizationRepository().Find(
                new OrganizationByGreenTekIdSpecification(greenTekId));
            if (orgs == null || orgs.Count <= 0)
            {
                log.Info(string.Format("Can not found Organization for Trading Id: {0}!", tradingOrgName));
                return null;
            }

            Organization tradingOrg = null;
            foreach (Organization org in orgs) if ("SAL".Equals(org.BusinessType)) tradingOrg = org;

            if (tradingOrg == null)
            {
                log.Info("Can not found Organization");
                return null;
            }

            ArticleCode artCode = new ArticleCode(greenTekId, articleCode, articleDesc, totalAmount, tradingOrg.Uid);
            artCode.InsertedDate = DateTime.Now.Date;

            return artCode;
        }
    }
}
