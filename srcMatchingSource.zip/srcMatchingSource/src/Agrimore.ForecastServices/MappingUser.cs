using System;
using System.Collections.Generic;
using System.Text;

namespace Agrimore.ForecastServices
{
    public class MappingUser : Mapping
    {
        public MappingUser()
        {
            base.Initialize("user");
        }

        public int this[string key]
        {
            get { return Convert.ToInt32(base[key]); }
        }
    }
}
