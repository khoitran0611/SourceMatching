using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using System.IO;
using System.Data;
using AgriMore.Logistics.Domain.Transaction;

namespace Agrimore.ForecastServices
{
    public class FinalizingBidJob : Job
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            log.Info("Find Won Bidding");
            IList<BiddingDefine> biddingDefines = new List<BiddingDefine>(repositoryFactory.GetBiddingDefineRepository().Find(new FinalizingBiddingSpecification()));
            if (biddingDefines.Count <= 0)
            {
                log.Info("Not found Bidding Options");
                return;
            }

            //IList<BiddingDefine> biddingDefines = new List<BiddingDefine>();
            //biddingDefines.Add(repositoryFactory.GetBiddingDefineRepository().GetOne(17));
            log.Info(string.Format("Found {0} Bidding Options", biddingDefines.Count));

            foreach (BiddingDefine bidDef in biddingDefines)
            {
                if (bidDef.MinPrice == bidDef.CurBidPrice)
                {
                    var transactionManager = new TransactionManager();
                    try
                    {
                        transactionManager.BeginTransaction();
                        log.Info(string.Format("Remove Bidding Option on product ID {0} with amount {1}", bidDef.ProdSupForecast.Uid, bidDef.Amount));

                        repositoryFactory.GetBiddingDefineRepository().Remove(bidDef);

                        transactionManager.CommitTransaction();
                    }
                    catch (Exception exception)
                    {
                        transactionManager.RollbackTransaction();
                        log.Info(exception.Message);
                    }
                }
                else
                    SendMailConfirm(bidDef);
            }

            log.Info("Finish");
        }

        #region Private Methods
        private void SendMailConfirm(BiddingDefine biddingDefine)
        {
            log.Info("Begin Send Finalizing Bid Email");
            try
            {
                IList<BiddingProcess> listBidProcess = new List<BiddingProcess>(repositoryFactory.GetBiddingProcessRepository().Find(new BiddingProcessOnBidOptionSpecification(biddingDefine)));
                if (listBidProcess.Count <= 0) return;

                BiddingProcess winBiding = listBidProcess[0];
                // ReSharper disable AssignNullToNotNullAttribute
                string mailContentPath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "FinalizingBid.xml");
                // ReSharper restore AssignNullToNotNullAttribute

                var comfirmEmail = new DataSet("FinalizingBid");
                comfirmEmail.ReadXml(mailContentPath);
                DataRow[] rows = comfirmEmail.Tables["FinalizingBid"].Select();
                Organization growerOrg = repositoryFactory.GetOrganizationRepository().GetOne(biddingDefine.ProdSupForecast.Organization.Uid);

                string strSubject = Convert.ToString(rows[0]["subject"]);
                string strBody = Convert.ToString(rows[0]["body"]);

                Organization buyerOrg = repositoryFactory.GetOrganizationRepository().GetOne(winBiding.Organization.Uid);
                log.Info(string.Format("Won Bidding TC: {0}", buyerOrg.Name));

                strSubject = strSubject.Replace("${BuyerTC}", buyerOrg.Name);
                strSubject = strSubject.Replace("${Supplier}", growerOrg.Name);
                strSubject = strSubject.Replace("${DeliveryDate}", biddingDefine.ProdSupForecast.AvailableDate.ToString("dd/MM/yyyy"));
                strSubject = strSubject.Replace("${Species}", biddingDefine.ProdSupForecast.Species.Name);
                strSubject = strSubject.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);
                log.Info(string.Format("Seller TC: {0}", growerOrg.TradingOrganizations[0].Name));

                strBody = strBody.Replace("${BiddedDate}", winBiding.BiddedDate.ToString("dd/MM/yyyy HH:mm"));
                strBody = strBody.Replace("${BuyerTC}", buyerOrg.Name);
                strBody = strBody.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);

                strBody = strBody.Replace("${UniqueID}", biddingDefine.ProdSupForecast.Uid.ToString());
                strBody = strBody.Replace("${DeliveryDate}", biddingDefine.ProdSupForecast.AvailableDate.ToString("dd/MM/yyyy"));
                strBody = strBody.Replace("${AvailableAmount}", biddingDefine.Amount.ToString());
                strBody = strBody.Replace("${AmountUOM}", biddingDefine.ProdSupForecast.Uom.Name);
                strBody = strBody.Replace("${Price}", winBiding.BiddedPrice.ToString());
                strBody = strBody.Replace("${Currency}", biddingDefine.Currency);

                strBody = strBody.Replace("${Species}", biddingDefine.ProdSupForecast.Species.Name);
                strBody = strBody.Replace("${Colour}", biddingDefine.ProdSupForecast.Color.Name);
                strBody = strBody.Replace("${CategoryType}", biddingDefine.ProdSupForecast.CategoryType.Name);
                strBody = strBody.Replace("${Category}", biddingDefine.ProdSupForecast.Category.Name);

                Address address = null;
                if (growerOrg.ChainEntities != null && growerOrg.ChainEntities.Count >= 0)
                {
                    var chainEntity = growerOrg.ChainEntities[0];
                    var listAddress = new List<Address>(chainEntity.Addresses);
                    if (listAddress.Count > 0) address = listAddress[0];
                }

                log.Info(string.Format("Supplier Organization: {0}", growerOrg.Name));
                strBody = strBody.Replace("${Supplier}", growerOrg.Name);
                strBody = strBody.Replace("${Street}", (address != null) ? address.StreetName : string.Empty);
                strBody = strBody.Replace("${HouseNumber}", (address != null) ? address.StreetNumber +
                    (!string.IsNullOrEmpty(address.NumberExtension) ? string.Format("/{0}", address.NumberExtension) : string.Empty) : string.Empty);
                strBody = strBody.Replace("${PostalCode}", (address != null) ? address.ZipCode : string.Empty);
                strBody = strBody.Replace("${City}", (address != null) ? address.City : string.Empty);
                strBody = strBody.Replace("${ExtraInfomation}", biddingDefine.ProdSupForecast.Remarks);

                //string toEmail = System.Configuration.ConfigurationManager.AppSettings["BofEmailAddress"];
                string buyerEmail = GetUserEmail(buyerOrg);
                string ccToEmail = GetCcEmailAddress(biddingDefine);
                log.Info(string.Format("Sent Finalizing Bid email to {0} and cc to {1}", buyerEmail, ccToEmail));

                EmailSender.SendMail(strSubject, strBody, buyerEmail, ccToEmail);
            }
            catch (Exception ex)
            {
                log.Info(ex.Message);
            }
        }

        //private string GetCcEmailAddress(BiddingProcess bidProcess, BiddingDefine bidDefine)
        private string GetCcEmailAddress(BiddingDefine bidDefine)
        {
            string ccEmails = string.Empty;
            ProductSupplyForecast prdSupplier = repositoryFactory.GetProductSuppyForecastRepository().GetOne(bidDefine.ProdSupForecast.Uid);
            if (prdSupplier.User != null && !string.IsNullOrEmpty(prdSupplier.User.Email))
                ccEmails += prdSupplier.User.Email + ",";

            //Organization buyerOrg = repositoryFactory.GetOrganizationRepository().GetOne(bidProcess.Organization.Uid);
            //string buyerEmail = GetUserEmail(buyerOrg);
            //if (!string.IsNullOrEmpty(buyerEmail)) ccEmails += buyerEmail + ',';

            Organization supplierOrg = repositoryFactory.GetOrganizationRepository().GetOne(prdSupplier.Organization.Uid);
            string selerEmail = GetUserEmail(supplierOrg.TradingOrganizations[0]);

            ccEmails += GetAdminUserEmails() + "," + ccEmails;
            if (!string.IsNullOrEmpty(ccEmails)) ccEmails = ccEmails.Substring(0, ccEmails.Length - 1);

            return ccEmails;
        }

        private string GetAdminUserEmails()
        {
            string userEmails = string.Empty;
            string[] userIds = System.Configuration.ConfigurationManager.AppSettings["AdminUsers"].Split(',');
            foreach (string userId in userIds)
            {
                ICollection<User> users = repositoryFactory.GetUserRepository().Find(new UserByUserNameSpecification(userId));
                if (users != null && users.Count > 0) foreach (User user in users) if (!string.IsNullOrEmpty(user.Email)) userEmails += user.Email + ",";
            }

            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }

        private string GetUserEmail(Organization org)
        {
            ChainEntity chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(org.ChainEntities[0].Uid);

            IEnumerable<User> users = chainEntity.Users;
            foreach (User user in users) if (!string.IsNullOrEmpty(user.Email)) return user.Email;

            return string.Empty;
        }

        private User GetUser(Organization org)
        {
            ChainEntity chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(org.ChainEntities[0].Uid);
            IList<User> users = new List<User>(chainEntity.Users);
            return users[0];
        }

        private Packaging GetOtherPakaging(ProductSupplyForecast prdFc, Organization buyerOrg)
        {
            IList<Packaging> packagings = new List<Packaging>(repositoryFactory.GetPackagingRepository().Find(
                new PackagingByTradingCorpSpecification(prdFc.Species.Uid, prdFc.Color.Uid, prdFc.CategoryType.Uid, prdFc.Category.Uid, buyerOrg.Uid)));

            if (packagings.Count <= 0) return null;

            return packagings[0];
        }
        #endregion
    }
}
//Organization buyerOrg = repositoryFactory.GetOrganizationRepository().GetOne(winBiding.Organization.Uid);

//strSubject = strSubject.Replace("${OtherTC}", buyerOrg.Name);
//strSubject = strSubject.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);
//strSubject = strSubject.Replace("${Supplier}", growerOrg.Name);
//strSubject = strSubject.Replace("${ProducerName}", biddingDefine.ProdSupForecast.Species.Name);
//strSubject = strSubject.Replace("${DeliveryDate}", biddingDefine.ProdSupForecast.AvailableDate.ToString("dd/MM/yyyy"));

//User loginUser = GetUser(winBiding.Organization);
//strBody = strBody.Replace("${ConfirmedDate}", biddingDefine.ClosedDate.ToString("dd/MM/yyyy"));
//strBody = strBody.Replace("${LoginOtherTCUser}", string.Format("{0} {1}", loginUser.FirstName, loginUser.LastName));
//strBody = strBody.Replace("${OtherTC}", buyerOrg.Name);
//strBody = strBody.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);

//strBody = strBody.Replace("${UniqueID}", biddingDefine.ProdSupForecast.Uid.ToString());
//strBody = strBody.Replace("${DeliveryDate}", biddingDefine.ProdSupForecast.AvailableDate.ToString("dd/MM/yyyy"));
//strBody = strBody.Replace("${DesiredAmount}", biddingDefine.Amount.ToString());
//strBody = strBody.Replace("${AvailableAmount}", biddingDefine.Amount.ToString());
//strBody = strBody.Replace("${AmountUOM}", biddingDefine.ProdSupForecast.Uom.Name);
//strBody = strBody.Replace("${Price}", winBiding.BiddedPrice.ToString());
//strBody = strBody.Replace("${Currency}", biddingDefine.Currency);

//strBody = strBody.Replace("${Species}", biddingDefine.ProdSupForecast.Species.Name);
//strBody = strBody.Replace("${Colour}", biddingDefine.ProdSupForecast.Color.Name);
//strBody = strBody.Replace("${CategoryType}", biddingDefine.ProdSupForecast.CategoryType.Name);
//strBody = strBody.Replace("${Category}", biddingDefine.ProdSupForecast.Category.Name);

//Address address = null;
//if (growerOrg.ChainEntities != null && growerOrg.ChainEntities.Count >= 0)
//{
//    var chainEntity = growerOrg.ChainEntities[0];
//    var listAddress = new List<Address>(chainEntity.Addresses);
//    if (listAddress.Count > 0) address = listAddress[0];
//}

//strBody = strBody.Replace("${Supplier}", growerOrg.Name);
//strBody = strBody.Replace("${Street}", (address != null) ? address.StreetName : string.Empty);
//strBody = strBody.Replace("${HouseNumber}", (address != null) ? address.StreetNumber +
//    (!string.IsNullOrEmpty(address.NumberExtension) ? string.Format("/{0}", address.NumberExtension) : string.Empty) : string.Empty);
//strBody = strBody.Replace("${PostalCode}", (address != null) ? address.ZipCode : string.Empty);
//strBody = strBody.Replace("${City}", (address != null) ? address.City : string.Empty);

//Packaging packaging = GetOtherPakaging(biddingDefine.ProdSupForecast, buyerOrg);
//strBody = strBody.Replace("${ArticleCodes}", (packaging != null) ? packaging.PackagingDesc : "Undefine");
//strBody = strBody.Replace("${ExtraInfomation}", biddingDefine.ProdSupForecast.Remarks);
//strBody = strBody.Replace("${Remarks}", string.Empty);