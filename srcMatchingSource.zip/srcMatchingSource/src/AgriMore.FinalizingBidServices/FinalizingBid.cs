﻿using System.ComponentModel;
using System.ServiceProcess;
using System.Threading;
using log4net;

namespace AgriMore.FinalizingBidServices
{
    [RunInstaller(true)]
    public class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            // This call is required by the Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitComponent call 
            //string keyName = "AgriMORESchedulerAutoRestart";
            //string assemblyLocation = Assembly.GetExecutingAssembly().Location;  // Or the EXE path.

            //// Set Auto-start.
            //Util.SetAutoStart(keyName, assemblyLocation);
        }

        private void InitializeComponent()
        {
            var serviceInstall = new ServiceInstaller();
            var serviceProcessInstall = new ServiceProcessInstaller();

            //serviceInstall.ServiceName = "AgriMOREFinalizingBid"; // this must match the ServiceName specified in WindowsService1.
            //serviceInstall.DisplayName = "AgriMORE Finalizing Bid"; // this will be displayed in the Services Manager.
            //serviceInstall.Description = "AgriMORE applications";

            serviceInstall.ServiceName = "AgriMOREFinalizingBid - Foodtworks"; // this must match the ServiceName specified in WindowsService1.
            serviceInstall.DisplayName = "AgriMORE Finalizing Bid - Foodtworks"; // this will be displayed in the Services Manager.
            serviceInstall.Description = "AgriMORE applications";
            serviceInstall.StartType = ServiceStartMode.Automatic;
            this.Installers.Add(serviceInstall);

            serviceProcessInstall.Account = System.ServiceProcess.ServiceAccount.LocalSystem; // run under the system account.
            serviceProcessInstall.Password = null;
            serviceProcessInstall.Username = null;
            this.Installers.Add(serviceProcessInstall);
        }
    }

    public partial class FinalizingBid : ServiceBase
    {
        private Job _finalizingBidJob;
        private Timer _finalizingBidStateTimer;
        private TimerCallback _finalizingBidDelegate;
        private static readonly ILog Log = LogManager.GetLogger("GeneralLog");

        public FinalizingBid()
        {
            InitializeComponent();
            log4net.Config.XmlConfigurator.Configure();
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            Log.Info("AgriMORE Finalizing Bid Service OnStart");
            //int timerInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimerInterval"]) * 5;

            _finalizingBidJob = new FinalizingBidJob();

#if DEBUG
            _finalizingBidJob.Execute(null);
#else
            _finalizingBidDelegate = new TimerCallback(_finalizingBidJob.Execute);
            _finalizingBidStateTimer = new Timer(_finalizingBidDelegate, this, 1000, 60000);
#endif
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            Log.Info("AgriMORE Finalizing Bid Service OnStop");
            _finalizingBidStateTimer.Dispose();
        }
    }
}
