using System;
using System.Linq;
using System.Collections.Generic;
using System.Net.Mail;
using System.Configuration;
using AgriMore.Logistics.Domain;
using System.Data;
using System.IO;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.FinalizingBidServices
{
    public class EmailSender
    {
        public static void SendMail(string subject, string body, string to, string ccs)
        {
            string username = ConfigurationManager.AppSettings["smtp.username"];
            SmtpClient smtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtp.host"],
                int.Parse(ConfigurationManager.AppSettings["smtp.port"]));

            smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"]);

            if (!string.IsNullOrEmpty(username))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential(username,
                    ConfigurationManager.AppSettings["smtp.password"]);
            }

            var message = new MailMessage();
            message.From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]);
            message.Subject = subject;
            message.Body = body;

            if (!string.IsNullOrEmpty(to))
            {
                to = to.Replace(';', ',');
                string[] toAddress = to.Split(',');
                foreach (string t in toAddress.Where(t => !string.IsNullOrEmpty(t.Trim()))) message.To.Add(t.Trim());
            }

            if (!string.IsNullOrEmpty(ccs))
            {
                ccs = ccs.Replace(';', ',');
                string[] ccAddress = ccs.Split(',');
                foreach (string t in ccAddress.Where(t => !string.IsNullOrEmpty(t.Trim()))) message.CC.Add(t.Trim());
            }

            smtpClient.Send(message);
        }

        public static void SendMail(string processType, string subject, string body, string to, string ccs)
        {
            SendMail(processType, subject, body, to, ccs, string.Empty);
        }

        public static void SendMail(string processType, string subject, string body, string to, string ccs, string bccs)
        {
            string username = ConfigurationManager.AppSettings["smtp.username"];
            SmtpClient smtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtp.host"],
                int.Parse(ConfigurationManager.AppSettings["smtp.port"]));

            smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"]);

            if (!string.IsNullOrEmpty(username))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential(username,
                    ConfigurationManager.AppSettings["smtp.password"]);
            }

            var message = new MailMessage();
            message.From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]);
            message.Subject = subject;
            message.Body = body;

            if (!string.IsNullOrEmpty(to))
            {
                to = to.Replace(';', ',');
                string[] toAddress = to.Split(',');
                foreach (string t in toAddress.Where(t => !string.IsNullOrEmpty(t.Trim()))) message.To.Add(t.Trim());
            }

            if (!string.IsNullOrEmpty(ccs))
            {
                ccs = ccs.Replace(';', ',');
                string[] ccAddress = ccs.Split(',');
                foreach (string t in ccAddress.Where(t => !string.IsNullOrEmpty(t.Trim()))) message.CC.Add(t.Trim());
            }

            if (!string.IsNullOrEmpty(bccs))
            {
                bccs = bccs.Replace(';', ',');
                string[] bccAddress = bccs.Split(',');
                foreach (string t in bccAddress.Where(t => !string.IsNullOrEmpty(t.Trim()))) message.Bcc.Add(t.Trim());
            }

            smtpClient.Send(message);
            LogEmail(to, ccs, bccs, subject, body, processType);
        }

        public static string SendAlertEmail(ProductSupplyForecast prdSf)
        {
            // ReSharper disable AssignNullToNotNullAttribute
            string mailContentPath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "AlertEmail.xml");
            // ReSharper restore AssignNullToNotNullAttribute

            DataSet alertEmail = new DataSet("AlertEmail");
            alertEmail.ReadXml(mailContentPath);
            DataRow[] rows = alertEmail.Tables["AlertEmail"].Select();

            string strSubject = Convert.ToString(rows[0]["subject"]);
            string strBody = Convert.ToString(rows[0]["body"]);

            strBody = strBody.Replace("${Product}", prdSf.Species.Name);
            strBody = strBody.Replace("${Colour}", prdSf.Color.Name);
            strBody = strBody.Replace("${CategoryType}", prdSf.CategoryType.Name);
            strBody = strBody.Replace("${Category}", prdSf.Category.Name);
            strBody = strBody.Replace("${Supplier}", prdSf.Organization.Name);
            strBody = strBody.Replace("${DeliveryDate}", prdSf.AvailableDate.ToString("dd/MM/yyyy"));

            SendMail(strSubject, strBody, GetAdminUserEmails(), string.Empty);
            return strBody;
        }

        private static string GetAdminUserEmails()
        {
            string userEmails = string.Empty;
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            string[] userIds = System.Configuration.ConfigurationManager.AppSettings["AdminUsers"].Split(',');

            foreach (string userId in userIds)
            {
                ICollection<User> users = repositoryFactory.GetUserRepository().Find(new UserByUserNameSpecification(userId));
                if (users != null && users.Count > 0) foreach (User user in users) if (!string.IsNullOrEmpty(user.Email)) userEmails += user.Email + ",";
            }

            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }

        public static string[] ParseEmails(string emails)
        {
            string enEmails = string.Empty, nlEmails = string.Empty, deEmails = string.Empty;

            string[] arToEmails = emails.Split(',');
            foreach (string[] arEmailLang in arToEmails.Select(emailLang => emailLang.Split(':')))
            {
                if (arEmailLang.Length == 1 || "nl-NL".Equals(arEmailLang[1])) nlEmails += arEmailLang[0] + ",";
                else if ("en-US".Equals(arEmailLang[1])) enEmails += arEmailLang[0] + ",";
                else if ("de-DE".Equals(arEmailLang[1])) deEmails += arEmailLang[0] + ",";
            }
            if (!string.IsNullOrEmpty(enEmails)) enEmails = enEmails.Substring(0, enEmails.Length - 1);
            if (!string.IsNullOrEmpty(nlEmails)) nlEmails = nlEmails.Substring(0, nlEmails.Length - 1);
            if (!string.IsNullOrEmpty(deEmails)) deEmails = deEmails.Substring(0, deEmails.Length - 1);

            return new string[] { enEmails, nlEmails, deEmails };
        }

        private static void LogEmail(string toEmails, string ccEmails, string bccEmails, string emailSubject, string emailContent, string processType)
        {
            var repositoryFactory = new RepositoryFactory();
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                var emailLogger = new EmailLogger
                {
                    ToEmails = toEmails,
                    CcEmails = ccEmails,
                    BccEmails = bccEmails,
                    EmailSubject = emailSubject,
                    MailContent = emailContent,
                    ProcessType = processType,
                    SentDate = DateTime.Now
                };
                repositoryFactory.GetEmailLoggerRepository().Add(emailLogger);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
            }
        }
    }
}
