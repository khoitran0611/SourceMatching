using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using System.IO;
using System.Data;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.FinalizingBidServices
{
    public class FinalizingBidJob : Job
    {
        private readonly RepositoryFactory _repositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            BiddingProcess4NormalProduct();

            BiddingProcess4CompositeProduct();

            Log.Info("Finish");
        }

        private void BiddingProcess4NormalProduct()
        {
            Log.Info("Find Won Bidding");
            IList<BiddingDefine> biddingDefines = new List<BiddingDefine>(_repositoryFactory.GetBiddingDefineRepository().Find(new FinalizingBiddingSpecification()));
            if (biddingDefines.Count <= 0)
            {
                Log.Info("Not found Bidding Options");
                return;
            }

            Log.Info(string.Format("Found {0} Bidding Options", biddingDefines.Count));

            foreach (BiddingDefine bidDef in biddingDefines)
            {
                if (bidDef.MinPrice == bidDef.CurBidPrice)
                {
                    var transactionManager = new TransactionManager();
                    try
                    {
                        transactionManager.BeginTransaction();
                        Log.Info(string.Format("Remove Bidding Option on product ID {0} with amount {1}", bidDef.ProdSupForecast.Uid, bidDef.Amount));

                        _repositoryFactory.GetBiddingDefineRepository().Remove(bidDef);

                        transactionManager.CommitTransaction();
                    }
                    catch (Exception exception)
                    {
                        transactionManager.RollbackTransaction();
                        Log.Info(exception.Message);
                    }
                }
                else
                    SendMailConfirm(bidDef);
            }
        }

        private void BiddingProcess4CompositeProduct()
        {
            Log.Info("Find Won Bidding for Composite product");
            IList<BiddingProcess4CompositeProduct> bidProcessList = BiddingProcessServices.FindFinalBidProcess4CompsiteProd();
            if (bidProcessList.Count <= 0)
            {
                Log.Info("Not found Bidding  for Composite product");
                return;
            }

            Log.Info(string.Format("Found {0} Bidding  for Composite product", bidProcessList.Count));

            foreach (var bidProcess in bidProcessList)
            {
                IList<BiddingProcess4CompositeProductBuyerOffer> bidOffers = BiddingProcessServices.FindAllOfferOnBiddingProcess(bidProcess.Uid);
                if (bidOffers == null || bidOffers.Count <= 0) continue;

                var wonOffer = bidOffers[0];
                if (wonOffer.OfferPrice < bidProcess.MinPrice) continue;
                Log.Info(string.Format("Won offer Id: {0}", wonOffer.Uid));

                bidProcess.IsMatched = true;
                bidProcess.WonBuyerId = wonOffer.BuyerId;
                bidProcess.WonPrice = wonOffer.OfferPrice;

                foreach (var priceDetail in bidProcess.PriceDetails)
                {
                    var offPriceDtls = wonOffer.OfferPriceDetails.SingleOrDefault(it => it.Product4CompositeProdFav.Uid == priceDetail.Product4CompositeProdFav.Uid);
                    if (offPriceDtls == null)
                    {
                        Log.Info(string.Format("Not found Price Detail for Product Composite Product Fav Id: {0}", priceDetail.Product4CompositeProdFav.Uid));
                        continue;
                    }
                    priceDetail.AgreedPrice = offPriceDtls.OfferPrice;
                }

                try
                {
                    Log.Info(string.Format("Check to Accept for Agreement Process for Composite Product Id: {0}, won price: {1}", bidProcess.Uid, wonOffer.OfferPrice));

                    BiddingProcessServices.UpdateBiddingProcess4CompositeProd(bidProcess);
                }
                catch (Exception ex)
                {
                    Log.Error(ex);
                }
            }
        }

        #region Private Methods
        private void SendMailConfirm(BiddingDefine biddingDefine)
        {
            Log.Info("Begin Send Finalizing Bid Email");
            try
            {
                IList<BiddingProcess> listBidProcess = new List<BiddingProcess>(_repositoryFactory.GetBiddingProcessRepository().Find(new BiddingProcessOnBidOptionSpecification(biddingDefine)));
                if (listBidProcess.Count <= 0) return;

                BiddingProcess winBiding = listBidProcess[0];
                if (winBiding.ConfirmProdId > 0)
                {
                    Log.Info(string.Format("Already send confirm email for Bidding: {0}", biddingDefine.Uid));
                    return;
                }

                var transactionManager = new TransactionManager();
                try
                {
                    long productCommitSoldId = 0;
                    transactionManager.BeginTransaction();
                    ProductSupplyForecast prodSupply = biddingDefine.ProdSupForecast;

                    if ((prodSupply.ExpectedAmount == 0 && prodSupply.AvailableForSale == biddingDefine.Amount) ||
                        (prodSupply.ExpectedAmount == prodSupply.AvailableForSale && prodSupply.AvailableForSale == biddingDefine.Amount))
                    {
                        prodSupply.StatusType = ProductStatusType.Commited;
                        prodSupply.SellerStatus = SellerStatus.CommittedSold;
                        prodSupply.BuyerStatus = BuyerStatus.CommittedBought;
                        prodSupply.CommitedAmount = biddingDefine.Amount;
                        prodSupply.ActualAmount = biddingDefine.Amount;
                        prodSupply.Price = winBiding.BiddedPrice;
                        prodSupply.WonInProcess = "Bidding";
                        prodSupply.PurchaseOrgId = winBiding.Organization.Uid;
                        productCommitSoldId = prodSupply.Uid;
                        _repositoryFactory.GetProductSuppyForecastRepository().Store(prodSupply);
                    }
                    else
                    {
                        var productCommitSold = new ProductSupplyForecast(prodSupply.Species, prodSupply.ProdType, prodSupply.Color, prodSupply.CategoryType,
                                                                          prodSupply.Category, prodSupply.AvailableDate, prodSupply.ExpectedAmount, prodSupply.Uom, prodSupply.User, prodSupply.Organization)
                        {
                            StatusType = ProductStatusType.Commited,
                            SellerStatus = SellerStatus.CommittedSold,
                            BuyerStatus = BuyerStatus.CommittedBought,
                            AvailableForSale = prodSupply.AvailableForSale,
                            SalePriodType = prodSupply.SalePriodType,

                            CommitedAmount = biddingDefine.Amount,
                            ActualAmount = biddingDefine.Amount,
                            Price = winBiding.BiddedPrice,
                            WonInProcess = "Bidding",
                            PurchaseOrgId = winBiding.Organization.Uid,
                            SalesOrganization = prodSupply.SalesOrganization,
                            ParentId = prodSupply.Uid,
                            Remarks = prodSupply.Remarks
                        };
                        if (prodSupply.AddressId != 0) productCommitSold.AddressId = prodSupply.AddressId;
                        if (prodSupply.LocationId != 0) productCommitSold.LocationId = prodSupply.LocationId;
                        if (prodSupply.Package != null) productCommitSold.Package = prodSupply.Package;
                        if (prodSupply.AdditionalAttrs != null) foreach (ProductAttribute prdAttr in prodSupply.AdditionalAttrs) productCommitSold.AddProductAttributeToList(prdAttr);

                        productCommitSold.BuyerRefOne = prodSupply.BuyerRefOne;
                        productCommitSold.BuyerRefTwo = prodSupply.BuyerRefTwo;
                        productCommitSold.SellerRefOne = prodSupply.SellerRefOne;
                        productCommitSold.SellerRefTwo = prodSupply.SellerRefTwo;
                        productCommitSold.ProducerRefOne = prodSupply.ProducerRefOne;
                        productCommitSold.ProducerRefTwo = prodSupply.ProducerRefTwo;
                        productCommitSold.PackingSlip = prodSupply.PackingSlip;

                        _repositoryFactory.GetProductSuppyForecastRepository().Add(productCommitSold);
                        _repositoryFactory.GetProductSuppyForecastRepository().Flush();
                        productCommitSoldId = productCommitSold.Uid;

                        //ICollection<PackingConfirmed> packCfms = _repositoryFactory.GetPackingConfirmedRepository().Find(new PackageConfirmedByProdIdsSpecification(prodSupply.Uid.ToString()));
                        if (prodSupply.Package != null)
                        {
                            PackagingDefine packagingDefine = prodSupply.Package;
                            long packagingAmount = Convert.ToInt64(biddingDefine.Amount / packagingDefine.PackagingAmount);
                            if (packagingAmount * packagingDefine.PackagingAmount < biddingDefine.Amount) packagingAmount = packagingAmount + 1;


                            for (int i = 1; i <= 3; i++)
                            {
                                var priceType = (PriceType)Enum.Parse(typeof(PriceType), i.ToString());
                                if (priceType == PriceType.Price && packagingDefine.Price == 0) continue;
                                if (priceType == PriceType.Rent && packagingDefine.RentPrice == 0) continue;
                                if (priceType == PriceType.Deposit && packagingDefine.DepositPrice == 0) continue;

                                var packingConfirmed = new PackingConfirmed
                                {
                                    Packing = packagingDefine,
                                    PackingAmount = packagingAmount,
                                    ProdConfirmed = productCommitSold,
                                    PriceType = priceType
                                };
                                _repositoryFactory.GetPackingConfirmedRepository().Add(packingConfirmed);
                            }
                        }
                    }

                    winBiding.ConfirmProdId = productCommitSoldId;
                    _repositoryFactory.GetBiddingProcessRepository().Store(winBiding);

                    transactionManager.CommitTransaction();
                    Log.Info(string.Format("Update Committed Bought -> ProdId: {0}, WonBidId: {1}", productCommitSoldId, winBiding.Uid));
                }
                catch (Exception ex)
                {
                    transactionManager.RollbackTransaction();
                    throw;
                }

                SendFinalizeEmail(biddingDefine, winBiding);
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        private void SendFinalizeEmail(BiddingDefine biddingDefine, BiddingProcess winBiding)
        {
            string toEmails = string.Empty;
            User loginUser = GetUser(winBiding.Organization);
            if (!string.IsNullOrEmpty(loginUser.Email)) toEmails += string.Format("{0}:{1}", loginUser.Email, loginUser.UsingLang ?? "nl-NL") + ",";

            ProductSupplyForecast productSupplyForecast = _repositoryFactory.GetProductSuppyForecastRepository().GetOne(biddingDefine.ProdSupForecast.Uid);
            Organization producerOrg = _repositoryFactory.GetOrganizationRepository().GetOne(productSupplyForecast.Organization.Uid);
            string producerEmail = GetUserLangEmail(producerOrg);
            if (!string.IsNullOrEmpty(producerEmail)) toEmails += producerEmail + ",";

            Organization saleOrg = GetSaleOrganization(biddingDefine.ProdSupForecast);
            if (saleOrg != null) toEmails += GetUserLangEmail(saleOrg);

            string ccEmails = GetAdminUserLangEmails();

            string[] arToEmails = EmailSender.ParseEmails(toEmails);
            string[] arCcEmails = EmailSender.ParseEmails(ccEmails);
            var langs = new string[] { "en-US", "nl-NL", "de-DE" };

            for (int i = 0; i < 3; i++)
            {
                if (string.IsNullOrEmpty(arToEmails[i]) && string.IsNullOrEmpty(arCcEmails[i])) continue;

                // ReSharper disable AssignNullToNotNullAttribute
                string mailContentPath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), string.Format("FinalizingBid_{0}.xml", langs[i]));
                // ReSharper restore AssignNullToNotNullAttribute

                var comfirmEmail = new DataSet("FinalizingBid");

                comfirmEmail.ReadXml(mailContentPath);
                DataRow[] rows = comfirmEmail.Tables["FinalizingBid"].Select();
                Organization growerOrg = _repositoryFactory.GetOrganizationRepository().GetOne(biddingDefine.ProdSupForecast.Organization.Uid);

                string strSubject = Convert.ToString(rows[0]["subject"]);
                string strBody = Convert.ToString(rows[0]["body"]);

                Organization buyerOrg = _repositoryFactory.GetOrganizationRepository().GetOne(winBiding.Organization.Uid);
                Log.Info(string.Format("Won Bidding TC: {0}", buyerOrg.Name));

                strSubject = strSubject.Replace("${BuyerTC}", buyerOrg.Name);
                strSubject = strSubject.Replace("${Supplier}", growerOrg.Name);
                strSubject = strSubject.Replace("${DeliveryDate}", biddingDefine.ProdSupForecast.AvailableDate.ToString("dd/MM/yyyy"));
                strSubject = strSubject.Replace("${Species}", biddingDefine.ProdSupForecast.Species.GetName(langs[i]));
                strSubject = strSubject.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);
                Log.Info(string.Format("Seller TC: {0}", growerOrg.TradingOrganizations[0].Name));

                strBody = strBody.Replace("${BiddedDate}", winBiding.BiddedDate.ToString("dd/MM/yyyy HH:mm"));
                strBody = strBody.Replace("${BuyerTC}", buyerOrg.Name);
                strBody = strBody.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);

                strBody = strBody.Replace("${UniqueID}", biddingDefine.ProdSupForecast.Uid.ToString());
                strBody = strBody.Replace("${DeliveryDate}", biddingDefine.ProdSupForecast.AvailableDate.ToString("dd/MM/yyyy"));
                strBody = strBody.Replace("${AvailableAmount}", biddingDefine.Amount.ToString());
                strBody = strBody.Replace("${AmountUOM}", biddingDefine.ProdSupForecast.Uom.Name);
                strBody = strBody.Replace("${Price}", winBiding.BiddedPrice.ToString());
                strBody = strBody.Replace("${Currency}", biddingDefine.Currency);

                strBody = strBody.Replace("${Species}", biddingDefine.ProdSupForecast.Species.GetName(langs[i]));
                strBody = strBody.Replace("${Colour}", biddingDefine.ProdSupForecast.Color.GetName(langs[i]));
                strBody = strBody.Replace("${CategoryType}", biddingDefine.ProdSupForecast.CategoryType.GetName(langs[i]));
                strBody = strBody.Replace("${Category}", biddingDefine.ProdSupForecast.Category.GetName(langs[i]));

                Address address = null;
                if (growerOrg.ChainEntities != null && growerOrg.ChainEntities.Count >= 0)
                {
                    var chainEntity = growerOrg.ChainEntities[0];
                    var listAddress = new List<Address>(chainEntity.Addresses);
                    if (listAddress.Count > 0) address = listAddress[0];
                }

                Log.Info(string.Format("Supplier Organization: {0}", growerOrg.Name));
                strBody = strBody.Replace("${Supplier}", growerOrg.Name);
                strBody = strBody.Replace("${Street}", (address != null) ? address.StreetName : string.Empty);
                strBody = strBody.Replace("${HouseNumber}", (address != null) ? address.StreetNumber +
                    (!string.IsNullOrEmpty(address.NumberExtension) ? string.Format("/{0}", address.NumberExtension) : string.Empty) : string.Empty);
                strBody = strBody.Replace("${PostalCode}", (address != null) ? address.ZipCode : string.Empty);
                strBody = strBody.Replace("${City}", (address != null) ? address.City : string.Empty);
                strBody = strBody.Replace("${ExtraInfomation}", biddingDefine.ProdSupForecast.Remarks);

                EmailSender.SendMail("Confirm Bid", strSubject, strBody, arToEmails[i], arCcEmails[i]);
                Log.Info(string.Format("Sent Finalizing Bid email to {0}", toEmails));
            }
        }

        private string GetAdminUserLangEmails()
        {
            string userEmails = string.Empty;
            string[] userIds = System.Configuration.ConfigurationManager.AppSettings["AdminUsers"].Split(',');
            userEmails = (from userId in userIds
                          select _repositoryFactory.GetUserRepository().Find(new UserByUserNameSpecification(userId))
                              into users
                              where users != null && users.Count > 0
                              from user in users
                              where !string.IsNullOrEmpty(user.Email)
                              select user).Aggregate(userEmails, (current, user) => current + (string.Format("{0}:{1}", user.Email, user.UsingLang ?? "nl-NL") + ","));

            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }

        private string GetUserLangEmail(Organization org)
        {
            Organization organization = _repositoryFactory.GetOrganizationRepository().GetOne(org.Uid);
            if (organization.ChainEntities == null || organization.ChainEntities.Count <= 0) return string.Empty;

            ChainEntity chainEntity = _repositoryFactory.GetChainEntityRepository().GetOne(organization.ChainEntities[0].Uid);

            IEnumerable<User> users = chainEntity.Users;
            string userEmails = users.Where(user => !string.IsNullOrEmpty(user.Email)).Aggregate(string.Empty, (current, user) => current + (string.Format("{0}:{1}", user.Email, user.UsingLang ?? "nl-NL") + ","));
            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }

        private User GetUser(Organization org)
        {
            Organization organization = _repositoryFactory.GetOrganizationRepository().GetOne(org.Uid);
            if (organization.ChainEntities == null || organization.ChainEntities.Count <= 0) return null;

            ChainEntity chainEntity = _repositoryFactory.GetChainEntityRepository().GetOne(organization.ChainEntities[0].Uid);
            IList<User> users = new List<User>(chainEntity.Users);
            return users[0];
        }

        protected Organization GetSaleOrganization(ProductSupplyForecast prodSf)
        {
            Organization tradingOrg;
            var tradingTypes = new string[] { "SAL", "BUY", "TRD" };
            if (prodSf.SalesOrganization != null) return prodSf.SalesOrganization;

            Organization organization = _repositoryFactory.GetOrganizationRepository().GetOne(prodSf.Organization.Uid);
            if (organization.TradingOrganizations.Count > 0)
                tradingOrg = _repositoryFactory.GetOrganizationRepository().GetOne(organization.TradingOrganizations[0].Uid);
            else
            {
                IList<GroupOrganizations> goOrg = organization.GroupOrganizations;
                foreach (GroupOrganizations groupOrganizationse in
                    goOrg.Where(groupOrganizationse => groupOrganizationse.Activated == 1).Where(groupOrganizationse => tradingTypes.Contains(groupOrganizationse.Organization.BusinessType)))
                {
                    return groupOrganizationse.Organization;
                }
                tradingOrg = null;
            }
            return tradingOrg;
        }
        #endregion
    }
}