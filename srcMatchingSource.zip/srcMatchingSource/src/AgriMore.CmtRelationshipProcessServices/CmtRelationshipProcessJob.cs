﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.CmtRelationshipProcessServices
{
    public class CmtRelationshipProcessJob : Job
    {
        private static readonly RepositoryFactory RepositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            Log.Info("Find Product Supply Forecast in Committed Relationship Process");
            IList<ProductSupplyForecast> cmtRltProds = new List<ProductSupplyForecast>(RepositoryFactory.GetProductSuppyForecastRepository().Find(new ProductSupplyInCmtRelationshipSpecification()));
            if (cmtRltProds.Count <= 0)
            {
                Log.Info("Not found Product Supply Forecast in Committed Relationship Process");
                return;
            }
            Log.Info(string.Format("Found {0} Product Supply Forecast in Committed Relationship Process", cmtRltProds.Count));

            foreach (ProductSupplyForecast prodSupply in cmtRltProds)
            {
                //CommittedRelationship cmtRlt = RepositoryFactory.GetCommittedRelationshipRepository().GetOne(prodSupply.CommittedRltId);
                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();
                    //foreach (CommittedRelationItem rltItem in cmtRlt.CommittedRltItems)
                    //{
                    //    long cmtAmount = rltItem.Percent * prodSupply.AvailableForSale / 100;
                    //    Log.Info(string.Format("Update Committed Sold for Buyer: {0}, Amount: {1}, Priority: {2}", rltItem.Buyer.Name, cmtAmount, rltItem.Priority));

                    //    var productCommitSold = new ProductSupplyForecast(prodSupply.Species, prodSupply.ProdType, prodSupply.Color, prodSupply.CategoryType, prodSupply.Category, prodSupply.AvailableDate,
                    //            prodSupply.ExpectedAmount, prodSupply.Uom, prodSupply.User, prodSupply.Organization)
                    //    {
                    //        StatusType = ProductStatusType.Commited,
                    //        SallerStatus = SallerStatus.CommittedSold,
                    //        BuyerStatus = BuyerStatus.CommittedBought,
                    //        AvailableForSale = prodSupply.AvailableForSale,
                    //        SalePriodType = prodSupply.SalePriodType,
                    //        AvailableToOtherTcs = cmtAmount,
                    //        CommitedAmount = cmtAmount,
                    //        ActualAmount = cmtAmount,
                    //        WonInProcess = "Committed",
                    //        PurchaseOrgId = rltItem.Buyer.Uid,
                    //        SalesOrganization = prodSupply.SalesOrganization,
                    //        ParentId = prodSupply.Uid,
                    //        Remarks = prodSupply.Remarks
                    //    };

                    //    if (prodSupply.AddressId != 0) productCommitSold.AddressId = prodSupply.AddressId;
                    //    if (prodSupply.LocationId != 0) productCommitSold.LocationId = prodSupply.LocationId;
                    //    if (prodSupply.Package != null) productCommitSold.Package = prodSupply.Package;
                    //    if (prodSupply.AdditionalAttrs != null) foreach (ProductAttribute prdAttr in prodSupply.AdditionalAttrs) productCommitSold.AddProductAttributeToList(prdAttr);

                    //    productCommitSold.BuyerRefOne = prodSupply.BuyerRefOne;
                    //    productCommitSold.BuyerRefTwo = prodSupply.BuyerRefTwo;
                    //    productCommitSold.SellerRefOne = prodSupply.SellerRefOne;
                    //    productCommitSold.SellerRefTwo = prodSupply.SellerRefTwo;
                    //    productCommitSold.ProducerRefOne = prodSupply.ProducerRefOne;
                    //    productCommitSold.ProducerRefTwo = prodSupply.ProducerRefTwo;
                    //    productCommitSold.PackingSlip = prodSupply.PackingSlip;

                    //    if (prodSupply.Package != null)
                    //    {
                    //        PackagingDefine packagingDefine = prodSupply.Package;
                    //        long packagingAmount = Convert.ToInt64(cmtAmount / packagingDefine.PackagingAmount);
                    //        if (packagingAmount * packagingDefine.PackagingAmount < cmtAmount) packagingAmount = packagingAmount + 1;

                    //        for (int i = 1; i <= 3; i++)
                    //        {
                    //            var priceType = (PriceType)Enum.Parse(typeof(PriceType), i.ToString());
                    //            if (priceType == PriceType.Price && packagingDefine.Price == 0) continue;
                    //            if (priceType == PriceType.Rent && packagingDefine.RentPrice == 0) continue;
                    //            if (priceType == PriceType.Deposit && packagingDefine.DepositPrice == 0) continue;

                    //            var packingConfirmed = new PackingConfirmed
                    //            {
                    //                Packing = packagingDefine,
                    //                PackingAmount = packagingAmount,
                    //                ProdConfirmed = productCommitSold,
                    //                PriceType = priceType
                    //            };
                    //            RepositoryFactory.GetPackingConfirmedRepository().Add(packingConfirmed);
                    //        }
                    //    }

                    //    RepositoryFactory.GetProductSuppyForecastRepository().Add(productCommitSold);
                    //    Log.Info("-----> OK!");
                    //}

                    prodSupply.StatusType = ProductStatusType.Commited;
                    prodSupply.ActualAmount = prodSupply.AvailableForSale;
                    prodSupply.CommitedAmount = prodSupply.AvailableForSale;
                    RepositoryFactory.GetProductSuppyForecastRepository().Store(prodSupply);

                    transactionManager.CommitTransaction();
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }

            Log.Info("Finish");
        }
    }
}
