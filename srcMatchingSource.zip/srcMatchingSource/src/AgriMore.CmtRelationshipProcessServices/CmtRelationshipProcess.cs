﻿using System;
using System.ComponentModel;
using System.Configuration;
using System.ServiceProcess;
using System.Threading;
using log4net;

namespace AgriMore.CmtRelationshipProcessServices
{
    [RunInstaller(true)]
    public class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            // This call is required by the Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitComponent call 
            //string keyName = "AgriMORESchedulerAutoRestart";
            //string assemblyLocation = Assembly.GetExecutingAssembly().Location;  // Or the EXE path.

            //// Set Auto-start.
            //Util.SetAutoStart(keyName, assemblyLocation);
        }

        private void InitializeComponent()
        {
            var serviceInstall = new ServiceInstaller();
            var serviceProcessInstall = new ServiceProcessInstaller();

            serviceInstall.ServiceName = "AgriMORECmtRltProcess - Foodtworks"; // this must match the ServiceName specified in WindowsService1.
            serviceInstall.DisplayName = "AgriMORE Committed Relationship Process - Foodtworks"; // this will be displayed in the Services Manager.
            serviceInstall.Description = "AgriMORE applications";
            serviceInstall.StartType = ServiceStartMode.Automatic;
            this.Installers.Add(serviceInstall);

            serviceProcessInstall.Account = System.ServiceProcess.ServiceAccount.LocalSystem; // run under the system account.
            serviceProcessInstall.Password = null;
            serviceProcessInstall.Username = null;
            this.Installers.Add(serviceProcessInstall);
        }
    }

    public partial class CmtRelationshipProcess : ServiceBase
    {
        private Job _cmtRltProcessJob;
        private Timer _cmtRltProcessStateTimer;
        private TimerCallback _cmtRltProcessDelegate;
        private static readonly ILog Log = LogManager.GetLogger("GeneralLog");

        public CmtRelationshipProcess()
        {
            InitializeComponent();
            log4net.Config.XmlConfigurator.Configure();
        }

#if DEBUG
        public void Run()
        {
            OnStart(null);
        }
#endif

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            Log.Info("AgriMORE Committed Relationship Process Service OnStart");
            int timerInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimerInterval"]) * 5;
            int repeatTime = Convert.ToInt32(ConfigurationManager.AppSettings["TimeRepeat"]);

            _cmtRltProcessJob = new CmtRelationshipProcessJob();

#if DEBUG
            _cmtRltProcessJob.Execute(null);
#else
            _cmtRltProcessDelegate = new TimerCallback(_cmtRltProcessJob.Execute);
            _cmtRltProcessStateTimer = new Timer(_cmtRltProcessDelegate, this, 1000, timerInterval * repeatTime);// //One per two Hour
#endif
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            Log.Info("AgriMORE Committed Relationship Process Service OnStop");
            _cmtRltProcessStateTimer.Dispose();
        }
    }
}
