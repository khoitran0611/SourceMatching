//using System;
//using System.Collections.Generic;
//using System.Text;
//using AgriMore.Logistics.Domain;
//using AgriMore.Logistics.Domain.Repository;
//using AgriMore.Logistics.Domain.Repository.MySql;
//using AgriMore.Logistics.Domain.Specification;
//using NUnit.Framework;

//namespace AgriMore.Logistics.Data.Specs
//{
//    /// <summary>
//    /// Tests the my sql table repository
//    /// </summary>
//    [TestFixture]
//    public class MySqlTableRepository_UnitOfMeasurement_Test
//    {
//        /// <summary>
//        /// Setup of testfixture.
//        /// </summary>
//        [SetUp]
//        public void Setup()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();

//            // truncate unitofmeasurement
//            DatabaseTest.ExecDDL(@"..\..\src\MySql\test_unitofmeasurement.sql");
//        }

//        /// <summary>
//        /// Cleanup of testfixture.
//        /// </summary>
//        [TearDown]
//        public void TearDown()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - GetOne(id)
//        /// - GetOne(uid)
//        /// - Remove(Element)
//        /// </summary>
//        [Test]
//        public void Test_UnitOfMeasurement_AddGetRemove()
//        {
//            string conString = DatabaseTest.ConnectionString;
//            IRepository<UnitOfMeasurement> rep = MySqlRepositoryFactory.Create<UnitOfMeasurement>(conString);
//            //IRepository<UnitOfMeasurement> rep = new MySqlTableRepository<UnitOfMeasurement>(new UnitOfMeasurementMapper(), "unitofmeasurement", new string[] { "uid", "name" }, conString); 
//            UnitOfMeasurement m = new UnitOfMeasurement("kg");
//            long uid= rep.Add(m);
//            Assert.AreNotEqual(0,uid);
//            Assert.AreNotEqual(0, m.Uid);
//            UnitOfMeasurement foundByName = rep.GetOne("kg");
//            Assert.AreEqual(m,foundByName);
//            UnitOfMeasurement foundByUid = rep.GetOne(uid);
//            Assert.AreEqual(m, foundByUid);
//            Assert.IsTrue(rep.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Store(Element)
//        /// - Remove(Element)
//        /// - Add(Element)
//        /// - GetOne(uid)
//        /// </summary>
//        [Test]
//        public void Test_UnitOfMeasurement_Store()
//        {
//            string conString = DatabaseTest.ConnectionString;
//            IRepository<UnitOfMeasurement> rep = MySqlRepositoryFactory.Create<UnitOfMeasurement>(conString);
//            //IRepository<UnitOfMeasurement> rep = new MySqlTableRepository<UnitOfMeasurement>(new UnitOfMeasurementMapper(), "unitofmeasurement", new string[] { "uid", "name" }, conString);
//            UnitOfMeasurement m = new UnitOfMeasurement("kg");
//            rep.Store(m);
//            Assert.AreNotEqual(0, m.Uid);
//            Assert.IsTrue(rep.Remove(m));
//            Assert.AreEqual(0, m.Uid);
//            rep.Add(m);
//            Assert.AreNotEqual(0, m.Uid);
//            rep.Store(m);
//            long id = m.Uid;
//            m = new UnitOfMeasurement("g");
//            m.Uid = id;
//            Assert.AreNotEqual(m,rep.GetOne(m.Uid));
//            id = m.Uid;
//            rep.Store(m);
//            Assert.AreEqual(id, m.Uid);
//            Assert.AreEqual(m, rep.GetOne(m.Uid));
//            Assert.IsTrue(rep.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - AsCollection()
//        /// - GetEnumerator()
//        /// - Find(ISpecification)
//        /// - Count(ISpecification)
//        /// - Remove(ISpecification)
//        /// </summary>
//        [Test]
//        public void Test_UnitOfMeasurement_CollectionEnumerableCountRemoveSpecs()
//        {
//            string conString = DatabaseTest.ConnectionString;
//            IRepository<UnitOfMeasurement> rep = MySqlRepositoryFactory.Create<UnitOfMeasurement>(conString);
//            //IRepository<UnitOfMeasurement> rep = new MySqlTableRepository<UnitOfMeasurement>(new UnitOfMeasurementMapper(), "unitofmeasurement", new string[] { "uid", "name" }, conString);
//            UnitOfMeasurement kg = new UnitOfMeasurement("kg");
//            UnitOfMeasurement g = new UnitOfMeasurement("g");
//            rep.Add(kg);
//            rep.Add(g);
//            ICollection<UnitOfMeasurement> measurements = rep.AsCollection();
//            Assert.AreEqual(2, measurements.Count);
//            int i = 0;
//            foreach (UnitOfMeasurement measurement in measurements)
//            {
//                if(measurement.Name == kg.Name)
//                {
//                    i++;
//                }
//                if (measurement.Name == g.Name)
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2,i);
//            i = 0;
//            foreach (UnitOfMeasurement measurement in rep)
//            {
//                if (measurement.Name == kg.Name)
//                {
//                    i++;
//                }
//                if (measurement.Name == g.Name)
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2, i);
//            i = 0;
//            foreach (UnitOfMeasurement measurement in rep.Find(new AllSpecification<UnitOfMeasurement>()))
//            {
//                if (measurement.Name == kg.Name)
//                {
//                    i++;
//                }
//                if (measurement.Name == g.Name)
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2, i);
//            Assert.AreEqual(2,rep.Count(new AllSpecification<UnitOfMeasurement>()));
//            rep.Remove(new AllSpecification<UnitOfMeasurement>());
//            Assert.AreEqual(0, rep.Count(new AllSpecification<UnitOfMeasurement>()));
//        }
//    }
//}
