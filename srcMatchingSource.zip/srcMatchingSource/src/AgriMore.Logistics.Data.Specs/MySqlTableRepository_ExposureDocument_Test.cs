//using System;
//using System.Collections.Generic;
//using System.Text;
//using AgriMore.Logistics.Domain;
//using AgriMore.Logistics.Domain.Repository;
//using AgriMore.Logistics.Domain.Repository.MySql;
//using AgriMore.Logistics.Domain.Specification;
//using NUnit.Framework;

//namespace AgriMore.Logistics.Data.Specs
//{
//    /// <summary>
//    /// Tests the my sql table repository
//    /// </summary>
//    [TestFixture]
//    public class MySqlTableRepository_ExposureDocument_Test
//    {
//        /// <summary>
//        /// Setup of testfixture.
//        /// </summary>
//        [SetUp]
//        public void Setup()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();
            
//            // create roles
//            //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_user.sql");
//        }

//        /// <summary>
//        /// Cleanup of testfixture.
//        /// </summary>
//        [TearDown]
//        public void TearDown()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - GetOne(id)
//        /// - GetOne(uid)
//        /// - Remove(Element)
//        /// </summary>
//        [Test]
//        public void Test_ExposureDocument_AddGetRemove()
//        {
//            //Review RaRO MoCR: why is this test commented?
//            //Review RaRo MoCr: more tests, less code that changes internal structure.
//            //string conString = DatabaseTest.ConnectionString;
//            //IRepository<ExposureDocument> rep = MySqlRepositoryFactory.Create<ExposureDocument>(conString);
//            //ExposureDocument m = new User("user1", "pass1", "George", "Bush", new string[] { "President", "Republican" });
//            //long uid = rep.Add(m);
//            //Assert.AreNotEqual(0, uid);
//            //Assert.AreNotEqual(0, m.Uid);
//            //ExposureDocument foundByName = rep.GetOne("George Bush");
//            //Assert.AreEqual(m, foundByName);
//            //ExposureDocument foundByUid = rep.GetOne(uid);
//            //Assert.AreEqual(m, foundByUid);
//            //Assert.IsTrue(rep.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Store(Element)
//        /// - Remove(Element)
//        /// - Add(Element)
//        /// - GetOne(uid)
//        /// </summary>
//        [Test]
//        public void Test_ExposureDocument_Store()
//        {
//            //string conString = DatabaseTest.ConnectionString;
//            //IRepository<ExposureDocument> rep = MySqlRepositoryFactory.Create<ExposureDocument>(conString);
//            //ExposureDocument m = new ExposureDocument("user1", "pass1", "George", "Bush", new string[] { "President", "Republican" });
//            //rep.Store(m);
//            //Assert.AreNotEqual(0, m.Uid);
//            //Assert.IsTrue(rep.Remove(m));
//            //m.Uid = 0;
//            //rep.Add(m);
//            //Assert.AreNotEqual(0, m.Uid);
//            //rep.Store(m);
//            //m.Username = "user3";
//            //Assert.AreNotEqual(m, rep.GetOne(m.Uid));
//            //long id = m.Uid;
//            //rep.Store(m);
//            //Assert.AreEqual(id, m.Uid);
//            //Assert.AreEqual(m, rep.GetOne(m.Uid));
//            //Assert.IsTrue(rep.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - AsCollection()
//        /// - GetEnumerator()
//        /// - Find(ISpecification)
//        /// - Count()
//        /// - Count(ISpecification)
//        /// - Remove(ISpecification)
//        /// </summary>
//        [Test]
//        public void Test_ExposureDocument_CollectionEnumerableCountRemoveSpecs()
//        {
//            //string conString = DatabaseTest.ConnectionString;
//            //IRepository<ExposureDocument> rep = MySqlRepositoryFactory.Create<ExposureDocument>(conString);
//            //ExposureDocument bush = new ExposureDocument("user1", "pass1", "George", "Bush", new string[] { "President", "Republican" });
//            //ExposureDocument clinton = new ExposureDocument("user2", "pass2", "Bill", "Clinton", new string[] { "President", "Democrat" });
//            //rep.Add(bush);
//            //rep.Add(clinton);
//            //Assert.AreEqual(2, rep.Count());
//            //int i = 0;
//            //foreach (ExposureDocument user in rep)
//            //{
//            //    if(user.Username == bush.Username)
//            //    {
//            //        i++;
//            //    }
//            //    if (user.Username == clinton.Username)
//            //    {
//            //        i++;
//            //    }
//            //}
//            //Assert.AreEqual(2, i);
//            //i = 0;
//            //foreach (ExposureDocument user in rep.Find(new AllSpecification<ExposureDocument>()))
//            //{
//            //    if (user.Username == bush.Username)
//            //    {
//            //        i++;
//            //    }
//            //    if (user.Username == clinton.Username)
//            //    {
//            //        i++;
//            //    }
//            //}
//            //Assert.AreEqual(2, i);
//            //Assert.AreEqual(2, rep.Count(new AllSpecification<ExposureDocument>()));
//            //rep.Remove(new AllSpecification<ExposureDocument>());
//            //Assert.AreEqual(0, rep.Count(new AllSpecification<ExposureDocument>()));
//        }
//    }
//}
