using System;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    ///// <summary>
    ///// Tests the NHibernateRepository
    ///// </summary>
    [TestFixture]
    public class NHibernateRepository_Shipment_Test
    {
    //    /// <summary>
    //    /// Setup of testfixture.
    //    /// </summary>
    //    [SetUp]
    //    public void Setup()
    //    {
    //        //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
    //    }

    //    /// <summary>
    //    /// Cleanup of testfixture.
    //    /// </summary>
    //    [TearDown]
    //    public void TearDown()
    //    {
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Shipment_Add()
    //    {
    //        NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
    //        nHibernateTransactionManager.BeginTransaction();

    //        Shipment shipment = CreateShipment();

    //        IRepository<Shipment> repository = new RepositoryFactory().GetShipmentRepository();

    //        #region Get expectations

    //        string expectedForwarderMailAddress = shipment.ForwarderMailaddress;
    //        string expectedForwarderName = shipment.Forwarder.Name;
    //        string expectedShipperName = shipment.Shipper.Name;
    //        string expectedReceiverName = shipment.Receiver.Name;

    //        string expectedPickupLocationName = shipment.PickupLocation.Name;
    //        string expectedDeliveryLocationName = shipment.DeliveryLocation.Name;

    //        ShipmentExposure shipmentExposure = new List<ShipmentExposure>(shipment.ShipmentExposures)[1];
    //        double expectedDocumentedValue = shipmentExposure.DocumentedValue;

    //        string expectedExposureTypeName = shipmentExposure.ExposureType.Name;
    //        #endregion

    //        long uid = repository.Add(shipment);

    //        nHibernateTransactionManager.CommitTransaction();

    //        nHibernateTransactionManager.BeginTransaction();

    //        shipment = repository.GetOne(uid);

    //        #region Verify expectations
    //        Assert.AreEqual(expectedForwarderMailAddress, shipment.ForwarderMailaddress);
    //        Assert.AreEqual(expectedShipperName, shipment.Shipper.Name);
    //        Assert.AreEqual(expectedForwarderName, shipment.Forwarder.Name);
    //        Assert.AreEqual(expectedReceiverName, shipment.Receiver.Name);
    //        Assert.AreEqual(expectedPickupLocationName, shipment.PickupLocation.Name);
    //        Assert.AreEqual(expectedDeliveryLocationName, shipment.DeliveryLocation.Name);

    //        shipmentExposure = new List<ShipmentExposure>(shipment.ShipmentExposures)[1];
    //        Assert.AreEqual(expectedDocumentedValue, shipmentExposure.DocumentedValue);
    //        Assert.AreEqual(expectedExposureTypeName, shipmentExposure.ExposureType.Name);

    //        #endregion

    //        nHibernateTransactionManager.CommitTransaction();
    //    }

    //    public static Shipment CreateShipment()
    //    {
    //        ChainEntity shipper = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
    //        Location shipperLocation = new List<Location>(shipper.Locations)[0];

    //        Shipment shipment =
    //            new Shipment(shipper,
    //                         NHibernateRepository_ChainEntity_Test.GetExistingChainEntity(),
    //                         NHibernateRepository_ChainEntity_Test.GetExistingChainEntity(), "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", CreatePackages(), shipperLocation,
    //                         GetNewLocation(1), new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", GetNewShipmentExposures());
    //        return shipment;
    //    }

    //    private static List<Package> CreatePackages()
    //    {
    //        List<Package> packages = new List<Package>();
    //        packages.Add(NHibernateRepository_Package_Test.GetExistingPackage());
    //        packages.Add(NHibernateRepository_Package_Test.GetExistingPackage());
    //        return packages;
    //    }

    //    public static List<ShipmentExposure> GetNewShipmentExposures()
    //    {
    //        List<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();
    //        shipmentExposures.Add(GetNewShipmentExposure());
    //        shipmentExposures.Add(GetNewShipmentExposure());
    //        return shipmentExposures;
    //    }

    //    private static ShipmentExposure GetNewShipmentExposure()
    //    {
    //        IRepository<ShipmentExposure> repository = new RepositoryFactory().CreateRepository<ShipmentExposure>();

    //        double value = 3000.31d;
    //        ShipmentExposure packageType = new ShipmentExposure(value - 2, value- 1, value-3, GetNewExposureType());

    //        //Assert.AreEqual(0, packageType.Uid);
    //        repository.Add(packageType);
    //        //Assert.AreNotEqual(0, packageType.Uid);
    //        packageType = repository.GetOne(packageType.Uid);
    //        return packageType;
    //    }

    //    private static ExposureType GetNewExposureType()
    //    {
    //        NHibernateRepository<ExposureType> nHibernateEntityRepository = new NHibernateRepository<ExposureType>();

    //        ExposureType exposureType = new ExposureType("ExposureType", GetExistingUnitOfMeasurement());
    //        nHibernateEntityRepository.Add(exposureType);
    //        exposureType = nHibernateEntityRepository.GetOne(exposureType.Uid);
    //        return exposureType;
    //    }


    //    public static UnitOfMeasurement GetExistingUnitOfMeasurement()
    //    {
    //        IRepository<UnitOfMeasurement> repository = new RepositoryFactory().CreateRepository<UnitOfMeasurement>();

    //        List<UnitOfMeasurement> agriMoreTimeZones = new List<UnitOfMeasurement>(repository.AsCollection());
    //        if (agriMoreTimeZones.Count > 0)
    //        {
    //            return agriMoreTimeZones[0];
    //        }

    //        UnitOfMeasurement unitOfMeasurement = new UnitOfMeasurement("UnitOfMeasurement");
    //        repository.Add(unitOfMeasurement);
    //        unitOfMeasurement = repository.GetOne(unitOfMeasurement.Uid);
    //        return unitOfMeasurement;
    //    }

    //    private static Location GetNewLocation(int sequenceNumber)
    //    {
    //        return new Location("Location " + sequenceNumber + " " + Guid.NewGuid());
    //    }
    }
}
