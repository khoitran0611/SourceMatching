using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using AgriMore.Logistics.Common.Exception;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using log4net.Config;
using MySql.Data.MySqlClient;
using NHibernate;
using NHibernate.Tool.hbm2ddl;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;
using Configuration=NHibernate.Cfg.Configuration;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class AtFirstNHibernateRepository_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            XmlConfigurator.Configure();
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test_NHibernateRepository_CanInstantiateNHibernateRepositoryFactory()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();

            Assert.IsNotNull(repositoryFactory.ConcreteRepositoryFactory as NHibernateRepositoryFactory);
        }

        [Test]
        public void Test_NHibernateRepository_CanCreateMySqlDatabaseStructure()
        {
            string key = "Run_Test_NHibernateRepository_CanCreateMySqlDatabaseStructure";
            bool runTest = bool.Parse(ConfigurationManager.AppSettings[key]);
            if (!runTest)
            {
                Debug.WriteLine("This test is configured not to run. See " + key + " in app.config.");
                return;
            }

            CreateMySqlDatabaseStructure();
        }

        private static void CreateMySqlDatabaseStructure()
        {
            Debug.WriteLine("Loading configuration.");
            Configuration configuration = NHibernateConfiguration.GetConfiguration();

            SchemaExport exporter = new SchemaExport(configuration);

            //Debug.WriteLine("Dropping current database schema.");
            //exporter.Drop(true, true);

            Debug.WriteLine("Creating a new database schema.");
            exporter.Create(true, true);

            Debug.WriteLine("Adding some extra indexes.");
            ISession nHibernateSession = new NHibernateDao().NHibernateSession;

            IDbConnection dbConnection = nHibernateSession.Connection;

            MySqlCommand sqlCommand = new MySqlCommand();
            sqlCommand.Connection = (MySqlConnection)dbConnection;

            Debug.WriteLine("NDX_Identification_Id");
            sqlCommand.CommandText = "CREATE INDEX NDX_Identification_Id ON Identification(Id)";
            sqlCommand.ExecuteNonQuery();

            Debug.WriteLine("NDX_ProcessingStep_PackageUidObjectUid");
            sqlCommand.CommandText = "CREATE INDEX NDX_ProcessingStep_PackageIdObjectId ON ProcessingStep(PackageUid, ObjectUid)";
            sqlCommand.ExecuteNonQuery();

            Debug.WriteLine("NDX_ProcessingStep_PackageUidParentPackageUid");
            sqlCommand.CommandText = "CREATE INDEX NDX_ProcessingStep_PackageUidParentPackageUid ON ProcessingStep(PackageUid, ParentPackageUid)";
            sqlCommand.ExecuteNonQuery();

            Debug.WriteLine("NDX_RepackPackageRelationship_RepackedPackageId");
            sqlCommand.CommandText = "CREATE INDEX NDX_RepackPackageRelationship_RepackedPackageId ON RepackPackageRelationship(RepackedPackageId, NewPackageFromRepackId)";
            sqlCommand.ExecuteNonQuery();

            Debug.WriteLine("Ready.");
        }

        [Test]
        public void Test_NHibernateRepository_CanInitializeTestData()
        {
            string key = "Run_Test_NHibernateRepository_CanInitializeTestData";
            bool runTest = bool.Parse(ConfigurationManager.AppSettings[key]);
            if (!runTest)
            {
                Debug.WriteLine("This test is configured not to run. See " + key + " in app.config.");
                return;
            }

            CreateMySqlDatabaseStructure();

            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<User> repository = repositoryFactory.CreateRepository<User>();

            new RepositoryFactory().InitializeTestData();

            Assert.AreEqual(14, repository.AsCollection().Count);
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_NHibernateRepository_Add_CanHandleNull()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();
            repository.Add(null);
        }

        [Test, ExpectedException(typeof(ArgumentException))]
        public void Test_NHibernateRepository_Add_CanHandleAssignedUid()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            Country country = new Country("Test");
            country.Uid = long.MaxValue;
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();
            repository.Add(country);
        }

        [Test]
        public void Test_NHibernateRepository_Contains()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            Country country = new Country("Test");
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();
            repository.Add(country);

            Assert.That(repository.Contains(country), Is.True);
        }

        [Test]
        public void Test_NHibernateRepository_GetOne_Specification()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            Country country = new Country("Test");
            repository.Add(country);

            ISpecification<Country> specification = new AllSpecification<Country>();

            country = repository.GetOne(specification);

            Assert.That(country, Is.Not.Null);
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_NHibernateRepository_GetOne_Specification_CanHandleNull()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            ISpecification<Country> specification = null;

            repository.GetOne(specification);
        }

        [Test]
        public void Test_NHibernateRepository_GetOne_String()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            string expectedName = "Test" + Guid.NewGuid();
            Country country = new Country(expectedName);
            repository.Add(country);

            country = repository.GetOne(expectedName);

            Assert.That(country, Is.Not.Null);
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_NHibernateRepository_GetOne_String_CanHandleNull()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            string nullString = null;

            repository.GetOne(nullString);
        }

        [Test]
        public void Test_NHibernateRepository_Count_Specification()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            ISpecification<Country> specification = new AllSpecification<Country>();

            long count = repository.Count(specification);

            Country country = new Country("Test");
            repository.Add(country);

            Assert.That(repository.Count(specification), Is.EqualTo(count + 1));
        }

        [Test]
        public void Test_NHibernateRepository_Count()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            long count = repository.Count();

            Country country = new Country("Test");
            repository.Add(country);

            Assert.That(repository.Count(), Is.EqualTo(count + 1));
        }

        [Test]
        public void Test_NHibernateRepository_Enumerator()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            Country country = new Country("Test");
            repository.Add(country);

            long expectedCount = repository.Count();

            Assert.That(expectedCount, Is.GreaterThan(0));

            long count = 0;

            foreach (Country countryInRepository in repository)
            {
                count++;                
            }

            Assert.That(count, Is.EqualTo(expectedCount));
        }

        [Test]
        public void Test_NHibernateRepository_GetEnumerator()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            Country country = new Country("Test");
            repository.Add(country);

            IEnumerator<Country> enumerator = repository.GetEnumerator();

            enumerator.MoveNext();

            country = enumerator.Current;

            Assert.That(country, Is.Not.Null);
        }

        [Test]
        public void Test_NHibernateRepository_Find()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            ISpecification<Country> specification = new AllSpecification<Country>();

            Country country = new Country("Test");
            repository.Add(country);
            long expectedCount = repository.Count(specification);

            long count = 0;
            foreach (Country countryInRepository in repository.Find(specification))
            {
                count++;
            }

            Assert.That(count, Is.EqualTo(expectedCount));
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_NHibernateRepository_Find_CanHandleNull()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            ISpecification<Country> specification = null;

            repository.Find(specification);
        }

        [Test]
        public void Test_NHibernateRepository_Remove()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            TransactionManager transactionManager = new TransactionManager();

            transactionManager.BeginTransaction();
            Country country = new Country("Test");
            repository.Add(country);
            transactionManager.CommitTransaction();

            long uid = country.Uid;

            transactionManager.BeginTransaction();
            country = repository.GetOne(uid);
            Assert.That(country, Is.Not.Null);
            repository.Remove(country);
            transactionManager.CommitTransaction();

            country = repository.GetOne(uid);
            Assert.That(country, Is.Null);
        }

        [Test, ExpectedException(typeof(UnknownObjectException))] //It might be interesting to translate this exception in the future.
        public void Test_NHibernateRepository_Remove_CanHandleException()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            TransactionManager transactionManager = new TransactionManager();

            transactionManager.BeginTransaction();
            Country country = new Country("Test");
            repository.Add(country);
            transactionManager.CommitTransaction();

            long uid = country.Uid;

            transactionManager.BeginTransaction();
            country = repository.GetOne(uid);
            Country country2 = repository.GetOne(uid);
            Assert.That(country, Is.Not.Null);
            repository.Remove(country);
            transactionManager.CommitTransaction();

            country = repository.GetOne(uid);
            Assert.That(country, Is.Null);

            repository.Remove(country2);
        }

        [Test, ExpectedException(typeof(UnknownObjectException))] //It might be interesting to translate this exception in the future.
        public void Test_NHibernateRepository_Store_CanHandleException()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            TransactionManager transactionManager = new TransactionManager();

            transactionManager.BeginTransaction();
            Country country = new Country("Test");
            repository.Add(country);
            transactionManager.CommitTransaction();

            long uid = country.Uid;

            transactionManager.BeginTransaction();
            country = repository.GetOne(uid);
            Country country2 = repository.GetOne(uid);
            Assert.That(country, Is.Not.Null);
            repository.Remove(country);
            transactionManager.CommitTransaction();

            country = repository.GetOne(uid);
            Assert.That(country, Is.Null);

            repository.Store(country2);
        }

        [Test, ExpectedException(typeof(NotImplementedException))]
        public void Test_NHibernateRepository_Remove_Specification()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            ISpecification<Country> specification = new AllSpecification<Country>();
            repository.Remove(specification);
        }

        [Test]
        public void Test_NHibernateRepository_Remove_With_Rollback()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();
            IRepository<Country> repository = repositoryFactory.CreateRepository<Country>();

            TransactionManager transactionManager = new TransactionManager();

            transactionManager.BeginTransaction();
            Country country = new Country("Country that will not be saved");
            repository.Add(country);
            transactionManager.RollbackTransaction();

            long uid = country.Uid;
            Assert.That(country.Uid, Is.Not.EqualTo(0));
            
            country = repository.GetOne(uid);
            Assert.That(country, Is.Null);
        }

    }
}
