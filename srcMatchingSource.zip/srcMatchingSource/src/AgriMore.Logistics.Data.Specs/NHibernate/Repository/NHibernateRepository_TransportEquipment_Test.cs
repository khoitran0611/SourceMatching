using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_TransportEquipment_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test_NHibernateRepository_TransportEquipment_Add()
        {
            NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
            nHibernateTransactionManager.BeginTransaction();

            TransportEquipment transportEquipment = GetNewTransportEquipment();

            #region Get expectations
            //TransportEquipment does not expose anything worth to expect.
            #endregion

            IRepository<TransportEquipment> nHibernateEntityRepository = new RepositoryFactory().CreateRepository<TransportEquipment>();

            long uid = nHibernateEntityRepository.Add(transportEquipment);

            nHibernateTransactionManager.CommitTransaction();

            nHibernateTransactionManager.BeginTransaction();

            transportEquipment = nHibernateEntityRepository.GetOne(uid);

            #region Verify expectations
            Assert.IsNotNull(transportEquipment);
            #endregion

            nHibernateTransactionManager.CommitTransaction();
        }

        public static TransportEquipment GetNewTransportEquipment()
        {
            ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
            Location location = new List<Location>(chainEntity.Locations)[0];

            TransportEquipment proofOfDelivery = new TransportEquipment(chainEntity, location);

            return proofOfDelivery;
        }
    }
}
