using System;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using log4net.Config;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepositoryFactory
    /// </summary>
    [TestFixture]
    public class NHibernateRepositoryFactory_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            XmlConfigurator.Configure();
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetIdentificationRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<Identification> repository = nhibernateRepositoryFactory.GetIdentificationRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(Identification)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetTreatmentTypeRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<TreatmentType> repository = nhibernateRepositoryFactory.GetTreatmentTypeRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(TreatmentType)));
        }
 
        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetTreatmentTypeCategoryRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<TreatmentTypeCategory> repository = nhibernateRepositoryFactory.GetTreatmentTypeCategoryRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(TreatmentTypeCategory)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetUserRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<User> repository = nhibernateRepositoryFactory.GetUserRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(User)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetExposureRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<Exposure> repository = nhibernateRepositoryFactory.GetExposureRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(Exposure)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetRoleRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<Role> repository = nhibernateRepositoryFactory.GetRoleRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(Role)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetAddressRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<Address> repository = nhibernateRepositoryFactory.GetAddressRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(Address)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetCashRegisterRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<CashRegister> repository = nhibernateRepositoryFactory.GetCashRegisterRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(CashRegister)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetAgriMoreTimeZoneRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<AgriMoreTimeZone> repository = nhibernateRepositoryFactory.GetAgriMoreTimeZoneRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(AgriMoreTimeZone)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetCountryRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<Country> repository = nhibernateRepositoryFactory.GetCountryRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(Country)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetPackageTypeCategoryRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<PackageTypeCategory> repository = nhibernateRepositoryFactory.GetPackageTypeCategoryRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(PackageTypeCategory)));
        }


        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetPackingMaterialRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<PackingMaterial> repository = nhibernateRepositoryFactory.GetPackingMaterialRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(PackingMaterial)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetUnitOfMeasurementRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<UnitOfMeasurement> repository = nhibernateRepositoryFactory.GetUnitOfMeasurementRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(UnitOfMeasurement)));
        }


        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetTransportEquipmentRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<TransportEquipment> repository = nhibernateRepositoryFactory.GetTransportEquipmentRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(TransportEquipment)));
        }


        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetTreatmentRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<Treatment> repository = nhibernateRepositoryFactory.GetTreatmentRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(Treatment)));
        }

        [Test]
        public void Test_NHibernateRepositoryFactory_CanGetRepackPackageRelationshipRepository()
        {
            NHibernateRepositoryFactory nhibernateRepositoryFactory = new NHibernateRepositoryFactory();
            IRepository<RepackPackageRelationship> repository = nhibernateRepositoryFactory.GetRepackPackageRelationshipRepository();

            Type type = repository.GetType().GetGenericArguments()[0];
            Assert.That(type, Is.EqualTo(typeof(RepackPackageRelationship)));
        } 
    }
}
