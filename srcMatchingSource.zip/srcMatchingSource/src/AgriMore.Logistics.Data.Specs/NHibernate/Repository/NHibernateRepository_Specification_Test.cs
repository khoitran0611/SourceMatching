using System;
using System.Collections.Generic;
using System.Diagnostics;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_Specification_Test
    {
    //    #region Setup/Teardown

    //    /// <summary>
    //    /// Setup of testfixture.
    //    /// </summary>
    //    [SetUp]
    //    public void Setup()
    //    {
    //    }

    //    /// <summary>
    //    /// Cleanup of testfixture.
    //    /// </summary>
    //    [TearDown]
    //    public void TearDown()
    //    {
    //    }

    //    #endregion

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_PackageForPutInLocationSpecification()
    //    {
    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

    //        ICollection<Shipment> shipments =
    //            new RepositoryFactory().GetShipmentRepository().Find(new ShipmentsForShipperSpecification(chainEntity, true, false));

    //        ICollection<Package> packagesFromOldSpecification = new RepositoryFactory().GetPackageRepository().Find(new PackagePutInLocationRequirementSpecification(chainEntity, shipments));

    //        ICollection<Package> packagesFromNewSpecification = new RepositoryFactory().GetPackageRepository().Find(new PackageForPutInLocationSpecification(chainEntity));

    //        foreach (Package package in packagesFromOldSpecification)
    //        {
    //            Debug.WriteLine("Old: " + package.IdentificationForChainEntity(chainEntity));
    //            Debug.WriteLine("Old: package.Uid: " + package.Uid);
    //        }

    //        foreach (Package package in packagesFromNewSpecification)
    //        {
    //            Debug.WriteLine("New: " + package.IdentificationForChainEntity(chainEntity));
    //            Debug.WriteLine("New: package.Uid: " + package.Uid);
    //        }

    //        Assert.That(new List<Package>(packagesFromNewSpecification).Count, Is.EqualTo(new List<Package>(packagesFromOldSpecification).Count));

    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_IdentificationByChainEntity()
    //    {
    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

    //        ICollection<Identification> allIdentifications = new RepositoryFactory().GetIdentificationRepository().Find(new IdentificationByChainEntity(chainEntity));

    //        //Assert.That(new List<Identification>(allIdentifications).Count, Is.GreaterThan(0));
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_PackageIdentificationSpecification()
    //    {
    //        Package package1 = NHibernateRepository_Package_Test.GetExistingPackage();
    //        Identification identification = new List<Identification>(package1.Identifications)[0];

    //        Package package2 = new RepositoryFactory().GetPackageRepository().GetOne(new PackageIdentificationSpecification(identification));
    //        Assert.That(package2, Is.EqualTo(package1));
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_PackageInLocationAndNotPackedOnce()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package packageGrandChild = NHibernateRepository_Package_Test.GetNewPackage();
    //        Package packageChild = NHibernateRepository_Package_Test.GetNewPackage();
    //        Package packageParent = NHibernateRepository_Package_Test.GetNewPackage();
    //        packageChild.Pack(packageGrandChild);
    //        packageParent.Pack(packageChild);

    //        Location location = NHibernateRepository_ChainEntity_Test.GetNewLocation(1);
    //        List<Exposure> exposures = new List<Exposure>();
    //        location.Put(packageParent, exposures, new DateTime(2008, 1, 1));
    //        location.Put(packageChild, exposures, new DateTime(2008, 1, 1));
    //        location.Put(packageGrandChild, exposures, new DateTime(2008, 1, 1));

    //        IRepository<Package> packageRepository = new RepositoryFactory().GetPackageRepository();
    //        packageRepository.Add(packageParent);
    //        transactionManager.CommitTransaction();

    //        location = new RepositoryFactory().GetLocationRepository().GetOne(location.Uid);

    //        ICollection<Package> packages = packageRepository.Find(new PackageInLocationAndNotPackedOnce(location));

    //        Assert.That(packages.Contains(packageGrandChild), Is.False);
    //        Assert.That(packages.Contains(packageChild), Is.False);
    //        Assert.That(packages.Contains(packageParent));
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_PackageInLocationSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package packageNotInLocation = NHibernateRepository_Package_Test.GetNewPackage();
    //        Package packageInLocation = NHibernateRepository_Package_Test.GetNewPackage();

    //        Location location = NHibernateRepository_ChainEntity_Test.GetNewLocation(1);
    //        List<Exposure> exposures = new List<Exposure>();
    //        location.Put(packageInLocation, exposures, new DateTime(2008, 1, 1));

    //        IRepository<Package> packageRepository = new RepositoryFactory().GetPackageRepository();
    //        packageRepository.Add(packageNotInLocation);
    //        packageRepository.Add(packageInLocation);
    //        transactionManager.CommitTransaction();

    //        location = new RepositoryFactory().GetLocationRepository().GetOne(location.Uid);

    //        ICollection<Package> packages = packageRepository.Find(new PackageInLocationSpecification(location));

    //        Assert.That(packages.Contains(packageNotInLocation), Is.False);
    //        Assert.That(packages.Contains(packageInLocation), Is.True);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_PackageKnownByChainEntity()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        IRepository<Package> packageRepository = new RepositoryFactory().GetPackageRepository();
    //        packageRepository.Add(package);
    //        ChainEntity chainEntity = new List<Identification>(package.Identifications)[0].ChainEntity;
    //        ChainEntity chainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity2);


    //        transactionManager.CommitTransaction();

    //        ICollection<Package> packages = packageRepository.Find(new PackageKnownByChainEntity(chainEntity));
    //        Assert.That(packages.Contains(package));

    //        packages = packageRepository.Find(new PackageKnownByChainEntity(chainEntity2));
    //        Assert.That(packages.Contains(package), Is.False);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_PackageNotInLocationAndKleinVerpakkingForChainEntity()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        PackageType packageType1 =
    //            NHibernateRepository_Package_Test.GetNewPackageType("retailPackaging", "PackageTypeCategoryName packageType1 " + Guid.NewGuid());
    //        PackageType packageType2 =
    //            NHibernateRepository_Package_Test.GetNewPackageType("retailPackaging", "PackageTypeCategoryName packageType2 " + Guid.NewGuid());

    //        Package packageNotInLocation = NHibernateRepository_Package_Test.GetNewPackage(packageType1);
    //        Package packageChildNotInLocation = NHibernateRepository_Package_Test.GetNewPackage(packageType1);
    //        Package packageInLocation = NHibernateRepository_Package_Test.GetNewPackage(packageType2);

    //        packageInLocation.Pack(packageChildNotInLocation);

    //        ChainEntity chainEntity1 = new List<Identification>(packageNotInLocation.Identifications)[0].ChainEntity;
    //        ChainEntity chainEntity2 = new List<Identification>(packageInLocation.Identifications)[0].ChainEntity;
    //        Assert.That(chainEntity1, Is.EqualTo(chainEntity2));

    //        Location location = new List<Location>(chainEntity1.Locations)[0];
    //        List<Exposure> exposures = new List<Exposure>();
    //        location.Put(packageInLocation, exposures, new DateTime(2008, 1, 1));

    //        IRepository<Package> packageRepository = new RepositoryFactory().GetPackageRepository();
    //        packageRepository.Add(packageNotInLocation);
    //        packageRepository.Add(packageInLocation);
            
    //        transactionManager.CommitTransaction();

    //        chainEntity1 = new RepositoryFactory().GetChainEntityRepository().GetOne(chainEntity1.Uid);

    //        ICollection<Package> packages = packageRepository.Find(new PackageNotInLocationAndKleinVerpakkingForChainEntity(chainEntity1));

    //        Assert.That(packages.Contains(packageNotInLocation), Is.True);
    //        Assert.That(packages.Contains(packageInLocation), Is.False);
    //        Assert.That(packages.Contains(packageChildNotInLocation), Is.False);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ChainEntityForTheUserSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        ChainEntity chainEntity1 = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
    //        User userInChainEntity1 = new List<User>(chainEntity1.Users)[0];

    //        ChainEntity chainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        User userInChainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewUser(1, 1);
    //        chainEntity2.AddUser(userInChainEntity2);

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity2);

    //        transactionManager.CommitTransaction();

    //        ICollection<ChainEntity> chainEntities = new RepositoryFactory().GetChainEntityRepository().Find(new ChainEntityForTheUserSpecification(userInChainEntity1));

    //        Assert.That(chainEntities.Contains(chainEntity1), Is.True);
    //        Assert.That(chainEntities.Contains(chainEntity2), Is.False);

    //        chainEntities = new RepositoryFactory().GetChainEntityRepository().Find(new ChainEntityForTheUserSpecification(userInChainEntity2));

    //        Assert.That(chainEntities.Contains(chainEntity1), Is.False);
    //        Assert.That(chainEntities.Contains(chainEntity2), Is.True);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_UserByUserNameSpecification()
    //    {
    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
    //        User user = new List<User>(chainEntity.Users)[0];

    //        User user2 = new RepositoryFactory().GetUserRepository().GetOne(new UserByUserNameSpecification(user.Username));

    //        Assert.That(user2, Is.EqualTo(user));
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_UserIsAuthenticatedSpecification()
    //    {
    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
    //        User user = new List<User>(chainEntity.Users)[0];

    //        User user2 = new RepositoryFactory().GetUserRepository().GetOne(new UserIsAuthenticatedSpecification(user.Username, user.Password));

    //        Assert.That(user2, Is.EqualTo(user));
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ChainEntiyByLocationSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        ChainEntity chainEntity1 = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
    //        Location location1 = new List<Location>(new List<Address>(chainEntity1.Addresses)[0].Locations)[0];

    //        ChainEntity chainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        Location location2 = new List<Location>(new List<Address>(chainEntity2.Addresses)[0].Locations)[0];

    //        Assert.That(location1, Is.Not.EqualTo(location2));

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity2);

    //        transactionManager.CommitTransaction();

    //        ChainEntity chainEntityFound = new RepositoryFactory().GetChainEntityRepository().GetOne(new ChainEntiyByLocationSpecification(location1));

    //        Assert.That(chainEntityFound, Is.EqualTo(chainEntity1));
    //        Assert.That(chainEntityFound, Is.Not.EqualTo(chainEntity2));

    //        chainEntityFound = new RepositoryFactory().GetChainEntityRepository().GetOne(new ChainEntiyByLocationSpecification(location2));

    //        Assert.That(chainEntityFound, Is.Not.EqualTo(chainEntity1));
    //        Assert.That(chainEntityFound, Is.EqualTo(chainEntity2));
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ChainEntiyByRoleSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        ChainEntity chainEntity1 = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
    //        User userInChainEntity1 = new List<User>(chainEntity1.Users)[0];
    //        Role role1 = NHibernateRepository_ChainEntity_Test.GetNewRole(1);
    //        userInChainEntity1.AddRole(role1);

    //        new RepositoryFactory().GetUserRepository().Store(userInChainEntity1);

    //        ChainEntity chainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        User userInChainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewUser(1, 1);
    //        chainEntity2.AddUser(userInChainEntity2);
    //        Role role2 = NHibernateRepository_ChainEntity_Test.GetNewRole(1);
    //        userInChainEntity2.AddRole(role2);

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity2);

    //        transactionManager.CommitTransaction();

    //        ICollection<ChainEntity> chainEntities = new RepositoryFactory().GetChainEntityRepository().Find(new ChainEntiyByRoleSpecification(role1));

    //        Assert.That(chainEntities.Contains(chainEntity1), Is.True);
    //        Assert.That(chainEntities.Contains(chainEntity2), Is.False);

    //        chainEntities = new RepositoryFactory().GetChainEntityRepository().Find(new ChainEntiyByRoleSpecification(role2));

    //        Assert.That(chainEntities.Contains(chainEntity1), Is.False);
    //        Assert.That(chainEntities.Contains(chainEntity2), Is.True);
    //    }
    //    [Test]
    //    public void Test_NHibernateRepository_Specification_DeliveredShipmentForChainEntityNotInLocatoinSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package packageNotInLocation = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity chainEntity1 = new List<Identification>(packageNotInLocation.Identifications)[0].ChainEntity;
    //        ChainEntity chainEntity2 = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        Assert.That(chainEntity1, Is.Not.EqualTo(chainEntity2));

    //        Location pickupLocation = new List<Location>(chainEntity1.Locations)[0];
    //        Location deliveryLocation = new List<Location>(chainEntity2.Locations)[0];

    //        Assert.That(pickupLocation, Is.Not.EqualTo(deliveryLocation));

    //        List<Package> packageList = new List<Package>();
    //        packageList.Add(packageNotInLocation);

    //        ChainEntity shipper = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

    //        Shipment shipment =
    //            new Shipment(shipper,
    //                         NHibernateRepository_ChainEntity_Test.GetExistingChainEntity(),
    //                         NHibernateRepository_ChainEntity_Test.GetExistingChainEntity(), "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", packageList, pickupLocation,
    //                         pickupLocation, new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", NHibernateRepository_Shipment_Test.GetNewShipmentExposures());

    //        shipment.Deliver(new DateTime(2008, 1, 1), string.Empty, deliveryLocation);

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity2);

    //        IRepository<Shipment> shipmentRepository = new RepositoryFactory().GetShipmentRepository();
    //        shipmentRepository.Add(shipment);

    //        transactionManager.CommitTransaction();

    //        chainEntity1 = new RepositoryFactory().GetChainEntityRepository().GetOne(chainEntity1.Uid);
    //        deliveryLocation = new RepositoryFactory().GetLocationRepository().GetOne(deliveryLocation.Uid);

    //        ICollection<Shipment> shipments = shipmentRepository.Find(new DeliveredShipmentForChainEntityNotInLocatoinSpecification(chainEntity1, deliveryLocation));

    //        Assert.That(shipments.Contains(shipment), Is.True);

    //        transactionManager.BeginTransaction();
    //        packageNotInLocation = new RepositoryFactory().GetPackageRepository().GetOne(packageNotInLocation.Uid);
    //        List<Exposure> exposures = new List<Exposure>();
    //        pickupLocation = new RepositoryFactory().GetLocationRepository().GetOne(pickupLocation.Uid);
    //        pickupLocation.Put(packageNotInLocation, exposures, new DateTime(2008, 1, 1));
    //        transactionManager.CommitTransaction();

    //        chainEntity1 = new RepositoryFactory().GetChainEntityRepository().GetOne(chainEntity1.Uid);
    //        deliveryLocation = new RepositoryFactory().GetLocationRepository().GetOne(deliveryLocation.Uid);

    //        shipments = shipmentRepository.Find(new DeliveredShipmentForChainEntityNotInLocatoinSpecification(chainEntity1, deliveryLocation));

    //        Assert.That(shipments.Contains(shipment), Is.False);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ShipmentsByChainEntity()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity shipper = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity receiver = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity forwarder = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity nobody = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location pickupLocation = new List<Location>(shipper.Locations)[0];
    //        Location deliveryLocation = new List<Location>(receiver.Locations)[0];

    //        Assert.That(pickupLocation, Is.Not.EqualTo(deliveryLocation));

    //        List<Package> packageList = new List<Package>();
    //        packageList.Add(package);


    //        Shipment shipment1 =
    //            new Shipment(shipper,
    //                         receiver,
    //                         forwarder, "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", packageList, pickupLocation,
    //                         deliveryLocation, new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", NHibernateRepository_Shipment_Test.GetNewShipmentExposures());

    //        shipment1.Deliver(new DateTime(2008, 1, 1), string.Empty, deliveryLocation);

    //        IRepository<ChainEntity> chainEntityRepository = new RepositoryFactory().GetChainEntityRepository();
    //        chainEntityRepository.Add(shipper);
    //        chainEntityRepository.Add(receiver);
    //        chainEntityRepository.Add(forwarder);
    //        chainEntityRepository.Add(nobody);

    //        IRepository<Shipment> shipmentRepository = new RepositoryFactory().GetShipmentRepository();
    //        shipmentRepository.Add(shipment1);

    //        transactionManager.CommitTransaction();

    //        shipment1 = new RepositoryFactory().GetShipmentRepository().GetOne(shipment1.Uid);
    //        shipper = chainEntityRepository.GetOne(shipper.Uid);
    //        receiver = chainEntityRepository.GetOne(receiver.Uid);
    //        forwarder = chainEntityRepository.GetOne(forwarder.Uid);
    //        nobody = chainEntityRepository.GetOne(nobody.Uid);

    //        ICollection<Shipment> shipments = shipmentRepository.Find(new ShipmentsByChainEntity(shipper));
    //        Assert.That(shipments.Contains(shipment1), Is.True);

    //        shipments = shipmentRepository.Find(new ShipmentsByChainEntity(receiver));
    //        Assert.That(shipments.Contains(shipment1), Is.True);

    //        shipments = shipmentRepository.Find(new ShipmentsByChainEntity(forwarder));
    //        Assert.That(shipments.Contains(shipment1), Is.True);

    //        shipments = shipmentRepository.Find(new ShipmentsByChainEntity(nobody));
    //        Assert.That(shipments.Contains(shipment1), Is.False);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ShipmentsForForwarderSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity shipper = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity receiver = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity forwarder = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location pickupLocation = new List<Location>(shipper.Locations)[0];
    //        Location deliveryLocation = new List<Location>(receiver.Locations)[0];

    //        Assert.That(pickupLocation, Is.Not.EqualTo(deliveryLocation));

    //        List<Package> packageList = new List<Package>();
    //        packageList.Add(package);

    //        Shipment shipment1 =
    //            new Shipment(shipper,
    //                         receiver,
    //                         forwarder, "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", packageList, pickupLocation,
    //                         deliveryLocation, new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", NHibernateRepository_Shipment_Test.GetNewShipmentExposures());

    //        shipment1.Deliver(new DateTime(2008, 1, 1), string.Empty, deliveryLocation);

    //        IRepository<ChainEntity> chainEntityRepository = new RepositoryFactory().GetChainEntityRepository();
    //        chainEntityRepository.Add(shipper);
    //        chainEntityRepository.Add(receiver);
    //        chainEntityRepository.Add(forwarder);

    //        IRepository<Shipment> shipmentRepository = new RepositoryFactory().GetShipmentRepository();
    //        shipmentRepository.Add(shipment1);

    //        transactionManager.CommitTransaction();

    //        shipment1 = new RepositoryFactory().GetShipmentRepository().GetOne(shipment1.Uid);
    //        shipper = chainEntityRepository.GetOne(shipper.Uid);
    //        forwarder = chainEntityRepository.GetOne(forwarder.Uid);

    //        Assert.That(shipment1.IsShipped, Is.False);
    //        Assert.That(shipment1.IsDelivered, Is.True);

    //        ICollection<Shipment> shipments = shipmentRepository.Find(new ShipmentsForForwarderSpecification(forwarder, false, true));
    //        Assert.That(shipments.Contains(shipment1), Is.True);

    //        shipments = shipmentRepository.Find(new ShipmentsForForwarderSpecification(forwarder, true, true));
    //        Assert.That(shipments.Contains(shipment1), Is.False);

    //        shipments = shipmentRepository.Find(new ShipmentsForForwarderSpecification(forwarder, false, false));
    //        Assert.That(shipments.Contains(shipment1), Is.False);

    //        shipments = shipmentRepository.Find(new ShipmentsForForwarderSpecification(shipper, false, true));
    //        Assert.That(shipments.Contains(shipment1), Is.False);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_UpcomingShipmentsForReceiverSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity shipper = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity receiver = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity forwarder = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location pickupLocation = new List<Location>(shipper.Locations)[0];
    //        Location deliveryLocation = new List<Location>(receiver.Locations)[0];

    //        Assert.That(pickupLocation, Is.Not.EqualTo(deliveryLocation));

    //        List<Package> packageList = new List<Package>();
    //        packageList.Add(package);

    //        Shipment shipment1 =
    //            new Shipment(shipper,
    //                         receiver,
    //                         forwarder, "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", packageList, pickupLocation,
    //                         deliveryLocation, new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", NHibernateRepository_Shipment_Test.GetNewShipmentExposures());

    //        shipment1.Pickup(new DateTime(2008, 1, 1));

    //        IRepository<ChainEntity> chainEntityRepository = new RepositoryFactory().GetChainEntityRepository();
    //        chainEntityRepository.Add(shipper);
    //        chainEntityRepository.Add(receiver);
    //        chainEntityRepository.Add(forwarder);

    //        IRepository<Shipment> shipmentRepository = new RepositoryFactory().GetShipmentRepository();
    //        shipmentRepository.Add(shipment1);

    //        transactionManager.CommitTransaction();

    //        shipment1 = new RepositoryFactory().GetShipmentRepository().GetOne(shipment1.Uid);
    //        receiver = chainEntityRepository.GetOne(receiver.Uid);
    //        forwarder = chainEntityRepository.GetOne(forwarder.Uid);

    //        Assert.That(shipment1.IsShipped, Is.True);
    //        Assert.That(shipment1.IsDelivered, Is.False);

    //        ICollection<Shipment> shipments = shipmentRepository.Find(new UpcomingShipmentsForReceiverSpecification(receiver));
    //        Assert.That(shipments.Contains(shipment1), Is.True);

    //        shipments = shipmentRepository.Find(new UpcomingShipmentsForReceiverSpecification(forwarder));
    //        Assert.That(shipments.Contains(shipment1), Is.False);

    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ShipmentsForShipperSpecification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity shipper = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity receiver = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();
    //        ChainEntity forwarder = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location pickupLocation = new List<Location>(shipper.Locations)[0];
    //        Location deliveryLocation = new List<Location>(receiver.Locations)[0];

    //        Assert.That(pickupLocation, Is.Not.EqualTo(deliveryLocation));

    //        List<Package> packageList = new List<Package>();
    //        packageList.Add(package);

    //        Shipment shipment1 =
    //            new Shipment(shipper,
    //                         receiver,
    //                         forwarder, "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", packageList, pickupLocation,
    //                         deliveryLocation, new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", NHibernateRepository_Shipment_Test.GetNewShipmentExposures());

    //        shipment1.Deliver(new DateTime(2008, 1, 1), string.Empty, deliveryLocation);

    //        IRepository<ChainEntity> chainEntityRepository = new RepositoryFactory().GetChainEntityRepository();
    //        chainEntityRepository.Add(shipper);
    //        chainEntityRepository.Add(receiver);
    //        chainEntityRepository.Add(forwarder);

    //        IRepository<Shipment> shipmentRepository = new RepositoryFactory().GetShipmentRepository();
    //        shipmentRepository.Add(shipment1);

    //        transactionManager.CommitTransaction();

    //        shipment1 = new RepositoryFactory().GetShipmentRepository().GetOne(shipment1.Uid);
    //        shipper = chainEntityRepository.GetOne(shipper.Uid);
    //        forwarder = chainEntityRepository.GetOne(forwarder.Uid);

    //        Assert.That(shipment1.IsShipped, Is.False);
    //        Assert.That(shipment1.IsDelivered, Is.True);

    //        ICollection<Shipment> shipments = shipmentRepository.Find(new ShipmentsForShipperSpecification(shipper, false, true));
    //        Assert.That(shipments.Contains(shipment1), Is.True);

    //        shipments = shipmentRepository.Find(new ShipmentsForShipperSpecification(shipper, true, true));
    //        Assert.That(shipments.Contains(shipment1), Is.False);

    //        shipments = shipmentRepository.Find(new ShipmentsForShipperSpecification(shipper, false, false));
    //        Assert.That(shipments.Contains(shipment1), Is.False);

    //        shipments = shipmentRepository.Find(new ShipmentsForShipperSpecification(forwarder, false, true));
    //        Assert.That(shipments.Contains(shipment1), Is.False);
    //    }


    //    [Test]
    //    public void Test_NHibernateRepository_Specification_TransportEquipmentByShipment()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();
    //        IRepository<Package> packageRepository = new RepositoryFactory().GetPackageRepository();
    //        packageRepository.Add(package);

    //        transactionManager.CommitTransaction();

    //        transactionManager.BeginTransaction();

    //        package = packageRepository.GetOne(package.Uid);

    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

    //        Location pickupLocation = new List<Location>(chainEntity.Locations)[0];
    //        Location deliveryLocation = new List<Location>(chainEntity.Locations)[0];

    //        pickupLocation.Put(package, new List<Exposure>(), new DateTime(2008, 1,1));

    //        new RepositoryFactory().GetLocationRepository().Store(pickupLocation);

    //        List<Package> packageList = new List<Package>();
    //        packageList.Add(package);

    //        Shipment shipment1 =
    //            new Shipment(chainEntity,
    //                         chainEntity,
    //                         chainEntity, "ShipperReferenceId",
    //                         "ForwarderReferenceId", "ReceiverReferenceId", packageList, pickupLocation,
    //                         deliveryLocation, new Range<DateTime>(new DateTime(2008, 1, 1), new DateTime(2008, 1, 31)),
    //                         new Range<DateTime>(new DateTime(2008, 2, 1), new DateTime(2008, 2, 20)),
    //                         "ForwarderMailaddress", "receiverMailaddress", NHibernateRepository_Shipment_Test.GetNewShipmentExposures());

    //        IRepository<Shipment> shipmentRepository = new RepositoryFactory().GetShipmentRepository();
    //        shipmentRepository.Add(shipment1);

    //        TransportEquipment transportEquipment =
    //            NHibernateRepository_TransportEquipment_Test.GetNewTransportEquipment();

    //        IRepository<TransportEquipment> transportEquipmentRepository = new RepositoryFactory().GetTransportEquipmentRepository();

    //        transportEquipment.Pickup(shipment1, new DateTime(2008, 1, 1), pickupLocation, new List<Exposure>());

    //        transportEquipmentRepository.Add(transportEquipment);

    //        transactionManager.CommitTransaction();

    //        shipment1 = new RepositoryFactory().GetShipmentRepository().GetOne(shipment1.Uid);
    //        transportEquipment = transportEquipmentRepository.GetOne(transportEquipment.Uid);

    //        ICollection<TransportEquipment> shipments = transportEquipmentRepository.Find(new TransportEquipmentByShipment(shipment1));
    //        Assert.That(shipments.Count, Is.EqualTo(1));
    //        Assert.That(shipments.Contains(transportEquipment), Is.True);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ExposureDocumentsByLocation()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package packageInLocation = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location location = new List<Location>(chainEntity.Locations)[0];
    //        List<Exposure> exposures = new List<Exposure>();

    //        Exposure exposure1 = NHibernateRepository_ExposureDocument_Test.GetNewExposure(1);

    //        exposures.Add(exposure1);

    //        location.Put(packageInLocation, exposures, new DateTime(2008, 1, 1));

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity);

    //        transactionManager.CommitTransaction();

    //        location = new RepositoryFactory().GetLocationRepository().GetOne(location.Uid);

    //        ICollection<ExposureDocument> exposureDocuments = new RepositoryFactory().GetExposureDocumentRepository().Find(new ExposureDocumentsByLocation(location));

    //        Assert.That(exposureDocuments.Count, Is.EqualTo(1));

    //        ExposureDocument exposureDocument = new List<ExposureDocument>(exposureDocuments)[0];

    //        Assert.That(new List<Exposure>(exposureDocument.Exposures)[0].Uid == exposure1.Uid);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ExposureDocumentsByPackage()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location location = new List<Location>(chainEntity.Locations)[0];
    //        List<Exposure> exposures = new List<Exposure>();

    //        Exposure exposure1 = NHibernateRepository_ExposureDocument_Test.GetNewExposure(1);

    //        exposures.Add(exposure1);

    //        location.Put(package, exposures, new DateTime(2008, 1, 1));

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity);

    //        transactionManager.CommitTransaction();

    //        exposure1 = new RepositoryFactory().GetExposureRepository().GetOne(exposure1.Uid);

    //        ICollection<ExposureDocument> exposureDocuments = new RepositoryFactory().GetExposureDocumentRepository().Find(new ExposureDocumentsByPackage(package));

    //        Assert.That(exposureDocuments.Count, Is.EqualTo(1));

    //        ExposureDocument exposureDocument = new List<ExposureDocument>(exposureDocuments)[0];

    //        Assert.That(new List<Exposure>(exposureDocument.Exposures)[0] == exposure1);
    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ProcessingStepByPackageAndExposureDocument()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();

    //        ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

    //        Location location = new List<Location>(chainEntity.Locations)[0];
    //        List<Exposure> exposures = new List<Exposure>();

    //        Exposure exposure1 = NHibernateRepository_ExposureDocument_Test.GetNewExposure(1);

    //        exposures.Add(exposure1);

    //        location.Put(package, exposures, new DateTime(2008, 1, 1));

    //        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity);

    //        transactionManager.CommitTransaction();

    //        transactionManager.BeginTransaction();

    //        package = new RepositoryFactory().GetPackageRepository().GetOne(package.Uid);
    //        ICollection<ExposureDocument> exposureDocuments = new RepositoryFactory().GetExposureDocumentRepository().Find(new ExposureDocumentsByPackage(package));

    //        ExposureDocument exposureDocument = new List<ExposureDocument>(exposureDocuments)[0];

    //        ProcessingStep processingStep = new ProcessingStep(string.Empty, package.Uid, 0 ,ProcessingStepType.Exposures, exposureDocument.Uid, 0, DateTime.MinValue, 0 );
    //        new RepositoryFactory().GetProcessingStepRepository().Add(processingStep);

    //        transactionManager.CommitTransaction();

    //        exposureDocument = new RepositoryFactory().GetExposureDocumentRepository().GetOne(exposureDocument.Uid);
    //        package = new RepositoryFactory().GetPackageRepository().GetOne(package.Uid);
    //        processingStep = new RepositoryFactory().GetProcessingStepRepository().GetOne(processingStep.Uid);


    //        ICollection<ProcessingStep> processingSteps = new RepositoryFactory().GetProcessingStepRepository().Find(new ProcessingStepByPackageAndExposureDocument(package, exposureDocument));
    //        Assert.That(processingSteps.Count, Is.EqualTo(1));
    //        Assert.That(processingSteps.Contains(processingStep));

    //    }

    //    [Test]
    //    public void Test_NHibernateRepository_Specification_ProcessingStepsByPackageIdentification()
    //    {
    //        TransactionManager transactionManager = new TransactionManager();
    //        transactionManager.BeginTransaction();

    //        Package package = NHibernateRepository_Package_Test.GetNewPackage();
    //        new RepositoryFactory().GetPackageRepository().Add(package);

    //        ProcessingStep processingStep = new ProcessingStep(string.Empty, package.Uid, 0, ProcessingStepType.Exposures, 0, 0, DateTime.MinValue, 0);
    //        new RepositoryFactory().GetProcessingStepRepository().Add(processingStep);

    //        transactionManager.CommitTransaction();

    //        package = new RepositoryFactory().GetPackageRepository().GetOne(package.Uid);
    //        processingStep = new RepositoryFactory().GetProcessingStepRepository().GetOne(processingStep.Uid);

    //        ICollection<ProcessingStep> processingSteps = new RepositoryFactory().GetProcessingStepRepository().Find(new ProcessingStepsByPackageIdentification(package, false));
    //        Assert.That(processingSteps.Count, Is.EqualTo(1));
    //        Assert.That(processingSteps.Contains(processingStep));

    //        processingSteps = new RepositoryFactory().GetProcessingStepRepository().Find(new ProcessingStepsByPackageIdentification(package, true));
    //        Assert.That(processingSteps.Count, Is.EqualTo(0));

    //        transactionManager.BeginTransaction();

    //        ProcessingStep processingStep2 = new ProcessingStep("ParentPackageId is filled in 1", 0, package.Uid, ProcessingStepType.Exposures, 0, 0, DateTime.MinValue, 0);
    //        new RepositoryFactory().GetProcessingStepRepository().Add(processingStep2);

    //        ProcessingStep processingStep3 = new ProcessingStep("ParentPackageId is filled in 2", 0, package.Uid, ProcessingStepType.Exposures, 0, 0, DateTime.MinValue, 0);
    //        new RepositoryFactory().GetProcessingStepRepository().Add(processingStep3);


    //        transactionManager.CommitTransaction();

    //        processingStep = new RepositoryFactory().GetProcessingStepRepository().GetOne(processingStep.Uid);
    //        processingStep2 = new RepositoryFactory().GetProcessingStepRepository().GetOne(processingStep2.Uid);
    //        processingStep3 = new RepositoryFactory().GetProcessingStepRepository().GetOne(processingStep3.Uid);

    //        processingSteps = new RepositoryFactory().GetProcessingStepRepository().Find(new ProcessingStepsByPackageIdentification(package, false));
    //        Assert.That(processingSteps.Count, Is.EqualTo(1));
    //        Assert.That(processingSteps.Contains(processingStep));

    //        processingSteps = new RepositoryFactory().GetProcessingStepRepository().Find(new ProcessingStepsByPackageIdentification(package, true));
    //        Assert.That(processingSteps.Count, Is.EqualTo(2));
    //        Assert.That(processingSteps.Contains(processingStep2));
    //        Assert.That(processingSteps.Contains(processingStep3));

    //    }
    }
}