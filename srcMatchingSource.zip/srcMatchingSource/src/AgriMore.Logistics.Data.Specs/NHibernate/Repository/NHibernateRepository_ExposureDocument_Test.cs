using System;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;
using AgriMore.Logistics.Data.NHibernate;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_ExposureDocument_Test
    {
        ///// <summary>
        ///// Setup of testfixture.
        ///// </summary>
        //[SetUp]
        //public void Setup()
        //{
        //    //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
        //}

        ///// <summary>
        ///// Cleanup of testfixture.
        ///// </summary>
        //[TearDown]
        //public void TearDown()
        //{
        //}

        //[Test]
        //public void Test_NHibernateRepository_ExposureDocument_Add()
        //{
        //    NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
        //    nHibernateTransactionManager.BeginTransaction();

        //    ExposureDocument exposureDocument = GetNewExposureDocument();

        //    IRepository<ExposureDocument> repository = new RepositoryFactory().GetExposureDocumentRepository();

        //    #region Get expectations

        //    DateTime expectedDateOfPlacement = exposureDocument.DateOfPlacement;
        //    DateTime expectedPackagePackingDateTime = exposureDocument.Package.PackingDateTime;
        //    string expectedLocationName = exposureDocument.Location.Name;
        //    List<Exposure> exposures = new List<Exposure>(exposureDocument.Exposures);
        //    int expectedExposuresCount = exposures.Count;
        //    Exposure exposure = exposures[0];
        //    DateTime expectedExposurePrescribedDateTime = exposure.PrescribedDateTime;
        //    string expectedExposureTypeName = exposure.ExposureType.Name;

        //    #endregion

        //    long uid = repository.Add(exposureDocument);
        //    long exposureUid = exposure.Uid;

        //    nHibernateTransactionManager.CommitTransaction();

        //    nHibernateTransactionManager.BeginTransaction();

        //    exposureDocument = repository.GetOne(uid);

        //    #region Verify expectations
        //    Assert.AreEqual(expectedDateOfPlacement, exposureDocument.DateOfPlacement);
        //    Assert.AreEqual(expectedPackagePackingDateTime, exposureDocument.Package.PackingDateTime);
        //    Assert.AreEqual(expectedLocationName, exposureDocument.Location.Name);
        //    exposures = new List<Exposure>(exposureDocument.Exposures);
        //    Assert.AreEqual(expectedExposuresCount, exposures.Count);

        //    exposure = exposures[0];
        //    foreach (Exposure exposureInList in exposures)
        //    {
        //        if (exposureInList.Uid == exposureUid)
        //        {
        //            exposure = exposureInList;
        //            break;
        //        }
        //    }
        //    Assert.AreEqual(expectedExposurePrescribedDateTime, exposure.PrescribedDateTime);
        //    Assert.AreEqual(expectedExposureTypeName, exposure.ExposureType.Name);

        //    #endregion

        //    nHibernateTransactionManager.CommitTransaction();
        //}

        //public static ExposureDocument GetNewExposureDocument()
        //{
        //    List<Exposure> exposures = new List<Exposure>();
        //    exposures.Add(GetNewExposure(1));
        //    exposures.Add(GetNewExposure(2));

        //    ExposureDocument exposureDocument = new ExposureDocument(NHibernateRepository_ChainEntity_Test.GetExistingLocation(), NHibernateRepository_Package_Test.GetExistingPackage(), exposures, Now());
        //    return exposureDocument;
        //}

        //private static DateTime Now()
        //{
        //    return new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
        //}

        //public static Exposure GetNewExposure(int sequenceNumber)
        //{
        //    List<MeasuredValue> measuredValues = new List<MeasuredValue>();
        //    measuredValues.Add(GetNewMeasuredValue(1));
        //    measuredValues.Add(GetNewMeasuredValue(2));

        //    Exposure exposure = new Exposure(100.10d * sequenceNumber, 200.10d * sequenceNumber, Now().AddDays(-sequenceNumber), measuredValues, GetExistingExposureType());
        //    return exposure;
        //}

        //private static ExposureType GetExistingExposureType()
        //{
        //    IRepository<ExposureType> repository = new RepositoryFactory().GetExposureTypeRepository();

        //    List<ExposureType> locations = new List<ExposureType>(repository.AsCollection());
        //    if (locations.Count > 0)
        //    {
        //        return locations[0];
        //    }

        //    ExposureType exposureType = new ExposureType("ExposureType", NHibernateRepository_Shipment_Test.GetExistingUnitOfMeasurement());
        //    Assert.AreEqual(0, exposureType.Uid);
        //    repository.Add(exposureType);
        //    Assert.AreNotEqual(0, exposureType.Uid);
        //    exposureType = repository.GetOne(exposureType.Uid);
        //    return exposureType;
        //}

        //private static MeasuredValue GetNewMeasuredValue(int sequenceNumber)
        //{
        //    return new MeasuredValue(100.11d * sequenceNumber, new DateTime(2008, 1, 10).AddDays(sequenceNumber));
        //}
    }
}