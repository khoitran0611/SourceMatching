using System;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;
using AgriMore.Logistics.Data.NHibernate;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_Treatment_Test
    {

        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        //public void Test_NHibernateRepository_Treatment_Add()
        //{
        //    NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
        //    nHibernateTransactionManager.BeginTransaction();

        //    Package package = NHibernateRepository_Package_Test.GetExistingPackage();

        //    Treatment treatment = GetNewTreatment();
        //    List<Treatment> treatments = new List<Treatment>();
        //    treatments.Add(treatment);
        //    package.AddTreatments(treatments);
        //    //package.AddTreatment(treatment);

        //    IRepository<Package> packageRepository =
        //        new RepositoryFactory().CreateRepository<Package>();

        //    #region Get expectations

        //    string expectedTreatmentName = treatment.Name;
        //    IRange<DateTime> expectedDuration = treatment.Duration;
        //    double expectedValue = treatment.Value;

        //    TreatmentType treatmentType = treatment.TreatmentType;
        //    string expectedTreatmentTypeName = treatmentType.Name;
        //    string expectedUnitOfMeasurementName = treatmentType.UnitOfMeasurement.Name;

        //    TreatmentTypeCategory treatmentTypeCategory = treatmentType.TreatmentTypeCategory;
        //    string expectedPackageTypeCategoryName = treatmentTypeCategory.Name;

        //    int expectedtreatmentTypesCount = new List<TreatmentType>(treatmentTypeCategory.TreatmentTypes).Count;

        //    #endregion

        //    packageRepository.Store(package);

        //    //long uid = treatment.Uid;
        //    //Assert.AreNotEqual(0, uid);

        //    nHibernateTransactionManager.CommitTransaction();

        //    nHibernateTransactionManager.BeginTransaction();

        //    IRepository<Treatment> treatmentRepository = new RepositoryFactory().CreateRepository<Treatment>();

        //    long uid = treatment.Uid;
        //    treatment = treatmentRepository.GetOne(uid);

        //    #region Verify expectations
        //    Assert.AreEqual(expectedTreatmentName, treatment.Name);
        //    Assert.AreEqual(expectedDuration.Start, treatment.Duration.Start);
        //    Assert.AreEqual(expectedDuration.End, treatment.Duration.End);
        //    Assert.AreEqual(expectedValue, treatment.Value);

        //    treatmentType = treatment.TreatmentType;
        //    Assert.AreEqual(expectedTreatmentTypeName, treatmentType.Name);
        //    Assert.AreEqual(expectedUnitOfMeasurementName, treatmentType.UnitOfMeasurement.Name);

        //    treatmentTypeCategory = treatmentType.TreatmentTypeCategory;
        //    Assert.AreEqual(expectedPackageTypeCategoryName, treatmentTypeCategory.Name);

        //    Assert.AreEqual(expectedtreatmentTypesCount, new List<TreatmentType>(treatmentTypeCategory.TreatmentTypes).Count);
        //    #endregion

        //    nHibernateTransactionManager.CommitTransaction();
        //}

        //public static Treatment GetNewTreatment()
        //{
        //    TreatmentType treatmentType = GetExistingTreatmentType();

        //    Treatment treatment =
        //        new Treatment(treatmentType, new Range<DateTime>(new DateTime(2008, 10, 23), new DateTime(2008, 10, 25)),
        //                      34000);
        //    return treatment;
        //}

        //public static Treatment GetExistingTreatment()
        //{
        //    IRepository<Treatment> repository = new RepositoryFactory().CreateRepository<Treatment>();

        //    List<Treatment> treatments = new List<Treatment>(repository.AsCollection());
        //    if (treatments.Count > 0)
        //    {
        //        return treatments[0];
        //    }

        //    Treatment treatment = GetNewTreatment();
        //    Assert.AreEqual(0, treatment.Uid);
        //    repository.Add(treatment);
        //    Assert.AreNotEqual(0, treatment.Uid);
        //    treatment = repository.GetOne(treatment.Uid);
        //    return treatment;
        //}

        public static TreatmentType GetExistingTreatmentType()
        {
            IRepository<TreatmentType> repository = new RepositoryFactory().CreateRepository<TreatmentType>();

            List<TreatmentType> treatmentTypes = new List<TreatmentType>(repository.AsCollection());
            if (treatmentTypes.Count > 0)
            {
                return treatmentTypes[0];
            }

            TreatmentTypeCategory treatmentTypeCategory=new TreatmentTypeCategory("Vergif");
            TreatmentType treatmentType = new TreatmentType("Chemical", treatmentTypeCategory, new UnitOfMeasurement("cm"));

            TreatmentTypeCategory treatmentTypeCategoryDrying = new TreatmentTypeCategory("Drying");
            TreatmentType treatmentTypeDrying = new TreatmentType("Drying", treatmentTypeCategoryDrying, new UnitOfMeasurement("cm"));

            if (treatmentType.Uid != 0)
            {
                treatmentType = treatmentTypeDrying;
            }

            //Assert.AreEqual(0, treatmentType.Uid);
            repository.Add(treatmentType);
            //Assert.AreNotEqual(0, treatmentType.Uid);
            treatmentType = repository.GetOne(treatmentType.Uid);
            return treatmentType;
        }
    }
}
