using System;
using AgriMore.Logistics.Common.Exception;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using NHibernate;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;
using ObjectNotFoundException=NHibernate.ObjectNotFoundException;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the DataExceptionTranslator
    /// </summary>
    [TestFixture]
    public class DataExceptionTranslator_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_DataExceptionTranslator_CanHandleNullArgument()
        {
            DataExceptionTranslator.GetException(null);
        }

        [Test]
        public void Test_DataExceptionTranslator_CanTranslateObjectNotFoundException()
        {
            ObjectNotFoundException sourceException = new ObjectNotFoundException(Guid.NewGuid(), typeof(Package));
            ObjectException objectException = DataExceptionTranslator.GetException(sourceException);
            Assert.That(objectException is AgriMore.Logistics.Common.Exception.ObjectNotFoundException);
            Assert.That(objectException.InnerException, Is.EqualTo(sourceException));
        }

        [Test]
        public void Test_DataExceptionTranslator_CanTranslateMySqlException17()
        {
            int number = 17;
            ADOException adoException = MySqlExceptionTranslator_Test.GetAdoException(number);
            ObjectException objectException = DataExceptionTranslator.GetException(adoException);
            Assert.That(objectException is ObjectLoginException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }
    }
}
