SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';
USE `agrimore_logistics`;
TRUNCATE TABLE `chainuserrole`;
TRUNCATE TABLE `chainuser`;
TRUNCATE TABLE `chainrole`;
INSERT INTO `chainrole` (`Name`) VALUES ('President');
INSERT INTO `chainrole` (`Name`) VALUES ('Republican');
INSERT INTO `chainrole` (`Name`) VALUES ('Democrat');

INSERT INTO `chainrole` (`Name`) VALUES ('Shipper');
INSERT INTO `chainrole` (`Name`) VALUES ('Grower');
INSERT INTO `chainrole` (`Name`) VALUES ('Forwarder');
INSERT INTO `chainrole` (`Name`) VALUES ('Receiver');
