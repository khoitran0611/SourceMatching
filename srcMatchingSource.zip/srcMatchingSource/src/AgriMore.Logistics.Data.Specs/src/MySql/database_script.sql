SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

CREATE SCHEMA IF NOT EXISTS `agrimore_logistics` ;
USE `agrimore_logistics`;

-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Timezone`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Timezone` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Timezone` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_timezone_name (`name` ASC) )
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackingMaterial`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackingMaterial` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackingMaterial` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_material_name (`name` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackageTypeCategory`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackageTypeCategory` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackageTypeCategory` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`UnitOfMeasurement`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`UnitOfMeasurement` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`UnitOfMeasurement` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_uom_name (`name` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackageType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackageType` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackageType` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `uomWidthId` BIGINT UNSIGNED NOT NULL ,
  `packingMaterialId` BIGINT UNSIGNED NOT NULL ,
  `packageTypeCategoryId` BIGINT UNSIGNED NOT NULL ,
  `uomHeightId` BIGINT UNSIGNED NOT NULL ,
  `uomLengthId` BIGINT UNSIGNED NOT NULL ,
  `uomWeightId` BIGINT UNSIGNED NOT NULL ,
  `width` DOUBLE NOT NULL ,
  `height` DOUBLE NOT NULL ,
  `length` DOUBLE NOT NULL ,
  `weight` DOUBLE NOT NULL ,
  `isSealed` BIT NOT NULL DEFAULT 0 ,
  `ventilation` BIT NOT NULL DEFAULT 0 ,
  PRIMARY KEY (`uid`) ,
  INDEX fkPackingMaterial_PT (`packingMaterialId` ASC) ,
  INDEX fkPackageTypeCategory_PT (`packageTypeCategoryId` ASC) ,
  INDEX fkUomWidth_PT (`uomWidthId` ASC) ,
  INDEX fkUomHeight_PT (`uomHeightId` ASC) ,
  INDEX fkUomLength_PT (`uomLengthId` ASC) ,
  INDEX fkUomWeight_PT (`uomWeightId` ASC) ,
  UNIQUE INDEX uk_packagetype_name (`name` ASC) ,
  CONSTRAINT `fkPackingMaterial_PT`
    FOREIGN KEY (`packingMaterialId` )
    REFERENCES `agrimore_logistics`.`PackingMaterial` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPackageTypeCategory_PT`
    FOREIGN KEY (`packageTypeCategoryId` )
    REFERENCES `agrimore_logistics`.`PackageTypeCategory` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkUomWidth_PT`
    FOREIGN KEY (`uomWidthId` )
    REFERENCES `agrimore_logistics`.`UnitOfMeasurement` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkUomHeight_PT`
    FOREIGN KEY (`uomHeightId` )
    REFERENCES `agrimore_logistics`.`UnitOfMeasurement` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkUomLength_PT`
    FOREIGN KEY (`uomLengthId` )
    REFERENCES `agrimore_logistics`.`UnitOfMeasurement` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkUomWeight_PT`
    FOREIGN KEY (`uomWeightId` )
    REFERENCES `agrimore_logistics`.`UnitOfMeasurement` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Package`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Package` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Package` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `packingDateTime` DATETIME NOT NULL ,
  `packageTypeId` BIGINT UNSIGNED NOT NULL ,
  `productCode` VARCHAR(45) NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkPackageType_Package (`packageTypeId` ASC) ,
  CONSTRAINT `fkPackageType_Package`
    FOREIGN KEY (`packageTypeId` )
    REFERENCES `agrimore_logistics`.`PackageType` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackagingHierarchy`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackagingHierarchy` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackagingHierarchy` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  `level` INT UNSIGNED NOT NULL ,
  `packageGroup` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkPackage_PackageHierarchy (`packageId` ASC) ,
  UNIQUE INDEX uqPackageInGroup (`packageId` ASC) ,
  CONSTRAINT `fkPackage_PackageHierarchy`
    FOREIGN KEY (`packageId` )
    REFERENCES `agrimore_logistics`.`Package` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PrimaryProduct`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PrimaryProduct` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PrimaryProduct` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `productionAreaId` VARCHAR(45) NOT NULL ,
  `lifeCycleId` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_primary_product (`productionAreaId` ASC, `lifeCycleId` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PrimaryProductPackage`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PrimaryProductPackage` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PrimaryProductPackage` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `primaryProductId` BIGINT UNSIGNED NOT NULL ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkPrimaryProduct_PPP (`primaryProductId` ASC) ,
  INDEX fkPackage_PPP (`packageId` ASC) ,
  CONSTRAINT `fkPrimaryProduct_PPP`
    FOREIGN KEY (`primaryProductId` )
    REFERENCES `agrimore_logistics`.`PrimaryProduct` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPackage_PPP`
    FOREIGN KEY (`packageId` )
    REFERENCES `agrimore_logistics`.`Package` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ChainEntity`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ChainEntity` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ChainEntity` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_chainentity_name (`name` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackageIdentification`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackageIdentification` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackageIdentification` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `chainEntityId` BIGINT UNSIGNED NOT NULL ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  `code` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkChainEntity_PackageIdentification (`chainEntityId` ASC) ,
  INDEX fkPackage_PackageIdentification (`packageId` ASC) ,
  CONSTRAINT `fkChainEntity_PackageIdentification`
    FOREIGN KEY (`chainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPackage_PackageIdentification`
    FOREIGN KEY (`packageId` )
    REFERENCES `agrimore_logistics`.`Package` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackageJournal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackageJournal` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackageJournal` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `action` VARCHAR(45) NOT NULL ,
  `actionDateTime` DATETIME NOT NULL ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ExposureType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ExposureType` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ExposureType` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `uomId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkUom_ExposureType (`uomId` ASC) ,
  UNIQUE INDEX uk_exposure_type_name (`name` ASC) ,
  CONSTRAINT `fkUom_ExposureType`
    FOREIGN KEY (`uomId` )
    REFERENCES `agrimore_logistics`.`UnitOfMeasurement` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Country`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Country` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Country` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(100) NOT NULL ,
  PRIMARY KEY (`uid`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Address`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Address` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Address` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `streetName` VARCHAR(45) NOT NULL ,
  `streetNumber` VARCHAR(45) NOT NULL ,
  `zipCode` VARCHAR(45) NOT NULL ,
  `city` VARCHAR(45) NOT NULL ,
  `email` VARCHAR(45) NULL ,
  `fax` VARCHAR(45) NULL ,
  `telephone` VARCHAR(45) NULL ,
  `countryId` BIGINT UNSIGNED NOT NULL ,
  `numberExtension` VARCHAR(45) NULL ,
  `stateProvince` VARCHAR(45) NULL ,
  `chainEntityId` BIGINT UNSIGNED NOT NULL ,
  `timezoneId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkCountry_Address (`countryId` ASC) ,
  INDEX fkChainEntity_Address (`chainEntityId` ASC) ,
  INDEX fkTimezone_Address (`timezoneId` ASC) ,
  CONSTRAINT `fkCountry_Address`
    FOREIGN KEY (`countryId` )
    REFERENCES `agrimore_logistics`.`Country` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkChainEntity_Address`
    FOREIGN KEY (`chainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkTimezone_Address`
	FOREIGN KEY (`timezoneId`)
	REFERENCES `agrimore_logistics`.`Timezone` (`uid`)
	ON DELETE NO ACTION
	ON UPDATE NO ACTION);


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Location`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Location` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Location` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `locationType` VARCHAR(45) NOT NULL ,
  `addressId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_location_name (`name` ASC) ,
  INDEX fkAddress_Location (`addressId` ASC) ,
  CONSTRAINT `fkAddress_Location`
    FOREIGN KEY (`addressId` )
    REFERENCES `agrimore_logistics`.`Address` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Exposure`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Exposure` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Exposure` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `exposureTypeId` BIGINT UNSIGNED NOT NULL ,
  `locationId` BIGINT UNSIGNED NOT NULL ,
  `startRange` DOUBLE NOT NULL ,
  `endRange` DOUBLE NOT NULL ,
  `prescribeDateTime` DATETIME NOT NULL ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkLocation_Exposure (`locationId` ASC) ,
  INDEX fkExposureType_Exposure (`exposureTypeId` ASC) ,
  INDEX fkPackage_Exposure (`packageId` ASC) ,
  CONSTRAINT `fkLocation_Exposure`
    FOREIGN KEY (`locationId` )
    REFERENCES `agrimore_logistics`.`Location` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkExposureType_Exposure`
    FOREIGN KEY (`exposureTypeId` )
    REFERENCES `agrimore_logistics`.`ExposureType` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPackage_Exposure`
    FOREIGN KEY (`packageId` )
    REFERENCES `agrimore_logistics`.`Package` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ExposureActualValue`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ExposureActualValue` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ExposureActualValue` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `value` DOUBLE NOT NULL ,
  `valueDateTime` DATETIME NOT NULL ,
  `exposureId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkExposure_ExposureValue (`exposureId` ASC) ,
  CONSTRAINT `fkExposure_ExposureValue`
    FOREIGN KEY (`exposureId` )
    REFERENCES `agrimore_logistics`.`Exposure` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ChainUser`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ChainUser` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ChainUser` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `firstname` VARCHAR(45) NOT NULL ,
  `username` VARCHAR(45) NOT NULL ,
  `lastname` VARCHAR(45) NOT NULL ,
  `password` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ChainRole`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ChainRole` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ChainRole` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ChainUserRole`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ChainUserRole` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ChainUserRole` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `chainUserId` BIGINT UNSIGNED NOT NULL ,
  `chainRoleId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkChainRole_Roles (`chainRoleId` ASC) ,
  INDEX fkChainUser_Roles (`chainUserId` ASC) ,
  CONSTRAINT `fkChainRole_Roles`
    FOREIGN KEY (`chainRoleId` )
    REFERENCES `agrimore_logistics`.`ChainRole` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkChainUser_Roles`
    FOREIGN KEY (`chainUserId` )
    REFERENCES `agrimore_logistics`.`ChainUser` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ChainEntityRole`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ChainEntityRole` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ChainEntityRole` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `chainEntityId` BIGINT UNSIGNED NOT NULL ,
  `chainRoleId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkChainEntity_ChainEntityRoles (`chainEntityId` ASC) ,
  INDEX fkChainRole_ChainEntityRoles (`chainRoleId` ASC) ,
  CONSTRAINT `fkChainEntity_ChainEntityRoles`
    FOREIGN KEY (`chainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkChainRole_ChainEntityRoles`
    FOREIGN KEY (`chainRoleId` )
    REFERENCES `agrimore_logistics`.`ChainRole` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`TreatmentType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`TreatmentType` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`TreatmentType` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX uk_treatmentType_name (`name` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackageTreatment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackageTreatment` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackageTreatment` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  `treatmentTypeId` BIGINT UNSIGNED NOT NULL ,
  `treatmentStartDateTime` DATETIME NOT NULL ,
  `treatmentEndDateTime` DATETIME NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkTreatmentType_PackageTreatment (`treatmentTypeId` ASC) ,
  INDEX fkPackage_PackageTreatment (`packageId` ASC) ,
  CONSTRAINT `fkTreatmentType_PackageTreatment`
    FOREIGN KEY (`treatmentTypeId` )
    REFERENCES `agrimore_logistics`.`TreatmentType` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPackage_PackageTreatment`
    FOREIGN KEY (`packageId` )
    REFERENCES `agrimore_logistics`.`Package` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PrimaryProductTreatment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PrimaryProductTreatment` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PrimaryProductTreatment` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `primaryProductId` BIGINT UNSIGNED NOT NULL ,
  `treatmentTypeId` BIGINT UNSIGNED NOT NULL ,
  `treatmentStartDateTime` DATETIME NOT NULL ,
  `treatmentEndDateTime` DATETIME NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkTreatmentType_PrimaryProductTreatment (`treatmentTypeId` ASC) ,
  INDEX fkPrimaryProduct_PrimaryProductTreatment (`primaryProductId` ASC) ,
  CONSTRAINT `fkTreatmentType_PrimaryProductTreatment`
    FOREIGN KEY (`treatmentTypeId` )
    REFERENCES `agrimore_logistics`.`TreatmentType` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPrimaryProduct_PrimaryProductTreatment`
    FOREIGN KEY (`primaryProductId` )
    REFERENCES `agrimore_logistics`.`PrimaryProduct` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Shipment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Shipment` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Shipment` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `forwarderChainEntityId` BIGINT UNSIGNED NOT NULL ,
  `shipperChainEntityId` BIGINT UNSIGNED NOT NULL ,
  `receiverChainEntityId` BIGINT UNSIGNED NOT NULL ,
  `pickupLocationId` BIGINT UNSIGNED NOT NULL ,
  `deliverLocationId` BIGINT UNSIGNED NOT NULL ,
  `forwarderMailaddress` VARCHAR(45) NOT NULL ,
  `receiverMailaddress` VARCHAR(45) NOT NULL ,
  `pickUpDateTimeRangeStart` DATETIME NOT NULL ,
  `pickUpDateTimeRangeEnd` DATETIME NOT NULL ,
  `deliverDateTimeRangeStart` DATETIME NOT NULL ,
  `deliverDateTimeRangeEnd` DATETIME NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkShipper_Shipment (`shipperChainEntityId` ASC) ,
  INDEX fkReceiver_Shipment (`receiverChainEntityId` ASC) ,
  INDEX fkForwarder_Shipment (`forwarderChainEntityId` ASC) ,
  INDEX fkPickupLocation_Shipment (`pickupLocationId` ASC) ,
  INDEX fkDeliverLocation_Shipment (`deliverLocationId` ASC) ,
  CONSTRAINT `fkShipper_Shipment`
    FOREIGN KEY (`shipperChainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkReceiver_Shipment`
    FOREIGN KEY (`receiverChainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkForwarder_Shipment`
    FOREIGN KEY (`forwarderChainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPickupLocation_Shipment`
    FOREIGN KEY (`pickupLocationId` )
    REFERENCES `agrimore_logistics`.`Location` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkDeliverLocation_Shipment`
    FOREIGN KEY (`deliverLocationId` )
    REFERENCES `agrimore_logistics`.`Location` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`Pickup`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`Pickup` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`Pickup` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `shipmentId` BIGINT UNSIGNED NOT NULL ,
  `pickupDateTime` DATETIME NOT NULL ,
  `locationId` BIGINT UNSIGNED NOT NULL ,
  `forwarderChainEntityId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkShipment_Pickup (`shipmentId` ASC) ,
  INDEX fkActualForwarder_Pickup (`forwarderChainEntityId` ASC) ,
  CONSTRAINT `fkShipment_Pickup`
    FOREIGN KEY (`shipmentId` )
    REFERENCES `agrimore_logistics`.`Shipment` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkActualForwarder_Pickup`
    FOREIGN KEY (`forwarderChainEntityId` )
    REFERENCES `agrimore_logistics`.`ChainEntity` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`ShipmentPackages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`ShipmentPackages` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`ShipmentPackages` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `shipmentId` BIGINT UNSIGNED NOT NULL ,
  `packageId` BIGINT UNSIGNED NOT NULL ,
  PRIMARY KEY (`uid`) ,
  INDEX fkShipment_ShipmentPackages (`shipmentId` ASC) ,
  INDEX fkPackage_ShipmentPackages (`packageId` ASC) ,
  CONSTRAINT `fkShipment_ShipmentPackages`
    FOREIGN KEY (`shipmentId` )
    REFERENCES `agrimore_logistics`.`Shipment` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkPackage_ShipmentPackages`
    FOREIGN KEY (`packageId` )
    REFERENCES `agrimore_logistics`.`Package` (`uid` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `agrimore_logistics`.`PackageMovementJournal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agrimore_logistics`.`PackageMovementJournal` ;

CREATE  TABLE IF NOT EXISTS `agrimore_logistics`.`PackageMovementJournal` (
  `uid` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `sourceLocationId` BIGINT UNSIGNED NOT NULL ,
  `destinationLocationId` BIGINT UNSIGNED NOT NULL ,
  `packageId` BIGINT NOT NULL ,
  `movementDateTime` DATETIME NOT NULL ,
  PRIMARY KEY (`uid`) )
ENGINE = InnoDB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;