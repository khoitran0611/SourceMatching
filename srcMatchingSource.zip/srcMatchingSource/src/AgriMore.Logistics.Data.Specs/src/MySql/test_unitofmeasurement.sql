SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';
USE `agrimore_logistics`;
TRUNCATE TABLE `unitofmeasurement`;