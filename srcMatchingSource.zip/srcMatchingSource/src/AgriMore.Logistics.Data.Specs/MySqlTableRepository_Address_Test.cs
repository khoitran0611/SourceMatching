//using System;
//using System.Collections.Generic;
//using System.Text;
//using AgriMore.Logistics.Data.MySql.Repository;
//using AgriMore.Logistics.Domain;
//using AgriMore.Logistics.Domain.Repository;
//using AgriMore.Logistics.Domain.Repository.MySql;
//using AgriMore.Logistics.Domain.Specification;
//using NUnit.Framework;

//namespace AgriMore.Logistics.Data.Specs
//{
//    /// <summary>
//    /// Tests the my sql table repository
//    /// </summary>
//    [TestFixture]
//    public class MySqlTableRepository_Address_Test
//    {
//        /// <summary>
//        /// Setup of testfixture.
//        /// </summary>
//        [SetUp]
//        public void Setup()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();

//            // create roles
//            DatabaseTest.ExecDDL(@"..\..\src\MySql\test_address.sql");
//        }

//        /// <summary>
//        /// Cleanup of testfixture.
//        /// </summary>
//        [TearDown]
//        public void TearDown()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - GetOne(id)
//        /// - GetOne(uid)
//        /// - Remove(Element)
//        /// </summary>
//        [Test]
//        public void Test_Address_AddGetRemove()
//        {
//            IRepository<Country> repCountry = new MySqlCountryRepository();
//            //IRepository<ChainEntity> repChainEntity = new MySqlChainEntityRepository();
//            IRepository<Address> repAddress = new MySqlAddressRepository();
//            Address m = new Address("Street 1", "1234 AB", "City", repCountry.GetOne("Country"), "Suburb 1", "Subdivision");
//            long uid = repAddress.Add(m);
//            Assert.AreNotEqual(0, uid);
//            Assert.AreNotEqual(0, m.Uid);
//            Address foundByName = repAddress.GetOne("Street 1\r\nSuburb 1\r\n1234 AB City\r\nSubdivision\r\nCountry\r\n");
//            Assert.AreEqual(m, foundByName);
//            Address foundByUid = repAddress.GetOne(uid);
//            Assert.AreEqual(m, foundByUid);
//            Assert.IsTrue(repAddress.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Store(Element)
//        /// - Remove(Element)
//        /// - Add(Element)
//        /// - GetOne(uid)
//        /// </summary>
//        [Test]
//        public void Test_Address_Store()
//        {
//            IRepository<Country> repCountry = new MySqlCountryRepository();
//            //IRepository<ChainEntity> repChainEntity = new MySqlChainEntityRepository();
//            IRepository<Address> repAddress = new MySqlAddressRepository();
//            Address m = new Address("Street 1", "1234 AB", "City", repCountry.GetOne("Country"), "Suburb 1", "Subdivision");
//            repAddress.Store(m);
//            Assert.AreNotEqual(0, m.Uid);
//            Assert.IsTrue(repAddress.Remove(m));
//            m.Uid = 0;
//            repAddress.Add(m);
//            Assert.AreNotEqual(0, m.Uid);
//            repAddress.Store(m);
//            //m.StreetLine = "user3";
//            //Assert.AreNotEqual(m, rep.GetOne(m.Uid));
//            long id = m.Uid;
//            //rep.Store(m);
//            Assert.AreEqual(id, m.Uid);
//            Assert.AreEqual(m, repAddress.GetOne(m.Uid));
//            Assert.IsTrue(repAddress.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - AsCollection()
//        /// - GetEnumerator()
//        /// - Find(ISpecification)
//        /// - Count()
//        /// - Count(ISpecification)
//        /// - Remove(ISpecification)
//        /// </summary>
//        [Test]
//        public void Test_Address_CollectionEnumerableCountRemoveSpecs()
//        {
//            IRepository<Country> repCountry = new MySqlCountryRepository();
//            //IRepository<ChainEntity> repChainEntity = new MySqlChainEntityRepository();
//            IRepository<Address> repAddress = new MySqlAddressRepository();

//            Country country = new Country("Nederland");
//            ChainEntity chainEntity = new ChainEntity("ChainEntity 3");

//            Address m1 = new Address("Street 1", "1234 AB", "City", country, "Suburb 1", "Subdivision");
//            Address m2 = new Address("Street 2", "1234 AB", "City", country, "Suburb 1", "Subdivision");
//            repAddress.Add(m1);
//            repAddress.Add(m2);
//            Assert.AreEqual(2, repAddress.Count());
//            int i = 0;
//            foreach (Address a in repAddress)
//            {
//                if (a.Equals(m1))
//                {
//                    i++;
//                }
//                if (a.Equals(m2))
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2, i);
//            i = 0;
//            foreach (Address a in repAddress.Find(new AllSpecification<Address>()))
//            {
//                if (a.Equals(m1))
//                {
//                    i++;
//                }
//                if (a.Equals(m2))
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2, i);
//            Assert.AreEqual(2, repAddress.Count(new AllSpecification<Address>()));
//            repAddress.Remove(new AllSpecification<Address>());
//            Assert.AreEqual(0, repAddress.Count(new AllSpecification<Address>()));
//        }
//    }
//}
