﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mail;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.AgreementFinalProcessServices
{
    public class EmailSender
    {
        public static bool IsSendInviteEmail
        {
            get { return string.IsNullOrEmpty(ConfigurationManager.AppSettings["SendInviteEmail"]) || Convert.ToBoolean(ConfigurationManager.AppSettings["SendInviteEmail"]); }
        }

        public static bool IsSendEmail
        {
            get { return string.IsNullOrEmpty(ConfigurationManager.AppSettings["SendEmail"]) || Convert.ToBoolean(ConfigurationManager.AppSettings["SendEmail"]); }
        }


        public static string BofEmailAddress
        {
            get { return ConfigurationManager.AppSettings["BofEmailAddress"]; }
        }

        public static string AdminUsers
        {
            get { return ConfigurationManager.AppSettings["AdminUsers"]; }
        }

        public static void SendMail(string processType, string subject, string body, string to, string ccs)
        {
            SendMail(processType, subject, body, to, ccs, string.Empty);
        }

        public static void SendMail(string processType, string subject, string body, string to, string ccs, string bccs)
        {
            string username = ConfigurationManager.AppSettings["smtp.username"];
            SmtpClient smtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtp.host"],
                int.Parse(ConfigurationManager.AppSettings["smtp.port"]));

            smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"]);

            if (!string.IsNullOrEmpty(username))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential(username,
                    ConfigurationManager.AppSettings["smtp.password"]);
            }

            var message = new MailMessage();
            message.From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]);
            message.Subject = subject;
            message.Body = body;

            if (!string.IsNullOrEmpty(to))
            {
                to = to.Replace(';', ',');
                string[] toAddress = to.Split(',');

                foreach (string t in toAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                {
                    message.To.Add(new MailAddress(t.Trim()));
                }
            }

            if (!string.IsNullOrEmpty(ccs))
            {
                ccs = ccs.Replace(';', ',');
                string[] ccAddress = ccs.Split(',');
                foreach (string t in ccAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                {
                    message.CC.Add(new MailAddress(t.Trim()));
                }
            }

            if (!string.IsNullOrEmpty(bccs))
            {
                bccs = bccs.Replace(';', ',');
                string[] bccAddress = bccs.Split(',');
                foreach (string t in bccAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                    message.Bcc.Add(new MailAddress(t.Trim()));
            }

            if (IsSendEmail) smtpClient.Send(message);
            LogEmail(to, ccs, bccs, subject, body, processType);
        }

        public static void SendMailConfirm(string toEmails, string ccEmails, DesiredAmount desiredAmount, string packagingDesc, string remarks)
        {
            var repositoryFactory = new RepositoryFactory();
            Organization growerOrg = repositoryFactory.GetOrganizationRepository().GetOne(desiredAmount.ProdSupply.Organization.Uid);
            toEmails = string.IsNullOrEmpty(toEmails) ? BofEmailAddress : toEmails;

            string[] arToEmails = ParseEmails(toEmails);
            string[] arCcEmails = ParseEmails(ccEmails);
            var langs = new string[] { "en-US", "nl-NL", "de-DE" };
            var tbdTexts = new string[] { "To be determined", "Nader vast te stellen", "Preis zu einem späteren Zeitpunkt bestimmt werden" };

            for (int i = 0; i < 3; i++)
            {
                if (string.IsNullOrEmpty(arToEmails[i]) && string.IsNullOrEmpty(arCcEmails[i])) continue;
                string mailContentPath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), string.Format("ConfirmedEmail_{0}.xml", langs[i]));

                DataSet comfirmEmail = new DataSet("ConfirmedEmail");
                comfirmEmail.ReadXml(mailContentPath);
                DataRow[] rows = comfirmEmail.Tables["ConfirmedEmail"].Select();

                string strSubject = Convert.ToString(rows[0]["subject"]);
                string strBody = Convert.ToString(rows[0]["body"]);

                strSubject = strSubject.Replace("${OtherTC}", desiredAmount.Organization.Name);
                strSubject = strSubject.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);
                strSubject = strSubject.Replace("${Supplier}", growerOrg.Name);
                strSubject = strSubject.Replace("${ProducerName}", desiredAmount.ProdSupply.Species.Name);
                strSubject = strSubject.Replace("${DeliveryDate}", desiredAmount.ProdSupply.AvailableDate.ToString("dd/MM/yyyy"));

                //Domain.User loginUser = RepositoryHelper.GetCurrentUser();
                strBody = strBody.Replace("${ConfirmedDate}", DateTime.Now.ToString("dd/MM/yyyy"));
                strBody = strBody.Replace("${LoginOtherTCUser}", string.Format("{0} {1}", desiredAmount.User.FirstName, desiredAmount.User.LastName));
                strBody = strBody.Replace("${OtherTC}", desiredAmount.Organization.Name);
                strBody = strBody.Replace("${PreferredTC}", growerOrg.TradingOrganizations[0].Name);

                strBody = strBody.Replace("${UniqueID}", desiredAmount.ConfirmProdId.ToString()); //desiredAmount.ProdSupply.Uid.ToString());
                strBody = strBody.Replace("${DeliveryDate}", desiredAmount.ProdSupply.AvailableDate.ToString("dd/MM/yyyy"));
                strBody = strBody.Replace("${DesiredAmount}", desiredAmount.Amount.ToString());
                strBody = strBody.Replace("${AvailableAmount}", Convert.ToUInt64(desiredAmount.ProdSupply.AvailableToOtherTcs).ToString());
                strBody = strBody.Replace("${AmountUOM}", desiredAmount.Uom.Name);
                strBody = strBody.Replace("${Price}", (desiredAmount.Price > 0) ? desiredAmount.Price.ToString() : tbdTexts[i]);
                strBody = strBody.Replace("${Currency}", desiredAmount.Currency);

                strBody = strBody.Replace("${Species}", desiredAmount.ProdSupply.Species.GetName(langs[i]));
                strBody = strBody.Replace("${Colour}", desiredAmount.ProdSupply.Color.GetName(langs[i]));
                strBody = strBody.Replace("${CategoryType}", desiredAmount.ProdSupply.CategoryType.GetName(langs[i]));
                strBody = strBody.Replace("${Category}", desiredAmount.ProdSupply.Category.GetName(langs[i]));

                Address address = null;
                User user = null;
                if (growerOrg.ChainEntities != null && growerOrg.ChainEntities.Count > 0)
                {
                    var chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(growerOrg.ChainEntities[0].Uid);
                    var listAddress = new List<Address>(chainEntity.Addresses);
                    if (listAddress.Count > 0) address = listAddress[0];

                    if (chainEntity.Users != null && chainEntity.Users.Count() > 0) user = chainEntity.Users.FirstOrDefault();
                }
                strBody = strBody.Replace("${Supplier}", growerOrg.Name);
                strBody = strBody.Replace("${Street}", (address != null) ? address.StreetName : string.Empty);
                strBody = strBody.Replace("${HouseNumber}", (address != null) ? address.StreetNumber +
                    (!string.IsNullOrEmpty(address.NumberExtension) ? string.Format("/{0}", address.NumberExtension) : string.Empty) : string.Empty);
                strBody = strBody.Replace("${PostalCode}", (address != null) ? address.ZipCode : string.Empty);
                strBody = strBody.Replace("${City}", (address != null) ? address.City : string.Empty);
                strBody = strBody.Replace("${PhoneNumber}", (user != null) ? user.PhoneNumMobile : string.Empty);

                strBody = strBody.Replace("${ArticleCodes}", packagingDesc);
                strBody = strBody.Replace("${ExtraInfomation}", desiredAmount.ProdSupply.Remarks);
                strBody = strBody.Replace("${Remarks}", remarks);

                //SendMail("Confirm Agreement - Packaging", strSubject, strBody, toEmails, ccEmails);
                SendMail("Confirm Agreement - Packaging", strSubject, strBody, arToEmails[i], arCcEmails[i]);
            }
        }

        public static string GetAdminUserLangEmails()
        {
            var repositoryFactory = new RepositoryFactory();

            string userEmails = string.Empty;
            string[] userIds = EmailSender.AdminUsers.Split(','); //System.Configuration.ConfigurationManager.AppSettings["AdminUsers"].Split(',');)
            userEmails = (from userId in userIds
                          select repositoryFactory.GetUserRepository().Find(new UserByUserNameSpecification(userId))
                              into users
                              where users != null && users.Count > 0
                              from user in users
                              where !string.IsNullOrEmpty(user.Email)
                              select user).Aggregate(userEmails, (current, user) => current + (string.Format("{0}:{1}", user.Email, user.UsingLang ?? "nl-NL") + ","));

            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }

        public static string GetUserLangEmail(Organization org)
        {
            var repositoryFactory = new RepositoryFactory();
            repositoryFactory.GetOrganizationRepository().Refresh(org);
            if (org.ChainEntities == null || org.ChainEntities.Count <= 0) return string.Empty;

            ChainEntity chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(org.ChainEntities[0].Uid);

            IEnumerable<User> users = chainEntity.Users;
            string userEmails = users.Where(user => !string.IsNullOrEmpty(user.Email)).Aggregate(string.Empty, (current, user) => current + (String.Format("{0}:{1}", user.Email, user.UsingLang ?? "nl-NL") + ","));
            if (!string.IsNullOrEmpty(userEmails)) userEmails = userEmails.Substring(0, userEmails.Length - 1);

            return userEmails;
        }


        public static string[] ParseEmails(string emails)
        {
            string enEmails = string.Empty, nlEmails = string.Empty, deEmails = string.Empty;

            string[] arToEmails = emails.Split(',');
            foreach (string[] arEmailLang in arToEmails.Select(emailLang => emailLang.Split(':')))
            {
                if (arEmailLang.Length == 1 || "nl-NL".Equals(arEmailLang[1])) nlEmails += arEmailLang[0] + ",";
                else if ("en-US".Equals(arEmailLang[1])) enEmails += arEmailLang[0] + ",";
                else if ("de-DE".Equals(arEmailLang[1])) deEmails += arEmailLang[0] + ",";
            }
            if (!string.IsNullOrEmpty(enEmails)) enEmails = enEmails.Substring(0, enEmails.Length - 1);
            if (!string.IsNullOrEmpty(nlEmails)) nlEmails = nlEmails.Substring(0, nlEmails.Length - 1);
            if (!string.IsNullOrEmpty(deEmails)) deEmails = deEmails.Substring(0, deEmails.Length - 1);

            return new string[] { enEmails, nlEmails, deEmails };
        }

        private static void LogEmail(string toEmails, string ccEmails, string bccEmails, string emailSubject, string emailContent, string processType)
        {
            var repositoryFactory = new RepositoryFactory();
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                var emailLogger = new EmailLogger
                {
                    ToEmails = toEmails,
                    CcEmails = ccEmails,
                    BccEmails = bccEmails,
                    EmailSubject = emailSubject,
                    MailContent = emailContent,
                    ProcessType = processType,
                    SentDate = DateTime.Now
                };
                repositoryFactory.GetEmailLoggerRepository().Add(emailLogger);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
            }
        }
    }
}
