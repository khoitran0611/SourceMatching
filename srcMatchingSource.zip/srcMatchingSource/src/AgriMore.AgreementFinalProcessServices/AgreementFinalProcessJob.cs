﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.AgreementFinalProcessServices
{
    public class AgreementFinalProcessJob : Job
    {
        private static readonly RepositoryFactory RepositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            AgreementProcess4NormalProduct();

            AgreementProcess4CompositeProduct();

            Log.Info("Finish");
        }

        private void AgreementProcess4NormalProduct()
        {
            Log.Info("Find Agreement Process");
            IList<ProductSupplyForecast> productSupplyForecasts = new List<ProductSupplyForecast>(RepositoryFactory.GetProductSuppyForecastRepository().Find(new AgreementFinalProcessSpecification()));
            if (productSupplyForecasts.Count <= 0)
            {
                Log.Info("Not found Agreement Process");
                return;
            }

            Log.Info(string.Format("Found {0} Agreement Process", productSupplyForecasts.Count));

            foreach (ProductSupplyForecast prodSupply in productSupplyForecasts)
            {
                if (prodSupply.AvailableToOtherTcs == prodSupply.TotalDesiredAmount) continue;
                IList<DesiredAmountQueue> desiredQueues = RepositoryFactory.GetDesiredAmountQueueRepository().Find(new DesiredAmountQueueOnProdIdSpecification(prodSupply.Uid)).ToList();
                if (desiredQueues.Count > 0 && prodSupply.EvalOfferType == EvalOfferType.HighestValue) desiredQueues = desiredQueues.OrderByDescending(it => it.Amount).ToList();

                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();
                    IList<DesiredAmountQueue> removeDesiredQueues = new List<DesiredAmountQueue>();
                    foreach (DesiredAmountQueue desiredQueue in desiredQueues)
                    {
                        decimal amount = desiredQueue.Amount;
                        if (desiredQueue.OfferPrice < prodSupply.FloorPrice) continue;
                        if ((prodSupply.TotalDesiredAmount + desiredQueue.Amount > prodSupply.AvailableToOtherTcs) &&
                            (desiredQueue.MinAmount == 0 || prodSupply.TotalDesiredAmount + desiredQueue.MinAmount > prodSupply.AvailableToOtherTcs)) continue;

                        if (prodSupply.AvailableToOtherTcs != null &&
                            prodSupply.TotalDesiredAmount + desiredQueue.Amount > prodSupply.AvailableToOtherTcs) amount = (decimal)prodSupply.AvailableToOtherTcs - prodSupply.TotalDesiredAmount;

                        Log.Info(string.Format("Check to Accept for Org: {0} Amount: {1} Price: {2}", desiredQueue.Organization.Name, amount, desiredQueue.OfferPrice));

                        long productCommitSoldId = 0;
                        ProductSupplyForecast desiredProd = null;
                        if ((prodSupply.ExpectedAmount == 0 && prodSupply.AvailableForSale == prodSupply.AvailableToOtherTcs && prodSupply.AvailableToOtherTcs == desiredQueue.Amount) ||
                            (prodSupply.ExpectedAmount == prodSupply.AvailableForSale && prodSupply.AvailableForSale == prodSupply.AvailableToOtherTcs && prodSupply.AvailableToOtherTcs == desiredQueue.Amount))
                        {
                            prodSupply.StatusType = ProductStatusType.Commited;
                            prodSupply.SellerStatus = SellerStatus.CommittedSold;
                            prodSupply.BuyerStatus = BuyerStatus.CommittedBought;
                            prodSupply.CommitedAmount = amount;//desiredQueue.Amount;
                            prodSupply.ActualAmount = amount;//desiredQueue.Amount;
                            prodSupply.PurchaseOrgId = desiredQueue.Organization.Uid;
                            prodSupply.WonInProcess = "Agreement";
                            prodSupply.Price = desiredQueue.OfferPrice;

                            productCommitSoldId = prodSupply.Uid;
                            desiredProd = prodSupply;
                        }
                        else
                        {
                            var productCommitSold = new ProductSupplyForecast(prodSupply.Species, prodSupply.ProdType, prodSupply.Color, prodSupply.CategoryType, prodSupply.Category, prodSupply.AvailableDate,
                                prodSupply.ExpectedAmount, prodSupply.Uom, prodSupply.User, prodSupply.Organization)
                            {
                                StatusType = ProductStatusType.Commited,
                                SellerStatus = SellerStatus.CommittedSold,
                                BuyerStatus = BuyerStatus.CommittedBought,
                                AvailableForSale = prodSupply.AvailableForSale,
                                SalePriodType = prodSupply.SalePriodType,
                                AvailableToOtherTcs = amount,//desiredQueue.Amount,
                                CommitedAmount = amount,//desiredQueue.Amount,
                                ActualAmount = amount,//desiredQueue.Amount,
                                Price = desiredQueue.OfferPrice,
                                WonInProcess = "Agreement",
                                PurchaseOrgId = desiredQueue.Organization.Uid,
                                SalesOrganization = prodSupply.SalesOrganization,
                                ParentId = prodSupply.Uid,
                                Remarks = prodSupply.Remarks
                            };

                            if (prodSupply.AddressId != 0) productCommitSold.AddressId = prodSupply.AddressId;
                            if (prodSupply.LocationId != 0) productCommitSold.LocationId = prodSupply.LocationId;
                            if (prodSupply.Package != null) productCommitSold.Package = prodSupply.Package;
                            if (prodSupply.AdditionalAttrs != null) foreach (ProductAttribute prdAttr in prodSupply.AdditionalAttrs) productCommitSold.AddProductAttributeToList(prdAttr);

                            productCommitSold.BuyerRefOne = prodSupply.BuyerRefOne;
                            productCommitSold.BuyerRefTwo = prodSupply.BuyerRefTwo;
                            productCommitSold.SellerRefOne = prodSupply.SellerRefOne;
                            productCommitSold.SellerRefTwo = prodSupply.SellerRefTwo;
                            productCommitSold.ProducerRefOne = prodSupply.ProducerRefOne;
                            productCommitSold.ProducerRefTwo = prodSupply.ProducerRefTwo;
                            productCommitSold.PackingSlip = prodSupply.PackingSlip;

                            RepositoryFactory.GetProductSuppyForecastRepository().Add(productCommitSold);
                            RepositoryFactory.GetProductSuppyForecastRepository().Flush();
                            productCommitSoldId = productCommitSold.Uid;
                            desiredProd = productCommitSold;
                            //ICollection<PackingConfirmed> packCfms = RepositoryFactory.GetPackingConfirmedRepository().Find(new PackageConfirmedByProdIdsSpecification(prodSupply.Uid.ToString()));
                            if (prodSupply.Package != null)
                            {
                                PackagingDefine packagingDefine = prodSupply.Package;
                                long packagingAmount = Convert.ToInt64(amount / packagingDefine.PackagingAmount);
                                if (packagingAmount * packagingDefine.PackagingAmount < amount) packagingAmount = packagingAmount + 1;


                                for (int i = 1; i <= 3; i++)
                                {
                                    var priceType = (PriceType)Enum.Parse(typeof(PriceType), i.ToString());
                                    if (priceType == PriceType.Price && packagingDefine.Price == 0) continue;
                                    if (priceType == PriceType.Rent && packagingDefine.RentPrice == 0) continue;
                                    if (priceType == PriceType.Deposit && packagingDefine.DepositPrice == 0) continue;

                                    var packingConfirmed = new PackingConfirmed
                                    {
                                        Packing = packagingDefine,
                                        PackingAmount = packagingAmount,
                                        ProdConfirmed = productCommitSold,
                                        PriceType = priceType
                                    };
                                    RepositoryFactory.GetPackingConfirmedRepository().Add(packingConfirmed);
                                }
                            }
                        }

                        //var desiredAmount = new DesiredAmount(desiredQueue.Amount, prodSupply.Uom, desiredQueue.User, desiredQueue.Organization, prodSupply)
                        var desiredAmount = new DesiredAmount(amount, prodSupply.Uom, desiredQueue.User, desiredQueue.Organization, desiredProd)
                        {
                            Price = desiredQueue.OfferPrice,
                            Currency = desiredQueue.Currency,
                            UpdatedDate = DateTime.Now,
                            ConfirmProdId = productCommitSoldId//productCommitSold.Uid
                        };

                        prodSupply.TotalDesiredAmount += amount; //desiredQueue.Amount;
                        RepositoryFactory.GetDesiredAmountRepository().Add(desiredAmount);
                        RepositoryFactory.GetProductSuppyForecastRepository().Store(prodSupply);
                        removeDesiredQueues.Add(desiredQueue);

                        SendConfirm(desiredAmount, desiredAmount.User, string.Empty);
                        Log.Info("-----> OK!");
                    }

                    foreach (DesiredAmountQueue desiredQueue in removeDesiredQueues) RepositoryFactory.GetDesiredAmountQueueRepository().Remove(desiredQueue);

                    if (prodSupply.TotalDesiredAmount != prodSupply.AvailableToOtherTcs) prodSupply.AvailableToOtherTcs = 0;//productSupplyForecast.TotalDesiredAmount;
                    prodSupply.AskingPrice = 0; prodSupply.FloorPrice = 0;

                    Log.Info(string.Format("Roll Available For Other TCs {0} back to Available For Sale on product ID {1}", prodSupply.AvailableToOtherTcs - prodSupply.TotalDesiredAmount, prodSupply.Uid));

                    RepositoryFactory.GetProductSuppyForecastRepository().Store(prodSupply);

                    transactionManager.CommitTransaction();
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }
        }

        private void AgreementProcess4CompositeProduct()
        {
            Log.Info("Find Agreement Process for Composite Product");
            IList<AgreementProcess4CompositeProduct> agmtProcessList = AgreementProcessServices.FindFinalAgreementProcess4CompsiteProd();
            if (agmtProcessList.Count <= 0)
            {
                Log.Info("Not found Agreement Process for Composite Product");
                return;
            }

            Log.Info(string.Format("Found {0} Agreement Process for Composite Product", agmtProcessList.Count));

            foreach (var agmtProcess in agmtProcessList)
            {
                IList<AgreementProcess4CompositeProductBuyerOffer> desiredQueues = AgreementProcessServices.FindAllOfferOnAgreementProcess(agmtProcess.Uid);
                if (desiredQueues == null || desiredQueues.Count <= 0) continue;

                var wonOffer = desiredQueues[0];
                if (wonOffer.OfferPrice < agmtProcess.FloorPrice) continue;
                Log.Info(string.Format("Won offer Id: {0}", wonOffer.Uid));

                agmtProcess.IsMatched = true;
                agmtProcess.WonBuyerId = wonOffer.BuyerId;
                agmtProcess.AgreedPrice = wonOffer.OfferPrice;

                foreach (var priceDetail in agmtProcess.PriceDetails)
                {
                    var offPriceDtls = wonOffer.OfferPriceDetails.SingleOrDefault(it => it.Product4CompositeProdFav.Uid == priceDetail.Product4CompositeProdFav.Uid);
                    if (offPriceDtls == null)
                    {
                        Log.Info(string.Format("Not found Price Detail for Product Composite Product Fav Id: {0}", priceDetail.Product4CompositeProdFav.Uid));
                        continue;
                    }
                    priceDetail.AgreedPrice = offPriceDtls.OfferPrice;
                }

                try
                {
                    Log.Info(string.Format("Check to Accept for Agreement Process for Composite Product Id: {0}, won price: {1}", agmtProcess.Uid, wonOffer.OfferPrice));

                    AgreementProcessServices.UpdateAgmtProcess4CompositeProd(agmtProcess);
                }
                catch (Exception ex)
                {
                    Log.Error(ex);
                }
            }
        }

        private static void SendConfirm(DesiredAmount desiredAmount, User user, string remarks)
        {
            string toEmails = string.Empty;
            if (!string.IsNullOrEmpty(user.Email)) toEmails += string.Format("{0}:{1}", user.Email, user.UsingLang ?? "nl-NL") + ",";

            Organization producerOrg = RepositoryFactory.GetOrganizationRepository().GetOne(desiredAmount.ProdSupply.Organization.Uid);
            string producerEmail = EmailSender.GetUserLangEmail(producerOrg); //GetUserEmail(producerOrg);
            if (!string.IsNullOrEmpty(producerEmail)) toEmails += producerEmail + ",";

            Organization saleOrg = GetSaleOrganization(desiredAmount.ProdSupply);
            if (saleOrg != null) toEmails += EmailSender.GetUserLangEmail(saleOrg); //GetUserEmail(saleOrg);

            string ccEmails = EmailSender.GetAdminUserLangEmails(); //GetAdminUserEmails();
            EmailSender.SendMailConfirm(toEmails, ccEmails, desiredAmount, string.Empty, remarks);
        }

        private static Organization GetSaleOrganization(ProductSupplyForecast prodSf)
        {
            Organization tradingOrg;
            if (prodSf.SalesOrganization != null) return prodSf.SalesOrganization;

            Organization organization = RepositoryFactory.GetOrganizationRepository().GetOne(prodSf.Organization.Uid);
            if (organization.TradingOrganizations.Count > 0)
                tradingOrg = RepositoryFactory.GetOrganizationRepository().GetOne(organization.TradingOrganizations[0].Uid);
            else
            {
                IList<GroupOrganizations> goOrg = organization.GroupOrganizations;
                foreach (GroupOrganizations groupOrganizationse in
                        goOrg.Where(groupOrganizationse => groupOrganizationse.Activated == 1).Where(
                            groupOrganizationse => IsSaleOrPurchase(groupOrganizationse.Organization)))
                {
                    return groupOrganizationse.Organization;
                }
                tradingOrg = null;
            }
            return tradingOrg;
        }

        protected static bool IsSaleOrPurchase(Organization organization)
        {
            var tradingTypes = new string[] { "SAL", "BUY", "TRD" };
            return tradingTypes.Contains(organization.BusinessType); //organization.BusinessType.Equals("SAL") || organization.BusinessType.Equals("OSAL");
        }
    }
}
