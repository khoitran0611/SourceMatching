﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class DutchAuctionDefine : IIdentifyable
    {
        private long uid;
        private Organization tradingOrg;
        private Species product;
        private string catTypeIds;
        private string categoryIds;
        private string supplierIds;
        private DateTime startDate;
        private DateTime endDate;
        private decimal maxPrice;
        private decimal minPrice;
        private decimal curPrice;
        private string decrementPrice;
        private UnitOfMeasurement uom;
        private string currency;
        private DateTime startAt;
        private int startTime;
        private DateTime closedAt;
        private int closedTime;
        private int clockRunningTime;
        private string prodForecastIds;
        private string createdBy;
        private DateTime createdAt;
        private readonly ISet invitedOrgs = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="DutchAuctionDefine"/> class.
        /// </summary>
        public DutchAuctionDefine()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DutchAuctionDefine"/> class.
        /// </summary>
        /// <param name="tradingOrg"></param>
        /// <param name="product"></param>
        /// <param name="catTypeIds"></param>
        /// <param name="categoryIds"></param>
        /// <param name="supplierIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="maxPrice"></param>
        /// <param name="minPrice"></param>
        /// <param name="curPrice"></param>
        /// <param name="uom"></param>
        /// <param name="currency"></param>
        /// <param name="startAt"></param>
        /// <param name="startTime"></param>
        /// <param name="closedAt"></param>
        /// <param name="closedTime"></param>
        /// <param name="prodForecastIds"></param>
        /// <param name="createdBy"></param>
        /// <param name="createdAt"></param>
        public DutchAuctionDefine(Organization tradingOrg, Species product, string catTypeIds, string categoryIds, string supplierIds, DateTime startDate,
            DateTime endDate, decimal maxPrice, decimal minPrice, decimal curPrice, UnitOfMeasurement uom, string currency, DateTime startAt, int startTime,
                DateTime closedAt, int closedTime, string prodForecastIds, string createdBy, DateTime createdAt)
        {
            this.tradingOrg = tradingOrg;
            this.product = product;
            this.CatTypeIds = catTypeIds;
            this.categoryIds = categoryIds;
            this.supplierIds = supplierIds;
            this.startDate = startDate;
            this.endDate = endDate;
            this.maxPrice = maxPrice;
            this.minPrice = minPrice;
            this.curPrice = curPrice;
            this.uom = uom;
            this.currency = currency;
            this.startAt = startAt;
            this.startTime = startTime;
            this.closedAt = closedAt;
            this.closedTime = closedTime;
            this.prodForecastIds = prodForecastIds;
            this.createdBy = createdBy;
            this.createdAt = createdAt;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the TradingOrg.
        /// </summary>
        public Organization TradingOrg
        {
            get { return tradingOrg; }
            set { tradingOrg = value; }
        }

        /// <summary>
        /// Gets or sets the Product.
        /// </summary>
        public Species Product
        {
            get { return product; }
            set { product = value; }
        }

        /// <summary>
        /// Gets or sets the Category Type.
        /// </summary>
        public string CatTypeIds
        {
            get { return catTypeIds; }
            set { catTypeIds = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryIds.
        /// </summary>
        public string CategoryIds
        {
            get { return categoryIds; }
            set { categoryIds = value; }
        }

        /// <summary>
        /// Gets or sets the Supplier Ids.
        /// </summary>
        public string SupplierIds
        {
            get { return supplierIds; }
            set { supplierIds = value; }
        }

        /// <summary>
        /// Gets or sets the Start Date.
        /// </summary>
        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }

        /// <summary>
        /// Gets or sets the End Date.
        /// </summary>
        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }

        /// <summary>
        /// Gets or sets the Max Price.
        /// </summary>
        public decimal MaxPrice
        {
            get { return maxPrice; }
            set { maxPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Min Price.
        /// </summary>
        public decimal MinPrice
        {
            get { return minPrice; }
            set { minPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Current Price.
        /// </summary>
        public decimal CurPrice
        {
            get { return curPrice; }
            set { curPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Decrement Price.
        /// </summary>
        public string DecrementPrice
        {
            get { return decrementPrice; }
            set { decrementPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Unit Of Measurement.
        /// </summary>
        public UnitOfMeasurement Uom
        {
            get { return uom; }
            set { uom = value; }
        }

        /// <summary>
        /// Gets or sets the Currency.
        /// </summary>
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        /// <summary>
        /// Gets or sets the Start At.
        /// </summary>
        public DateTime StartAt
        {
            get { return startAt; }
            set { startAt = value; }
        }

        /// <summary>
        /// Gets or sets the Trading OrgId.
        /// </summary>
        public int StartTime
        {
            get { return startTime; }
            set { startTime = value; }
        }

        /// <summary>
        /// Gets or sets the Closed At.
        /// </summary>
        public DateTime ClosedAt
        {
            get { return closedAt; }
            set { closedAt = value; }
        }

        /// <summary>
        /// Gets or sets the Closed Time.
        /// </summary>
        public int ClosedTime
        {
            get { return closedTime; }
            set { closedTime = value; }
        }

        /// <summary>
        /// Gets or sets the Clock Running Time.
        /// </summary>
        public int ClockRunningTime
        {
            get { return clockRunningTime; }
            set { clockRunningTime = value; }
        }

        ///<summary>
        /// Gets or sets the Product Forecast Ids.
        ///</summary>
        public string ProdForecastIds
        {
            get { return prodForecastIds; }
            set { prodForecastIds = value; }
        }

        /// <summary>
        /// Gets or sets the Created By.
        /// </summary>
        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        /// <summary>
        /// Gets or sets the Created At.
        /// </summary>
        public DateTime CreatedAt
        {
            get { return createdAt; }
            set { createdAt = value; }
        }

        /// <summary>
        /// Gets or sets the Invited Orgaganization.
        /// </summary>
        public IList<Organization> InvitedOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(invitedOrgs); }
        }

        /// <summary>
        /// Add Invited Orgaganization
        /// </summary>
        /// <param name="org"></param>
        public void AddInvitedOrgToList(Organization org)
        {
            invitedOrgs.Add(org);
        }

        /// <summary>
        /// Remove Invited Orgaganization
        /// </summary>
        public void RemoveInvitedOrgFromList()
        {
            invitedOrgs.Clear();
        }
    }
}
