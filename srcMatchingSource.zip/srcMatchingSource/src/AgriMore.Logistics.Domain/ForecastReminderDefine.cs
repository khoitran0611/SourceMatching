﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class ForecastReminderDefine : IIdentifyable
    {
        private long uid;
        private DateTime fromDate;
        private DateTime toDate;
        private string reminderOn;
        private int reminderPeriod;
        private string toEmail;
        private string ccEmail;

        private readonly ISet growers = new HashedSet();
        private readonly ISet emails = new HashedSet();
        private bool onlyForHarvestDays;

        ///<summary>
        /// Initializes a new instance of the <see cref="ForecastReminderDefine"/> class.
        ///</summary>
        public ForecastReminderDefine()
        {

        }

        ///<summary>
        /// Initializes a new instance of the <see cref="ForecastReminderDefine"/> class.
        ///</summary>
        ///<param name="fromDate"></param>
        ///<param name="toDate"></param>
        ///<param name="reminderOn"></param>
        ///<param name="reminderPeriod"></param>
        ///<param name="toEmail"></param>
        ///<param name="ccEmail"></param>
        public ForecastReminderDefine(DateTime fromDate, DateTime toDate, string reminderOn, int reminderPeriod, string toEmail, string ccEmail)
        {
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.reminderOn = reminderOn;
            this.reminderPeriod = reminderPeriod;
            this.toEmail = toEmail;
            this.ccEmail = ccEmail;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the From Date.
        /// </summary>
        public DateTime FromDate
        {
            get { return fromDate; }
            set { fromDate = value; }
        }

        /// <summary>
        /// Gets or sets the To Date.
        /// </summary>
        public DateTime ToDate
        {
            get { return toDate; }
            set { toDate = value; }
        }

        /// <summary>
        /// Gets or sets the Reminder On.
        /// </summary>
        public string ReminderOn
        {
            get { return reminderOn; }
            set { reminderOn = value; }
        }

        /// <summary>
        /// Gets or sets the Reminder Period.
        /// </summary>
        public int ReminderPeriod
        {
            get { return reminderPeriod; }
            set { reminderPeriod = value; }
        }

        /// <summary>
        /// Gets or sets the To Email.
        /// </summary>
        public string ToEmail
        {
            get { return toEmail; }
            set { toEmail = value; }
        }

        /// <summary>
        /// Gets or sets the CcEmail.
        /// </summary>
        public string CcEmail
        {
            get { return ccEmail; }
            set { ccEmail = value; }
        }

        /// <summary>
        /// Gets or sets the OnlyForHarvestDays.
        /// </summary>
        public bool OnlyForHarvestDays
        {
            get {
                return onlyForHarvestDays;
            }
            set
            {
                onlyForHarvestDays = value;
            }
        }

        /// <summary>
        /// Gets or sets the Growers.
        /// </summary>
        public IList<Organization> Growers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(growers); }
        }

        /// <summary>
        /// Add Grower Orgaganization
        /// </summary>
        /// <param name="org"></param>
        public void AddGrowerOrgToList(Organization org)
        {
            growers.Add(org);
        }

        /// <summary>
        /// Remove Invited Orgaganization
        /// </summary>
        public void RemoveGrowerOrgFromList()
        {
            growers.Clear();
        }


        /// <summary>
        /// Gets or sets the Emails.
        /// </summary>
        public IList<ForecastReminderDefineEmail> Emails
        {
            get { return ListHandler.ConvertToGenericList<ForecastReminderDefineEmail>(emails); }
        }

        /// <summary>
        /// Add emails
        /// </summary>
        /// <param name="email"></param>
        public void AddEmailToList(ForecastReminderDefineEmail email)
        {
            emails.Add(email);
        }

        /// <summary>
        /// Remove emails
        /// </summary>
        public void RemoveEmailsFromList()
        {
            emails.Clear();
        }
 
    }
}
