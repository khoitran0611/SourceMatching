using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class BiddingProcess : IIdentifyable
    {
        private long uid;
        private DateTime biddedDate;
        private decimal biddedPrice;
        private BiddingDefine bidDefine;
        private Organization organization;
        private short confirmed;
        private long confirmProdId;

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingProcess"/> class.
        /// </summary>
        protected BiddingProcess()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingProcess"/> class.
        /// </summary>
        /// <param name="biddedDate"></param>
        /// <param name="biddedPrice"></param>
        /// <param name="bidDefine"></param>
        /// <param name="org"></param>
        public BiddingProcess(DateTime biddedDate, decimal biddedPrice, BiddingDefine bidDefine, Organization org)
        {
            this.biddedDate = biddedDate;
            this.biddedPrice = biddedPrice;
            this.bidDefine = bidDefine;
            this.organization = org;
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Gets or sets the Bidded Date.
        /// </summary>
        public DateTime BiddedDate
        {
            get { return biddedDate; }
            set { biddedDate = value; }
        }

        /// <summary>
        /// Gets or sets the Bidded Price.
        /// </summary>
        public decimal BiddedPrice
        {
            get { return biddedPrice; }
            set { biddedPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Confirmed.
        /// </summary>
        public short Confirmed
        {
            get { return confirmed; }
            set { confirmed = value; }
        }

        /// <summary>
        /// Gets or sets the comfirm.
        /// </summary>
        public long ConfirmProdId
        {
            get { return confirmProdId; }
            set { confirmProdId = value; }
        }

        /// <summary>
        /// Gets or sets the BidDefine.
        /// </summary>
        public BiddingDefine BidDefine
        {
            get { return bidDefine; }
            set { bidDefine = value; }
        }

        /// <summary>
        /// Gets or sets the Organization.
        /// </summary>
        public Organization Organization
        {
            get { return organization; }
            set { organization = value; }
        }
    }
}
