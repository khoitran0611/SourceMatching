﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class DutchAuctionWonPrdSupply : IIdentifyable
    {

        private long uid;
        private long prodSupplyId;
        private long amount;
        private short confirmed;
        private DutchAuctionWonBid dutchWon;

        /// <summary>
        /// Initializes a new instance of the <see cref="DutchAuctionWonPrdSupply"/> class.
        /// </summary>
        public DutchAuctionWonPrdSupply()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DutchAuctionWonPrdSupply"/> class.
        /// </summary>
        /// <param name="prodSupplyId"></param>
        /// <param name="amount"></param>
        ///// <param name="dutchAuctionWonBid"></param>
        //public DutchAuctionWonPrdSupply(long prodSupplyId, long amount, DutchAuctionWonBid dutchAuctionWonBid)
        public DutchAuctionWonPrdSupply(long prodSupplyId, long amount)
        {
            this.prodSupplyId = prodSupplyId;
            this.amount = amount;
            //this.dutchWon = dutchAuctionWonBid;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Product Supply Id.
        /// </summary>
        public long ProdSupplyId
        {
            get { return prodSupplyId; }
            set { prodSupplyId = value; }
        }

        /// <summary>
        /// Gets or sets the Amount.
        /// </summary>
        public long Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        /// <summary>
        /// Gets or sets the Confirmed.
        /// </summary>
        public short Confirmed
        {
            get { return confirmed; }
            set { confirmed = value; }
        }

        ///// <summary>
        ///// Gets or sets the Dutch Auction Won Bid.
        ///// </summary>
        public DutchAuctionWonBid DutchWon
        {
            get { return dutchWon; }
            set { dutchWon = value; }
        }
    }
}
