﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AgreementProcess4CompositeProductBuyerOfferDetail : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual AgreementProcess4CompositeProductBuyerOffer BuyerOffer { get; set; }
    }
}
