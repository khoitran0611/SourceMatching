using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class BiddingMinPriceSetting : IIdentifyable
    {
        private long uid;
        private Species product;
        private Color color;
        private CategoryType catType;
        private Category category;
        private Organization tradingOrg;
        private DateTime fromDate;
        private DateTime toDate;
        private decimal minPrice;

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingMinPriceSetting"/> class.
        /// </summary>
        protected BiddingMinPriceSetting()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingMinPriceSetting"/> class.
        /// </summary>
        /// <param name="product"></param>
        /// <param name="cl"></param>
        /// <param name="ctgt"></param>
        /// <param name="ctg"></param>
        /// <param name="org"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="minPrice"></param>
        public BiddingMinPriceSetting(Species product, Color cl, CategoryType ctgt, Category ctg, Organization org, DateTime fromDate, DateTime toDate, decimal minPrice)
        {
            this.product = product;
            this.color = cl;
            this.catType = ctgt;
            this.category = ctg;
            this.tradingOrg = org;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.minPrice = minPrice;
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            var other = obj as BiddingMinPriceSetting;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return uid.GetHashCode();
        }
        #endregion

        /// <summary>
        /// Gets or sets the Product.
        /// </summary>
        /// <value>The product.</value>
        public Species Product
        {
            get { return product; }
            set { product = value; }
        }

        /// <summary>
        /// Gets or sets the Product.
        /// </summary>
        /// <value>The color.</value>
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryType.
        /// </summary>
        /// <value>The Category Type.</value>
        public CategoryType CatType
        {
            get { return catType; }
            set { catType = value; }
        }

        /// <summary>
        /// Gets or sets the Category.
        /// </summary>
        /// <value>The Category.</value>
        public Category Category
        {
            get { return category; }
            set { category = value; }
        }

        /// <summary>
        /// Gets or sets the Trader Organization.
        /// </summary>
        /// <value>The trader Organization.</value>
        public Organization TradingOrg
        {
            get { return tradingOrg; }
            set { tradingOrg = value; }
        }

        /// <summary>
        /// Gets or sets the From Date.
        /// </summary>
        /// <value>The From date.</value>
        public DateTime FromDate
        {
            get { return fromDate; }
            set { fromDate = value; }
        }

        /// <summary>
        /// Gets or sets the To Date.
        /// </summary>
        /// <value>The To Date</value>
        public DateTime ToDate
        {
            get { return toDate; }
            set { toDate = value; }
        }

        /// <summary>
        /// Gets or sets the minimum price.
        /// </summary>
        public decimal MinPrice
        {
            get { return minPrice; }
            set { minPrice = value; }
        }
    }
}
