﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class FinalCostCodesLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private FinalCostCodes costCodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryTypeLang"/> class.
        /// </summary>
        public FinalCostCodesLang()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryTypeLang"/> class.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="_costCodes"></param>
        public FinalCostCodesLang(string name, string langCode, FinalCostCodes _costCodes)
        {
            this.name = name;
            this.langCode = langCode;
            this.costCodes = _costCodes;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

        /// <summary>
        /// Gets or sets the CostCodes
        /// </summary>
        public FinalCostCodes CostCodes
        {
            get { return costCodes; }
            set { costCodes = value; }
        }
    }
}
