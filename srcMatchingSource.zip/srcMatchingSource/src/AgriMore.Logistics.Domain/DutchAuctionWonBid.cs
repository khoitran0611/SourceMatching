﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class DutchAuctionWonBid : IIdentifyable
    {
        private long uid;
        private Organization wonOrg;
        private string wonItems;
        private long wonAmount;
        private decimal wonPrice;
        private string currency;
        private DutchAuctionDefine dutchAuction;
        private short confirmed;
        private string biddedBy;
        private string confirmProdIds;
        private DateTime biddedAt;
        private readonly ISet prodSupplies = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="DutchAuctionWonBid"/> class.
        /// </summary>
        public DutchAuctionWonBid()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DutchAuctionWonBid"/> class.
        /// </summary>
        /// <param name="wonOrg"></param>
        /// <param name="wonItems"></param>
        /// <param name="wonPrice"></param>
        /// <param name="currency"></param>
        /// <param name="dutchAuction"></param>
        /// <param name="biddedBy"></param>
        /// <param name="biddedAt"></param>
        public DutchAuctionWonBid(Organization wonOrg, string wonItems, decimal wonPrice, string currency, DutchAuctionDefine dutchAuction,
            string biddedBy, DateTime biddedAt)
        {
            this.wonOrg = wonOrg;
            this.wonItems = wonItems;
            this.wonPrice = wonPrice;
            this.currency = currency;
            this.dutchAuction = dutchAuction;
            this.biddedBy = biddedBy;
            this.biddedAt = biddedAt;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Won Organization.
        /// </summary>
        public Organization WonOrg
        {
            get { return wonOrg; }
            set { wonOrg = value; }
        }

        /// <summary>
        /// Gets or sets the Won Items.
        /// </summary>
        public string WonItems
        {
            get { return wonItems; }
            set { wonItems = value; }
        }

        /// <summary>
        /// Gets or sets the Won Amount.
        /// </summary>
        public long WonAmount
        {
            get { return wonAmount; }
            set { wonAmount = value; }
        }

        /// <summary>
        /// Gets or sets the Won Price.
        /// </summary>
        public decimal WonPrice
        {
            get { return wonPrice; }
            set { wonPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Currency.
        /// </summary>
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        /// <summary>
        /// Gets or sets the Dutch Auction.
        /// </summary>
        public DutchAuctionDefine DutchAuction
        {
            get { return dutchAuction; }
            set { dutchAuction = value; }
        }

        /// <summary>
        /// Gets or sets the Confirmed.
        /// </summary>
        public short Confirmed
        {
            get { return confirmed; }
            set { confirmed = value; }
        }

        /// <summary>
        /// Gets or sets the Bidded By.
        /// </summary>
        public string BiddedBy
        {
            get { return biddedBy; }
            set { biddedBy = value; }
        }

        /// <summary>
        /// Gets or sets the ConfirmProdIds.
        /// </summary>
        public string ConfirmProdIds
        {
            get { return confirmProdIds; }
            set { confirmProdIds = value; }
        }

        /// <summary>
        /// Gets or sets the Bidded At.
        /// </summary>
        public DateTime BiddedAt
        {
            get { return biddedAt; }
            set { biddedAt = value; }
        }

        /// <summary>
        /// Gets or sets the Won Product Supplies.
        /// </summary>
        public IList<DutchAuctionWonPrdSupply> ProdSupplies
        {
            get { return ListHandler.ConvertToGenericList<DutchAuctionWonPrdSupply>(prodSupplies); }
        }

        /// <summary>
        /// Add Won Product Supply
        /// </summary>
        /// <param name="wonPrdSupply"></param>
        public void AddWonProdSupplyToList(DutchAuctionWonPrdSupply wonPrdSupply)
        {
            prodSupplies.Add(wonPrdSupply);
        }

        /// <summary>
        /// Remove Won Product Supplies
        /// </summary>
        public void RemoveWonProdSupplyFromList()
        {
            prodSupplies.Clear();
        }
    }
}
