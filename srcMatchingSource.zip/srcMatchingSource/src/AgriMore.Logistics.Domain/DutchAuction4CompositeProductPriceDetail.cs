﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class DutchAuction4CompositeProductPriceDetail : IIdentifyable
    {
        public long Uid { get; set; }

        public virtual decimal AgreedPrice { get; set; }

        public virtual decimal MinPrice { get; set; }

        public virtual decimal MaxPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }
        public virtual DutchAuction4CompositeProduct DutchAuction4CompositeProd { get; set; }

        public DutchAuction4CompositeProductPriceDetail Copy()
        {
            var tmpObj = (DutchAuction4CompositeProductPriceDetail)this.MemberwiseClone();
            tmpObj.Uid = 0;
            tmpObj.DutchAuction4CompositeProd = null;
            return tmpObj;
        }
    }
}
