﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BaseGroupOfOrganization : IIdentifyable<BaseGroupOfOrganization.BaseGoOID>
    {
        private BaseGoOID uid;
        private string createdBy;
        private DateTime createdAt;
        private int isActive;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseGroupOfOrganization"/> class.
        /// </summary>
        public BaseGroupOfOrganization() { }

        public BaseGoOID Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        public DateTime CreatedAt
        {
            get { return createdAt; }
            set { createdAt = value; }
        }

        public int IsActive
        {
            get { return isActive; }
            set { isActive = value; }
        }

        [Serializable]
        public class BaseGoOID : IComparable
        {
            public override bool Equals(object obj)
            {
                if (obj == this)
                    return true;
                if (obj == null)
                    return false;

                BaseGoOID that = obj as BaseGoOID;
                if (that == null)
                {
                    return false;
                }
                else
                {
                    if (this.OrgId != that.OrgId)
                        return false;
                    if (this.GroupOrgId != that.GroupOrgId)
                        return false;
                    return true;
                }

            }

            public override int GetHashCode()
            {
                return OrgId.GetHashCode() ^ GroupOrgId.GetHashCode();
            }

            public string OrgId
            {
                get
                {
                    return orgId;
                }
                set
                {
                    orgId = value;
                }
            }

            public string GroupOrgId
            {
                get
                {
                    return groupOrgId;
                }
                set
                {
                    groupOrgId = value;
                }
            }

            protected string orgId;
            protected string groupOrgId;

            #region IComparable Members

            public int CompareTo(object obj)
            {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }
    }
}