﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class AddonsConfirmed : IIdentifyable
    {
        private long uid;
        private long amount;
        private int debitVat;
        private string debitVatText;
        private int creditVat;
        private string creditVatText;
        private AddOnsDefine addOns;
        private PackingConfirmed packConfirmed;
        private ProductSupplyForecast prodConfirmed;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddonsConfirmed"/> class.
        /// </summary>
        public AddonsConfirmed()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddonsConfirmed"/> class.
        /// </summary>
        /// <param name="addOns"></param>
        /// <param name="packConfirmed"></param>
        /// <param name="prodConfirmed"></param>
        public AddonsConfirmed(AddOnsDefine addOns, PackingConfirmed packConfirmed, ProductSupplyForecast prodConfirmed)
        {
            this.addOns = addOns;
            this.packConfirmed = packConfirmed;
            this.prodConfirmed = prodConfirmed;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Amount.
        /// </summary>
        /// <value>The uid.</value>
        public long Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        /// <summary>
        /// Gets or sets the DebitVat
        /// </summary>
        public int DebitVat
        {
            get { return debitVat; }
            set { debitVat = value; }
        }

        /// <summary>
        /// Gets or sets the DebitVatText
        /// </summary>
        public string DebitVatText
        {
            get { return debitVatText; }
            set { debitVatText = value; }
        }

        /// <summary>
        /// Gets or sets the CreditVat
        /// </summary>
        public int CreditVat
        {
            get { return creditVat; }
            set { creditVat = value; }
        }

        /// <summary>
        /// Gets or sets the CreditVatText
        /// </summary>
        public string CreditVatText
        {
            get { return creditVatText; }
            set { creditVatText = value; }
        }

        /// <summary>
        /// Gets or sets the AddOns.
        /// </summary>
        /// <value>The uid.</value>
        public AddOnsDefine AddOns
        {
            get { return addOns; }
            set { addOns = value; }
        }

        /// <summary>
        /// Gets or sets the PackConfirmed.
        /// </summary>
        /// <value>The uid.</value>
        public PackingConfirmed PackConfirmed
        {
            get { return packConfirmed; }
            set { packConfirmed = value; }
        }

        /// <summary>
        /// Gets or sets the ProdConfirmed.
        /// </summary>
        /// <value>The uid.</value>
        public ProductSupplyForecast ProdConfirmed
        {
            get { return prodConfirmed; }
            set { prodConfirmed = value; }
        }
    }
}
