﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    public class BiddingPurchase : IIdentifyable
    {
        private long uid;
        private long amount;
        private UnitOfMeasurement uom;
        private decimal maxPrice;
        private decimal biddingPrice;
        private string currency;
        private bool isMatched;
        private long matchedProdId;
        private DateTime purchaseFrom;
        private DateTime purchaseTo;
        private DateTime biddingStartAt;
        private DateTime biddingCloseAt;
        private string buyerUid;
        private string sellerWonId;
        private DateTime updatedAt;
        private long planningId;
        private long issuedSeq;

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingPurchase"/> class.
        /// </summary>
        public BiddingPurchase() { }

        private readonly ISet prodFavs = new HashedSet();
        private readonly ISet sellers = new HashedSet();
        private readonly ISet suppliers = new HashedSet();
        private readonly ISet idtPackagings = new HashedSet();

        public long Uid { get { return uid; } set { uid = value; } }
        public long Amount { get { return amount; } set { amount = value; } }
        public UnitOfMeasurement Uom { get { return uom; } set { uom = value; } }
        public decimal MaxPrice { get { return maxPrice; } set { maxPrice = value; } }
        public decimal BiddingPrice { get { return biddingPrice; } set { biddingPrice = value; } }
        public string Currency { get { return currency; } set { currency = value; } }
        public bool IsMatched { get { return isMatched; } set { isMatched = value; } }
        public long MatchedProdId { get { return matchedProdId; } set { matchedProdId = value; } }
        public DateTime PurchaseFrom { get { return purchaseFrom; } set { purchaseFrom = value; } }
        public DateTime PurchaseTo { get { return purchaseTo; } set { purchaseTo = value; } }
        public DateTime BiddingStartAt { get { return biddingStartAt; } set { biddingStartAt = value; } }
        public DateTime BiddingCloseAt { get { return biddingCloseAt; } set { biddingCloseAt = value; } }
        public string BuyerUid { get { return buyerUid; } set { buyerUid = value; } }
        public string SellerWonId { get { return sellerWonId; } set { sellerWonId = value; } }
        public DateTime UpdatedAt { get { return updatedAt; } set { updatedAt = value; } }
        public long PlanningId { get { return planningId; } set { planningId = value; } }
        public long IssuedSeq { get { return issuedSeq; } set { issuedSeq = value; } }

        #region Gets/Set/Remove Product Favourites
        /// <summary>
        /// Gets or sets the Available To Orgaganization.
        /// </summary>
        public IList<ProductFavourites> ProdFavs
        {
            get { return ListHandler.ConvertToGenericList<ProductFavourites>(prodFavs); }
        }

        /// <summary>
        /// Add Product Favourite
        /// </summary>
        /// <param name="proFav"></param>
        public void AddFavouriteToList(ProductFavourites proFav)
        {
            prodFavs.Add(proFav);
        }

        /// <summary>
        /// Remove Favourite
        /// </summary>
        public void RemoveFavouritesFromList()
        {
            prodFavs.Clear();
        }
        #endregion

        #region Gets/Set/Remove Seller
        /// <summary>
        /// Gets or sets the Available To Orgaganization.
        /// </summary>
        public IList<Organization> Sellers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(sellers); }
        }

        /// <summary>
        /// Add Seller
        /// </summary>
        /// <param name="org"></param>
        public void AddSellerToList(Organization org)
        {
            sellers.Add(org);
        }

        /// <summary>
        /// Remove Seller
        /// </summary>
        public void RemoveSellerFromList()
        {
            sellers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Available to Trading Companies
        /// <summary>
        /// Gets or sets the Supplier.
        /// </summary>
        public IList<Organization> Suppliers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(suppliers); }
        }

        /// <summary>
        /// Add Supplier
        /// </summary>
        /// <param name="org"></param>
        public void AddSupplierToList(Organization org)
        {
            suppliers.Add(org);
        }

        /// <summary>
        /// Remove Supplier
        /// </summary>
        public void RemoveSupplierFromList()
        {
            suppliers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Packaging
        /// <summary>
        /// Gets or sets PackagingDefine.
        /// </summary>
        public IList<PackagingDefine> IdtPackagings
        {
            get { return ListHandler.ConvertToGenericList<PackagingDefine>(idtPackagings); }
        }

        /// <summary>
        /// Add Packaging
        /// </summary>
        /// <param name="pack"></param>
        public void AddPackagingToList(PackagingDefine pack)
        {
            idtPackagings.Add(pack);
        }

        /// <summary>
        /// Remove Packaging
        /// </summary>
        public void RemovePackagingFromList()
        {
            idtPackagings.Clear();
        }
        #endregion
    }
}
