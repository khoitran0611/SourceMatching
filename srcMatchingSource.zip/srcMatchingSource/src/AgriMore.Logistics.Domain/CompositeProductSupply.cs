﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class CompositeProductSupply : IIdentifyable
    {
        public long Uid { get; set; }

        public virtual string Name { get; set; }

        public virtual decimal PriceSurcharge { get; set; }

        public virtual decimal Price { get; set; }

        public virtual string Currency { get; set; }

        public virtual DateTime AvailableDate { get; set; }

        public virtual DateTime DispatchDate { get; set; }

        public virtual CompositeProdStatus Status { get; set; }

        public virtual long ShipmentItemId { get; set; }

        public virtual long DebitInvId { get; set; }

        public virtual long  CreditInvId { get; set; }

        public virtual string SellerId { get; set; }

        public virtual string BuyerId { get; set; }

        public virtual PackagingDefine PackageType { get; set; }

        public virtual DateTime UpdatedAt { get; set; }

        private readonly IList product4CmpProd = new List<Products4CompositeProduct>();
        [DataMember(Name = "Product4CmpProd")]
        public IList<Products4CompositeProduct> Product4CmpProd
        {
            get { return product4CmpProd.Cast<Products4CompositeProduct>().ToList(); }
        }

        public void AddProd4CompositeProduct(Products4CompositeProduct prod4CmpProduct)
        {
            prod4CmpProduct.CompositeProd = this;
            product4CmpProd.Add(prod4CmpProduct);
        }

        public void RemoveProdCompositeProduct(Products4CompositeProduct prod4CmpProduct)
        {
            product4CmpProd.Remove(prod4CmpProduct);
        }

        public void RemoveAllProd4CompositeProduct()
        {
            product4CmpProd.Clear();
        }
    }
}
