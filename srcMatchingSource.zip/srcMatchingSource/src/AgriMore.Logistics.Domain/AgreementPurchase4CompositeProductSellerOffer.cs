﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AgreementPurchase4CompositeProductSellerOffer : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual DateTime OfferAt { get; set; }

        public virtual string SellerId { get; set; }

        public virtual AgreementPurchase4CompositeProduct AgmtPurchase { get; set; }

        #region Offer Price Details
        private readonly IList offerPriceDetails = new List<AgreementPurchase4CompositeProductSellerOfferDetail>();
        [DataMember(Name = "OfferPriceDetails")]
        public IList<AgreementPurchase4CompositeProductSellerOfferDetail> OfferPriceDetails
        {
            get { return offerPriceDetails.Cast<AgreementPurchase4CompositeProductSellerOfferDetail>().ToList(); }
        }

        public void AddOfferPriceDetail(AgreementPurchase4CompositeProductSellerOfferDetail offerPriceDetail)
        {
            offerPriceDetail.SellerOffer = this;
            offerPriceDetails.Add(offerPriceDetail);
        }

        public void RemoveOfferPriceDetail(AgreementPurchase4CompositeProductSellerOfferDetail offerPriceDetail)
        {
            offerPriceDetails.Remove(offerPriceDetail);
        }

        public void RemoveAllOfferPriceDetail()
        {
            offerPriceDetails.Clear();
        }
        #endregion
    }
}
