﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public enum CorporateInfoType
    {
        Video = 0,
        Picture = 1,

        Certificate = 2,

        Document = 3
    }
}
