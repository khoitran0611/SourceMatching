﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public class AddOnDefineOrganization
    {
        private AddOnsDefine addOnsDefine ;        
        private long isSelected;

        /// <summary>
        /// 
        /// </summary>
        public AddOnDefineOrganization() { }              

        /// <summary>
        /// 
        /// </summary>
        public long IsSelected
        {
            get { return isSelected; }
            set { isSelected = value; }
        }

        public AddOnsDefine AddOnsDefine
        {
            get { return addOnsDefine; }
            set { addOnsDefine = value; }
        }
    }
}
