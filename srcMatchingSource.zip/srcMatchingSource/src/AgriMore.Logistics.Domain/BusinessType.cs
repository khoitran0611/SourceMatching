﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BusinessType : IIdentifyable<string>, INameAccessor
    {
        private string uid;
        private string name;

        /// <summary>
        /// Initializes a new instance of the <see cref="Organization"/> class.
        /// </summary>
        protected BusinessType() { }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        public string Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the organization name.
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string GetName(string langCode)
        {
            return name;
        }
    }
}
