﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using System.Linq;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class AvailableForSaleSetting : IIdentifyable
    {
        private long uid;
        private Species product;
        private ProdType prodType;
        private CategoryType catType;
        private Category category;

        private DateTime availableFrom;
        private DateTime availableTo;

        private int startNDays;
        private int endNDays;

        private PeriodSettingType settingType;
        private SalePriodType salePeriodType;
        private int availablePercent;
        private string createdBy;
        private DateTime createdDate;

        private string settingOrgId;
        private readonly ISet settingForOrgs = new HashedSet();
        private readonly ISet settingAvaiableForOrgs = new HashedSet();
        private bool automaticallyUpdateWithNew;
        //private string orgSetting;
        //private string admGroupId;

        /// <summary>
        /// Initializes a new instance of the <see cref="AvailableForSaleSetting"/> class.
        /// </summary>
        public AvailableForSaleSetting()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AvailableForSaleSetting"/> class.
        /// </summary>
        /// <param name="product"></param>
        /// <param name="prodType"></param>
        /// <param name="availableFrom"></param>
        /// <param name="availableTo"></param>
        /// <param name="salePeriodType"></param>
        /// <param name="availablePercent"></param>
        /// <param name="createdBy"></param>
        /// <param name="createdDate"></param>
        public AvailableForSaleSetting(Species product, ProdType prodType, DateTime availableFrom, DateTime availableTo, SalePriodType salePeriodType,
            int availablePercent, string createdBy, DateTime createdDate)
        {
            this.product = product;
            this.prodType = prodType;
            this.availableFrom = availableFrom;
            this.availableTo = availableTo;
            this.salePeriodType = salePeriodType;
            this.availablePercent = availablePercent;
            this.createdBy = createdBy;
            this.createdDate = createdDate;
            this.settingType = PeriodSettingType.Fixed;
        }

        ///<summary>
        ///</summary>
        ///<param name="product"></param>
        ///<param name="prodType"></param>
        ///<param name="startNDays"></param>
        ///<param name="endNDays"></param>
        ///<param name="salePeriodType"></param>
        ///<param name="availablePercent"></param>
        ///<param name="createdBy"></param>
        ///<param name="createdDate"></param>
        public AvailableForSaleSetting(Species product, ProdType prodType, int startNDays, int endNDays, SalePriodType salePeriodType,
            int availablePercent, string createdBy, DateTime createdDate)
        {
            this.product = product;
            this.prodType = prodType;
            this.startNDays = startNDays;
            this.endNDays = endNDays;
            this.salePeriodType = salePeriodType;
            this.availablePercent = availablePercent;
            this.createdBy = createdBy;
            this.createdDate = createdDate;
            this.settingType = PeriodSettingType.Flexible;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the ProdType.
        /// </summary>
        public ProdType ProdType
        {
            get { return prodType; }
            set { prodType = value; }
        }

        /// <summary>
        /// Gets or sets the Product.
        /// </summary>
        public Species Product
        {
            get { return product; }
            set { product = value; }
        }

        /// <summary>
        /// Gets or sets the Product.
        /// </summary>
        public CategoryType CatType
        {
            get { return catType; }
            set { catType = value; }
        }

        /// <summary>
        /// Gets or sets the Category.
        /// </summary>
        public Category Category
        {
            get { return category; }
            set { category = value; }
        }

        /// <summary>
        /// Gets or sets the Available From Date.
        /// </summary>
        public DateTime AvailableFrom
        {
            get { return availableFrom; }
            set { availableFrom = value; }
        }

        /// <summary>
        /// Gets or sets the Available To Date.
        /// </summary>
        public DateTime AvailableTo
        {
            get { return availableTo; }
            set { availableTo = value; }
        }

        /// <summary>
        /// Gets or sets the StartNDays.
        /// </summary>
        public int StartNDays
        {
            get { return startNDays; }
            set { startNDays = value; }
        }

        /// <summary>
        /// Gets or sets the EndNDays.
        /// </summary>
        public int EndNDays
        {
            get { return endNDays; }
            set { endNDays = value; }
        }
        /// <summary>
        /// Gets or sets the AutomaticallyUpdateWithNew.
        /// </summary>
        public bool AutomaticallyUpdateWithNew
        {
            get { return automaticallyUpdateWithNew;}
            set { automaticallyUpdateWithNew = value; }
        }

        /// <summary>
        /// Gets or sets the Setting Type.
        /// </summary>
        public PeriodSettingType SettingType
        {
            get { return settingType; }
            set { settingType = value; }
        }

        /// <summary>
        /// Gets or sets the Sale Period Type.
        /// </summary>
        public SalePriodType SalePeriodType
        {
            get { return salePeriodType; }
            set { salePeriodType = value; }
        }

        /// <summary>
        /// Gets or sets the Available Percent.
        /// </summary>
        public int AvailablePercent
        {
            get { return availablePercent; }
            set { availablePercent = value; }
        }

        /// <summary>
        /// Gets or sets the Created By.
        /// </summary>
        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        /// <summary>
        /// Gets or sets the Created Date.
        /// </summary>
        public DateTime CreatedDate
        {
            get { return createdDate; }
            set { createdDate = value; }
        }

        /// <summary>
        /// Gets or sets the Setting Organization Id.
        /// </summary>
        public string SettingOrgId
        {
            get { return settingOrgId; }
            set { settingOrgId = value; }
        }

        /// <summary>
        /// Gets or sets the Setting For Orgaganization.
        /// </summary>
        public IList<Organization> SettingForOrgs
        {
            get {
                    return ListHandler.ConvertToGenericList<Organization>(settingForOrgs);
            }
        }

        /// <summary>
        /// Gets or sets the Setting For Orgaganization.
        /// </summary>
        public IList<Organization> SettingAvaiableForOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(settingAvaiableForOrgs); }
        }
        
        /// <summary>
        /// Add Setting For Orgaganization
        /// </summary>
        /// <param name="org"></param>
        public void AddSettingForOrgToList(Organization org)
        {
            settingForOrgs.Add(org);
        }

        /// <summary>
        /// Remove Setting For Orgaganization
        /// </summary>
        public void RemoveSettingForOrgFromList()
        {
            settingForOrgs.Clear();
        }


        /// <summary>
        /// Add Setting For Orgaganization
        /// </summary>
        /// <param name="org"></param>
        public void AddSettingForAvaiableOrgToList(Organization org)
        {
            settingAvaiableForOrgs.Add(org);
        }

        /// <summary>
        /// Remove Setting For Orgaganization
        /// </summary>
        public void RemoveSettingForAvaiableOrgFromList()
        {
            settingAvaiableForOrgs.Clear();
        }
    }
}
