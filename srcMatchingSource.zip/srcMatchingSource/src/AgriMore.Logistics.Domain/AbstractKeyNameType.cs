using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Base class for domain types that are composed of a 'name' and must be persistable. 
    /// This class implements the Uid and Name properties and supports the IIdentifyable interface.
    /// To use this class, you must provide a constructor that calls the base constructor with a 
    /// 'name' argument. Please be aware that the name value is immutable after the object has been
    /// created.
    /// </summary>
    public abstract class AbstractKeyNameType : IIdentifyable
    {
        private string name;
        private long uid;

        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractKeyNameType"/> class.
        /// </summary>
        protected AbstractKeyNameType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractKeyNameType"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public AbstractKeyNameType(string name)
        {
            this.name = name;
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            if (obj != null)
                if (typeof(AbstractKeyNameType).IsAssignableFrom(obj.GetType()))
                    return ((AbstractKeyNameType)obj).Name == name;
            return false;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return name;
        }

        /// <summary>
        /// Serves as a hash function for a particular type. <see cref="M:System.Object.GetHashCode"></see> is suitable for use in hashing algorithms and data structures like a hash table.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return uid.GetHashCode();
        }
    }
}