﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class CommittedRelationshipPeriod : IIdentifyable
    {
        private long uid;

        private Species product;
        private ProdType prodType;
        private Color color;
        private CategoryType catType;
        private Category category;
        private long addressId;
        private long locationId;
        private string prodAttrIds;
        private bool isValid;

        private int percent;
        private int priority;
        private long minAmount;
        private long fixedAmount;
        private string indicatedPackIds;
        private string indicatedPackNames;
        private DateTime fromDate;
        private DateTime toDate;

        private Organization grower;
        private string buyerId;
        //private Organization buyer;
        private CommittedRelationship cmtRelationship;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommittedRelationshipPeriod"/> class.
        /// </summary>
        public CommittedRelationshipPeriod()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        ///<summary>
        /// Gets or sets Product
        ///</summary>
        public Species Product
        {
            get { return product; }
            set { product = value; }
        }

        ///<summary>
        /// Gets or sets ProdType
        ///</summary>
        public ProdType ProdType
        {
            get { return prodType; }
            set { prodType = value; }
        }

        ///<summary>
        /// Gets or sets Color
        ///</summary>
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

        ///<summary>
        /// Gets or sets CatType
        ///</summary>
        public CategoryType CatType
        {
            get { return catType; }
            set { catType = value; }
        }

        ///<summary>
        /// Gets or sets Category
        ///</summary>
        public Category Category
        {
            get { return category; }
            set { category = value; }
        }

        /// <summary>
        /// Gets or sets the Address.
        /// </summary>
        /// <value>The Address.</value>
        public long AddressId
        {
            get { return addressId; }
            set { addressId = value; }
        }

        /// <summary>
        /// Gets or sets the Location.
        /// </summary>
        /// <value>The Location.</value>
        public long LocationId
        {
            get { return locationId; }
            set { locationId = value; }
        }

        /// <summary>
        /// Gets or sets the Product Attribute Ids.
        /// </summary>
        /// <value>The Location.</value>
        public string ProdAttrIds
        {
            get { return prodAttrIds; }
            set { prodAttrIds = value; }
        }

        /// <summary>
        /// Gets or sets the IsValid.
        /// </summary>
        /// <value>The Location.</value>
        public bool IsValid
        {
            get { return isValid; }
            set { isValid = value; }
        }

        ///<summary>
        /// Gets or sets Percent
        ///</summary>
        public int Percent
        {
            get { return percent; }
            set { percent = value; }
        }

        ///<summary>
        /// Gets or sets priority
        ///</summary>
        public int Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        ///<summary>
        /// Gets or sets MinAmount
        ///</summary>
        public long MinAmount
        {
            get { return minAmount; }
            set { minAmount = value; }
        }

        ///<summary>
        /// Gets or sets FixAmount
        ///</summary>
        public long FixedAmount
        {
            get { return fixedAmount; }
            set { fixedAmount = value; }
        }

        ///<summary>
        /// Gets or sets IndicatedPackIds
        ///</summary>
        public string IndicatedPackIds
        {
            get { return indicatedPackIds; }
            set { indicatedPackIds = value; }
        }

        ///<summary>
        /// Gets or sets IndicatedPackNames
        ///</summary>
        public string IndicatedPackNames
        {
            get { return indicatedPackNames; }
            set { indicatedPackNames = value; }
        }

        ///<summary>
        /// Gets or sets FromDate
        ///</summary>
        public DateTime FromDate
        {
            get { return fromDate; }
            set { fromDate = value; }
        }

        ///<summary>
        /// Gets or sets ToDate
        ///</summary>
        public DateTime ToDate
        {
            get { return toDate; }
            set { toDate = value; }
        }

        ///<summary>
        /// Gets or sets Grower
        ///</summary>
        public Organization Grower
        {
            get { return grower; }
            set { grower = value; }
        }

        /////<summary>
        ///// Gets or sets Grower
        /////</summary>
        //public Organization Buyer
        //{
        //    get { return buyer; }
        //    set { buyer = value; }
        //}

        ///<summary>
        /// Gets or sets BuyerId
        ///</summary>
        public string BuyerId
        {
            get { return buyerId; }
            set { buyerId = value; }
        }

        ///<summary>
        /// Gets or sets CmtRelationship
        ///</summary>
        public CommittedRelationship CmtRelationship
        {
            get { return cmtRelationship; }
            set { cmtRelationship = value; }
        }
    }
}