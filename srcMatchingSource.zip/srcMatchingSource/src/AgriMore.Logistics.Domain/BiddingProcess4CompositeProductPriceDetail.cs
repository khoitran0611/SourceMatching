﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BiddingProcess4CompositeProductPriceDetail : IIdentifyable
    {
        public long Uid { get; set; }

        public virtual decimal AgreedPrice { get; set; }

        public virtual decimal MinPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }
        public virtual BiddingProcess4CompositeProduct BiddingProcess4CompositeProd { get; set; }

        public BiddingProcess4CompositeProductPriceDetail Copy()
        {
            var tmpObj = (BiddingProcess4CompositeProductPriceDetail)this.MemberwiseClone();
            tmpObj.Uid = 0;
            tmpObj.BiddingProcess4CompositeProd = null;
            return tmpObj;
        }
    }
}