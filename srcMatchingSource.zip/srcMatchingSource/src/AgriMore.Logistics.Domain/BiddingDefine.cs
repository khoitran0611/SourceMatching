using System;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class BiddingDefine : IIdentifyable
    {
        private long uid;
        private decimal amount;
        private decimal minPrice;
        private string currency;
        private decimal curBidPrice;
        private bool hasAdjust;
        private DateTime startDate;
        private DateTime closedDate;
        private int closeAtMinute;
        private ProductSupplyForecast prodSupForecast;
        private Organization salesOrganization;
        private readonly ISet invitedOrgs = new HashedSet();


        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingDefine"/> class.
        /// </summary>
        protected BiddingDefine()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingDefine"/> class.
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="minPrice"></param>
        /// <param name="currency"></param>
        /// <param name="curBidPrice"></param>
        /// <param name="closedDate"></param>
        /// <param name="prdSf"></param>
        public BiddingDefine(decimal amount, decimal minPrice, string currency, decimal curBidPrice, DateTime closedDate, ProductSupplyForecast prdSf)
        {
            this.amount = amount;
            this.minPrice = minPrice;
            this.curBidPrice = curBidPrice;
            this.currency = currency;
            this.hasAdjust = false;
            this.closedDate = closedDate;
            this.prodSupForecast = prdSf;
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        public decimal Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        /// <summary>
        /// Gets or sets the min price.
        /// </summary>
        public decimal MinPrice
        {
            get { return minPrice; }
            set { minPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Currency.
        /// </summary>
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        /// <summary>
        /// Gets or sets the current bid price.
        /// </summary>
        public decimal CurBidPrice
        {
            get { return curBidPrice; }
            set { curBidPrice = value; }
        }

        /// <summary>
        /// Gets or sets the HasAdjust.
        /// </summary>
        public bool HasAdjust
        {
            get { return hasAdjust; }
            set { hasAdjust = value; }
        }

        /// <summary>
        /// Gets or sets the Start Date.
        /// </summary>
        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }

        /// <summary>
        /// Gets or sets the Closed Date.
        /// </summary>
        public DateTime ClosedDate
        {
            get { return closedDate; }
            set { closedDate = value; }
        }

        /// <summary>
        /// Gets or sets the CloseAtMinute.
        /// </summary>
        public int CloseAtMinute
        {
            get { return closeAtMinute; }
            set { closeAtMinute = value; }
        }

        /// <summary>
        /// Gets or sets the ProdSupForecast.
        /// </summary>
        public ProductSupplyForecast ProdSupForecast
        {
            get { return prodSupForecast; }
            internal set { prodSupForecast = value; }
        }

        /// <summary>
        /// Gets or sets the Sales Organization.
        /// </summary>
        public Organization SalesOrganization
        {
            get { return salesOrganization; }
            set { salesOrganization = value; }
        }

        /// <summary>
        /// Gets or sets the Invited Orgaganization.
        /// </summary>
        public IList<Organization> InvitedOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(invitedOrgs); }
        }

        /// <summary>
        /// Add Invited Orgaganization
        /// </summary>
        /// <param name="org"></param>
        public void AddInvitedOrgToList(Organization org)
        {
            invitedOrgs.Add(org);
        }

        /// <summary>
        /// Remove Invited Orgaganization
        /// </summary>
        public void RemoveInvitedOrgFromList()
        {
            invitedOrgs.Clear();
        }
    }
}
