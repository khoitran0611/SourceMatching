﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BiddingPurchase4CompositeProductSellerOfferDetail : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual BiddingPurchase4CompositeProductSellerOffer SellerOffer { get; set; }
    }
}
