using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// ExposureType gives the type of exposure. Temperature is for instance a type of exposure
    /// </summary>
    public class ExposureType : IIdentifyable
    {

        private string name;
        private UnitOfMeasurement unitOfMeasurement;
        private long uid;

        private int temperature;
        private UnitOfMeasurement temperatureUoM; 

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureType"/> class.
        /// </summary>
        public ExposureType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureType"/> class.
        /// </summary>
        /// <param name="name">Name of the exposure.</param>
        /// <param name="unitOfMeasurement"></param>
        public ExposureType(string name, UnitOfMeasurement unitOfMeasurement)
        {
            if (unitOfMeasurement == null)
            {
                throw new ArgumentNullException("unitOfMeasurement");
            }

            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (name.Trim().Length == 0)
            {
                throw new ArgumentException("name is empty", "name");
            }

            this.name = name;
            this.unitOfMeasurement = unitOfMeasurement;            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="unitOfMeasurement"></param>
        /// <param name="temperature"></param>
        /// <param name="temperatureUoM"></param>
        public ExposureType(string name, UnitOfMeasurement unitOfMeasurement, int temperature, UnitOfMeasurement temperatureUoM)
        {
            if (unitOfMeasurement == null)
            {
                throw new ArgumentNullException("unitOfMeasurement");
            }

            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (name.Trim().Length == 0)
            {
                throw new ArgumentException("name is empty", "name");
            }

            this.name = name;
            this.unitOfMeasurement = unitOfMeasurement;
            this.temperature = temperature;
            this.temperatureUoM = temperatureUoM;
        }

        /// <summary>
        /// Gets the unit of measure.
        /// </summary>
        /// <value>The unit of measure.</value>
        public UnitOfMeasurement UnitOfMeasurement
        {
            get { return unitOfMeasurement; }
            set { unitOfMeasurement = value; }
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }

            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            ExposureType other = obj as ExposureType;

            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            return Name.Equals(other.Name);
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return String.Format("{0} in {1}", Name, unitOfMeasurement);
        }

        public int Temperature
        {
            get { return temperature; }
            set { temperature = value; }
        }

        /// <summary>
        /// m
        /// </summary>
        public UnitOfMeasurement TemperatureUOM
        {
            get { return temperatureUoM; }
            set { temperatureUoM = value; }
        }    
    }
}