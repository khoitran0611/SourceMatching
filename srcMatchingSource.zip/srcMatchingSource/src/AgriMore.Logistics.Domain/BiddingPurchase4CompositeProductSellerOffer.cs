﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BiddingPurchase4CompositeProductSellerOffer : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual DateTime OfferAt { get; set; }

        public virtual string SellerId { get; set; }

        public virtual BiddingPurchase4CompositeProduct BiddingPurchase { get; set; }

        #region Offer Price Details
        private readonly IList offerPriceDetails = new List<BiddingPurchase4CompositeProductSellerOfferDetail>();
        [DataMember(Name = "OfferPriceDetails")]
        public IList<BiddingPurchase4CompositeProductSellerOfferDetail> OfferPriceDetails
        {
            get { return offerPriceDetails.Cast<BiddingPurchase4CompositeProductSellerOfferDetail>().ToList(); }
        }

        public void AddOfferPriceDetail(BiddingPurchase4CompositeProductSellerOfferDetail offerPriceDetail)
        {
            offerPriceDetail.SellerOffer = this;
            offerPriceDetails.Add(offerPriceDetail);
        }

        public void RemoveOfferPriceDetail(BiddingPurchase4CompositeProductSellerOfferDetail offerPriceDetail)
        {
            offerPriceDetails.Remove(offerPriceDetail);
        }

        public void RemoveAllOfferPriceDetail()
        {
            offerPriceDetails.Clear();
        }
        #endregion
    }
}
