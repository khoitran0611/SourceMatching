﻿namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public enum AvailableSettingType
    {
        ///<summary>
        ///</summary>
        Fixed = 1,

        ///<summary>
        ///</summary>
        Flexible = 2
    }
}
