﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class EmailLogger : IIdentifyable
    {
        private long uid;
        private DateTime sentDate;
        private string toEmails;
        private string ccEmails;
        private string bccEmails;
        private string emailSubject;
        private string mailContent;
        private string processType;


        /// <summary>
        /// Initializes a new instance of the <see cref="EmailLogger"/> class.
        /// </summary>
        public EmailLogger()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EmailLogger"/> class.
        /// </summary>
        /// <param name="sentDate"></param>
        /// <param name="toEmails"></param>
        /// <param name="ccEmails"></param>
        /// <param name="bccEmails"></param>
        /// <param name="mailContent"></param>
        /// <param name="processType"></param>
        public EmailLogger(DateTime sentDate, string toEmails, string ccEmails, string bccEmails, string mailContent, string processType)
        {
            this.sentDate = sentDate;
            this.toEmails = toEmails;
            this.ccEmails = ccEmails;
            this.bccEmails = bccEmails;
            this.mailContent = mailContent;
            this.processType = processType;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the SentDate.
        /// </summary>
        public DateTime SentDate
        {
            get { return sentDate; }
            set { sentDate = value; }
        }

        /// <summary>
        /// Gets or sets the ToEmails.
        /// </summary>
        public string ToEmails
        {
            get { return toEmails; }
            set { toEmails = value; }
        }

        /// <summary>
        /// Gets or sets the CcEmails.
        /// </summary>
        public string CcEmails
        {
            get { return ccEmails; }
            set { ccEmails = value; }
        }

        /// <summary>
        /// Gets or sets the BccEmails.
        /// </summary>
        public string BccEmails
        {
            get { return bccEmails; }
            set { bccEmails = value; }
        }

        /// <summary>
        /// Gets or sets the EmailSubject.
        /// </summary>
        public string EmailSubject
        {
            get { return emailSubject; }
            set { emailSubject = value; }
        }

        /// <summary>
        /// Gets or sets the MailContent.
        /// </summary>
        public string MailContent
        {
            get { return mailContent; }
            set { mailContent = value; }
        }

        /// <summary>
        /// Gets or sets the ProcessType.
        /// </summary>
        public string ProcessType
        {
            get { return processType; }
            set { processType = value; }
        }
    }
}
