﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    public class AgreementPurchase : IIdentifyable
    {
        private long uid;
        private long amount;
        private UnitOfMeasurement uom;
        private PurchaseType purchaseType;
        private decimal agreePrice;
        private decimal fixedPrice;
        private decimal offerPrice;
        private decimal ceilingPrice;
        private string currency;
        private bool isMatched;
        private long matchedProdId;
        private DateTime purchaseFrom;
        private DateTime purchaseTo;
        private DateTime agreementStartAt;
        private DateTime agreementCloseAt;
        private string buyerUid;
        private string sellerWonId;
        private DateTime updatedAt;
        private long planningId;
        private long issuedSeq;

        /// <summary>
        /// Initializes a new instance of the <see cref="AgreementPurchase"/> class.
        /// </summary>
        public AgreementPurchase() { }

        private readonly ISet prodFavs = new HashedSet();
        private readonly ISet sellers = new HashedSet();
        private readonly ISet suppliers = new HashedSet();
        private readonly ISet idtPackagings = new HashedSet();

        public long Uid { get { return uid; } set { uid = value; } }
        public long Amount { get { return amount; } set { amount = value; } }
        public UnitOfMeasurement Uom { get { return uom; } set { uom = value; } }
        public PurchaseType PurchaseType { get { return purchaseType; } set { purchaseType = value; } }
        public decimal AgreePrice { get { return agreePrice; } set { agreePrice = value; } }
        public decimal FixedPrice { get { return fixedPrice; } set { fixedPrice = value; } }
        public decimal OfferPrice { get { return offerPrice; } set { offerPrice = value; } }
        public decimal CeilingPrice { get { return ceilingPrice; } set { ceilingPrice = value; } }
        public string Currency { get { return currency; } set { currency = value; } }
        public bool IsMatched { get { return isMatched; } set { isMatched = value; } }
        public long MatchedProdId { get { return matchedProdId; } set { matchedProdId = value; } }
        public DateTime PurchaseFrom { get { return purchaseFrom; } set { purchaseFrom = value; } }
        public DateTime PurchaseTo { get { return purchaseTo; } set { purchaseTo = value; } }
        public DateTime AgreementStartAt { get { return agreementStartAt; } set { agreementStartAt = value; } }
        public DateTime AgreementCloseAt { get { return agreementCloseAt; } set { agreementCloseAt = value; } }
        public string BuyerUid { get { return buyerUid; } set { buyerUid = value; } }
        public string SellerWonId { get { return sellerWonId; } set { sellerWonId = value; } }
        public DateTime UpdatedAt { get { return updatedAt; } set { updatedAt = value; } }
        public long PlanningId { get { return planningId; } set { planningId = value; } }
        public long IssuedSeq { get { return issuedSeq; } set { issuedSeq = value; } }

        #region Gets/Set/Remove Product Favourites
        /// <summary>
        /// Gets or sets the Available To Orgaganization.
        /// </summary>
        public IList<ProductFavourites> ProdFavs
        {
            get { return ListHandler.ConvertToGenericList<ProductFavourites>(prodFavs); }
        }

        /// <summary>
        /// Add Product Favourite
        /// </summary>
        /// <param name="proFav"></param>
        public void AddFavouriteToList(ProductFavourites proFav)
        {
            prodFavs.Add(proFav);
        }

        /// <summary>
        /// Remove Favourite
        /// </summary>
        public void RemoveFavouritesFromList()
        {
            prodFavs.Clear();
        }
        #endregion

        #region Gets/Set/Remove Seller
        /// <summary>
        /// Gets or sets the Available To Orgaganization.
        /// </summary>
        public IList<Organization> Sellers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(sellers); }
        }

        /// <summary>
        /// Add Seller
        /// </summary>
        /// <param name="org"></param>
        public void AddSellerToList(Organization org)
        {
            sellers.Add(org);
        }

        /// <summary>
        /// Remove Seller
        /// </summary>
        public void RemoveSellerFromList()
        {
            sellers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Available to Trading Companies
        /// <summary>
        /// Gets or sets the Supplier.
        /// </summary>
        public IList<Organization> Suppliers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(suppliers); }
        }

        /// <summary>
        /// Add Supplier
        /// </summary>
        /// <param name="org"></param>
        public void AddSupplierToList(Organization org)
        {
            suppliers.Add(org);
        }

        /// <summary>
        /// Remove Supplier
        /// </summary>
        public void RemoveSupplierFromList()
        {
            suppliers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Packaging
        /// <summary>
        /// Gets or sets PackagingDefine.
        /// </summary>
        public IList<PackagingDefine> IdtPackagings
        {
            get { return ListHandler.ConvertToGenericList<PackagingDefine>(idtPackagings); }
        }

        /// <summary>
        /// Add Packaging
        /// </summary>
        /// <param name="pack"></param>
        public void AddPackagingToList(PackagingDefine pack)
        {
            idtPackagings.Add(pack);
        }

        /// <summary>
        /// Remove Packaging
        /// </summary>
        public void RemovePackagingFromList()
        {
            idtPackagings.Clear();
        }
        #endregion

    }
}