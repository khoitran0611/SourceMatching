using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class AuditTrail : IIdentifyable
    {
        private long uid;
        private DateTime date;
        private string level;
        private string orgId;
        private string message;
        private string exception;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuditTrail"/> class.
        /// </summary>
        protected AuditTrail() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="AuditTrail"/> class.
        /// </summary>
        /// <param name="date"></param>
        /// <param name="level"></param>
        /// <param name="orgId"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public AuditTrail(DateTime date, string level, string orgId, string message, string exception)
        {
            this.date = date;
            this.level = level;
            this.orgId = orgId;
            this.message = message;
            this.exception = exception;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Date.
        /// </summary>
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        /// <summary>
        /// Gets or sets the Level.
        /// </summary>
        public string Level
        {
            get { return level; }
            set { level = value; }
        }

        /// <summary>
        /// Gets or sets the OrgId.
        /// </summary>
        public string OrgId
        {
            get { return orgId; }
            set { orgId = value; }
        }

        /// <summary>
        /// Gets or sets the Message.
        /// </summary>
        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        /// <summary>
        /// Gets or sets the Exception.
        /// </summary>
        public string Exception
        {
            get { return exception; }
            set { exception = value; }
        }
    }
}
