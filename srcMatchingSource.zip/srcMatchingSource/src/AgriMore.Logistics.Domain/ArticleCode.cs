using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class ArticleCode : IIdentifyable
    {
        private long uid;
        private long greenTekTradingId;
        private string code;
        private string articleDesc;
        private int totalAmount;
        private string tradingOrgId;
        private DateTime insertedDate;

        /// <summary>
        /// Initializes a new instance of the <see cref="ArticleCode"/> class.
        /// </summary>
        public ArticleCode() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ArticleCode"/> class.
        /// </summary>
        /// <param name="greenTekId"></param>
        /// <param name="artCode"></param>
        /// <param name="artDesc"></param>
        /// <param name="totalAmount"></param>
        /// <param name="tradingOrgId"></param>
        public ArticleCode(long greenTekId, string artCode, string artDesc, int totalAmount, string tradingOrgId)
        {
            this.greenTekTradingId = greenTekId;
            this.code = artCode;
            this.articleDesc = artDesc;
            this.totalAmount = totalAmount;
            this.tradingOrgId = tradingOrgId;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Green Tek Id
        /// </summary>
        public long GreenTekTradingId
        {
            get { return greenTekTradingId; }
            set { greenTekTradingId = value; }
        }

        /// <summary>
        /// Gets or sets the article code
        /// </summary>
        public string Code
        {
            get { return code; }
            set { code = value; }
        }

        /// <summary>
        /// Gets or sets the article description
        /// </summary>
        public string ArticleDesc
        {
            get { return articleDesc; }
            set { articleDesc = value; }
        }

        /// <summary>
        /// Gets or sets the total amount.
        /// </summary>
        public int TotalAmount
        {
            get { return totalAmount; }
            set { totalAmount = value; }
        }

        /// <summary>
        /// Gets or sets the trading organization id
        /// </summary>
        public string TradingOrgId
        {
            get { return tradingOrgId; }
            set { tradingOrgId = value; }
        }

        /// <summary>
        /// Gets or sets inserted date.
        /// </summary>
        public DateTime InsertedDate
        {
            get { return insertedDate; }
            set { insertedDate = value; }
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            ArticleCode other = obj as ArticleCode;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return uid.GetHashCode();
        }
    }
}
