﻿namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public enum EvalOfferType
    {
        ///<summary>
        /// Award Highest Price down
        ///</summary>
        HighestPrice = 1,

        ///<summary>
        /// Award Highest Value down
        ///</summary>
        HighestValue = 2
    }
}
