﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AddOnDefineOrg : IIdentifyable
    {
        private long uid;

        private AddOnsDefine addOnsDefine;
        private Organization organization;
        private long isSelected;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnDefineOrg"/> class.
        /// </summary>
        public AddOnDefineOrg()
        {
        }


        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public AddOnsDefine AddOnsDefine
        {
            get { return addOnsDefine; }
            set { addOnsDefine = value; }
        }       
        /// <summary>
        /// 
        /// </summary>
        public long IsSelected
        {
            get { return isSelected; }
            set { isSelected = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public Organization Organization
        {
            get { return organization; }
            set { organization = value; }
        }
    }
}
