﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BaseOrganizationLang : IIdentifyable<BaseOrganizationLang.BaseOrgLangID>
    {
        private BaseOrgLangID uid;
        private string name;
        private string streetName;
        private string city;
        private string state;
        private string country;

        private string createdBy;
        private DateTime createdAt;
        private int ouid;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseOrganizationLang"/> class.
        /// </summary>
        public BaseOrganizationLang() { }

        public BaseOrgLangID Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string StreetName
        {
            get { return streetName; }
            set { streetName = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public string State
        {
            get { return state; }
            set { state = value; }
        }

        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        public DateTime CreatedAt
        {
            get { return createdAt; }
            set { createdAt = value; }
        }

        public int Ouid
        {
            get { return ouid; }
            set { ouid = value; }
        }

        [Serializable]
        public class BaseOrgLangID : IComparable
        {
            public BaseOrgLangID()
            {
            }

            public override bool Equals(object obj)
            {
                if (obj == this)
                    return true;
                if (obj == null)
                    return false;

                BaseOrgLangID that = obj as BaseOrgLangID;
                if (that == null)
                {
                    return false;
                }
                else
                {
                    if (this.OrgId != that.OrgId)
                        return false;
                    if (this.LangCode != that.LangCode)
                        return false;
                    return true;
                }

            }

            public override int GetHashCode()
            {
                return OrgId.GetHashCode() ^ LangCode.GetHashCode();
            }

            public string OrgId
            {
                get
                {
                    return orgId;
                }
                set
                {
                    orgId = value;
                }
            }

            public int LangCode
            {
                get
                {
                    return langCode;
                }
                set
                {
                    langCode = value;
                }
            }

            protected string orgId;
            protected int langCode;

            #region IComparable Members

            public int CompareTo(object obj)
            {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }
    }
}
