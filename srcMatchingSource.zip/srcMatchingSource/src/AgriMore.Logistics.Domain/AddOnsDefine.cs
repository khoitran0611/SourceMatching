﻿using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class AddOnsDefine : IIdentifyable
    {
        private long uid;

        private string addOnsDesc;
        private Organization adminGroup;
        private decimal withoutPackPrice;
        private string currency;
        private readonly ISet forProducts = new HashedSet();
        private readonly ISet forAvailableProducts = new HashedSet();
        private readonly ISet forOrganizations = new HashedSet();
        private readonly ISet forAvailableOrganizations = new HashedSet();
        private readonly ISet addOnsDefLangs = new HashedSet();
        private string gs1Code;
        private string ledgerCode;
        private string otherCode;
        private bool automaticallyUpdateWithNewOrganizations;
        private bool automaticallyUpdateWithNewProducts;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnsDefine"/> class.
        /// </summary>
        public AddOnsDefine()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnsDefine"/> class.
        /// </summary>
        /// <param name="addOnsDesc"></param>
        /// <param name="adminGroup"></param>
        public AddOnsDefine(string addOnsDesc, Organization adminGroup)
        {
            this.addOnsDesc = addOnsDesc;
            this.adminGroup = adminGroup;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Add Ons Description
        /// </summary>
        /// <value>The uid.</value>
        public string AddOnsDesc
        {
            get { return addOnsDesc; }
            set { addOnsDesc = value; }
        }

        /// <summary>
        /// Gets or sets the Add Ons AutomaticallyUpdateWithNewOrganizations
        /// </summary>
        /// <value>The uid.</value>
        public bool AutomaticallyUpdateWithNewOrganizations
        {
            get { return automaticallyUpdateWithNewOrganizations; }
            set { automaticallyUpdateWithNewOrganizations = value; }
        }

        /// <summary>
        /// Gets or sets the Add Ons AutomaticallyUpdateWithNew
        /// </summary>
        /// <value>The uid.</value>
        public bool AutomaticallyUpdateWithNewProducts
        {
            get { return automaticallyUpdateWithNewProducts; }
            set { automaticallyUpdateWithNewProducts = value; }
        }

        /// <summary>
        /// Gets or sets the Add Ons Description
        /// </summary>
        /// <value>The uid.</value>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }

        /// <summary>
        /// Gets or sets the Add Ons Description
        /// </summary>
        /// <value>The uid.</value>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }

        /// <summary>
        /// Gets or sets the Add Ons Description
        /// </summary>
        /// <value>The uid.</value>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        /// <summary>
        /// Gets or sets the WithoutPackPrice
        /// </summary>
        /// <value>The uid.</value>
        public decimal WithoutPackPrice
        {
            get { return withoutPackPrice; }
            set { withoutPackPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Currency
        /// </summary>
        /// <value>The uid.</value>
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        /// <summary>
        /// Gets or sets the Admin Group.
        /// </summary>
        /// <value>The uid.</value>
        public Organization AdminGroup
        {
            get { return adminGroup; }
            set { adminGroup = value; }
        }

        /// <summary>
        /// Gets the Products.
        /// </summary>
        public IList<Species> ForProducts
        {
            get { return ListHandler.ConvertToGenericList<Species>(forProducts); }
        }

        /// <summary>
        /// Add Products
        /// </summary>
        /// <param name="product"></param>
        public void AddProductToList(Species product)
        {
            forProducts.Add(product);
        }

        /// <summary>
        /// Remove Products
        /// </summary>
        public void RemoveProductFromList()
        {
            forProducts.Clear();
        }

        /// <summary>
        /// Gets the AvailableProducts.
        /// </summary>
        public IList<Species> ForAvailableProducts
        {
            get { return ListHandler.ConvertToGenericList<Species>(forAvailableProducts); }
        }

        /// <summary>
        /// Add AvailableProducts
        /// </summary>
        /// <param name="product"></param>
        public void AddAvailableProductToList(Species product)
        {
            forAvailableProducts.Add(product);
        }

        /// <summary>
        /// Remove Available Products
        /// </summary>
        public void RemoveAvailableProductFromList()
        {
            forAvailableProducts.Clear();
        }


        /// <summary>
        /// Gets Organizations.
        /// </summary>
        public IList<Organization> ForOrganizations
        {
            get { return ListHandler.ConvertToGenericList<Organization>(forOrganizations); }
        }

        /// <summary>
        /// Add Organization
        /// </summary>
        /// <param name="org"></param>
        public void AddOrganization(Organization org)
        {
            forOrganizations.Add(org);
        }

        /// <summary>
        /// Remove Organizations
        /// </summary>
        public void RemoveOrganization()
        {
            forOrganizations.Clear();
        }

        /// <summary>
        /// GetsAvaiable Organizations.
        /// </summary>
        public IList<Organization> ForAvailableOrganizations
        {
            get { return ListHandler.ConvertToGenericList<Organization>(forAvailableOrganizations); }
        }

        /// <summary>
        /// Add Organization
        /// </summary>
        /// <param name="org"></param>
        public void AddAvailableOrganization(Organization org)
        {
            forAvailableOrganizations.Add(org);
        }

        /// <summary>
        /// Remove Organizations
        /// </summary>
        public void RemoveAvailableOrganization()
        {
            forAvailableOrganizations.Clear();
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            AddOnsDefineLang addOnsDefineLang = AddOnsDefLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return addOnsDefineLang == null ? addOnsDesc : addOnsDefineLang.Name;
        }

        /// <summary>
        /// Gets or sets the AddOnsDefLangs.
        /// </summary>
        public IList<AddOnsDefineLang> AddOnsDefLangs
        {
            get { return ListHandler.ConvertToGenericList<AddOnsDefineLang>(addOnsDefLangs); }
        }

        /// <summary>
        /// Add AddOnsDefineLang
        /// </summary>
        /// <param name="addOnsDefineLang"></param>
        public void AddAddOnsDefineLangToList(AddOnsDefineLang addOnsDefineLang)
        {
            addOnsDefLangs.Add(addOnsDefineLang);
        }

        /// <summary>
        /// Remove AddOnsDefineLang
        /// </summary>
        public void RemoveAddOnsDefineLangFromList()
        {
            addOnsDefLangs.Clear();
        }

        /// <summary>
        /// Remove AddOnsDefineLang
        /// </summary>
        public void RemoveAddOnsDefineLangFromList(AddOnsDefineLang addOnsDefineLang)
        {
            addOnsDefLangs.Remove(addOnsDefineLang);
        }
    }
}
