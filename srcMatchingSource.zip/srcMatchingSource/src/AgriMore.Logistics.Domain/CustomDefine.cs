﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class is an implementation for CustomDefine
    /// </summary>
    public class CustomDefine : IIdentifyable
    {
        #region //Variables
        private long uid;
        private long userId;
        private string tableName;
        private string defineValues;
        #endregion

        #region //Contructor
        /// <summary>
        /// Contructor
        /// </summary>
        public CustomDefine()
        {
            uid = 0;
            userId = 0;
            tableName = "";
            defineValues = "";
        }
        #endregion

        #region //Properties

        /// <summary>
        /// Gets or sets the UserId.
        /// </summary>
        public long UserId
        {
            get
            {
                return userId;
            }
            set
            {
                userId = value;
            }
        }
        /// <summary>
        /// Gets or sets the TableName.
        /// </summary>
        public string TableName
        {
            set
            {
                tableName = value;
            }
            get
            {
                return tableName;
            }
        }
        /// <summary>
        /// Gets or sets the DefineValues.
        /// </summary>
        public string DefineValues
        {
            set
            {
                defineValues = value;
            }
            get
            {
                return defineValues;
            }
        }
        #endregion
        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public long Uid
        {
            get
            {
                return uid;
            }
            set
            {
                uid = value;
            }
        }
    }

    /// <summary>
    /// This class define static string for table
    /// </summary>
    public class TableDataName
    {
        /// <summary>
        ///
        /// </summary>
        public const string ForeCastAndStock = "ForeCastAndStock";
    }
}
