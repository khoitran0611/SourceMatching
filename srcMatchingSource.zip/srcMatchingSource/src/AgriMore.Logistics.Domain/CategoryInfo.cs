﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public class CategoryInfo : IIdentifyable
    {
         private long uid;        
        private long categoryId;
        private long productId;        
        

        /// <summary>
        /// 
        /// </summary>
        public CategoryInfo()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        public long ProductId
        {
            get { return productId; }
            set { productId = value; }
        }



        public long CategoryId
        {
            get { return categoryId; }
            set { categoryId = value; }
        }        
    }
}
