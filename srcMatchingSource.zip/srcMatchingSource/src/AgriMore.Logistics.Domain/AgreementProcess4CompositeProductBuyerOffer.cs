﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AgreementProcess4CompositeProductBuyerOffer : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual DateTime OfferAt { get; set; }

        public virtual string BuyerId { get; set; }

        public virtual AgreementProcess4CompositeProduct AgmtProcess { get; set; }

        #region Offer Price Details
        private readonly IList offerPriceDetails = new List<AgreementProcess4CompositeProductBuyerOfferDetail>();
        [DataMember(Name = "OfferPriceDetails")]
        public IList<AgreementProcess4CompositeProductBuyerOfferDetail> OfferPriceDetails
        {
            get { return offerPriceDetails.Cast<AgreementProcess4CompositeProductBuyerOfferDetail>().ToList(); }
        }

        public void AddOfferPriceDetail(AgreementProcess4CompositeProductBuyerOfferDetail offerPriceDetail)
        {
            offerPriceDetail.BuyerOffer = this;
            offerPriceDetails.Add(offerPriceDetail);
        }

        public void RemoveOfferPriceDetail(AgreementProcess4CompositeProductBuyerOfferDetail offerPriceDetail)
        {
            offerPriceDetails.Remove(offerPriceDetail);
        }

        public void RemoveAllOfferPriceDetail()
        {
            offerPriceDetails.Clear();
        }
        #endregion
    }
}
