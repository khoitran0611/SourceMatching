﻿using System;
using System.Linq;
using System.Collections;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using System.Runtime.Serialization;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    public class BiddingProcess4CompositeProduct : IIdentifyable
    {
        public long Uid { get; set; }

        public virtual CompositeProductFavourite CompositeProdFav { get; set; }

        public virtual CompositeProductSupply CompositeProdSupply { get; set; }

        public virtual decimal WonPrice { get; set; }

        public virtual decimal MinPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual bool IsMatched { get; set; }

        public virtual bool IsIndicatedProd { get; set; }

        public virtual DateTime FromDate { get; set; }

        public virtual DateTime ToDate { get; set; }

        public virtual DateTime StartAt { get; set; }

        public virtual DateTime CloseAt { get; set; }

        public virtual string SellerId { get; set; }

        public virtual string WonBuyerId { get; set; }

        public virtual DateTime UpdatedAt { get; set; }

        #region Invited Seller Organization
        private readonly ISet invitedBuyerOrgs = new HashedSet();
        [DataMember(Name = "InvitedBuyerOrgs")]
        public IList<Organization> InvitedBuyerOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(invitedBuyerOrgs); }
        }

        public void AddInvitedBuyer(Organization buyer)
        {
            invitedBuyerOrgs.Add(buyer);
        }

        public void RemoveInvitedBuyer(Organization buyer)
        {
            invitedBuyerOrgs.Remove(buyer);
        }

        public void RemoveAllInvitedBuyer()
        {
            invitedBuyerOrgs.Clear();
        }
        #endregion

        #region Agreement Supplier Organization
        private readonly ISet supplierOrgs = new HashedSet();
        [DataMember(Name = "SupplierOrgs")]
        public IList<Organization> SupplierOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(supplierOrgs); }
        }

        public void AddSupplier(Organization supplier)
        {
            supplierOrgs.Add(supplier);
        }

        public void RemoveSupplier(Organization supplier)
        {
            supplierOrgs.Remove(supplier);
        }

        public void RemoveAllSupplier()
        {
            supplierOrgs.Clear();
        }
        #endregion

        #region Price Details
        private readonly IList priceDetails = new List<BiddingProcess4CompositeProductPriceDetail>();
        [DataMember(Name = "PriceDetails")]
        public IList<BiddingProcess4CompositeProductPriceDetail> PriceDetails
        {
            get { return priceDetails.Cast<BiddingProcess4CompositeProductPriceDetail>().ToList(); }
        }

        public void AddPriceDetail(BiddingProcess4CompositeProductPriceDetail priceDetail)
        {
            priceDetail.BiddingProcess4CompositeProd = this;
            priceDetails.Add(priceDetail);
        }

        public void RemovePriceDetail(BiddingProcess4CompositeProductPriceDetail priceDetail)
        {
            priceDetails.Remove(priceDetail);
        }

        public void RemoveAllPriceDetail()
        {
            priceDetails.Clear();
        }
        #endregion
    }
}
