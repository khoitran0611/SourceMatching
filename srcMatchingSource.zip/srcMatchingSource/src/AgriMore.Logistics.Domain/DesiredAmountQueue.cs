﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class DesiredAmountQueue : IIdentifyable
    {

        private long uid;
        private long amount;
        private long minAmount;
        private decimal offerPrice;
        private string currency;
        private DateTime insertedDate;
        private DateTime updatedDate;
        private User user;
        private Organization organization;
        private ProductSupplyForecast prodSupply;

        /// <summary>
        /// Initializes a new instance of the <see cref="DesiredAmount"/> class.
        /// </summary>
        protected DesiredAmountQueue()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DesiredAmount"/> class.
        /// </summary>
        /// <param name="amount">The desired amount.</param>
        /// <param name="offerPrice">The Offer Price.</param>
        /// <param name="user">The user.</param>
        /// <param name="organization">The organization.</param>
        /// <param name="prodSupply">The product supply forecast.</param>
        public DesiredAmountQueue(long amount, decimal offerPrice, User user, Organization organization, ProductSupplyForecast prodSupply)
        {
            this.amount = amount;
            this.offerPrice = offerPrice;
            this.user = user;
            this.organization = organization;
            this.prodSupply = prodSupply;
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            ProductSupplyForecast other = obj as ProductSupplyForecast;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return uid.GetHashCode();
        }

        /// <summary>
        /// Gets or sets the desired amount.
        /// </summary>
        /// <value>The desired amount.</value>
        public long Amount
        {
            get
            {
                return amount;
            }
            set
            {
                amount = value;
            }
        }

        /// <summary>
        /// Gets or sets the minimum desired amount.
        /// </summary>
        /// <value>The minimum desired amount.</value>
        public long MinAmount
        {
            get
            {
                return minAmount;
            }
            set
            {
                minAmount = value;
            }
        }

        /// <summary>
        /// Gets or sets the price.
        /// </summary>
        public decimal OfferPrice
        {
            get { return offerPrice; }
            set { offerPrice = value; }
        }

        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        /// <summary>
        /// Gets or sets inserted date
        /// </summary>
        public DateTime InsertedDate
        {
            get { return insertedDate; }
            set { insertedDate = value; }
        }

        /// <summary>
        /// Gets or sets updated date
        /// </summary>
        public DateTime UpdatedDate
        {
            get { return updatedDate; }
            set { updatedDate = value; }
        }

        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        /// <value>The category.</value>
        public User User
        {
            get
            {
                return user;
            }
            internal set
            {
                user = value;
            }
        }

        /// <summary>
        /// Gets or sets the Organization.
        /// </summary>
        public Organization Organization
        {
            get
            {
                return organization;
            }
            internal set
            {
                organization = value;
            }
        }

        /// <summary>
        /// Gets or sets the product supply forecast.
        /// </summary>
        public ProductSupplyForecast ProdSupply
        {
            get { return prodSupply; }
            set { prodSupply = value; }
        }
    }
}
