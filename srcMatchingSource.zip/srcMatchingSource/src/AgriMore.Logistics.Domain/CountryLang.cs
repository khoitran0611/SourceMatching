﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class CountryLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private Country country;

        /// <summary>
        /// 
        /// </summary>
        public CountryLang()
        {
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="name"></param>
       /// <param name="langCode"></param>
       /// <param name="country"></param>
        public CountryLang(string name, string langCode, Country country)
        {
            this.name = name;
            this.langCode = langCode;
            this.country = country;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

       /// <summary>
       /// 
       /// </summary>
        public Country Country
        {
            get { return country; }
            set { country = value; }
        }
    }
}
