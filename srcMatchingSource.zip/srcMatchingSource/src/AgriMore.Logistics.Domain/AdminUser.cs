using System;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class is an implementation for AdminUser
    /// </summary>
    public class AdminUser : IIdentifyable<string>
    {
        private string uid;
        private string fullName;
        private string phone;
        private string mobile;
        private string email;
        private int userLock;
        private Organization organization;
        private readonly ISet users = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="AdminUser"/> class.
        /// </summary>
        protected AdminUser() { }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        public string Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the FullName.
        /// </summary>
        public string FullName
        {
            get { return fullName; }
            set { fullName = value; }
        }

        /// <summary>
        /// Gets or sets the Phone.
        /// </summary>
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        /// <summary>
        /// Gets or sets the Mobile.
        /// </summary>
        public string Mobile
        {
            get { return mobile; }
            set { mobile = value; }
        }

        /// <summary>
        /// Gets or sets the Email.
        /// </summary>
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        /// <summary>
        /// Gets or sets the UserLock.
        /// </summary>
        public int UserLock
        {
            get { return userLock; }
            set { userLock = value; }
        }

        /// <summary>
        /// Gets or sets the organization.
        /// </summary>
        public Organization Organization
        {
            get { return organization; }
            set { organization = value; }
        }

        /// <summary>
        /// Gets or sets the users.
        /// </summary>
        public IList<User> Users
        {
            get { return ListHandler.ConvertToGenericList<User>(users); }
        }
    }
}
