﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BiddingPurchaseSellerBidded : IIdentifyable
    {
        private long uid;
        private string sellerId;
        private decimal biddingPrice;
        private string currency;
        private DateTime biddingAt;
        private BiddingPurchase bidPurchase;

        /// <summary>
        /// Initializes a new instance of the <see cref="BiddingPurchaseSellerBidded"/> class.
        /// </summary>
        public BiddingPurchaseSellerBidded() { }

        public long Uid { get { return uid; } set { uid = value; } }
        public decimal BiddingPrice { get { return biddingPrice; } set { biddingPrice = value; } }
        public string Currency { get { return currency; } set { currency = value; } }
        public DateTime BiddingAt { get { return biddingAt; } set { biddingAt = value; } }
        public string SellerId { get { return sellerId; } set { sellerId = value; } }
        public BiddingPurchase BidPurchase { get { return bidPurchase; } set { bidPurchase = value; } }
    }
}
