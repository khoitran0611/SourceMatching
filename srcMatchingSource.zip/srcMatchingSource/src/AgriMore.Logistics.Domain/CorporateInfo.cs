﻿using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    public class CorporateInfo : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual string Name { get; set; }

        public virtual CorporateInfoType InfoType { get; set; }

        public virtual string Filename { get; set; }

        public virtual string ContentType { get; set; }

        public virtual string StoreLocation { get; set; }

        public virtual bool IsVisibleAll { get; set; }

        public virtual bool IsShowDirectly { get; set; }

        public virtual string OrgId { get; set; }

        private readonly ISet visibleOrgs = new HashedSet();
        public IList<Organization> VisibleOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(visibleOrgs); }
        }

        public void AddVisibleOrg(Organization org)
        {
            visibleOrgs.Add(org);
        }

        public void RemoveVisibleOrg(Organization org)
        {
            visibleOrgs.Remove(org);
        }

        public void RemoveAllVisibleOrgs()
        {
            visibleOrgs.Clear();
        }

        private readonly ISet visibleRoles = new HashedSet();
        public IList<Role> VisibleRoles
        {
            get { return ListHandler.ConvertToGenericList<Role>(visibleRoles); }
        }

        public void AddVisibleRole(Role role)
        {
            visibleRoles.Add(role);
        }

        public void RemoveVisibleRole(Role role)
        {
            visibleRoles.Remove(role);
        }

        public void RemoveAllVisibleRoles()
        {
            visibleRoles.Clear();
        }
    }
}
