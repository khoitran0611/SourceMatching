﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class ChainEntityProperty : IIdentifyable
    {
        private long uid;
        private Property property;
        private string propertyValue;
        private ChainEntity chainEntity;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntityProperty"/> class.
        /// </summary>
        public ChainEntityProperty()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntityProperty"/> class.
        /// </summary>
        /// <param name="property"></param>
        /// <param name="propertyValue"></param>
        /// <param name="chainEntity"></param>
        public ChainEntityProperty(Property property, string propertyValue, ChainEntity chainEntity)
        {
            this.property = property;
            this.propertyValue = propertyValue;
            this.chainEntity = chainEntity;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Property.
        /// </summary>
        public Property Property
        {
            get { return property; }
            set { property = value; }
        }

        /// <summary>
        /// Gets or sets the Value.
        /// </summary>
        public string PropertyValue
        {
            get { return propertyValue; }
            set { propertyValue = value; }
        }

        /// <summary>
        /// Gets or sets the TradingOrg.
        /// </summary>
        public ChainEntity ChainEntity
        {
            get { return chainEntity; }
            set { chainEntity = value; }
        }
    }
}
