﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class CategoryLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private Category category;

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryLang"/> class.
        /// </summary>
        public CategoryLang()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryLang"/> class.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="category"></param>
        public CategoryLang(string name, string langCode, Category category)
        {
            this.name = name;
            this.langCode = langCode;
            this.category = category;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryType
        /// </summary>
        public Category Category
        {
            get { return category; }
            set { category = value; }
        }
    }
}
