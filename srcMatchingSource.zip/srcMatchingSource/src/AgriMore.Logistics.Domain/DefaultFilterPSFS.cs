﻿using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class DefaultFilterPSFS : IIdentifyable
    {
        private long uid;
        private string salesOrgId;
        private string listOrgId;
        private int speciesId;
        private int prodTypeId;
        private int colorId;
        private string listCategoryId;
        private int categoryTypeId;
        private string listProdId;

        private int isAllSuppliers;
        private int isAllCategories;
        private int isAllAdditionalProduct;
        private int isUpdateDataAuto;

        private int forecastStockFilter;
        private int productStatusFilter;
        private User createdBy;

        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultFilterPSFS"/> class.
        /// </summary>
        public DefaultFilterPSFS()
        {

        }
        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultFilterPSFS"/> class.
        /// </summary>
        /// <param name="salesOrgId"></param>
        /// <param name="listOrgId"></param>
        /// <param name="speciesId"></param>
        /// <param name="listCategoryId"></param>
        /// <param name="categoryTypeId"></param>
        /// <param name="listProdId"></param>
        /// <param name="isAllSuppliers"></param>
        /// <param name="isAllCategories"></param>
        /// <param name="isAllAdditionalProduct"></param>
        /// <param name="isUpdateDataAuto"></param>        
        /// <param name="forecastStockFilter"></param>
        /// <param name="productStatusFilter"></param>
        /// <param name="createdBy"></param>
        public DefaultFilterPSFS(string salesOrgId, string listOrgId, int speciesId, int prodTypeId, int colorId, string listCategoryId, int categoryTypeId, string listProdId, int isAllSuppliers, int isAllCategories, int isAllAdditionalProduct, int isUpdateDataAuto, int forecastStockFilter, int productStatusFilter, User createdBy)
        {
            this.salesOrgId = salesOrgId;
            this.listOrgId = listOrgId;
            this.speciesId = speciesId;
            this.prodTypeId = prodTypeId;
            this.colorId = colorId;
            this.listCategoryId = listCategoryId;
            this.categoryTypeId = categoryTypeId;
            this.listProdId = listProdId;
            this.isAllSuppliers = isAllSuppliers;
            this.isAllCategories = isAllCategories;
            this.isAllAdditionalProduct = isAllAdditionalProduct;
            this.isUpdateDataAuto = isUpdateDataAuto;
            this.forecastStockFilter = forecastStockFilter;
            this.productStatusFilter = productStatusFilter;
            this.createdBy = createdBy;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }
        
        /// <summary>
        /// 
        /// </summary>
        public string ListOrgId
        {
            get { return listOrgId; }
            set { listOrgId = value; }
        }
       
        /// <summary>
        /// 
        /// </summary>
        public string ListCategoryId
        {
            get { return listCategoryId; }
            set { listCategoryId = value; }
        }
        
        /// <summary>
        /// 
        /// </summary>
        public string ListProdId
        {
            get { return listProdId; }
            set { listProdId = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int IsAllSuppliers
        {
            get { return isAllSuppliers; }
            set { isAllSuppliers = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int IsAllCategories
        {
            get { return isAllCategories; }
            set { isAllCategories = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int IsAllAdditionalProduct
        {
            get { return isAllAdditionalProduct; }
            set { isAllAdditionalProduct = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int IsUpdateDataAuto
        {
            get { return isUpdateDataAuto; }
            set { isUpdateDataAuto = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public User CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string SalesOrgId
        {
            get { return salesOrgId; }
            set { salesOrgId = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int SpeciesId
        {
            get { return speciesId; }
            set { speciesId = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int CategoryTypeId
        {
            get { return categoryTypeId; }
            set { categoryTypeId = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int ForecastStockFilter
        {
            get { return forecastStockFilter; }
            set { forecastStockFilter = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int ProductStatusFilter
        {
            get { return productStatusFilter; }
            set { productStatusFilter = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int ProdTypeId
        {
            get { return prodTypeId; }
            set { prodTypeId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int ColorId
        {
            get { return colorId; }
            set { colorId = value; }
        }
    }
}