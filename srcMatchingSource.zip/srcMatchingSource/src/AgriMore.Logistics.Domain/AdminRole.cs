using System;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class is an implementation for AdminRole
    /// </summary>
    public class AdminRole : IIdentifyable<string>
    {
        private string uid;
        private string roleDesc;
        private readonly ISet roles = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="AdminRole"/> class.
        /// </summary>
        protected AdminRole() { }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        public string Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the RoleDesc.
        /// </summary>
        public string RoleDesc
        {
            get { return roleDesc; }
            set { roleDesc = value; }
        }

        /// <summary>
        /// Gets or sets the roles.
        /// </summary>
        public IList<Role> Roles
        {
            get { return ListHandler.ConvertToGenericList<Role>(roles); }
        }
    }
}
