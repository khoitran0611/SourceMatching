﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class ProductSupply
    {


        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSupply"/> class.
        /// </summary>
        public ProductSupply()
        {
        }

        public long Uid { get; set; }

        public long ParentId { get; set; }

        public DateTime AvailableDate { get; set; }

        public decimal Amount { get; set; }

        public UoM UoM { get; set; }

        public Product Product { get; set; }

        public long AddressId { get; set; }

        public long LocationId { get; set; }

        public string StrOrgId { get; set; }

        public long OrganizationId { get; set; }

        public long SalesOrgId { get; set; }

        public long PurchaseChainEntityId { get; set; }

        public int Quantity { get; set; }

        public bool IsPackedByChain { get; set; }

        public bool IsDecomposed { get; set; }

        public SellerStatus SaleStatus { get; set; }

        public BuyerStatus BuyStatus { get; set; }

        public long Version { get; set; }
    }
}
