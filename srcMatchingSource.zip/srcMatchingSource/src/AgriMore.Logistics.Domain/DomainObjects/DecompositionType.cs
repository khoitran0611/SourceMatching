﻿using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class DecompositionType
    {
        private long uid;
        private string name;
        private string gs1Code;
        private string otherCode;
        private string ledgerCode;
           
        /// <summary>
        /// 
        /// </summary>
        public DecompositionType()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Packaging Description.
        /// </summary>
        /// <value>The uid.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }
        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }
        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            DecompositionTypeLang prodGrpLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return prodGrpLang == null ? Name : prodGrpLang.Name;
        }
        /// <summary>
        /// Gets or sets the ProdGrpLangs.
        /// </summary>
        public IList<DecompositionTypeLang> CategoryLangs
        {
            get;
            set;
        }

        //public TreatmentTypeCategory TreatmentTypeCategory { get; set; }

        public UoM UnitOfMeasurement { get; set; }
    }
}