﻿namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class ProductGroupLang
    {
        private long uid;
        private string name;
        private string langCode;        

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductGroupLang"/> class.
        /// </summary>
        public ProductGroupLang()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductGroupLang"/> class.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="prodGroup"></param>
        public ProductGroupLang(string name, string langCode)
        {
            this.name = name;
            this.langCode = langCode;            
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }       
    }
}