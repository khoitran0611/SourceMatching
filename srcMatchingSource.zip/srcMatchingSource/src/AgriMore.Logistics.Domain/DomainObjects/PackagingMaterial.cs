﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class PackagingMaterial
    {
        private long uid;
        private string name;        
        
        public PackagingMaterial() 
        {

        }

        public PackagingMaterial(string name)
        {            
            this.Name = name;
        }

        public long Uid
        { 
            get { return uid; }
            set { this.uid = value; }
        }

        public string Name 
        { 
            get { return name; }
            set { this.name = value; }
        }        
    }
}
