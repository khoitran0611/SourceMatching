﻿namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class TreatmentCategoryLang
    {
        private long uid;
        private string name;
        private string langCode;        

        /// <summary>
        /// 
        /// </summary>
        public TreatmentCategoryLang()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        public TreatmentCategoryLang(string name, string langCode)
        {
            this.name = name;
            this.langCode = langCode;            
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }       
    }
}