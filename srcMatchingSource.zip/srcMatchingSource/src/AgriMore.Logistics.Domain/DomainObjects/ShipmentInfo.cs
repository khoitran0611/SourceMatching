﻿using System;

namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class ShipmentInfo
    {
        public string ProductSupplyIds { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string CreatedUserId { get; set; }

        public long ReceiverChainEntityId { get; set; }

        public string LoadingAdviceDocName
        {
            get;
            set;
        }

        public string LoadingAdviceDocPath
        {
            get;
            set;
        }

    }
}
