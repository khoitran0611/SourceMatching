﻿using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class DecompositionCategory
    {
        private long uid;
        private string name;        
           
        /// <summary>
        /// 
        /// </summary>
        public DecompositionCategory()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Packaging Description.
        /// </summary>
        /// <value>The uid.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }        

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            DecompositionCategoryLang prodGrpLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return prodGrpLang == null ? Name : prodGrpLang.Name;
        }
        /// <summary>
        /// Gets or sets the ProdGrpLangs.
        /// </summary>
        public IList<DecompositionCategoryLang> CategoryLangs
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        //public IList<DecompositionType> DecompositionTypes
        //{
        //    get;
        //    set;
        //} 
    }
}