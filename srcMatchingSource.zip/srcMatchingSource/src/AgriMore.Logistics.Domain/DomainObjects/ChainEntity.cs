﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain.DomainObjects
{
    public class ChainEntity
    {
        public long Uid { get; set; }

        public string Name { get; set; }
    }
}
