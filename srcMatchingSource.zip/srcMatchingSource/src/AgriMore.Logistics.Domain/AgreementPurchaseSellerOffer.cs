﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AgreementPurchaseSellerOffer : IIdentifyable
    {
        private long uid;
        private string sellerId;
        private decimal offerPrice;
        private string currency;
        private DateTime offerAt;
        private AgreementPurchase agmtPurchase;

        /// <summary>
        /// Initializes a new instance of the <see cref="AgreementPurchaseSellerOffer"/> class.
        /// </summary>
        public AgreementPurchaseSellerOffer() { }

        public long Uid { get { return uid; } set { uid = value; } }
        public decimal OfferPrice { get { return offerPrice; } set { offerPrice = value; } }
        public string Currency { get { return currency; } set { currency = value; } }
        public DateTime OfferAt { get { return offerAt; } set { offerAt = value; } }
        public string SellerId { get { return sellerId; } set { sellerId = value; } }
        public AgreementPurchase AgmtPurchase { get { return agmtPurchase; } set { agmtPurchase = value; } }
    }
}
