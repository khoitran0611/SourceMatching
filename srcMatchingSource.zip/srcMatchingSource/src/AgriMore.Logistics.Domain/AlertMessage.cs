using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class AlertMessage : IIdentifyable
    {
        private long uid;
        private string alertText;
        private short status;
        private DateTime alertDate;

        /// <summary>
        /// Initializes a new instance of the <see cref="AlertMessage"/> class.
        /// </summary>
        protected AlertMessage()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlertMessage"/> class.
        /// </summary>
        /// <param name="alertText"></param>
        /// <param name="status"></param>
        public AlertMessage(string alertText, short status)
        {
            this.alertText = alertText;
            this.status = status;
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            ProductSupplyForecast other = obj as ProductSupplyForecast;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return uid.GetHashCode();
        }

        /// <summary>
        /// Gets or sets the AlertText.
        /// </summary>
        public string AlertText
        {
            get { return alertText; }
            set { alertText = value; }
        }

        /// <summary>
        /// Gets or sets the Status.
        /// </summary>
        public short Status
        {
            get { return status; }
            set { status = value; }
        }

        /// <summary>
        /// Gets or sets Alert Date
        /// </summary>
        public DateTime AlertDate
        {
            get { return alertDate; }
            set { alertDate = value; }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public enum AlertStatus
    {
        /// <summary>
        /// 
        /// </summary>
        New = 1,

        /// <summary>
        /// 
        /// </summary>
        InProcess = 2,

        /// <summary>
        /// 
        /// </summary>
        Resolved = 3,

        /// <summary>
        /// 
        /// </summary>
        NoLongerRelevant = 4
    }
}