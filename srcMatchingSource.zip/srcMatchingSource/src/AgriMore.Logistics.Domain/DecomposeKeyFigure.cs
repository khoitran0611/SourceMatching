﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class DecomposeKeyFigure : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual string ForOrgId { get; set; }

        public virtual long RootProdId { get; set; }

        public virtual Species FromProduct { get; set; }

        public virtual Species ToProduct { get; set; }

        public virtual decimal FigureVal { get; set; }

        public virtual string CreatedOrgId { get; set; }

        public virtual KeyFigure FigureInfo { get; set; }
    }
}
