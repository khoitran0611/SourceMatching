using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Common;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Color
    /// </summary>
    public class Color : AbstractKeyNameType
    {
        private string gs1Code;
        private string otherCode;
        private readonly ISet productRelations = new HashedSet();
        private readonly ISet colorLangs = new HashedSet();
        private string ledgerCode;

        /// <summary>
        /// Initializes a new instance of the <see cref="Color"/> class.
        /// </summary>
        protected Color()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Color"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Color(string name)
            : base(name)
        {
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }

        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }

        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        ///<summary>
        /// Get ProductRelationship
        ///</summary>
        public IList<ProductRelationship> ProductRelations
        {
            get { return ListHandler.ConvertToGenericList<ProductRelationship>(productRelations); }
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            ColorLang colorLang = ColorLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return colorLang == null ? Name : colorLang.Name;
        }

        /// <summary>
        /// Gets or sets the SpeciesLangs.
        /// </summary>
        public IList<ColorLang> ColorLangs
        {
            get { return ListHandler.ConvertToGenericList<ColorLang>(colorLangs); }
        }

        /// <summary>
        /// Add ColorLangs
        /// </summary>
        /// <param name="colorLang"></param>
        public void AddColorLangToList(ColorLang colorLang)
        {
            colorLangs.Add(colorLang);
        }

        /// <summary>
        /// Remove ColorLangs
        /// </summary>
        public void RemoveColorLangFromList()
        {
            colorLangs.Clear();
        }

        /// <summary>
        /// Remove ColorLangs
        /// </summary>
        public void RemoveColorLangFromList(ColorLang colorLang)
        {
            colorLangs.Remove(colorLang);
        }
    }
}
