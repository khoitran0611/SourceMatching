using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// CategoryType
    /// </summary>
    public class CategoryType : AbstractKeyNameType
    {
        private string gs1Code;
        private string otherCode;
        private readonly ISet productRelations = new HashedSet();
        private readonly ISet catTypeLangs = new HashedSet();
        private Category category;
        
        private string ledgerCode;

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryType"/> class.
        /// </summary>
        public CategoryType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryType"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public CategoryType(string name)
            : base(name)
        {
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }

        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }

        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public Category Category
        {
            get { return category; }
            set { category = value; }
        }

        ///<summary>
        /// Get ProductRelationship
        ///</summary>
        public IList<ProductRelationship> ProductRelations
        {
            get { return ListHandler.ConvertToGenericList<ProductRelationship>(productRelations); }
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            CategoryTypeLang catTypeLang = CatTypeLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return catTypeLang == null ? Name : catTypeLang.Name;
        }

        /// <summary>
        /// Gets or sets the CatTypeLangs.
        /// </summary>
        public IList<CategoryTypeLang> CatTypeLangs
        {
            get { return ListHandler.ConvertToGenericList<CategoryTypeLang>(catTypeLangs); }
        }

        /// <summary>
        /// Add CatTypeLangs
        /// </summary>
        /// <param name="catTypeLang"></param>
        public void AddCategoryTypeLangToList(CategoryTypeLang catTypeLang)
        {
            catTypeLangs.Add(catTypeLang);
        }

        /// <summary>
        /// Remove CatTypeLangs
        /// </summary>
        public void RemoveCategoryTypeLangFromList()
        {
            catTypeLangs.Clear();
        }

        /// <summary>
        /// Remove CatTypeLangs
        /// </summary>
        public void RemoveCategoryTypeLangFromList(CategoryTypeLang catTypeLang)
        {
            catTypeLangs.Remove(catTypeLang);
        }
    }
}
