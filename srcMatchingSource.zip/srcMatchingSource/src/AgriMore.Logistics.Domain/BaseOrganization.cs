﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BaseOrganization : IIdentifyable<string>
    {
        private string uid;
        private string businessType;
        private string timeZone;
        private string currency;
        private string visibleOutside;
        private string createdBy;
        private DateTime createdAt;
        private int ouid;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseOrganization"/> class.
        /// </summary>
        public BaseOrganization() { }

        public string Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        public string BusinessType
        {
            get { return businessType; }
            set { businessType = value; }
        }

        public string TimeZone
        {
            get { return timeZone; }
            set { timeZone = value; }
        }

        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        public string VisibleOutside
        {
            get { return visibleOutside; }
            set { visibleOutside = value; }
        }

        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        public DateTime CreatedAt
        {
            get { return createdAt; }
            set { createdAt = value; }
        }

        public int Ouid
        {
            get { return ouid; }
            set { ouid = value; }
        }
    }
}
