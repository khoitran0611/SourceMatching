﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BiddingProcess4CompositeProductBuyerOfferDetail : IIdentifyable
    {
        public long Uid { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual BiddingProcess4CompositeProductBuyerOffer BuyerOffer { get; set; }
    }
}
