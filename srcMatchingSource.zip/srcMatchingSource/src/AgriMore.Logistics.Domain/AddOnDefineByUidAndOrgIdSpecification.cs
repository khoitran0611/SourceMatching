﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class AddOnDefineByUidAndOrgIdSpecification: ISpecification<AddOnDefineOrg>
    {
        private string listAddOnDefineId;
        private string tradingId;        

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnDefineByUidAndOrgIdSpecification"/> class.
        /// </summary>
        /// <param name="listAddOnDefineId"></param>
        /// <param name="tradingId"></param>
        public AddOnDefineByUidAndOrgIdSpecification(string listAddOnDefineId, string tradingId)
        {
            this.listAddOnDefineId = listAddOnDefineId;
            this.tradingId = tradingId;
        }       

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(AddOnDefineOrg element)
        {
            return true;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {                
                string queryString = "from AddOnDefineOrg ao where ao.AddOnsDefine.Uid in(:listAddOnDefineId) and ao.Organization.Uid =:orgId";
                Query query = new Query(queryString);
                query.AddParameter("listAddOnDefineId", listAddOnDefineId.Split(','));
                query.AddParameter("orgId", tradingId);

                return query;
            }
        }
    }
}
