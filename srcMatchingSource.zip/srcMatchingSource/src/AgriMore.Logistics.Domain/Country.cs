using AgriMore.Logistics.Common;
using Iesi.Collections;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Represents the countries in the system.
    /// </summary>
    public class Country : AbstractKeyNameType, INameAccessor
    {
        private string gs1Code;
        private string otherCode;
        private string ledgerCode;
        private readonly ISet countryLangs = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="Country"/> class.
        /// </summary>
        protected Country()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Country"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Country(string name)
           // : base(name)
        {            
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            CountryLang countryLang = CountryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return countryLang == null ? Name : countryLang.Name;
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }
        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }


        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }        

        /// <summary>
        /// 
        /// </summary>
        public IList<CountryLang> CountryLangs
        {
            get { return ListHandler.ConvertToGenericList<CountryLang>(countryLangs); }
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="countryLang"></param>
        public void AddCountryLangToList(CountryLang countryLang)
        {
            countryLangs.Add(countryLang);
        }

       /// <summary>
       /// 
       /// </summary>
        public void RemoveCountryLangFromList()
        {
            countryLangs.Clear();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="countryLang"></param>
        public void RemoveCountryLangFromList(CountryLang countryLang)
        {
            countryLangs.Remove(countryLang);
        }
    }
}