﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AgreementPurchase4CompositeProductPriceDetail : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual decimal AgreedPrice { get; set; }

        public virtual decimal FixedPrice { get; set; }

        public virtual decimal OfferPrice { get; set; }

        public virtual decimal CeilingPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }
        public virtual AgreementPurchase4CompositeProduct AgmtPurchase4CompositeProd { get; set; }

        public AgreementPurchase4CompositeProductPriceDetail Copy()
        {
            var tmpObj = (AgreementPurchase4CompositeProductPriceDetail)this.MemberwiseClone();
            tmpObj.Uid = 0;
            tmpObj.AgmtPurchase4CompositeProd = null;
            return tmpObj;
        }
    }
}
