﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class AgreementProcess4CompositeProductPriceDetail : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual decimal AgreedPrice { get; set; }

        public virtual decimal FixedPrice { get; set; }

        public virtual decimal FloorPrice { get; set; }

        public virtual decimal AskingPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }
        public virtual AgreementProcess4CompositeProduct AgmtProcess4CompositeProd { get; set; }

        public AgreementProcess4CompositeProductPriceDetail Copy()
        {
            var tmpObj = (AgreementProcess4CompositeProductPriceDetail)this.MemberwiseClone();
            tmpObj.Uid = 0;
            tmpObj.AgmtProcess4CompositeProd = null;
            return tmpObj;
        }
    }
}
