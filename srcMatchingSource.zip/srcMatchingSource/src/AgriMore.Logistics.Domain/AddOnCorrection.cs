﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class AddOnCorrection : IIdentifyable
    {
        private long uid;
        private AddOnsDefine addOn;
        private int numberOfAddOns;
        private decimal price;
        private int vat;
        private string vatText;
        private long forProdId;
        private PackageCorrection crtPack;
        private Invoicing forInvoice;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnCorrection"/> class.
        /// </summary>
        public AddOnCorrection()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the AddOn.
        /// </summary>
        /// <value>The uid.</value>
        public AddOnsDefine AddOn
        {
            get { return addOn; }
            set { addOn = value; }
        }

        /// <summary>
        /// Gets or sets the NumberOfAddOns.
        /// </summary>
        /// <value>The NumberOfAddOns.</value>
        public int NumberOfAddOns
        {
            get { return numberOfAddOns; }
            set { numberOfAddOns = value; }
        }

        /// <summary>
        /// Gets or sets the Price.
        /// </summary>
        /// <value>The Price.</value>
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        /// <summary>
        /// Gets or sets the Vat.
        /// </summary>
        /// <value>The Vat.</value>
        public int Vat
        {
            get { return vat; }
            set { vat = value; }
        }

        /// <summary>
        /// Gets or sets the VatText.
        /// </summary>
        /// <value>The VatText.</value>
        public string VatText
        {
            get { return vatText; }
            set { vatText = value; }
        }

        /// <summary>
        /// Gets or sets the ForProdId.
        /// </summary>
        /// <value>The ForProdId.</value>
        public long ForProdId
        {
            get { return forProdId; }
            set { forProdId = value; }
        }

        /// <summary>
        /// Gets or sets the CrtPack.
        /// </summary>
        /// <value>The CrtPack.</value>
        public PackageCorrection CrtPack
        {
            get { return crtPack; }
            set { crtPack = value; }
        }

        /// <summary>
        /// Gets or sets the ForInvoice.
        /// </summary>
        /// <value>The ForInvoice.</value>
        public Invoicing ForInvoice
        {
            get { return forInvoice; }
            set { forInvoice = value; }
        }
    }
}
