﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    public class ConsumerSupplyReference : IIdentifyable
    {
        private long uid;
        private string orgId;
        private bool autoUpdateProducer;
        private bool autoUpdateSupplier;
        private string createdBy;
        private DateTime createdAt;

        private readonly ISet refProducers = new HashedSet();
        private readonly ISet notRefProducers = new HashedSet();
        private readonly ISet refSuppliers = new HashedSet();
        private readonly ISet notRefSuppliers = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerSupplyReference"/> class.
        /// </summary>
        public ConsumerSupplyReference()
        {
        }

        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        public string OrgId
        {
            get { return orgId; }
            set { orgId = value; }
        }

        public bool AutoUpdateProducer
        {
            get { return autoUpdateProducer; }
            set { autoUpdateProducer = value; }
        }

        public bool AutoUpdateSupplier
        {
            get { return autoUpdateSupplier; }
            set { autoUpdateSupplier = value; }
        }

        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        public DateTime CreatedAt
        {
            get { return createdAt; }
            set { createdAt = value; }
        }

        #region Gets/Set/Remove Reference to Producers
        /// <summary>
        /// Gets Peoducers.
        /// </summary>
        public IList<Organization> RefProducers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(refProducers); }
        }

        /// <summary>
        /// Add Reference Producer
        /// </summary>
        /// <param name="org"></param>
        public void AddRefProducerToList(Organization org)
        {
            refProducers.Add(org);
        }

        /// <summary>
        /// Remove a Supplier
        /// </summary>
        public void RemoveRefProducerFromList(Organization producer)
        {
            refProducers.Remove(producer);
        }

        /// <summary>
        /// Remove Reference Producer
        /// </summary>
        public void RemoveRefProducerFromList()
        {
            refProducers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Not Reference to Producers
        /// <summary>
        /// Gets Not Ref Producers.
        /// </summary>
        public IList<Organization> NotRefProducers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(notRefProducers); }
        }

        /// <summary>
        /// Add Not Reference Producer
        /// </summary>
        /// <param name="org"></param>
        public void AddNotRefProducerToList(Organization org)
        {
            notRefProducers.Add(org);
        }

        /// <summary>
        /// Remove a Producer
        /// </summary>
        public void RemoveNotRefProducerFromList(Organization producer)
        {
            notRefProducers.Remove(producer);
        }

        /// <summary>
        /// Remove Reference Producer
        /// </summary>
        public void RemoveNotRefProducerFromList()
        {
            notRefProducers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Reference to Suppliers
        /// <summary>
        /// Gets the Suppliers
        /// </summary>
        public IList<Organization> RefSuppliers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(refSuppliers); }
        }

        /// <summary>
        /// Add a Supplier
        /// </summary>
        /// <param name="supplier"></param>
        public void AddRefSupplierToList(Organization supplier)
        {
            refSuppliers.Add(supplier);
        }

        /// <summary>
        /// Remove a Supplier
        /// </summary>
        public void RemoveRefSupplierFromList(Organization supplier)
        {
            refSuppliers.Remove(supplier);
        }

        /// <summary>
        /// Clear all Supplier
        /// </summary>
        public void RemoveRefSupplierFromList()
        {
            refSuppliers.Clear();
        }
        #endregion

        #region Gets/Set/Remove Not Reference to Suppliers
        /// <summary>
        /// Gets the Suppliers
        /// </summary>
        public IList<Organization> NotRefSuppliers
        {
            get { return ListHandler.ConvertToGenericList<Organization>(notRefSuppliers); }
        }

        /// <summary>
        /// Add a Not Ref Supplier
        /// </summary>
        /// <param name="supplier"></param>
        public void AddNotRefSupplierToList(Organization supplier)
        {
            notRefSuppliers.Add(supplier);
        }

        /// <summary>
        /// Remove a Not Ref Supplier
        /// </summary>
        public void RemoveNotRefSupplierFromList(Organization supplier)
        {
            notRefSuppliers.Remove(supplier);
        }

        /// <summary>
        /// Clear all Not Ref Supplier
        /// </summary>
        public void RemoveNotRefSupplierFromList()
        {
            notRefSuppliers.Clear();
        }
        #endregion
    }
}
