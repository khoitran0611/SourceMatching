﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    public class BiddingPurchase4CompositeProduct : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual CompositeProductSupply CompositeProdSupply { get; set; }

        public virtual CompositeProductFavourite CompositeProdFav { get; set; }

        public virtual decimal WonPrice { get; set; }

        public virtual decimal MaxPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual bool IsMatched { get; set; }

        public virtual bool IsIndicatedProd { get; set; }

        public virtual DateTime FromDate { get; set; }

        public virtual DateTime ToDate { get; set; }

        public virtual DateTime StartAt { get; set; }

        public virtual DateTime CloseAt { get; set; }

        public virtual string BuyerId { get; set; }

        public virtual string WonSellerId { get; set; }

        public virtual DateTime UpdatedAt { get; set; }

        #region Invited Seller Organization
        private readonly ISet invitedSellerOrgs = new HashedSet();
        [DataMember(Name = "InvitedSellerOrgs")]
        public IList<Organization> InvitedSellerOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(invitedSellerOrgs); }
        }

        public void AddInvitedSeller(Organization seller)
        {
            invitedSellerOrgs.Add(seller);
        }

        public void RemoveInvitedSeller(Organization seller)
        {
            invitedSellerOrgs.Remove(seller);
        }

        public void RemoveAllInvitedSeller()
        {
            invitedSellerOrgs.Clear();
        }
        #endregion

        #region Agreement Supplier Organization
        private readonly ISet agreedSupplierOrgs = new HashedSet();
        [DataMember(Name = "AgreedSupplierOrgs")]
        public IList<Organization> AgreedSupplierOrgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(agreedSupplierOrgs); }
        }

        public void AddAgreedSupplier(Organization supplier)
        {
            agreedSupplierOrgs.Add(supplier);
        }

        public void RemoveAgreedSupplier(Organization supplier)
        {
            agreedSupplierOrgs.Remove(supplier);
        }

        public void RemoveAllAgreedSupplier()
        {
            agreedSupplierOrgs.Clear();
        }
        #endregion

        #region Price Details
        private readonly IList priceDetails = new List<BiddingPurchase4CompositeProductPriceDetail>();
        [DataMember(Name = "PriceDetails")]
        public IList<BiddingPurchase4CompositeProductPriceDetail> PriceDetails
        {
            get { return priceDetails.Cast<BiddingPurchase4CompositeProductPriceDetail>().ToList(); }
        }

        public void AddPriceDetail(BiddingPurchase4CompositeProductPriceDetail priceDetail)
        {
            priceDetail.BiddingPurchase4CompositeProd = this;
            priceDetails.Add(priceDetail);
        }

        public void RemovePriceDetail(BiddingPurchase4CompositeProductPriceDetail priceDetail)
        {
            priceDetails.Remove(priceDetail);
        }

        public void RemoveAllPriceDetail()
        {
            priceDetails.Clear();
        }
        #endregion
    }
}
