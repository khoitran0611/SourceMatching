using System;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Iesi.Collections;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// ForecastReminderDefineEmail
    /// </summary>
    public class ForecastReminderDefineEmail : IIdentifyable
    {
        private long uid;
        private string languageCode;
        private string emailSubject;
        private string emailBody;
        private ForecastReminderDefine forecastReminderDefine;
        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntity"/> class.
        /// </summary>
        public ForecastReminderDefineEmail()
        {
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        ///<summary>
        /// Gets or sets languageCode code
        ///</summary>
        public string LanguageCode
        {
            get { return languageCode; }
            set { languageCode = value; }
        }

        ///<summary>
        /// Gets or sets EmailSubject code
        ///</summary>
        public string EmailSubject
        {
            get { return emailSubject; }
            set { emailSubject = value; }
        }

        ///<summary>
        /// Gets or sets EmailBody code
        ///</summary>
        public string EmailBody
        {
            get { return emailBody; }
            set { emailBody = value; }
        }

         /// <summary>
        /// Gets or sets the ForecastReminderDefine
        /// </summary>
        public ForecastReminderDefine ForecastReminderDefine
        {
            get { return forecastReminderDefine; }
            set { forecastReminderDefine = value; }
        }
        
    }
}