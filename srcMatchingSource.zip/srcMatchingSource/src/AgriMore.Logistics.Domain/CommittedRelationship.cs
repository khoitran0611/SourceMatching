﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class CommittedRelationship : IIdentifyable
    {
        private long uid;
        private Species product;
        private ProdType prodType;
        private Color color;
        private CategoryType catType;
        private Category category;
        private long addressId;
        private long locationId;
        private string prodAttrIds;
        private string indicatedPackIds;
        private string indicatedPackNames;

        //private int isAllPeriod;
        private DateTime availableFrom;
        private DateTime availableTo;
        private Organization grower;
        private Organization buyer;
        private string createdBy;
        
        //private ProductFavourites prodFavorite;

        private readonly ISet committedRltPeriods = new HashedSet();

        /// <summary>
        /// Initializes a new instance of the <see cref="CommittedRelationship"/> class.
        /// </summary>
        public CommittedRelationship()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        ///<summary>
        /// Gets or sets Product
        ///</summary>
        public Species Product
        {
            get { return product; }
            set { product = value; }
        }

        ///<summary>
        /// Gets or sets ProdType
        ///</summary>
        public ProdType ProdType
        {
            get { return prodType; }
            set { prodType = value; }
        }

        ///<summary>
        /// Gets or sets Color
        ///</summary>
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

        ///<summary>
        /// Gets or sets CatType
        ///</summary>
        public CategoryType CatType
        {
            get { return catType; }
            set { catType = value; }
        }

        ///<summary>
        /// Gets or sets Category
        ///</summary>
        public Category Category
        {
            get { return category; }
            set { category = value; }
        }

        /// <summary>
        /// Gets or sets the Address.
        /// </summary>
        /// <value>The Address.</value>
        public long AddressId
        {
            get { return addressId; }
            set { addressId = value; }
        }

        /// <summary>
        /// Gets or sets the Location.
        /// </summary>
        /// <value>The Location.</value>
        public long LocationId
        {
            get { return locationId; }
            set { locationId = value; }
        }

        ///<summary>
        /// Gets or sets Product Attribure Ids
        ///</summary>
        public string ProdAttrIds
        {
            get { return prodAttrIds; }
            set { prodAttrIds = value; }
        }

        ///<summary>
        /// Gets or sets AvailableFrom
        ///</summary>
        public DateTime AvailableFrom
        {
            get { return availableFrom; }
            set { availableFrom = value; }
        }

        ///<summary>
        /// Gets or sets AvailableTo
        ///</summary>
        public DateTime AvailableTo
        {
            get { return availableTo; }
            set { availableTo = value; }
        }

        ///<summary>
        /// Gets or sets IndicatedPackIds
        ///</summary>
        public string IndicatedPackIds
        {
            get { return indicatedPackIds; }
            set { indicatedPackIds = value; }
        }

        ///<summary>
        /// Gets or sets IndicatedPackNames
        ///</summary>
        public string IndicatedPackNames
        {
            get { return indicatedPackNames; }
            set { indicatedPackNames = value; }
        }

        ///<summary>
        /// Gets or sets Grower
        ///</summary>
        public Organization Grower
        {
            get { return grower; }
            set { grower = value; }
        }

        ///<summary>
        /// Gets or sets Buyer
        ///</summary>
        public Organization Buyer
        {
            get { return buyer; }
            set { buyer = value; }
        }

        ///<summary>
        /// Gets or sets CreatedBy
        ///</summary>
        public string CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        #region Committed Relationship Items Events
        /// <summary>
        /// Gets or sets the Committed Relation Periods.
        /// </summary>
        public IList<CommittedRelationshipPeriod> CommittedRltPeriods
        {
            get { return ListHandler.ConvertToGenericList<CommittedRelationshipPeriod>(committedRltPeriods); }
        }

        /// <summary>
        /// Add Committed Relation Period
        /// </summary>
        /// <param name="cmtRltPeriod"></param>
        public void AddCommittedRelationItemToList(CommittedRelationshipPeriod cmtRltPeriod)
        {
            committedRltPeriods.Add(cmtRltPeriod);
        }

        /// <summary>
        /// Remove Committed Relation Period
        /// </summary>
        public void RemoveCommittedRelationItemFromList()
        {
            committedRltPeriods.Clear();
        }

        /// <summary>
        /// Remove Committed Relation Period
        /// </summary>
        public void RemoveCommittedRelationItemFromList(CommittedRelationshipPeriod cmtRltPeriod)
        {
            committedRltPeriods.Remove(cmtRltPeriod);
        }
        #endregion
    }
}