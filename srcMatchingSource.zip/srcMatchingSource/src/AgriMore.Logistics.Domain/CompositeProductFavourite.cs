﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class CompositeProductFavourite : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual string Name { get; set; }

        public virtual decimal PriceSurcharge { get; set; }

        public virtual string Currency { get; set; }

        public virtual PackagingDefine PackageType { get; set; }

        public virtual string OrgId { get; set; }

        private readonly IList prod4CompositeFav = new List<Products4CompositeProductFavourite>();
        [DataMember(Name = "Prod4CompositeFav")]
        public IList<Products4CompositeProductFavourite> Prod4CompositeFav
        {
            get { return prod4CompositeFav.Cast<Products4CompositeProductFavourite>().ToList(); }
        }

        public void AddProd4CompositeFav(Products4CompositeProductFavourite products4CompositeFav)
        {
            products4CompositeFav.CompositeProdFav = this;
            prod4CompositeFav.Add(products4CompositeFav);
        }

        public void RemoveProd4CompositeFav(Products4CompositeProductFavourite products4CompositeFav)
        {
            prod4CompositeFav.Remove(products4CompositeFav);
        }

        public void RemoveAllProd4CompositeFav()
        {
            prod4CompositeFav.Clear();
        }
    }
}
