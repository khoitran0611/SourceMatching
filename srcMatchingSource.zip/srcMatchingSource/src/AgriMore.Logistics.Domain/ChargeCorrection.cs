﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class ChargeCorrection : IIdentifyable
    {
        private long uid;
        private InvoiceCharge invCharge;
        private int amount;
        private int vat;
        private string vatText;
        private Invoicing forInvoice;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeCorrection"/> class.
        /// </summary>
        public ChargeCorrection()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the invCharge.
        /// </summary>
        /// <value>The uid.</value>
        public InvoiceCharge InvCharge
        {
            get { return invCharge; }
            set { invCharge = value; }
        }

        /// <summary>
        /// Gets or sets the Amount.
        /// </summary>
        /// <value>The uid.</value>
        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        /// <summary>
        /// Gets or sets the Vat.
        /// </summary>
        /// <value>The uid.</value>
        public int Vat
        {
            get { return vat; }
            set { vat = value; }
        }

        /// <summary>
        /// Gets or sets the VatText.
        /// </summary>
        /// <value>The uid.</value>
        public string VatText
        {
            get { return vatText; }
            set { vatText = value; }
        }

        /// <summary>
        /// Gets or sets the ForInvoice.
        /// </summary>
        /// <value>The uid.</value>
        public Invoicing ForInvoice
        {
            get { return forInvoice; }
            set { forInvoice = value; }
        }
    }
}
