﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public class CommittedRelationshipModel
    {
        public string Uid { get; set; }

        public Organization Grower { get; set; }

        public Species Product { get; set; }

        public ProdType ProdType { get; set; }

        public Color Color { get; set; }

        public CategoryType CatType { get; set; }

        public Category Category { get; set; }

        public long AddressId { get; set; }

        public long LocationId { get; set; }

        public string AttrIds { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public long CommittedRelationshipPeriodId { get; set; }

        public IList<CommittedRltItem> RelationItems { get; set; }
    }

    public class CommittedRltItem
    {
        public long ItemId { get; set; }

        public int Percent { get; set; }

        public int Priority { get; set; }

        public long MinAmount { get; set; }

        public long FixedAmount { get; set; }

        public string IdtPackIds { get; set; }

        public string IdtPackNames { get; set; }

        public bool IsValid { get; set; }

        public string BuyerName { get; set; }

        public string BuyerId { get; set; }
    }
}
