using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Category
    /// </summary>
    public class Category : AbstractKeyNameType
    {
        private string gs1Code;
        private string otherCode;
        private readonly ISet productRelations = new HashedSet();
        private readonly ISet categoryLangs = new HashedSet();
        private readonly ISet categoryTypes = new HashedSet();
        private string ledgerCode;
        private ProductType productType;        

        /// <summary>
        /// Initializes a new instance of the <see cref="Category"/> class.
        /// </summary>
        public Category()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Category"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Category(string name)
            : base(name)
        {
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }
        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }
        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public ProductType ProductType
        {
            get { return productType; }
            set { productType = value; }
        }

        ///<summary>
        /// Get ProductRelationship
        ///</summary>
        public IList<ProductRelationship> ProductRelations
        {
            get { return ListHandler.ConvertToGenericList<ProductRelationship>(productRelations); }
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            CategoryLang categoryLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return categoryLang == null ? Name : categoryLang.Name;
        }

        /// <summary>
        /// Gets or sets the CatTypeLangs.
        /// </summary>
        public IList<CategoryLang> CategoryLangs
        {
            get { return ListHandler.ConvertToGenericList<CategoryLang>(categoryLangs); }
        }

        /// <summary>
        /// Add CategoryLangs
        /// </summary>
        /// <param name="categoryLang"></param>
        public void AddCategoryLangToList(CategoryLang categoryLang)
        {
            categoryLangs.Add(categoryLang);
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList()
        {
            categoryLangs.Clear();
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList(CategoryLang categoryLang)
        {
            categoryLangs.Remove(categoryLang);
        }

        
        public IEnumerable<CategoryType> CategoryTypes
        {
            get
            {
                return ListHandler.ConvertToGenericList<CategoryType>(categoryTypes);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryType"></param>
        public void AddCategoryType(CategoryType categoryType)
        {
            categoryTypes.Add(categoryType);
        }

    }

    public enum ProductType
    {
        Unknown = -1,

        Product = 0,

        NonProduct = 1        
    }
}
