﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class ColorLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private Color color;

        /// <summary>
        /// Initializes a new instance of the <see cref="ColorLang"/> class.
        /// </summary>
        public ColorLang()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ColorLang"/> class.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="color"></param>
        public ColorLang(string name, string langCode, Color color)
        {
            this.name = name;
            this.langCode = langCode;
            this.color = color;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryType
        /// </summary>
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }
    }
}
