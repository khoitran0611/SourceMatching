﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class BiddingPurchase4CompositeProductPriceDetail : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual decimal MaxPrice { get; set; }

        public virtual decimal AgreedPrice { get; set; }

        public virtual string Currency { get; set; }

        public virtual Products4CompositeProductFavourite Product4CompositeProdFav { get; set; }
        public virtual BiddingPurchase4CompositeProduct BiddingPurchase4CompositeProd { get; set; }

        public BiddingPurchase4CompositeProductPriceDetail Copy()
        {
            var tmpObj = (BiddingPurchase4CompositeProductPriceDetail)this.MemberwiseClone();
            tmpObj.Uid = 0;
            tmpObj.BiddingPurchase4CompositeProd = null;
            return tmpObj;
        }
    }
}
