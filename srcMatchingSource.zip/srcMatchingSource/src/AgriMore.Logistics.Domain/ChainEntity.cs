using System;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// A ChainEntity is an entity in the logistics chain, like a grower, distribution centre, transport company, supermarket.
    /// The ChainEntity has a number of locations to store packages in. parties can create shipments and deliver packages to each other.
    /// </summary>
    public class ChainEntity : AbstractKeyNameType
    {
        private readonly ISet addresses = new HashedSet();
        private readonly ISet properties = new HashedSet();
        private readonly ISet users = new HashedSet();
        private readonly ISet organizations = new HashedSet();
        private string vatNumber;
        private string cocNumber;
        private string bankAccount1;
        private string bankAccount2;
        private string gs1Code;
        private string otherCode;
        private string ledgerCode;
        private string preferredLanguage;
        private string reminderEmail;
        private string invoiceEmail;
        private string priceUpdateReminderEmail;
        private string glnCode;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntity"/> class.
        /// </summary>
        protected ChainEntity()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntity"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public ChainEntity(string name)
            : base(name)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntity"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="addresses">The addresses.</param>
        /// <param name="users">The users.</param>
        public ChainEntity(string name, IEnumerable<Address> addresses, IEnumerable<User> users)
            : base(name)
        {
            this.addresses.AddAll(new List<Address>(addresses));
            this.users.AddAll(new List<User>(users));
        }

        /// <summary>
        /// Gets or sets the addresses.
        /// </summary>
        /// <value>The addresses.</value>
        public IEnumerable<Address> Addresses
        {
            get
            {
                foreach (Address address in addresses)
                {
                    yield return address;
                }
            }
        }

        /// <summary>
        /// Gets or sets the Properties.
        /// </summary>
        /// <value>The Properties.</value>
        public IEnumerable<ChainEntityProperty> Properties
        {
            get
            {
                foreach (ChainEntityProperty chainEntityProperty in properties)
                {
                    yield return chainEntityProperty;
                }
            }
        }

        /// <summary>
        /// Gets the locations.
        /// </summary>
        /// <value>The locations.</value>
        public IEnumerable<Location> Locations
        {
            get
            {
                IList<Location> locations = new List<Location>();
                foreach (Address address in addresses)
                {
                    foreach (Location location in address.Locations)
                    {
                        locations.Add(location);
                    }
                }
                return locations;
            }
        }

        /// <summary>
        /// Gets the users.
        /// </summary>
        /// <value>The users.</value>
        public IEnumerable<User> Users
        {
            get
            {
                foreach (User user in users)
                {
                    yield return user;
                }
            }
        }

        /// <summary>
        /// Gets the organizations.
        /// </summary>
        public IList<Organization> Organizations
        {
            get { return ListHandler.ConvertToGenericList<Organization>(organizations); }
        }

        /// <summary>
        /// Gets the roles.
        /// </summary>
        /// <value>The roles.</value>
        public IEnumerable<Role> Roles
        {
            get
            {
                ICollection<Role> roles = new Collection<Role>();
                foreach (User user in users)
                {
                    foreach (Role role in user.Roles)
                    {
                        if (!roles.Contains(role))
                        {
                            roles.Add(role);
                        }
                    }
                }

                return roles;
            }
        }

        /// <summary>
        /// Determines whether [contains] [the specified specified location].
        /// </summary>
        /// <param name="specifiedLocation">The specified location.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified specified location]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Location specifiedLocation)
        {
            foreach (Address address in addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location.Equals(specifiedLocation))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Determines whether the chain entity contains the specified address.
        /// </summary>
        /// <param name="address">The address.</param>
        /// <returns>
        /// 	<c>true</c> if the chain entity contains the specified address.; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Address address)
        {
            foreach (Address ad in addresses)
            {
                if (address.Equals(ad))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Adds the user for testing purposes.
        /// </summary>
        /// <param name="user">The user.</param>
        public void AddUser(User user)
        {
            if (user == null)
                throw new ArgumentNullException("user");

            users.Add(user);
        }

        /// <summary>
        /// Determines whether [contains] [the specified specified location].
        /// </summary>
        /// <param name="specifiedUser">The specified user.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified specified location]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(User specifiedUser)
        {
            return users.Contains(specifiedUser);
        }

        /// <summary>
        /// Adds the address.
        /// </summary>
        /// <param name="address">The address.</param>
        public void AddAddress(Address address)
        {
            if (address == null)
            {
                throw new ArgumentNullException("address");
            }

            addresses.Add(address);
        }

        /// <summary>
        /// Adds the property.
        /// </summary>
        /// <param name="property">The property</param>
        public void AddProperty(ChainEntityProperty property)
        {
            if (property == null)
            {
                throw new ArgumentNullException("property");
            }

            properties.Add(property);
        }

        /// <summary>
        /// Removes the property
        /// </summary>
        /// <param name="property">The property</param>
        public void RemoveProperty(ChainEntityProperty property)
        {
            properties.Remove(property);
        }

        ///<summary>
        /// Clear All Properties
        ///</summary>
        public void ClearAllProperties()
        {
            properties.Clear();
        }

        ///<summary>
        /// Gets or sets the VAT number
        ///</summary>
        public string VatNumber
        {
            get { return vatNumber; }
            set { vatNumber = value; }
        }

        ///<summary>
        /// Gets or sets the Coc number
        ///</summary>
        public string CocNumber
        {
            get { return cocNumber; }
            set { cocNumber = value; }
        }

        ///<summary>
        /// Gets or sets the BankAccount1
        ///</summary>
        public string BankAccount1
        {
            get { return bankAccount1; }
            set { bankAccount1 = value; }
        }

        ///<summary>
        /// Gets or sets the BankAccount2
        ///</summary>
        public string BankAccount2
        {
            get { return bankAccount2; }
            set { bankAccount2 = value; }
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }

        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }

        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        ///<summary>
        /// Gets or sets PreferredLanguage
        ///</summary>
        public string PreferredLanguage
        {
            get { return preferredLanguage; }
            set { preferredLanguage = value; }
        }

        ///<summary>
        /// Gets or sets ReminderEmail
        ///</summary>
        public string ReminderEmail
        {
            get { return reminderEmail; }
            set { reminderEmail = value; }
        }

        ///<summary>
        /// Gets or sets InvoiceEmail
        ///</summary>
        public string InvoiceEmail
        {
            get { return invoiceEmail; }
            set { invoiceEmail = value; }
        }

        public string GLNCode
        {
            get { return glnCode; }
            set { glnCode = value; }
        }

        ///<summary>
        /// Gets or sets PriceUpdateReminderEmail
        ///</summary>
        public string PriceUpdateReminderEmail
        {
            get { return priceUpdateReminderEmail; }
            set { priceUpdateReminderEmail = value; }
        }

        public virtual bool IsShowGeneralInfo4All { get; set; }

        public virtual bool IsShowDirectly { get; set; }

        private readonly ISet showGeneral4Orgs = new HashedSet();
        public IList<Organization> ShowGeneral4Orgs
        {
            get { return ListHandler.ConvertToGenericList<Organization>(showGeneral4Orgs); }
        }

        public void AddShowGeneralOrg(Organization org)
        {
            showGeneral4Orgs.Add(org);
        }

        public void RemoveShowGeneralOrg(Organization org)
        {
            showGeneral4Orgs.Remove(org);
        }

        public void RemoveAllShowGeneralOrgs()
        {
            showGeneral4Orgs.Clear();
        }

        private readonly ISet visible4Roles = new HashedSet();
        public IList<Role> Visible4Roles
        {
            get { return ListHandler.ConvertToGenericList<Role>(visible4Roles); }
        }

        public void AddVisibleRole(Role role)
        {
            visible4Roles.Add(role);
        }

        public void RemoveVisibleRole(Role role)
        {
            visible4Roles.Remove(role);
        }

        public void RemoveAllVisibleRoles()
        {
            visible4Roles.Clear();
        }
    }
}