﻿using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class AddOnsDefineLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private AddOnsDefine addOns;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnsDefineLang"/> class.
        /// </summary>
        public AddOnsDefineLang()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddOnsDefineLang"/> class.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="addOns"></param>
        public AddOnsDefineLang(string name, string langCode, AddOnsDefine addOns)
        {
            this.name = name;
            this.langCode = langCode;
            this.addOns = addOns;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryType
        /// </summary>
        public AddOnsDefine AddOns
        {
            get { return addOns; }
            set { addOns = value; }
        }
    }
}
