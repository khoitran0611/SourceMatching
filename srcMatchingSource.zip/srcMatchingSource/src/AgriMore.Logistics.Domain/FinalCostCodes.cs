using Iesi.Collections;
using AgriMore.Logistics.Common;
using System.Collections.Generic;
using System.Linq;
namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Represents the countries in the system.
    /// </summary>
    public enum FinalCostCodesRefCode
    {
        /// <summary>
        /// Represents the countries in the system.
        /// </summary>
        PackageTypePrice=1,
        /// <summary>
        /// Represents the countries in the system.
        /// </summary>
        PackageTypeRent=2,
        /// <summary>
        /// Represents the countries in the system.
        /// </summary>
        PackageTypeDeposit=3
    }
    /// <summary>
    /// Represents the countries in the system.
    /// </summary>
    public class FinalCostCodes : AbstractKeyNameType
    {
        private string gs1Code;
        private string otherCode;
        private string ledgerCode;
        private long refCode;
        private readonly ISet finalCostCodesLangs = new HashedSet();
        /// <summary>
        /// Initializes a new instance of the <see cref="Country"/> class.
        /// </summary>
        protected FinalCostCodes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Country"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public FinalCostCodes(string name)
            : base(name)
        {
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            FinalCostCodesLang fLang = FinalCostCodesLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return fLang == null ? this.Name : fLang.Name;
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }
        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }


        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        ///<summary>
        /// Gets or sets RefCode code
        ///</summary>
        public long RefCode
        {
            get { return refCode; }
            set { refCode = value; }
        }

        /// <summary>
        /// Gets or sets the InvChargeCatLangs.
        /// </summary>
        public IList<FinalCostCodesLang> FinalCostCodesLangs
        {
            get { return ListHandler.ConvertToGenericList<FinalCostCodesLang>(finalCostCodesLangs); }
        }
    }
}