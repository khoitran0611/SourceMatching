﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class DecompositionInfo : IIdentifyable
    {
        public long Uid { get; set; }
        public DateTime PeriodFromDate { get; set; }
        public DateTime PeriodToDate { get; set; }
        public long ProductId { get; set; }
        public decimal Cost { get; set; }
        public string CostCurrency { get; set; }
        public int NumberPackage { get; set; }
        public string CostUnit { get; set; }
        public DecompositionType DecomposeType { get; set; }
    }
}
