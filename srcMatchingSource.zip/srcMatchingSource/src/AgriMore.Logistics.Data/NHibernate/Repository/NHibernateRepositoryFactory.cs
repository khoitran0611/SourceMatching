using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.NHibernate.Repository
{
    /// <summary>
    /// Represents the NHibernateRepositoryFactory class.
    /// </summary>
    public class NHibernateRepositoryFactory : IRepositoryFactory
    {
        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the treatment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Treatment> GetTreatmentRepository()
        {
            return CreateRepository<Treatment>();
        }

        #endregion

        /// <summary>
        /// Gets the identification repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Identification> GetIdentificationRepository()
        {
            return CreateRepository<Identification>();
        }


        /// <summary>
        /// Gets the exposure document repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureDocument> GetExposureDocumentRepository()
        {
            return CreateRepository<ExposureDocument>();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<PackageType> GetPackageTypeRepository()
        {
            return CreateRepository<PackageType>();
        }

        /// <summary>
        /// Gets the treatment type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<TreatmentType> GetTreatmentTypeRepository()
        {
            return CreateRepository<TreatmentType>();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TreatmentTypeCategory> GetTreatmentTypeCategoryRepository()
        {
            return CreateRepository<TreatmentTypeCategory>();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<User> GetUserRepository()
        {
            return CreateRepository<User>();
        }

        /// <summary>
        /// Gets the exposure repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Exposure> GetExposureRepository()
        {
            return CreateRepository<Exposure>();
        }

        /// <summary>
        /// Gets the exposure type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureType> GetExposureTypeRepository()
        {
            return CreateRepository<ExposureType>();
        }

        /// <summary>
        /// retrieve a ChainEntity repository
        ///</summary>
        /// <returns></returns>
        public IRepository<ChainEntity> GetChainEntityRepository()
        {
            return CreateRepository<ChainEntity>();
        }

        /// <summary>
        /// retrieve a Consumer Supply Reference repository
        ///</summary>
        /// <returns></returns>
        public IRepository<ConsumerSupplyReference> GetConsumerSupplyReferenceRepository()
        {
            return CreateRepository<ConsumerSupplyReference>();
        }

        /// <summary>
        /// Gets the role repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Role> GetRoleRepository()
        {
            return CreateRepository<Role>();
        }

        /// <summary>
        /// retrieve a Location repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Location> GetLocationRepository()
        {
            return CreateRepository<Location>();
        }

        /// <summary>
        /// Gets the address repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Address> GetAddressRepository()
        {
            return CreateRepository<Address>();
        }

        /// <summary>
        /// Gets the Corporate Information repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<CorporateInfo> GetCorporateInfoRepository()
        {
            return CreateRepository<CorporateInfo>();
        }

        /// <summary>
        /// Gets the shipment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Shipment> GetShipmentRepository()
        {
            return CreateRepository<Shipment>();
        }

        /// <summary>
        /// Gets the package repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Package> GetPackageRepository()
        {
            return CreateRepository<Package>();
        }


        /// <summary>
        /// Gets the processing step repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ProcessingStep> GetProcessingStepRepository()
        {
            return CreateRepository<ProcessingStep>();
        }

        /// <summary>
        /// Creates the repository.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <returns></returns>
        public IRepository<TElement> CreateRepository<TElement>() where TElement : class, IIdentifyable
        {
            return new NHibernateRepository<TElement>();
        }

        /// <summary>
        /// Creates the repository.
        /// </summary>
        /// <typeparam name="TElement"></typeparam>
        /// <typeparam name="IdType"></typeparam>
        /// <returns></returns>
        public IRepository<TElement, IdType> CreateRepository<TElement, IdType>() where TElement : class, IIdentifyable<IdType>
        {
            return new NHibernateRepository<TElement, IdType>();
        }

        /// <summary>
        /// Gets the cash register repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<CashRegister> GetCashRegisterRepository()
        {
            return new NHibernateRepository<CashRegister>();
        }

        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the repack package relationship repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<RepackPackageRelationship> GetRepackPackageRelationshipRepository()
        {
            return new NHibernateRepository<RepackPackageRelationship>();
        }

        #endregion

        /// <summary>
        /// Creates the transaction manager.
        /// </summary>
        /// <returns></returns>
        public ITransactionManager CreateTransactionManager()
        {
            return new NHibernateTransactionManager();
        }

        /// <summary>
        /// Initializes the test data.
        /// </summary>
        public void InitializeTestData()
        {
            InitializeStaticMembersOfDomain();

            //ClearAll();

            new DataFiller().Fill();
        }

        private static void InitializeStaticMembersOfDomain()
        {
            Role.Initialize();
        }

        #region IRepositoryFactory Members


        /// <summary>
        /// Gets the transport equipment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<TransportEquipment> GetTransportEquipmentRepository()
        {
            return CreateRepository<TransportEquipment>();
        }


        #endregion

        #region IRepositoryFactory Members


        /// <summary>
        /// Gets the agri more time zone repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<AgriMoreTimeZone> GetAgriMoreTimeZoneRepository()
        {
            return CreateRepository<AgriMoreTimeZone>();
        }

        #endregion

        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the country repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Country> GetCountryRepository()
        {
            return CreateRepository<Country>();
        }


        /// <summary>
        /// Gets the package type category repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackageTypeCategory> GetPackageTypeCategoryRepository()
        {
            return CreateRepository<PackageTypeCategory>();
        }
        /// <summary>
        /// Gets the package type category repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackageTypeSubCategory> GetPackageTypeSubCategoryRepository()
        {
            return CreateRepository<PackageTypeSubCategory>();
        }

        /// <summary>
        /// Gets the packing material repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackingMaterial> GetPackingMaterialRepository()
        {
            return CreateRepository<PackingMaterial>();
        }

        /// <summary>
        /// Gets the unit of measurement repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<UnitOfMeasurement> GetUnitOfMeasurementRepository()
        {
            return CreateRepository<UnitOfMeasurement>();
        }

        /// <summary>
        /// Gets the Property repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Property> GetPropertyRepository()
        {
            return CreateRepository<Property>();
        }

        /// <summary>
        /// Gets the Chain Entity Property repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ChainEntityProperty> GetChainEntityPropertyRepository()
        {
            return CreateRepository<ChainEntityProperty>();
        }

        /// <summary>
        /// Gets the ProductGroup repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductGroup> GetProductGroupRepository()
        {
            return CreateRepository<ProductGroup>();
        }

        /// <summary>
        /// Gets the species repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Species> GetSpeciesRepository()
        {
            return CreateRepository<Species>();
        }

        /// <summary>
        /// Gets the Product Attribute Group repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductAttributeGroup> GetProductAttributeGroupRepository()
        {
            return CreateRepository<ProductAttributeGroup>();
        }

        /// <summary>
        /// Gets the species repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductAttribute> GetProductAttributeRepository()
        {
            return CreateRepository<ProductAttribute>();
        }

        /// <summary>
        /// Gets ProdType repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProdType> GetProdTypeRepository()
        {
            return CreateRepository<ProdType>();
        }

        /// <summary>
        /// Gets color repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Color> GetColorRepository()
        {
            return CreateRepository<Color>();
        }

        /// <summary>
        /// Gets category type repository
        /// </summary>
        /// <returns></returns>
        public IRepository<CategoryType> GetCategoryTypeRepository()
        {
            return CreateRepository<CategoryType>();
        }

        /// <summary>
        /// Gets category repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Category> GetCategoryRepository()
        {
            return CreateRepository<Category>();
        }

        ///// <summary>
        ///// Gets Species Color CategoryType repository
        ///// </summary>
        ///// <returns></returns>
        //public IRepository<SpeciesColorCategoryType> GetSpeciesColorCategoryTypeRepository()
        //{
        //    return CreateRepository<SpeciesColorCategoryType>();
        //}

        /// <summary>
        /// Gets Committed Relationship repository
        /// </summary>
        /// <returns></returns>
        public IRepository<CommittedRelationship> GetCommittedRelationshipRepository()
        {
            return CreateRepository<CommittedRelationship>();
        }

        /// <summary>
        /// Gets Committed Relationship Period repository
        /// </summary>
        /// <returns></returns>
        public IRepository<CommittedRelationshipPeriod> GetCommittedRelationshipPeriodRepository()
        {
            return CreateRepository<CommittedRelationshipPeriod>();
        }

        /// <summary>
        /// Gets Prod Committed Relationship Info repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProdCommittedRelationshipInfo> GetProdCommittedRelationshipInfoRepository()
        {
            return CreateRepository<ProdCommittedRelationshipInfo>();
        }

        /// <summary>
        /// Gets Prod Buyer Received Info repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProdBuyerReceivedInfo> GetProdBuyerReceivedInfoRepository()
        {
            return CreateRepository<ProdBuyerReceivedInfo>();
        }

        /// <summary>
        /// Gets Packaging Buyer Received Info repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PackagingBuyerReceivedInfo> GetPackagingBuyerReceivedInfoRepository()
        {
            return CreateRepository<PackagingBuyerReceivedInfo>();
        }

        /// <summary>
        /// Gets Shipment Item repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ShipmentItem> GetShipmentItemRepository()
        {
            return CreateRepository<ShipmentItem>();
        }

        /// <summary>
        /// Gets Shipment List repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ShipmentList> GetShipmentListRepository()
        {
            return CreateRepository<ShipmentList>();
        }

        /// <summary>
        /// Gets Shipment Item for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ShipmentItem4CompositeProd> GetShipmentItem4CompositeProdRepository()
        {
            return CreateRepository<ShipmentItem4CompositeProd>();
        }

        /// <summary>
        /// Gets Shipment List for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ShipmentList4CompositeProd> GetShipmentList4CompositeProdRepository()
        {
            return CreateRepository<ShipmentList4CompositeProd>();
        }

        /// <summary>
        /// Gets CategoryType Category repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductRelationship> GetProductRelationshipRepository()
        {
            return CreateRepository<ProductRelationship>();
        }

        /// <summary>
        /// Gets Harvest Day repository
        /// </summary>
        /// <returns></returns>
        public IRepository<DefaultFilterPSFS> GetDefaultFilterPSFSRepository()
        {
            return CreateRepository<DefaultFilterPSFS>();
        }

        /// <summary>
        /// Gets Harvest Day repository
        /// </summary>
        /// <returns></returns>
        public IRepository<HarvestDay> GetHarvestDayRepository()
        {
            return CreateRepository<HarvestDay>();
        }

        /// <summary>
        /// Gets Composite Product Favourite repository
        /// </summary>
        /// <returns></returns>
        public IRepository<CompositeProductFavourite> GetCompositeProductFavouriteRepository()
        {
            return CreateRepository<CompositeProductFavourite>();
        }

        /// <summary>
        /// Gets Product Favourites repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductFavourites> GetProductFavouritesRepository()
        {
            return CreateRepository<ProductFavourites>();
        }

        /// <summary>
        /// Gets Products for Composite Product Favourite repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Products4CompositeProductFavourite> GetProducts4CompositeProductFavouriteRepository()
        {
            return CreateRepository<Products4CompositeProductFavourite>();
        }

        /// <summary>
        /// Gets Packaging Define Org
        /// </summary>
        /// <returns></returns>
        public IRepository<PackagingDefineOrg> GetPackagingDefineOrgRepository()
        {
            return CreateRepository<PackagingDefineOrg>();
        }

        /// <summary>
        /// Gets Packaging Define Org
        /// </summary>
        /// <returns></returns>
        public IRepository<AddOnDefineOrg> GetAddOnDefineOrgRepository()
        {
            return CreateRepository<AddOnDefineOrg>();
        }

        /// <summary>
        /// Gets Logging
        /// </summary>
        /// <returns></returns>
        public IRepository<Domain.Logging> GetLoggingRepository()
        {
            return CreateRepository<Domain.Logging>();
        }

        /// <summary>
        /// Gets product supply forecast repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductSupplyForecast> GetProductSuppyForecastRepository()
        {
            return CreateRepository<ProductSupplyForecast>();
        }

        /// <summary>
        /// Gets Composite Product Supply repository
        /// </summary>
        /// <returns></returns>
        public IRepository<CompositeProductSupply> GetCompositeProductSupplyRepository()
        {
            return CreateRepository<CompositeProductSupply>();
        }

        /// <summary>
        /// Gets Desired Amount repository
        /// </summary>
        /// <returns></returns>
        public IRepository<DesiredAmount> GetDesiredAmountRepository()
        {
            return CreateRepository<DesiredAmount>();
        }

        /// <summary>
        /// Gets Desired Amount Queue repository
        /// </summary>
        /// <returns></returns>
        public IRepository<DesiredAmountQueue> GetDesiredAmountQueueRepository()
        {
            return CreateRepository<DesiredAmountQueue>();
        }

        /// <summary>
        /// Gets Specific Demand repository
        /// </summary>
        /// <returns></returns>
        public IRepository<SpecificDemand> GetSpecificDemandRepository()
        {
            return CreateRepository<SpecificDemand>();
        }

        /// <summary>
        /// Gets Audit Trail repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AuditTrail> GetAuditTrailRepository()
        {
            return CreateRepository<AuditTrail>();
        }

        /// <summary>
        /// Gets Alert Message repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AlertMessage> GetAlertMessageRepository()
        {
            return CreateRepository<AlertMessage>();
        }

        /// <summary>
        /// Gets Alert Message repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Invoicing> GetInvoicingRepository()
        {
            return CreateRepository<Invoicing>();
        }

        /// <summary>
        /// Gets Invoicing Correction repository
        /// </summary>
        /// <returns></returns>
        public IRepository<InvoicingCorrection> GetInvoicingCorrectionRepository()
        {
            return CreateRepository<InvoicingCorrection>();
        }

        /// <summary>
        /// Gets Invoice Charge repository
        /// </summary>
        /// <returns></returns>
        public IRepository<InvoiceCharge> GetInvoiceChargeRepository()
        {
            return CreateRepository<InvoiceCharge>();
        }

        /// <summary>
        /// Gets Invoice Charge Category repository
        /// </summary>
        /// <returns></returns>
        public IRepository<InvoiceChargeCategory> GetInvoiceChargeCategoryRepository()
        {
            return CreateRepository<InvoiceChargeCategory>();
        }

        /// <summary>
        /// Gets Invoice Charge Category repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AddOnCorrection> GetAddOnCorrectionRepository()
        {
            return CreateRepository<AddOnCorrection>();
        }

        /// <summary>
        /// Gets Invoice Charge Category repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PackageCorrection> GetPackageCorrectionRepository()
        {
            return CreateRepository<PackageCorrection>();
        }

        /// <summary>
        /// Gets Invoice Charge Category repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ChargeCorrection> GetChargeCorrectionRepository()
        {
            return CreateRepository<ChargeCorrection>();
        }

        /// <summary>
        /// Gets Vat Setting repository
        /// </summary>
        /// <returns></returns>
        public IRepository<VatSetting> GetVatSettingRepository()
        {
            return CreateRepository<VatSetting>();
        }

        /// <summary>
        /// Gets Email Logger repository
        /// </summary>
        /// <returns></returns>
        public IRepository<EmailLogger> GetEmailLoggerRepository()
        {
            return CreateRepository<EmailLogger>();
        }

        /// <summary>
        /// Gets Update Fix Price Setting repository
        /// </summary>
        /// <returns></returns>
        public IRepository<UpdateFixPriceSetting> GetUpdateFixPriceSettingRepository()
        {
            return CreateRepository<UpdateFixPriceSetting>();
        }

        /// <summary>
        /// Gets Forecast Reminder Define repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ForecastReminderDefine> GetForecastReminderDefineRepository()
        {
            return CreateRepository<ForecastReminderDefine>();
        }

        /// <summary>
        /// Gets Product Alert repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductAlert> GetProductAlertRepository()
        {
            return CreateRepository<ProductAlert>();
        }

        /// <summary>
        /// Gets Bidding MinPrice Setting repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingMinPriceSetting> GetBiddingMinPriceSettingRepository()
        {
            return CreateRepository<BiddingMinPriceSetting>();
        }

        /// <summary>
        /// Gets Bidding Define repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingDefine> GetBiddingDefineRepository()
        {
            return CreateRepository<BiddingDefine>();
        }

        /// <summary>
        /// Gets Dutch Auction Define repository
        /// </summary>
        /// <returns></returns>
        public IRepository<DutchAuctionDefine> GetDutchAuctionDefineRepository()
        {
            return CreateRepository<DutchAuctionDefine>();
        }

        /// <summary>
        /// Gets Dutch Auction for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<DutchAuction4CompositeProduct> GetDutchAuction4CompositeProductRepository()
        {
            return CreateRepository<DutchAuction4CompositeProduct>();
        }

        /// <summary>
        /// Gets Planning Sale repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PlanningSale> GetPlanningSaleRepository()
        {
            return CreateRepository<PlanningSale>();
        }

        /// <summary>
        /// Gets Period Sales Process repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PeriodSalesProcess> GetPeriodSalesProcessRepository()
        {
            return CreateRepository<PeriodSalesProcess>();
        }

        /// <summary>
        /// Gets Period Sales Planning repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PeriodSalesPlanning> GetPeriodSalesPlanningRepository()
        {
            return CreateRepository<PeriodSalesPlanning>();
        }

        /// <summary>
        /// Gets Dutch Auction Won Bid repository
        /// </summary>
        /// <returns></returns>
        public IRepository<DutchAuctionWonBid> GetDutchAuctionWonBidRepository()
        {
            return CreateRepository<DutchAuctionWonBid>();
        }

        /// <summary>
        /// Gets Available For Sale Setting repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AvailableForSaleSetting> GetAvailableForSaleSettingRepository()
        {
            return CreateRepository<AvailableForSaleSetting>();
        }

        /// <summary>
        /// Gets Bidding Process repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingProcess> GetBiddingProcessRepository()
        {
            return CreateRepository<BiddingProcess>();
        }

        /// <summary>
        /// Gets Product Confirmed repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ProductConfirmed> GetProductConfirmedRepository()
        {
            return CreateRepository<ProductConfirmed>();
        }

        /// <summary>
        /// Gets Packing Confirmed repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PackingConfirmed> GetPackingConfirmedRepository()
        {
            return CreateRepository<PackingConfirmed>();
        }

        /// <summary>
        /// Gets Addons Confirmed repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AddonsConfirmed> GetAddonsConfirmedRepository()
        {
            return CreateRepository<AddonsConfirmed>();
        }

        /// <summary>
        /// Gets Addons Confirmed repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PackagingDefine> GetPackagingDefineRepository()
        {
            return CreateRepository<PackagingDefine>();
        }

        /// <summary>
        /// Gets Addons Confirmed repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AddOnsDefine> GetAddOnsDefineRepository()
        {
            return CreateRepository<AddOnsDefine>();
        }

        /// <summary>
        /// Gets Agreement Purchase repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AgreementPurchase> GetAgreementPurchaseRepository()
        {
            return CreateRepository<AgreementPurchase>();
        }

        /// <summary>
        /// Gets Agreement Process for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AgreementProcess4CompositeProduct> GetAgreementProcess4CompositeProductRepository()
        {
            return CreateRepository<AgreementProcess4CompositeProduct>();
        }

        /// <summary>
        /// Gets Agreement Process for Composite Product Buyer Offer repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AgreementProcess4CompositeProductBuyerOffer> GetAgreementProcess4CompositeProductBuyerOfferRepository()
        {
            return CreateRepository<AgreementProcess4CompositeProductBuyerOffer>();
        }

        /// <summary>
        /// Gets Agreement Purchase for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AgreementPurchase4CompositeProduct> GetAgreementPurchase4CompositeProductRepository()
        {
            return CreateRepository<AgreementPurchase4CompositeProduct>();
        }

        /// <summary>
        /// Gets Agreement Purchase for Composite Product Seller Offer repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AgreementPurchase4CompositeProductSellerOffer> GetAgreementPurchase4CompositeProductSellerOfferRepository()
        {
            return CreateRepository<AgreementPurchase4CompositeProductSellerOffer>();
        }

        /// <summary>
        /// Gets Agreement Purchase Seller Offer repository
        /// </summary>
        /// <returns></returns>
        public IRepository<AgreementPurchaseSellerOffer> GetAgreementPurchaseSellerOfferRepository()
        {
            return CreateRepository<AgreementPurchaseSellerOffer>();
        }

        /// <summary>
        /// Gets Bidding Process for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingProcess4CompositeProduct> GetBiddingProcess4CompositeProductRepository()
        {
            return CreateRepository<BiddingProcess4CompositeProduct>();
        }

        /// <summary>
        /// Gets Bidding Process for Composite Product Buyer Offer repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingProcess4CompositeProductBuyerOffer> GetBiddingProcess4CompositeProductBuyerOfferRepository()
        {
            return CreateRepository<BiddingProcess4CompositeProductBuyerOffer>();
        }

        /// <summary>
        /// Gets Bidding Purchase repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingPurchase> GetBiddingPurchaseRepository()
        {
            return CreateRepository<BiddingPurchase>();
        }

        /// <summary>
        /// Gets Bidding Purchase for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingPurchase4CompositeProduct> GetBiddingPurchase4CompositeProductRepository()
        {
            return CreateRepository<BiddingPurchase4CompositeProduct>();
        }

        /// <summary>
        /// Gets Bidding Purchase for Composite Product Seller Offer repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingPurchase4CompositeProductSellerOffer> GetBiddingPurchase4CompositeProductSellerOfferRepository()
        {
            return CreateRepository<BiddingPurchase4CompositeProductSellerOffer>();
        }

        /// <summary>
        /// Gets Bidding Purchase Seller Bidded repository
        /// </summary>
        /// <returns></returns>
        public IRepository<BiddingPurchaseSellerBidded> GetBiddingPurchaseSellerBiddedRepository()
        {
            return CreateRepository<BiddingPurchaseSellerBidded>();
        }

        /// <summary>
        /// Gets Reverse Auction repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ReverseAuction> GetReverseAuctionRepository()
        {
            return CreateRepository<ReverseAuction>();
        }

        /// <summary>
        /// Gets Reverse Auction for Composite Product repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ReverseAuction4CompositeProduct> GetReverseAuction4CompositeProductRepository()
        {
            return CreateRepository<ReverseAuction4CompositeProduct>();
        }

        /// <summary>
        /// Gets Reverse Auction Seller Bidded repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ReverseAuctionSellerBidded> GetReverseAuctionSellerBiddedRepository()
        {
            return CreateRepository<ReverseAuctionSellerBidded>();
        }

        /// <summary>
        /// Gets Planning Purchase repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PlanningPurchase> GetPlanningPurchaseRepository()
        {
            return CreateRepository<PlanningPurchase>();
        }

        /// <summary>
        /// Gets Planning Purchase Process repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PlanningPurchaseProcess> GetPlanningPurchaseProcessRepository()
        {
            return CreateRepository<PlanningPurchaseProcess>();
        }

        /// <summary>
        /// Gets Addons Confirmed repository
        /// </summary>
        /// <returns></returns>
        public IRepository<PackagingAddOns> GetPackagingAddOnsRepository()
        {
            return CreateRepository<PackagingAddOns>();
        }

        /// <summary>
        /// Gets Article Code repository
        /// </summary>
        /// <returns></returns>
        public IRepository<ArticleCode> GetArticleCodeRepository()
        {
            return CreateRepository<ArticleCode>();
        }

        /// <summary>
        /// Gets Packaging repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Packaging> GetPackagingRepository()
        {
            return CreateRepository<Packaging>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<BusinessType, string> GetBusinessTypeRepository()
        {
            return CreateRepository<BusinessType, string>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<BaseOrganization, string> GetBaseOrganizationRepository()
        {
            return CreateRepository<BaseOrganization, string>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<BaseOrganizationLang, BaseOrganizationLang.BaseOrgLangID> GetBaseOrganizationLangRepository()
        {
            return CreateRepository<BaseOrganizationLang, BaseOrganizationLang.BaseOrgLangID>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<BaseGroupOfOrganization, BaseGroupOfOrganization.BaseGoOID> GetBaseGroupOfOrganizationRepository()
        {
            return CreateRepository<BaseGroupOfOrganization, BaseGroupOfOrganization.BaseGoOID>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<Organization, string> GetOrganizationRepository()
        {
            return CreateRepository<Organization, string>();
        }

        /// <summary>
        /// Gets the CustomDefine repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<CustomDefine> GetCustomDefineRepository()
        {
            return CreateRepository<CustomDefine>();
        }


        #endregion

        /// <summary>
        /// Gets the PackageTypeSubCategoryLang repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackageTypeSubCategoryLang> GetPackageTypeSubCategoryLangRepository()
        {
            return CreateRepository<PackageTypeSubCategoryLang>();
        }

        /// <summary>
        /// Gets the PackageTypeSubCategoryLang repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<FinalCostCodes> GetFinalCostCodesRepository()
        {
            return CreateRepository<FinalCostCodes>();
        }

        /// <summary>
        /// Gets the ForecastReminderEmailStructure repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ForecastReminderEmailStructure> GetForecastReminderEmailStructureRepository()
        {
            return CreateRepository<ForecastReminderEmailStructure>();
        }

        /// <summary>
        /// Gets the PriceUpdateReminderEmailStructure repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PriceUpdateReminderEmailStructure> GetPriceUpdateReminderEmailStructureRepository()
        {
            return CreateRepository<PriceUpdateReminderEmailStructure>();
        }

        /// <summary>
        /// Gets the PriceUpdateReminderDefineEmail repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PriceUpdateReminderDefineEmail> GetPriceUpdateReminderDefineEmailRepository()
        {
            return CreateRepository<PriceUpdateReminderDefineEmail>();
        }

        /// <summary>
        /// Gets the PriceUpdateReminderDefine repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PriceUpdateReminderDefine> GetPriceUpdateReminderDefineRepository()
        {
            return CreateRepository<PriceUpdateReminderDefine>();
        }

        public IRepository<Invoice> GetInvoiceRepository()
        {
            return CreateRepository<Invoice>();
        }


        public IRepository<ParentProductGroupInfo> GetParentProductGroupInfoRepository()
        {
            return CreateRepository<ParentProductGroupInfo>();
        }

        public IRepository<PackagingMaterial> GetPackagingMaterialRepository()
        {
            return CreateRepository<PackagingMaterial>();
        }


        public IRepository<GroupOrganizations> GetGroupOrganizationsRepository()
        {
            return CreateRepository<GroupOrganizations>();
        }


        public IRepository<ParentPackageTypeCategory> GetParentPackageTypeCategoryRepository()
        {
            return CreateRepository<ParentPackageTypeCategory>();
        }


        public IRepository<ProductInfo> GetProductInfoRepository()
        {
            return CreateRepository<ProductInfo>();
        }

        public IRepository<TreatmentCategory> GetTreatmentCategoryRepository()
        {
            return CreateRepository<TreatmentCategory>();
        }

        public IRepository<ExposureDefine> GetExposureDefineRepository()
        {
            return CreateRepository<ExposureDefine>();
        }


        public IRepository<DecompositionCategory> GetDecompositionCategoryRepository()
        {
            return CreateRepository<DecompositionCategory>();
        }


        public IRepository<DecompositionType> GetDecompositionTypeRepository()
        {
            return CreateRepository<DecompositionType>();
        }


        public IRepository<ProductTreatmentInvoice> GetProductTreatmentInvoiceRepository()
        {
            return CreateRepository<ProductTreatmentInvoice>();
        }


        public IRepository<InvoiceProduct> GetInvoiceProductRepository()
        {
            return CreateRepository<InvoiceProduct>();
        }

        public IRepository<QualityDocumentUpload> GetQualityDocumentUploadRepository()
        {
            return CreateRepository<QualityDocumentUpload>();
        }       

        public IRepository<DecomposeKeyFigure> GetDecomposeKeyFigureRepository()
        {
            return CreateRepository<DecomposeKeyFigure>();
        }

        public IRepository<KeyFigure> GetKeyFigureRepository()
        {
            return CreateRepository<KeyFigure>();
        }

        public IRepository<SubAdministrativeGroup> GetSubAdministrativeGroupRepository()
        {
            return CreateRepository<SubAdministrativeGroup>();
        }


        public IRepository<CategoryInfo> GetCategoryInfoRepository()
        {
            return CreateRepository<CategoryInfo>();
        }
    }
}