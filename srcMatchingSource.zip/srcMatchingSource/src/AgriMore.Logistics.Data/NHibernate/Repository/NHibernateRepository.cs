using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using log4net;
using NHibernate;
using ObjectNotFoundException = AgriMore.Logistics.Common.Exception.ObjectNotFoundException;

namespace AgriMore.Logistics.Data.NHibernate.Repository
{
    /// <summary>
    /// Represents the NHibernateRepository class.
    /// </summary>
    /// <typeparam name="TElement">The type of the element.</typeparam>
    public class NHibernateRepository<TElement> : NHibernateRepository<TElement, long>, IRepository<TElement> where TElement : class, IIdentifyable, IIdentifyable<long>
    {
    }

    /// <summary>
    /// Represents the NHibernateRepository class.
    /// </summary>
    /// <typeparam name="TElement">The type of the element.</typeparam>
    /// <typeparam name="IdType">id type.</typeparam>
    public class NHibernateRepository<TElement, IdType> : IRepository<TElement, IdType> where TElement : class, IIdentifyable<IdType>
    {
        private readonly ILog log = LogManager.GetLogger("NHibernate.SQL");

        /// <summary>
        /// Gets the Element by a unique string id. the id is the same value as the return value of <code>ToString()</code>
        /// on the object.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        public TElement GetOne(string id)
        {
            log.Info("GetOne(string id)");
            if (id == null)
            {
                throw new ArgumentNullException("id");
            }
            if (id.Trim() == string.Empty)
            {
                throw new ArgumentException("id parameter cannot be empty");
            }

            if (typeof(IdType) == typeof(string))
            {
                try
                {
                    return new NHibernateDao<string>().Get<TElement>(id);
                }
                catch (ObjectNotFoundException)
                {
                    return null;
                }
            }

            foreach (TElement element in AsCollection())
            {
                if (element.Uid.ToString().Equals(id) || element.ToString().Equals(id))
                {
                    return element;
                }
            }
            return null;
        }

        /// <summary>
        /// Gets the Element by unique id. This Id is returned by the <code>Add(TElement element)</code> method.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        public TElement GetOne(IdType uid)
        {
            log.Info("GetOne(long uid)");
            try
            {
                return new NHibernateDao<IdType>().Get<TElement>(uid);
            }
            catch (ObjectNotFoundException)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets the Element by unique id. This Id is returned by the <code>Add(TElement element)</code> method.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        public TElement GetOneElement(IdType uid)
        {
            log.Info("GetOne(long uid)");
            try
            {
                return new NHibernateDao<IdType>().Get<TElement>(uid);
            }
            catch (ObjectNotFoundException)
            {
                return null;
            }
        }

        /// <summary>
        /// Adds the specified element. returns the uid assigned internally in the repository.
        /// This method assigns the id to the element. The uid of the element is not allowed to be != 0,
        /// since then it would have been added already.
        /// <example>
        ///   Shipment shipment = new Shipment();
        ///   ...
        ///   long uid = repository.Add(shipment);
        /// </example>
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>the unique internal id. this id can be used in <code>GetOne(long uid)</code></returns>
        public virtual IdType Add(TElement element)
        {
            log.Info("Add(TElement element)");

            if (element == null) throw new ArgumentNullException("element");


            //TODO: Is not correct string.
            if ("Int64".Equals(typeof(IdType).Name) && !default(IdType).Equals(element.Uid)) throw new ArgumentException("uid of element is already assigned, cannot add element");

            // TODO: ?
            //if (!0.Equals(element.Uid))
            //{
            //    throw new ArgumentException("uid of element is already assigned, cannot add element");
            //}

            try
            {
                if (!"Int64".Equals(typeof(IdType).Name))
                    new NHibernateDao<IdType>().Add(element);
                else
                    new NHibernateDao<IdType>().Save(element);
                return element.Uid;
            }
            catch (NonUniqueObjectException e)
            {
                throw new ArgumentException("Unique constraint violation", e);
            }
        }

        /// <summary>
        /// Returns all elements as a collection
        /// </summary>
        /// <returns></returns>
        public ICollection<TElement> AsCollection()
        {
            log.Info("AsCollection()");
            ICollection collection = new NHibernateDao().GetAll<TElement>();
            return ListHandler.ConvertToGenericList<TElement>(collection);
        }

        /// <summary>
        /// Returns all elements as a collection
        /// </summary>
        /// <returns></returns>
        public ICollection<TElement> AsCollectionNotCache()
        {
            log.Info("AsCollection()");
            ICollection collection = new NHibernateDao().GetAll<TElement>(false);
            return ListHandler.ConvertToGenericList<TElement>(collection);
        }

        /// <summary>
        /// Determines whether this repository contains the element. 
        /// <code>TElement.Equals(object obj)</code> can be used to determine this. You need to implement <code>Equals(object obj)</code>
        ///  on the TElement type.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this repository contains the element; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(TElement element)
        {
            log.Info("Contains(TElement element)");
            return AsCollection().Contains(element);
        }

        /// <summary>
        /// Gets One element using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>The element, or null if the element could not be found.</returns>
        public TElement GetOne(ISpecification<TElement, IdType> criteria)
        {
            log.Info("GetOne(ISpecification<TElement> criteria)");
            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }

            IQuery query = GetQuery(criteria);
            if (query != null)
            {
                Debug.WriteLine("Using HQL for " + criteria.GetType().Name);
                query.SetMaxResults(1);
                IList list = query.List();
                foreach (object o in list)
                {
                    return o as TElement;
                }

                return null;
            }

            IDictionary<IdType, TElement> mapIds = new Dictionary<IdType, TElement>();
            foreach (TElement element in AsCollection())
            {
                mapIds.Add(element.Uid, element);
            }

            DictionarySpecificationExecutor<IdType, TElement> exec =
                new DictionarySpecificationExecutor<IdType, TElement>(mapIds);
            return exec.GetOne(criteria);
        }

        /// <summary>
        /// Find elements of TElement by specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>A collection of elements, or an empty collection if no elements where found for the criteria</returns>
        public ICollection<TElement> Find(ISpecification<TElement, IdType> criteria)
        {
            log.Info("Find(ISpecification<TElement> criteria)");

            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }
            try
            {
                IQuery query = GetQuery(criteria);
                if (query != null)
                {
                    Debug.WriteLine("Using HQL for " + criteria.GetType().Name);

                    return ListHandler.ConvertToGenericList<TElement>(query.List());
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            IDictionary<IdType, TElement> mapIds = new Dictionary<IdType, TElement>();
            foreach (TElement element in AsCollection())
            {
                mapIds.Add(element.Uid, element);
            }

            DictionarySpecificationExecutor<IdType, TElement> exec =
                new DictionarySpecificationExecutor<IdType, TElement>(mapIds);
            return exec.Find(criteria);
        }

        /// <summary>
        /// Find elements of TElement by specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>A collection of elements, or an empty collection if no elements where found for the criteria</returns>
        public ICollection<TElement> Find(ISpecification<TElement, IdType> criteria, int skip, int take)
        {
            log.Info("Find(ISpecification<TElement> criteria)");

            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }
            try
            {
                IQuery query = GetQuery(criteria);
                if (query != null)
                {
                    Debug.WriteLine("Using HQL for " + criteria.GetType().Name);

                    IList list = query.SetFirstResult(skip).SetMaxResults(take).List();

                    //return ListHandler.ConvertToUniqueGenericList<TElement>(list);
                    return ListHandler.ConvertToGenericList<TElement>(list);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            IDictionary<IdType, TElement> mapIds = new Dictionary<IdType, TElement>();
            foreach (TElement element in AsCollection())
            {
                mapIds.Add(element.Uid, element);
            }

            DictionarySpecificationExecutor<IdType, TElement> exec =
                new DictionarySpecificationExecutor<IdType, TElement>(mapIds);
            return exec.Find(criteria);
        }

        public IList FindByHsql(string hslq)
        {
            IQuery query = new NHibernateDao().NHibernateSession.CreateQuery(hslq);

            return query.List();
        }

        public ICollection<TElement> Find(IdType[] uids)
        {
            log.Info("Find(params IdType[] uids)");

            return new NHibernateDao<IdType>().GetAll<TElement>(uids).Cast<TElement>().ToList();
        }

        private IQuery GetQuery(ISpecification<TElement, IdType> criteria)
        {
            log.Info(criteria.GetType().Name);

            IQuery query = null;

            Query criteriaQuery = criteria.Query;
            if (criteriaQuery != null)
            {
                query =
                    new NHibernateDao().NHibernateSession.CreateQuery(criteriaQuery.QueryString);
                foreach (QueryParameter queryParameter in criteriaQuery.QueryParameters)
                {
                    object queryParameterValue = queryParameter.Value;
                    if (queryParameterValue is IIdentifyable)
                    {
                        query.SetEntity(queryParameter.Name, queryParameterValue);
                    }

                    else if (queryParameterValue.GetType() == typeof(string))
                    {
                        query.SetString(queryParameter.Name, (string)queryParameterValue);
                    }

                    else if (queryParameterValue.GetType() == typeof(DateTime))
                    {
                        query.SetDateTime(queryParameter.Name, (DateTime)queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(DateTime[]))
                    {
                        query.SetParameterList(queryParameter.Name, (DateTime[])queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(bool))
                    {
                        query.SetBoolean(queryParameter.Name, (bool)queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(int))
                    {
                        query.SetInt64(queryParameter.Name, (int)queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(long))
                    {
                        query.SetInt64(queryParameter.Name, (long)queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(decimal))
                    {
                        query.SetDecimal(queryParameter.Name, (decimal)queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(string[]))
                    {
                        query.SetParameterList(queryParameter.Name, (string[])queryParameterValue);
                    }
                    else if (queryParameterValue.GetType() == typeof(long[]))
                    {
                        query.SetParameterList(queryParameter.Name, (long[])queryParameterValue);
                    }
                    else
                    {
                        throw new NotSupportedException("The QueryParameter value type '" +
                                                        queryParameterValue.GetType().Name + "' is not supported yet.");
                    }
                }

                if (criteriaQuery.IsCacheAble)
                {
                    query.SetCacheable(true);
                }

                if (criteriaQuery.IsPaging)
                {
                    query.SetMaxResults(criteriaQuery.MaxResults);
                    query.SetFirstResult(criteriaQuery.FirstResult);
                }
            }

            return query;
        }

        /// <summary>
        /// Stores the specified element. Equals needs to be implemented on the element.
        /// Equals is used to see if the element needs to be updated or added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>The UID of the element.</returns>
        public virtual void Store(TElement element)
        {
            log.Info("Store(TElement element)");

            new NHibernateDao().Save(element);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql"></param>
        public void ExecuteSql(string sql)
        {
            new NHibernateDao().ExecuteSql(sql);
        }

        /// <summary>
        /// Forces the underlying database to reflect the changes in order to get the generated UId's of objects and the
        /// assiated objects.
        /// </summary>
        public void Flush()
        {
            log.Info("Flush() - start");

            NHibernateDao nHibernateDao = new NHibernateDao();
            nHibernateDao.NHibernateSession.Flush();

            

            log.Info("Flush() - end");
        }

        public void Evict(TElement element)
        {
            NHibernateDao nHibernateDao = new NHibernateDao();
            nHibernateDao.NHibernateSession.Evict(element);

        }

        /// <summary>
        /// Forces the underlying database to reflect the changes in order to get the generated UId's of objects and the
        /// assiated objects.
        /// </summary>
        public void Refresh(TElement element)
        {
            log.Info("Refresh() - start");

            NHibernateDao nHibernateDao = new NHibernateDao();
            nHibernateDao.NHibernateSession.Refresh(element);

            log.Info("Refresh() - end");
        }

        /// <summary>
        /// Removes the specified element. Equals needs to be implemented on the element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>true if the element could be removed, false if not</returns>
        public bool Remove(TElement element)
        {
            log.Info("Remove(TElement element)");

            new NHibernateDao<IdType>().Delete(element);
            return true;
        }

        /// <summary>
        /// Removes the elements using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>collection if uids of the items removed</returns>
        public void Remove(ISpecification<TElement, IdType> criteria)
        {
            log.Info("Remove(ISpecification<TElement> criteria)");
            throw new NotImplementedException();
        }

        /// <summary>
        /// Counts the elements using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>the amount of elements that match the criteria</returns>
        public long Count(ISpecification<TElement, IdType> criteria)
        {
            log.Info("Count(ISpecification<TElement> criteria)");

            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }
            try
            {
                IQuery query = GetQuery(criteria);
                if (query != null)
                {
                    Debug.WriteLine("Using HQL for " + criteria.GetType().Name);

                    object result = query.UniqueResult();

                    return Convert.ToInt64(result);
                    //return ListHandler.ConvertToUniqueGenericList<TElement>(list);
                    //return ListHandler.ConvertToGenericList<TElement>(list);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            log.Info("Count(ISpecification<TElement> criteria)");
            IDictionary<IdType, TElement> mapIds = new Dictionary<IdType, TElement>();
            foreach (TElement element in AsCollection())
            {
                mapIds.Add(element.Uid, element);
            }
            return mapIds.Count;
        }

        /// <summary>
        /// Counts the elements.
        /// </summary>
        /// <returns>The number of elements</returns>
        public long Count()
        {
            log.Info("Count()");
            ICollection collection = new NHibernateDao().GetAll<TElement>();
            return collection.Count;
        }

        ///<summary>
        ///Returns an enumerator that iterates through the collection.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Collections.Generic.IEnumerator`1"></see> that can be used to iterate through the collection.
        ///</returns>
        ///<filterpriority>1</filterpriority>
        public IEnumerator<TElement> GetEnumerator()
        {
            log.Info("GetEnumerator()");
            ICollection collection = new NHibernateDao().GetAll<TElement>();
            foreach (TElement element in collection)
            {
                yield return element;
            }
        }

        ///<summary>
        ///Returns an enumerator that iterates through a collection.
        ///</summary>
        ///
        ///<returns>
        ///An <see cref="T:System.Collections.IEnumerator"></see> object that can be used to iterate through the collection.
        ///</returns>
        ///<filterpriority>2</filterpriority>
        IEnumerator IEnumerable.GetEnumerator()
        {
            log.Info("IEnumerable.GetEnumerator()");
            return GetEnumerator();
        }
    }
}