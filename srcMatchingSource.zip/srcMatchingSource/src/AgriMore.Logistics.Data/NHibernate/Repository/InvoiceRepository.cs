﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Data.NHibernate.Repository
{
    public class InvoiceRepository : NHibernateRepository<Invoice>, IInvoiceRepository
    {
        public Invoice New(Invoice element)
        {
            var invoice = (Invoice)element.Clone();

            foreach (var product in element.Products)
            {
                var invoiceProduct = (InvoiceProduct)product.Clone();

                invoice.AddProduct(invoiceProduct);
            }

            foreach (var charge in element.Charges)
            {
                var invoiceCharge = (InvoiceCharge1)charge.Clone();

                invoice.AddCharge(invoiceCharge);
            }

            return invoice;
        }

        public override long Add(Invoice element)
        {
            element.Latest = true;

            return base.Add(element);
        }

        public override void Store(Invoice element)
        {
            if (element.ParentUid > 0)
            {
                Invoice invoice = base.GetOne(element.ParentUid);
                invoice.Latest = false;
            }

            element.Latest = true;

            base.Store(element);
        }

        public ICollection<Invoice> Find(IEnumerable<string> orgIds, DateTime dateTime, InvoiceType invoiceType)
        {
            var criteria = new InvoiceSpecification(orgIds, dateTime, invoiceType);

            return Find(criteria);
        }
    }
}
