using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain.Transaction;
using log4net;

namespace AgriMore.Logistics.Data.NHibernate.Transaction
{
    /// <summary>
    /// Represents the NHibernateTransactionManager class.
    /// </summary>
    public class NHibernateTransactionManager : ITransactionManager
    {
        private readonly ILog log = LogManager.GetLogger("NHibernate.SQL");

        #region ITransactionManager Members

        /// <summary>
        /// Begins the transaction.
        /// </summary>
        public void BeginTransaction()
        {
            log.Info("BeginTransaction()");
            SessionFacade.BeginTransaction();
        }

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        public void CommitTransaction()
        {
            log.Info("CommitTransaction()");
            SessionFacade.CommitTransaction();
        }

        /// <summary>
        /// Rollbacks the transaction.
        /// </summary>
        public void RollbackTransaction()
        {
            log.Info("RollbackTransaction()");
            SessionFacade.RollbackTransaction();
        }

        #endregion
    }
}