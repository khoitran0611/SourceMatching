using System.Configuration;
using NHibernateCfgConfiguration = NHibernate.Cfg.Configuration;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the NHibernateConfiguration class.
    /// </summary>
    public static class NHibernateConfiguration
    {
        private const string NHIBERNATEASSEMBLY = "NHibernateAssembly";
        //private static volatile NHibernateCfgConfiguration config;
        //private static object syncRoot = new object();
        /// <summary>
        /// Gets the configuration.
        /// </summary>
        /// <returns></returns>
        public static NHibernateCfgConfiguration GetConfiguration()
        {
            NHibernateCfgConfiguration config = new NHibernateCfgConfiguration();

            //string[] nhibernateAssemblies = ConfigurationManager.AppSettings.GetValues(NHIBERNATEASSEMBLY);
            //foreach (string s in nhibernateAssemblies)
            //{
            //    config.AddAssembly(s);
            //}

            string nhibernateAssemblies = ConfigurationManager.AppSettings[NHIBERNATEASSEMBLY];
            config.AddAssembly(nhibernateAssemblies);
            return config;

            //if (config == null)
            //{
            //    lock (syncRoot)
            //    {
            //        if (config == null)
            //        {
            //            config = new NHibernateCfgConfiguration();
            //            string nhibernateAssemblies = ConfigurationManager.AppSettings[NHIBERNATEASSEMBLY];
            //            config.AddAssembly(nhibernateAssemblies);
            //        }
            //    }
            //}
            //return config;
        }
    }
}
