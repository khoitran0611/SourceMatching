using System;
using System.Collections;
using System.Linq;
using System.Diagnostics.CodeAnalysis;
using NH = NHibernate;
using NHibernateObjectNotFoundException = NHibernate.ObjectNotFoundException;
using NHibernateAdoException = NHibernate.ADOException;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the NHibernateDao class.
    /// </summary>
    public class NHibernateDao : NHibernateDao<long>
    {
    }

    /// <summary>
    /// Represents the NHibernateDao class.
    /// </summary>
    public class NHibernateDao<IdType>
    {
        private bool initiatedTransaction;

        /// <summary>
        /// Represents the Action enumeration.
        /// </summary>
        protected enum Action
        {
            /// <summary>
            /// Save
            /// </summary>
            Save,
            /// <summary>
            /// Update
            /// </summary>
            Update
        }

        /// <summary>
        /// Gets the N hibernate session.
        /// </summary>
        /// <value>Get access to the NHibernate session in the NHibernateHttpModule class.</value>
        public NH.ISession NHibernateSession
        {
            get
            {
                return NHibernateHttpModule.GetSession;
            }
        }

        /// <summary>
        /// Gets the object of type T with the id.
        /// If the item cannot be found. Translate the exception to one the caller can work with.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public T Get<T>(IdType id)
        {
            try
            {
                return (T)NHibernateSession.Load(typeof(T), id);
            }
            catch (NH.HibernateException e)
            {
                throw DataExceptionTranslator.GetException(e);
            }
        }

        /// <summary>
        /// Gets all objects of type T.
        /// </summary>
        /// <returns></returns>
        [
            SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate"),
                SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public ICollection GetAll<T>()
        {
            return NHibernateSession.CreateCriteria(typeof(T)).SetCacheable(true).List();
        }

        /// <summary>
        /// Gets all objects of type T.
        /// </summary>
        /// <returns></returns>
        [
            SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate"),
                SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public ICollection GetAll<T>(bool setCache)
        {
            return NHibernateSession.CreateCriteria(typeof(T)).SetCacheable(setCache).List();
        }

        public ICollection GetAll<T>(IdType[] ids)
        {
            var criteria = NHibernateSession.CreateCriteria(typeof(T));
            criteria.Add(new NH.Expression.InExpression("Uid", ids.Cast<object>().ToArray()));
            return criteria.List();
        }

        /// <summary>
        /// Save the specified object.
        /// </summary>
        /// <param name="transient">The transient.</param>
        public void Save<T>(T transient)
        {
            try
            {
                if (!NHibernateHttpModule.TransactionPresent)
                {
                    NHibernateHttpModule.BeginTransaction();
                    initiatedTransaction = true;
                }

                NHibernateSession.SaveOrUpdate(transient);

                if (NHibernateHttpModule.TransactionPresent)
                {
                    if (initiatedTransaction)
                    {
                        NHibernateHttpModule.CommitTransaction();
                        initiatedTransaction = false;
                    }
                }
            }
            catch (NH.HibernateException e)
            {
                if (NHibernateHttpModule.SessionPresent)
                {
                    if (NHibernateHttpModule.TransactionPresent)
                    {
                        NHibernateHttpModule.RollbackTransaction();
                    }
                }
                throw DataExceptionTranslator.GetException(e);
            }
        }

        /// <summary>
        /// Save the specified object.
        /// </summary>
        /// <param name="transient">The transient.</param>
        public void Add<T>(T transient)
        {
            try
            {
                if (!NHibernateHttpModule.TransactionPresent)
                {
                    NHibernateHttpModule.BeginTransaction();
                    initiatedTransaction = true;
                }

                NHibernateSession.Save(transient);

                if (NHibernateHttpModule.TransactionPresent)
                {
                    if (initiatedTransaction)
                    {
                        NHibernateHttpModule.CommitTransaction();
                        initiatedTransaction = false;
                    }
                }
            }
            catch (NH.HibernateException e)
            {
                if (NHibernateHttpModule.SessionPresent)
                {
                    if (NHibernateHttpModule.TransactionPresent)
                    {
                        NHibernateHttpModule.RollbackTransaction();
                    }
                }
                throw DataExceptionTranslator.GetException(e);
            }
        }

        ///<summary>
        ///</summary>
        ///<param name="sql"></param>
        public void ExecuteSql(string sql)
        {
            System.Data.IDbCommand cmd = NHibernateSession.Connection.CreateCommand();
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Deletes the specified entity.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity">The entity.</param>
        public void Delete<T>(T entity)
        {
            try
            {
                //NHibernateHttpModule.BeginTransaction();
                if (!NHibernateHttpModule.TransactionPresent)
                {
                    NHibernateHttpModule.BeginTransaction();
                    initiatedTransaction = true;
                }

                NHibernateSession.Delete(entity);

                if (NHibernateHttpModule.TransactionPresent)
                {
                    if (initiatedTransaction)
                    {
                        NHibernateHttpModule.CommitTransaction();
                        initiatedTransaction = false;
                    }
                }
                //NHibernateHttpModule.CommitTransaction();
            }

            catch (NH.HibernateException e)
            {
                if (NHibernateHttpModule.SessionPresent)
                {
                    NHibernateHttpModule.RollbackTransaction();
                }

                throw DataExceptionTranslator.GetException(e);
            }
        }
    }
}