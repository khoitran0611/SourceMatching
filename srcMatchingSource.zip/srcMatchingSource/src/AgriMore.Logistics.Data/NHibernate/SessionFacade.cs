
namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the SessionFacade class.
    /// </summary>
    public sealed class SessionFacade
    {
        private SessionFacade()
        { }

        /// <summary>
        /// Begins the transaction.
        /// </summary>
        public static void BeginTransaction()
        {
            NHibernateHttpModule.BeginTransaction();
        }

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        public static void CommitTransaction()
        {
            NHibernateHttpModule.CommitTransaction();
        }

        /// <summary>
        /// Rolls the transaction back.
        /// </summary>
        public static void RollbackTransaction()
        {
            NHibernateHttpModule.RollbackTransaction();
        }
    }
}
