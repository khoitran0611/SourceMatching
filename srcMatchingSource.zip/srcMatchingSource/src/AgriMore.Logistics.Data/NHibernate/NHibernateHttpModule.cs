using System;
using System.Web;
using AgriMore.Logistics.Data.NHibernate;
using log4net;
using NHibernate;
using NHibernate.Cfg;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Summary description for NHibernateHttpModule.
    /// </summary>
    public class NHibernateHttpModule : IHttpModule
    {
        private static readonly ILog log = LogManager.GetLogger("NHibernate.SQL");

        // this is only used if not running in HttpModule mode
        private static ISessionFactory sessionFactory;

        // this is only used if not running in HttpModule mode
        private static ISession nonHttpContextSession;

        private const string KEY_NHIBERNATE_FACTORY = "NHibernateSessionFactory";
        private const string KEY_NHIBERNATE_SESSION = "NHibernateSession";

        /// <summary>
        /// Gets a value indicating whether a transaction is present.
        /// </summary>
        /// <value><c>true</c> if a transaction is present; otherwise, <c>false</c>.</value>
        public static bool TransactionPresent
        {
            get
            {
                if (SessionPresent)
                {
                    return Session.Transaction != null;
                }
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether [session present].
        /// </summary>
        /// <value><c>true</c> if [session present]; otherwise, <c>false</c>.</value>
        public static bool SessionPresent
        {
            get { return Session != null; }
        }


        /// <summary>
        /// Disposes of the resources (other than memory) used by the module that implements <see cref="T:System.Web.IHttpModule"></see>.
        /// </summary>
        public void Dispose()
        {
            Close();

            if (sessionFactory != null)
            {
                sessionFactory.Close();
            }
        }

        /// <summary>
        /// Gets the session count.
        /// </summary>
        /// <value>The session count.</value>
        public static int SessionCount
        {
            get
            {
                return sessionCount;
            }
        }

        /// <summary>
        /// Closes this instance.
        /// </summary>
        public static void Close()
        {
            if (Session != null)
            {
                sessionCount--;
                Session.Close();
                Session.Dispose();
                Session = null;
            }
        }

        /// <summary>
        /// Flushes this instance.
        /// </summary>
        public static void Flush()
        {
            if (Session != null)
            {
                Session.Flush();
            }
        }

        #region IHttpModule

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public void Init(HttpApplication context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }

            context.EndRequest += new EventHandler(context_EndRequest);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void context_EndRequest(object sender, EventArgs e)
        {
            HttpApplication application = (HttpApplication)sender;

            HttpContext context = application.Context;
            ISession session = context.Items[KEY_NHIBERNATE_SESSION] as ISession;
            if (session != null)
            {
                sessionCount--;
                session.Close();
                session.Dispose();
            }

            context.Items[KEY_NHIBERNATE_SESSION] = null;
        }

        #endregion IHttpModule


        /// <summary>
        /// Creates the session factory.
        /// </summary>
        /// <returns></returns>
        protected static ISessionFactory CreateSessionFactory()
        {
            ISessionFactory factory;
            Configuration config = NHibernateConfiguration.GetConfiguration();

            factory = config.BuildSessionFactory();

            if (factory == null)
            {
                //CentralLogger.Log("Call to Configuration.BuildSessionFactory() returned null.", CentralLogger.LogLevel.Error, "FrameworkLogger");
                throw new InvalidOperationException("Call to Configuration.BuildSessionFactory() returned null.");
            }
            else
            {
                return factory;
            }
        }

        /// <summary>
        /// Gets the current factory.
        /// </summary>
        /// <value>The current factory.</value>
        public static ISessionFactory CurrentFactory
        {
            get
            {
                if (HttpContext.Current == null)
                {
                    // running without an HttpContext (non-web mode)
                    // the nhibernate session is a singleton in the app domain
                    if (sessionFactory != null)
                    {
                        return sessionFactory;
                    }
                    else
                    {
                        sessionFactory = CreateSessionFactory();

                        return sessionFactory;
                    }
                }
                else
                {
                    // running inside of an HttpContext (web mode)
                    // the nhibernate session is a singleton to the http request
                    HttpContext currentContext = HttpContext.Current;

                    ISessionFactory factory = currentContext.Application[KEY_NHIBERNATE_FACTORY] as ISessionFactory;

                    if (factory == null)
                    {
                        factory = CreateSessionFactory();
                        currentContext.Application[KEY_NHIBERNATE_FACTORY] = factory;
                    }

                    return factory;
                }
            }
        }

        /// <summary>
        /// Creates the session.
        /// </summary>
        /// <returns></returns>
        public static ISession CreateSession()
        {
            ISessionFactory factory = CurrentFactory;

            if (factory == null)
            {
                throw new InvalidOperationException("Call to Configuration.BuildSessionFactory() returned null.");
            }

            ISession nHibernateSession = factory.OpenSession();

            if (nHibernateSession == null)
            {
                throw new InvalidOperationException("Call to factory.OpenSession() returned null.");
            }

            return nHibernateSession;
        }

        private static int sessionCount = 0;

        /// <summary>
        /// Gets the get session.
        /// </summary>
        /// <value>The get session.</value>
        internal static ISession GetSession
        {
            get
            {
                if (Session == null)
                {
                    sessionCount++;
                    Session = CreateSession();
                }
                return Session;
            }
        }

        private static ISession Session
        {
            get
            {
                if (HttpContext.Current == null)
                {
                    return nonHttpContextSession;
                }
                else
                {
                    return HttpContext.Current.Items[KEY_NHIBERNATE_SESSION] as ISession;
                }
            }
            set
            {
                if (HttpContext.Current == null)
                {
                    nonHttpContextSession = value;
                }
                else
                {
                    HttpContext.Current.Items[KEY_NHIBERNATE_SESSION] = value;
                }
            }
        }

        /// <summary>
        /// Begins the transaction.
        /// </summary>
        public static void BeginTransaction()
        {
            if ((GetSession.Transaction == null) || (!GetSession.Transaction.WasCommitted && !GetSession.Transaction.WasRolledBack))
            {
                log.Info("NHibernateHttpModule.BeginTransaction");

                GetSession.BeginTransaction();
            }
        }

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        public static void CommitTransaction()
        {
            if (Session != null)
            {
                ITransaction transaction = Session.Transaction;
                if (transaction != null && !transaction.WasCommitted && !transaction.WasRolledBack)
                {
                    log.Info("NHibernateHttpModule.CommitTransaction");
                    transaction.Commit();
                    transaction.Dispose();
                }

                Close();
            }
        }

        /// <summary>
        /// Rollbacks the transaction.
        /// </summary>
        public static void RollbackTransaction()
        {
            if (Session != null)
            {
                ITransaction transaction = Session.Transaction;

                if (transaction != null && !transaction.WasCommitted && !transaction.WasRolledBack)
                {
                    log.Info("NHibernateHttpModule.RollbackTransaction");
                    transaction.Rollback();
                    transaction.Dispose();
                }

                Close();
            }
        }
    }
}