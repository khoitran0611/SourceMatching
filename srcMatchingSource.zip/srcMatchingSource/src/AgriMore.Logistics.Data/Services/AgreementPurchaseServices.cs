﻿using System;
using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class AgreementPurchaseServices : BaseService
    {
        private static readonly object Obj = new object();

        public static AgreementPurchase4CompositeProduct UpdateAgmtPurchase4CompositeProd(AgreementPurchase4CompositeProduct agmtPurchase)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                agmtPurchase.UpdatedAt = DateTime.Now;

                factory.GetAgreementPurchase4CompositeProductRepository().Store(agmtPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return agmtPurchase;
        }

        public static AgreementPurchase4CompositeProduct SaveOrUpdateAgmtPurchase4CompositeProd(AgreementPurchase4CompositeProduct agmtPurchase, IList<AgreementPurchase4CompositeProductPriceDetail> priceDetails,
            string sellerIds, string supplierIds)
        {

            var transactionManager = new TransactionManager();
            try
            {
                if (agmtPurchase.Uid != 0) agmtPurchase.RemoveAllInvitedSeller();
                IList<Organization> lstTradingOrgs = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(sellerIds)).ToList();
                foreach (Organization org in lstTradingOrgs) agmtPurchase.AddInvitedSeller(org);

                if (agmtPurchase.Uid != 0) agmtPurchase.RemoveAllAgreedSupplier();
                IList<Organization> lstSuppliers = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(supplierIds)).ToList();
                foreach (Organization supplier in lstSuppliers) agmtPurchase.AddAgreedSupplier(supplier);

                if (agmtPurchase.Uid != 0) agmtPurchase.RemoveAllPriceDetail();
                foreach (var priceDetail in priceDetails) agmtPurchase.AddPriceDetail(priceDetail);

                transactionManager.BeginTransaction();

                agmtPurchase.UpdatedAt = DateTime.Now;
                if (agmtPurchase.Uid != 0)
                    factory.GetAgreementPurchase4CompositeProductRepository().Store(agmtPurchase);
                else
                    factory.GetAgreementPurchase4CompositeProductRepository().Add(agmtPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return agmtPurchase;
        }

        public static AgreementPurchase IndicateProd4AgreementPurchase(AgreementPurchase agmtPurchase, decimal price, ProductSupplyForecast prod, Organization sellerOrg, bool isUdp4Prod, string errAptMsg)
        {
            lock (Obj)
            {
                factory.GetAgreementPurchaseRepository().Refresh(agmtPurchase);
                if (agmtPurchase.IsMatched) throw new Exception(errAptMsg);

                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    agmtPurchase.IsMatched = true;
                    agmtPurchase.MatchedProdId = prod.Uid;
                    agmtPurchase.AgreePrice = price;
                    if (string.IsNullOrEmpty(agmtPurchase.SellerWonId)) agmtPurchase.SellerWonId = sellerOrg.Uid;

                    factory.GetAgreementPurchaseRepository().Store(agmtPurchase);

                    if (isUdp4Prod)
                    {
                        prod.CommitedAmount = prod.AvailableForSale;
                        prod.ActualAmount = prod.AvailableForSale;
                        prod.AvailableToOtherTcs = prod.AvailableForSale;

                        prod.StatusType = ProductStatusType.Commited;
                        prod.SellerStatus = SellerStatus.CommittedSold;
                        prod.BuyerStatus = BuyerStatus.CommittedBought;

                        prod.Price = agmtPurchase.AgreePrice;
                        prod.Currency = agmtPurchase.Currency;
                        prod.PurchaseOrgId = agmtPurchase.BuyerUid;
                        prod.SalesOrganization = sellerOrg;
                        factory.GetProductSuppyForecastRepository().Store(prod);
                    }

                    //Check and remove other puchase process that come from Planning Purchase.
                    if (agmtPurchase.PlanningId != 0 && agmtPurchase.IssuedSeq != 0)
                    {
                        var bp = BiddingPurchaseServices.GetBiddingPurchase(agmtPurchase.PlanningId, agmtPurchase.IssuedSeq);
                        if (bp != null) factory.GetBiddingPurchaseRepository().Remove(bp);

                        var ra = ReverseAuctionServices.GetReverseAuction(agmtPurchase.PlanningId, agmtPurchase.IssuedSeq);
                        if (ra != null) factory.GetReverseAuctionRepository().Remove(ra);
                    }

                    transactionManager.CommitTransaction();
                }
                catch
                {
                    transactionManager.RollbackTransaction();
                    throw;
                }
            }
            return agmtPurchase;
        }

        public static void DeleteAgreementPurchase4CompositeProd(AgreementPurchase4CompositeProduct agmtPurchase)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                factory.GetAgreementPurchase4CompositeProductRepository().Remove(agmtPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static IList<AgreementPurchase> GetAgreementPurchase(long planningId, long issuedSeq)
        {
            try
            {
                const string queryString = "select ap from AgreementPurchase ap where ap.PlanningId = :planningId and ap.IssuedSeq = :issueSeq";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                query.SetParameter("planningId", planningId);
                query.SetParameter("issueSeq", issuedSeq);

                return query.List().Cast<AgreementPurchase>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<AgreementPurchase4CompositeProduct> FindInvitedAgreementPurchase4CompositeProd(string fromBuyer, string toSeller, string purchaseType)
        {
            try
            {
                var queryString = "select ap from AgreementPurchase4CompositeProduct as ap join ap.InvitedSellerOrgs as invtOrg where invtOrg.Uid = :sellerId";
                if (!string.IsNullOrEmpty(fromBuyer)) queryString += " and ap.BuyerId = :buyerId ";
                if (!string.IsNullOrEmpty(purchaseType)) queryString += " and ap.PurchaseType = :purchaseType ";
                queryString += " and (ap.WonSellerId = :sellerId or (ap.WonSellerId is null and ap.CloseAt >= :curDateTime))";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                if (!string.IsNullOrEmpty(fromBuyer)) query.SetParameter("buyerId", fromBuyer);
                if (!string.IsNullOrEmpty(purchaseType))
                {
                    var purchase = (PurchaseType)Enum.Parse(typeof(PurchaseType), purchaseType);
                    query.SetParameter("purchaseType", Convert.ToInt32(purchase));
                }
                query.SetParameter("sellerId", toSeller);
                query.SetParameter("curDateTime", DateTime.Now);

                return query.List().Cast<AgreementPurchase4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static AgreementPurchase4CompositeProductSellerOffer FindAgreementOfferOnAgmtPurchaseByOrg(long agmtPurchaseId, string orgId)
        {
            try
            {
                const string queryString = "select ap from AgreementPurchase4CompositeProductSellerOffer as ap where ap.AgmtPurchase.Uid = :agmtPurchaseId and ap.SellerId = :sellerId";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("agmtPurchaseId", agmtPurchaseId);
                query.SetParameter("sellerId", orgId);

                query.SetMaxResults(1);
                return query.List().Cast<AgreementPurchase4CompositeProductSellerOffer>().ToList()[0];
            }
            catch
            {
                return null;
            }
        }
    }
}
