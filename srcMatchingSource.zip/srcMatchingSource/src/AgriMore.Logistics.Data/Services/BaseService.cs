﻿using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Domain.Repository;
using log4net;

namespace AgriMore.Logistics.Data.Services
{
    public class BaseService
    {
        protected static IRepositoryFactory factory = new NHibernateRepositoryFactory();
        protected static readonly ILog Log = LogManager.GetLogger("AuditTrailLogger");
    }
}
