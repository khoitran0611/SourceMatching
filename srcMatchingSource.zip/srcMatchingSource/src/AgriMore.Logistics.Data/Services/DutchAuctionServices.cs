﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class DutchAuctionServices : BaseService
    {
        public static DutchAuction4CompositeProduct UpdateDutchAuction4CompositeProd(DutchAuction4CompositeProduct dthAuction)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                dthAuction.UpdatedAt = DateTime.Now;

                factory.GetDutchAuction4CompositeProductRepository().Store(dthAuction);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return dthAuction;
        }

        public static DutchAuction4CompositeProduct SaveOrUpdateDutchAuction4CompositeProd(DutchAuction4CompositeProduct bidProcess, IList<DutchAuction4CompositeProductPriceDetail> priceDetails,
            string sellerIds, string supplierIds)
        {
            var transactionManager = new TransactionManager();
            try
            {
                if (bidProcess.Uid != 0) bidProcess.RemoveAllInvitedBuyer();
                IList<Organization> lstTradingOrgs = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(sellerIds)).ToList();
                foreach (Organization org in lstTradingOrgs) bidProcess.AddInvitedBuyer(org);

                if (bidProcess.Uid != 0) bidProcess.RemoveAllSupplier();
                IList<Organization> lstSuppliers = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(supplierIds)).ToList();
                foreach (Organization supplier in lstSuppliers) bidProcess.AddSupplier(supplier);

                if (bidProcess.Uid != 0) bidProcess.RemoveAllPriceDetail();
                foreach (var priceDetail in priceDetails) bidProcess.AddPriceDetail(priceDetail);

                transactionManager.BeginTransaction();

                bidProcess.UpdatedAt = DateTime.Now;
                if (bidProcess.Uid != 0)
                    factory.GetDutchAuction4CompositeProductRepository().Store(bidProcess);
                else
                    factory.GetDutchAuction4CompositeProductRepository().Add(bidProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return bidProcess;
        }

        public static void DeleteDutchAuctionProcess4CompositeProd(DutchAuction4CompositeProduct dthAuction)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                factory.GetDutchAuction4CompositeProductRepository().Remove(dthAuction);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static IList<DutchAuction4CompositeProduct> FindDutchAuctionProcess4CompositeProductInPeriod(string sellerId, string fromDate, string toDate)
        {
            try
            {
                string queryString = "select distinct dthAuction from DutchAuction4CompositeProduct dthAuction where dthAuction.SellerId = :sellerOrgId";
                if (!string.IsNullOrEmpty(fromDate)) queryString += " and dthAuction.StartAt >= :fromDate";
                if (!string.IsNullOrEmpty(toDate)) queryString += " and dthAuction.StartAt <= :toDate";
                queryString += " order by dthAuction.StartAt desc";

                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameter("sellerOrgId", sellerId);
                if (!string.IsNullOrEmpty(fromDate)) query.SetParameter("fromDate", Convert.ToDateTime(fromDate).Date);
                if (!string.IsNullOrEmpty(toDate)) query.SetParameter("toDate", Convert.ToDateTime(toDate).AddDays(1).Date);

                return query.List().Cast<DutchAuction4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<DutchAuction4CompositeProduct> FindInvitedDutchAuction4CompositeProd(string fromSeller, string toBuyer)
        {
            try
            {
                var queryString = "select dthAuct from DutchAuction4CompositeProduct as dthAuct join dthAuct.InvitedBuyerOrgs as invtOrg where invtOrg.Uid = :buyerId";
                if (!string.IsNullOrEmpty(fromSeller)) queryString += " and dthAuct.SellerId = :sellerId ";
                queryString += " and (dthAuct.WonBuyerId = :buyerId or (dthAuct.WonBuyerId is null and dthAuct.CloseAt >= :curDateTime))";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                if (!string.IsNullOrEmpty(fromSeller)) query.SetParameter("sellerId", fromSeller);
                query.SetParameter("buyerId", toBuyer);
                query.SetParameter("curDateTime", DateTime.Now);

                return query.List().Cast<DutchAuction4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<DutchAuction4CompositeProduct> GetDutchAuction4CompositeProductJustTimeOut()
        {
            const string queryString = "select distinct dtauc from DutchAuction4CompositeProduct dtauc where (dtauc.CloseAt = :closeDateTime or dtauc.CloseAt = :closeDateTimeSub1) and dtauc.WonBuyerId is null";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<DutchAuction4CompositeProduct>().ToList();
        }
    }
}
