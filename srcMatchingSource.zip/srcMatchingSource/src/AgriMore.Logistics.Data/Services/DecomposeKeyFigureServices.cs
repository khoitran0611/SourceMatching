﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class DecomposeKeyFigureServices : BaseService
    {
        public static void SaveOrUpdate(KeyFigure keyFigureInfo, IList<DecomposeKeyFigure> keyFigures)
        {
            if (IsOverlapPeriod(keyFigureInfo)) throw new InvalidDataException();

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                KeyFigure curKeyFigure = null;
                if (keyFigureInfo.Uid <= 0)
                {
                    curKeyFigure = new KeyFigure
                                   {
                                       ForOrg = keyFigureInfo.ForOrg,
                                       RootProduct = keyFigureInfo.RootProduct,
                                       FromDate = keyFigureInfo.FromDate,
                                       ToDate = keyFigureInfo.ToDate,
                                       CreatedOrgId = keyFigureInfo.CreatedOrgId
                                   };
                    foreach (var decomposeKeyFigure in keyFigures)
                        curKeyFigure.AddDecomposeKeyFigure(decomposeKeyFigure);

                    factory.GetKeyFigureRepository().Add(curKeyFigure);
                }
                else
                {
                    curKeyFigure = factory.GetKeyFigureRepository().GetOne(keyFigureInfo.Uid);
                    curKeyFigure.FromDate = keyFigureInfo.FromDate;
                    curKeyFigure.ToDate = keyFigureInfo.ToDate;

                    IList<DecomposeKeyFigure> curKeyFigures = curKeyFigure.DecomposeFigures;
                    var remKeyFigures = curKeyFigures.Where(it => !keyFigures.Any(kf => kf.FromProduct.Uid == it.FromProduct.Uid && kf.ToProduct.Uid == it.ToProduct.Uid)).ToList();

                    if (remKeyFigures.Count > 0)
                    {
                        foreach (var remKeyFigure in remKeyFigures) curKeyFigure.RemoveDecomposeKeyFigure(remKeyFigure);
                    }

                    foreach (var keyFigure in keyFigures)
                    {
                        var adjKeyFugire = curKeyFigures.SingleOrDefault(it => it.FromProduct.Uid == keyFigure.FromProduct.Uid && it.ToProduct.Uid == keyFigure.ToProduct.Uid);
                        if (adjKeyFugire != null)
                            adjKeyFugire.FigureVal = keyFigure.FigureVal;
                        else
                            curKeyFigure.AddDecomposeKeyFigure(keyFigure);
                    }

                    factory.GetKeyFigureRepository().Store(curKeyFigure);
                }

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static bool IsOverlapPeriod(KeyFigure keyFigure)
        {
            try
            {
                string queryString = "select distinct kf from KeyFigure kf where kf.ForOrg.Uid = :forOrgId and kf.RootProduct.Uid = :rootProdId " +
                    //"and kf.CreatedOrgId = :createdOrgId and ((kf.FromDate <= :fromDate and kf.ToDate >= :fromDate) " +
                                          "and ((kf.FromDate <= :fromDate and kf.ToDate >= :fromDate) " +
                                     "or (kf.FromDate <= :toDate and kf.ToDate >= :toDate) or (kf.FromDate >= :fromDate and kf.ToDate <= :toDate) " +
                                     "or (kf.FromDate <= :fromDate and kf.ToDate >= :toDate))";
                if (keyFigure.Uid > 0) queryString += string.Format(" and kf.Uid != {0}", keyFigure.Uid);

                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("forOrgId", keyFigure.ForOrg.Uid);
                query.SetInt64("rootProdId", keyFigure.RootProduct.Uid);
                //query.SetString("createdOrgId", keyFigure.CreatedOrgId);
                query.SetDateTime("toDate", keyFigure.ToDate.Date);
                query.SetDateTime("fromDate", keyFigure.FromDate.Date);
                var numberResult = query.List().Count;
                return numberResult > 0;
            }
            catch
            {
                return false;
            }
        }

        public static IList<KeyFigure> GetKeyFigures(string orgIds, long rootProdId, int pageIndex, int pageSize)
        {
            //string queryString = string.Format("select distinct kf from KeyFigure kf where kf.CreatedOrgId = '{0}'", createOrgId);
            string queryString = "select distinct kf from KeyFigure kf where 1 = 1";
            if (!string.IsNullOrEmpty(orgIds)) queryString += " and kf.ForOrg.Uid in (:forOrgIds)";
            if (rootProdId > 0) queryString += " and kf.RootProduct.Uid = :rootProdId";

            var session = NHibernateHttpModule.GetSession;
            var query = session.CreateQuery(queryString);

            if (!string.IsNullOrEmpty(orgIds)) query.SetParameterList("forOrgIds", orgIds.Split(','));
            if (rootProdId > 0) query.SetInt64("rootProdId", rootProdId); ;

            query.SetMaxResults(pageSize);
            query.SetFirstResult(pageIndex * pageSize);
            return query.List().Cast<KeyFigure>().ToList();
        }

        public static int CountKeyFigure(string orgIds, long rootProdId)
        {
            var numberEvent = 0;
            var orgId = string.Empty;
            if (!string.IsNullOrEmpty(orgIds))
            {
                var arOrgId = orgIds.Split(',');
                orgId = string.Format("'{0}'", string.Join("','", arOrgId));
            }

            //string queryString = string.Format("SELECT COUNT(*) FROM `keyfigures` where `keyfigures`.CreatedByOrgId = '{0}'", createOrgId);
            string queryString = "SELECT COUNT(*) FROM `keyfigures` where 1 = 1";
            if (!string.IsNullOrEmpty(orgIds)) queryString += string.Format(" and `keyfigures`.OrgId in ({0})", orgId);
            if (rootProdId > 0) queryString += string.Format(" and `keyfigures`.RootProdId = {0}", rootProdId);

            using (var cmd = NHibernateHttpModule.GetSession.Connection.CreateCommand())
            {
                cmd.CommandText = queryString;

                var obj = cmd.ExecuteScalar();
                if (obj is DBNull) return 0;

                numberEvent = Convert.ToInt32(obj);
            }
            return numberEvent;
        }

        public static IList<DecomposeKeyFigure> GetAllByRoot(long rootProdId)
        {
            try
            {
                //var defChain = factory.GetChainEntityRepository().GetOne(defChainId);
                //var defOrgId = (defChain != null && defChain.Organizations != null) ? defChain.Organizations[0].Uid : string.Empty;
                //if (string.IsNullOrEmpty(defOrgId)) return null;

                const string queryString = "select distinct kf from DecomposeKeyFigure kf where kf.RootProdId = :rootProdId";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetInt64("rootProdId", rootProdId);
                //query.SetString("defOrgId", defOrgId);
                return query.List().Cast<DecomposeKeyFigure>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<DecomposeKeyFigure> GetByRoot(string forOrgId, long rootProdId)
        {
            try
            {
                //var defChain = factory.GetChainEntityRepository().GetOne(defChainId);
                //var defOrgId = (defChain != null && defChain.Organizations != null) ? defChain.Organizations[0].Uid : string.Empty;
                //if (string.IsNullOrEmpty(defOrgId)) return null;

                const string queryString = "select distinct kf from DecomposeKeyFigure kf where kf.ForOrgId = :forOrgId and kf.RootProdId = :rootProdId " +
                                           "and kf.FigureInfo.FromDate <= :selDate and kf.FigureInfo.ToDate >= :selDate";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("forOrgId", forOrgId);
                query.SetInt64("rootProdId", rootProdId);
                //query.SetString("defOrgId", defOrgId);
                query.SetDateTime("selDate", DateTime.Now.Date);
                return query.List().Cast<DecomposeKeyFigure>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static DecomposeKeyFigure GetKeyFigure(string forOrgId, long rootProdId, long fromProdId, long toProdId)
        {
            try
            {
                //var defChain = factory.GetChainEntityRepository().GetOne(defChainId);
                //var defOrgId = (defChain != null && defChain.Organizations != null) ? defChain.Organizations[0].Uid : string.Empty;
                //if (string.IsNullOrEmpty(defOrgId)) return null;

                const string queryString = "select distinct kf from DecomposeKeyFigure kf where kf.ForOrgId = :forOrgId and kf.RootProdId = :rootProdId " +
                                           "and kf.FromProduct.Uid = :fromProdId and kf.ToProduct.Uid = :toProdId " +
                                           "and kf.FigureInfo.FromDate <= :selDate and kf.FigureInfo.ToDate >= :selDate";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("forOrgId", forOrgId);
                query.SetInt64("rootProdId", rootProdId);
                query.SetInt64("fromProdId", fromProdId);
                //query.SetString("defOrgId", defOrgId);
                query.SetInt64("toProdId", toProdId);
                query.SetDateTime("selDate", DateTime.Now.Date);
                return query.List().Cast<DecomposeKeyFigure>().FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }

        public static KeyFigure GetKeyFigure(string forOrgId, long rootProdId)
        {
            try
            {
                const string queryString = "select distinct kf from KeyFigure kf where kf.ForOrg.Uid = :forOrgId and kf.RootProduct.Uid = :rootProdId " +
                                           "and kf.FromDate <= :selDate and kf.ToDate >= :selDate";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("forOrgId", forOrgId);
                query.SetInt64("rootProdId", rootProdId);
                query.SetDateTime("selDate", DateTime.Now.Date);
                return query.List().Cast<KeyFigure>().FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }
    }
}
