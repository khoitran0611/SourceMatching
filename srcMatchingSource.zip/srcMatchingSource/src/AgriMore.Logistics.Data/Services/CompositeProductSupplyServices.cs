﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class CompositeProductSupplyServices : BaseService
    {
        public static CompositeProductSupply FinOne(long cmpProdId)
        {
            return factory.GetCompositeProductSupplyRepository().GetOne(cmpProdId);
        }

        public static CompositeProductSupply SaveOrUpdate(CompositeProductSupply cmpProdSupply)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                factory.GetCompositeProductSupplyRepository().Store(cmpProdSupply);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return cmpProdSupply;
        }

        public static CompositeProductSupply SaveOrUpdate(CompositeProductSupply cmpProdSupply, Products4CompositeProduct prod4CmpProd, ProductSupplyForecast idtProdSupply)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                if (idtProdSupply.Uid == 0)
                {
                    factory.GetProductSuppyForecastRepository().Add(idtProdSupply);
                    factory.GetProductSuppyForecastRepository().Flush();
                }

                prod4CmpProd.ProductSupply = idtProdSupply;
                cmpProdSupply.AddProd4CompositeProduct(prod4CmpProd);
                if (cmpProdSupply.Uid != 0)
                    factory.GetCompositeProductSupplyRepository().Store(cmpProdSupply);
                else
                {
                    factory.GetCompositeProductSupplyRepository().Add(cmpProdSupply);
                    if (cmpProdSupply.PackageType != null)
                    {
                        var packDefine = cmpProdSupply.PackageType;
                        if (packDefine.Price == 0 && packDefine.RentPrice == 0 && packDefine.DepositPrice == 0)
                        {
                            var packCfm = new PackingConfirmed
                            {
                                Packing = packDefine,
                                PackingAmount = 1,
                                CmpProdConfirmed = cmpProdSupply,
                                PriceType = PriceType.Price,
                                AmountPerPack = packDefine.PackagingAmount
                            };

                            factory.GetPackingConfirmedRepository().Add(packCfm);
                        }
                        else
                        {
                            for (int i = 1; i <= 3; i++)
                            {
                                var priceType = (PriceType)Enum.Parse(typeof(PriceType), i.ToString());
                                if (priceType == PriceType.Price && packDefine.Price == 0) continue;
                                if (priceType == PriceType.Rent && packDefine.RentPrice == 0) continue;
                                if (priceType == PriceType.Deposit && packDefine.DepositPrice == 0) continue;

                                var packCfm = new PackingConfirmed
                                {
                                    Packing = packDefine,
                                    PackingAmount = 1,
                                    CmpProdConfirmed = cmpProdSupply,
                                    PriceType = priceType,
                                    AmountPerPack = packDefine.PackagingAmount
                                };

                                factory.GetPackingConfirmedRepository().Add(packCfm);
                            }
                        }
                    }
                }

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return cmpProdSupply;
        }

        public static IList<CompositeProductSupply> GetCompositeProductReady4Dispatch(DateTime fromDate, DateTime toDate, string buyerId, string exceptUids)
        {
            try
            {
                string queryString = "select distinct cmpProd from CompositeProductSupply cmpProd where cmpProd.BuyerId = :buyerId ";
                queryString += "and cmpProd.AvailableDate >= :fromDate and cmpProd.AvailableDate <= :toDate and cmpProd.Status = :prodStatus";
                if (!string.IsNullOrEmpty(exceptUids)) queryString += " and cmpProd not in (:exceptUids)";
                queryString += " and (cmpProd.ShipmentItemId is null or cmpProd.ShipmentItemId = 0) order by cmpProd.AvailableDate desc";

                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameter("buyerId", buyerId);
                query.SetParameter("fromDate", fromDate.Date);
                query.SetParameter("toDate", toDate.AddDays(1).Date);
                query.SetParameter("prodStatus", Convert.ToInt32(CompositeProdStatus.Ready4Dispatch));
                if (!string.IsNullOrEmpty(exceptUids)) query.SetParameterList("exceptUids", Array.ConvertAll<string, long>(exceptUids.Split(','), (it) => Convert.ToInt64(it)));

                return query.List().Cast<CompositeProductSupply>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<CompositeProductSupply> GetCompositeProduct4Invoice(string issOrgInvId, string recOrgInvId, string reltOrgIds, InvoiceType invType, DateTime fromDate, DateTime toDate)
        {
            try
            {
                string queryString = "select distinct cmpProd from CompositeProductSupply as cmpProd join cmpProd.Product4CmpProd as prd4Cmp where cmpProd.SellerId = :issOrgInvId ";
                queryString += " and cmpProd.AvailableDate >= :fromDate and cmpProd.AvailableDate < :toDate ";
                queryString += " and cmpProd.Status = 2 "; //Ready for Invoice.

                if (invType == InvoiceType.Debit)
                {
                    queryString += " and cmpProd.BuyerId = :recInvOrgId and prd4Cmp.ProductSupply.Organization in (:relateOrgIds) ";
                    queryString += " and (cmpProd.DebitInvId is null or cmpProd.DebitInvId = 0) ";//It's not in the Debit invoice.
                }
                else
                {
                    queryString += " and cmpProd.BuyerId in (:relateOrgIds) and prd4Cmp.ProductSupply.Organization = :recInvOrgId ";
                    queryString += " and (cmpProd.CreditInvId is null or cmpProd.CreditInvId = 0) ";//It's not in the Credit invoice.
                }

                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameter("issOrgInvId", issOrgInvId);
                query.SetParameter("recInvOrgId", recOrgInvId);
                query.SetParameterList("relateOrgIds", reltOrgIds.Split(','));
                query.SetParameter("fromDate", fromDate.Date);
                query.SetParameter("toDate", toDate.AddDays(1).Date);

                return query.List().Cast<CompositeProductSupply>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<CompositeProductSupply> GetCompositeProductByUids(string Uids)
        {
            try
            {
                string queryString = "select distinct cmpProd from CompositeProductSupply cmpProd where cmpProd.Uid in (:Uids)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameterList("Uids", Array.ConvertAll<string, long>(Uids.Split(','), (it) => Convert.ToInt64(it)));
                return query.List().Cast<CompositeProductSupply>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<PackingConfirmed> GetPackingConfirmed(string cmpProdIds)
        {
            try
            {
                string queryString = "select distinct packCfm from PackingConfirmed packCfm where packCfm.CmpProdConfirmed.Uid in (:Uids)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameterList("Uids", Array.ConvertAll<string, long>(cmpProdIds.Split(','), (it) => Convert.ToInt64(it)));
                return query.List().Cast<PackingConfirmed>().ToList();
            }
            catch
            {
                return null;
            }
        }
    }
}