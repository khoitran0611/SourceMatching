﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Data.NHibernate;

namespace AgriMore.Logistics.Data.Services
{
    public class SpeciesServices : BaseService
    {
        public IEnumerable<Species> GetAllProducts()
        {
            return factory.GetSpeciesRepository().AsCollection();
        }

        public IEnumerable<Species> GetByProductByIds(string prodIds)
        {
            try
            {
                const string queryString = "select distinct sp from Species sp where sp.Uid in (:speciesIds)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameterList("speciesIds", Array.ConvertAll(prodIds.Split(','), Convert.ToInt64));
                return query.List().Cast<Species>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public Species GetProductById(long productUid)
        {
            return factory.GetSpeciesRepository().GetOne(productUid);
        }

        public IEnumerable<TreatmentType> GetAllTreatmentTypes()
        {
            return factory.GetTreatmentTypeRepository().AsCollection();
        }

        public TreatmentType GetTreatmentTypeById(long treatmentTypeUid)
        {
            return factory.GetTreatmentTypeRepository().GetOne(treatmentTypeUid);
        }

        public IEnumerable<TreatmentTypeCategory> GetAllTreatmentTypeCategory()
        {
            return factory.GetTreatmentTypeCategoryRepository().AsCollection();
        }

        public TreatmentTypeCategory GetTreatmentTypeCategoryById(long treatmentCategoryUid)
        {
            return factory.GetTreatmentTypeCategoryRepository().GetOne(treatmentCategoryUid);
        }

        public IEnumerable<ExposureDefine> GetAllExposureDefine()
        {
            return factory.GetExposureDefineRepository().AsCollection();
        }

        public ExposureDefine GetExposureDefineById(long treatmentCategoryUid)
        {
            return factory.GetExposureDefineRepository().GetOne(treatmentCategoryUid);
        }

        public IEnumerable<ExposureType> GetAllExposureTypes()
        {
            return factory.GetExposureTypeRepository().AsCollection();
        }

        public ExposureType GetExposureTypeById(long treatmentCategoryUid)
        {
            return factory.GetExposureTypeRepository().GetOne(treatmentCategoryUid);
        }

        public IEnumerable<DecompositionCategory> GetAllDecompositionCategory()
        {
            return factory.GetDecompositionCategoryRepository().AsCollection();
        }

        public DecompositionCategory GetDecompositionCategoryById(long treatmentCategoryUid)
        {
            return factory.GetDecompositionCategoryRepository().GetOne(treatmentCategoryUid);
        }

        public IEnumerable<DecompositionType> GetDecompositionTypeById(long treatmentCategoryUid)
        {
            return factory.GetDecompositionTypeRepository().AsCollection()
                .Where(dt => dt.DecompositionCategory.Uid == treatmentCategoryUid).ToList();
        }

        public IEnumerable<DecompositionType> GetAllDecompositionType()
        {
            return factory.GetDecompositionTypeRepository().AsCollection();
        }


    }
}
