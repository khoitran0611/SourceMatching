﻿using System;
using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Data.Services
{
    public class OrganizationServices : BaseService
    {
        public static IList<Organization> GetByIds(string[] orgIds)
        {
            const string queryString = "SELECT {org.*} FROM `organizations` {org} WHERE {org}.OrgId IN (:orgIds)";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "org", typeof(Organization));
            iQuery.SetParameterList("orgIds", orgIds);
            return iQuery.List().Cast<Organization>().ToList();
        }

        public static IList<Organization> GetSubAdminGroup()
        {
            const string queryString = "SELECT {org.*} FROM `organizations` {org} " +
                                       "INNER JOIN `organizationmapping` ON {org}.OrgId = `organizationmapping`.OrganizationId " +
                                       "INNER JOIN `chainentity` ON `chainentity`.Uid = `organizationmapping`.ChainEntityId " +
                                       "INNER JOIN `user` ON `user`.ChainEntityId = `chainentity`.Uid " +
                                       "INNER JOIN `userrole` ON `userrole`.UserId = `user`.Uid WHERE `userrole`.RoleId = 15";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "org", typeof(Organization));
            return iQuery.List().Cast<Organization>().ToList();
        }

        public static IList<Organization> GetAvailableOrg(string orgId)
        {
            IList<Organization> visibleOrgs;
            string adminGroupId = System.Configuration.ConfigurationManager.AppSettings["AdministrativeGroup"];
            IList<string> subAdminGroupIds = SubAdministrativeGroupServices.GetSubAdminIdOfOrganization(orgId);
            if (subAdminGroupIds != null && subAdminGroupIds.Count > 0) //(subAdminGroupIds.Contains(orgId))
            {
                if (subAdminGroupIds.Contains(orgId))
                {
                    Organization selectedOrg = factory.GetOrganizationRepository().GetOne(orgId);
                    visibleOrgs = selectedOrg.GroupOrganizations.Where(it => it.Activated == 1).Select(it => it.Organization).ToList();
                }
                else
                    visibleOrgs = SubAdministrativeGroupServices.GetOrganizationInAdminGroups(subAdminGroupIds.ToArray());
            }
            else
            {
                Organization selectedOrg = factory.GetOrganizationRepository().GetOne(orgId);
                visibleOrgs = selectedOrg.InGroupOfOrganizations.Where(it => it.Activated == 1 && !adminGroupId.Equals(it.Organization.Uid)).Select(it => it.Organization).ToList();
                visibleOrgs.Add(selectedOrg);
            }
            return visibleOrgs;
        }

        public static void UpdateGoO(string groupOrgId, string orgId)
        {
            var command = NHibernateHttpModule.GetSession.Connection.CreateCommand();
            try
            {
                var baseGoO = factory.GetBaseGroupOfOrganizationRepository()
                    .AsCollection().Where(it => it.Uid.GroupOrgId == groupOrgId && it.Uid.OrgId == orgId)
                    .FirstOrDefault();
                if (baseGoO == null)
                {
                    string GoOSql = "Insert Into base_groupoforganization(GroupOrgId,OrgId)" +
                            " VALUES('" + groupOrgId + "', '" + orgId + "');";

                    factory.GetGroupOrganizationsRepository().ExecuteSql(GoOSql);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void DeleteGoO(string groupOrgId, string orgId)
        {
            var session = NHibernateHttpModule.CreateSession();
            try
            {
                string GoOSql = "Delete From base_groupoforganization" +
                        " WHERE GroupOrgId = '" + orgId + "'" +
                        " AND " + "OrgId = '" + groupOrgId + "'";

                factory.GetBaseGroupOfOrganizationRepository().ExecuteSql(GoOSql);

                //string sqlCommand = "DELETE FROM agrimore_for_test.am_grp_org_dtl" +
                //    " WHERE agrimore_for_test.am_grp_org_dtl.grouped_org_id = '" + groupOrgId + "'" +
                //    " AND " + "agrimore_for_test.am_grp_org_dtl.org_id = '" + orgId + "'";

                //System.Data.IDbCommand cmd = session.Connection.CreateCommand();
                //cmd.CommandText = sqlCommand;
                //cmd.ExecuteNonQuery();
                //cmd.CommandType = CommandType.Text;                                              
                //cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
