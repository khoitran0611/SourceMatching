﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class BiddingPurchaseServices : BaseService
    {
        public static BiddingPurchase GetBiddingPurchase(long planningId, long issuedSeq)
        {
            try
            {
                const string hsql = "select bp from BiddingPurchase bp where bp.PlanningId.Uid = :planningId and bp.IssuedSeq = :issuedSeq";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(hsql);
                query.SetParameter("planningId", planningId);
                query.SetParameter("issuedSeq", issuedSeq);

                return (BiddingPurchase)query.UniqueResult();
            }
            catch
            {
                return null;
            }
        }

        public static BiddingPurchase SaveOrUpdate(BiddingPurchase biddingPurchase)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                biddingPurchase.UpdatedAt = DateTime.Now;
                factory.GetBiddingPurchaseRepository().Store(biddingPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return biddingPurchase;
        }

        public static BiddingPurchase4CompositeProduct UpdatePurchase4CompositeProd(BiddingPurchase4CompositeProduct bidPurchase)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                bidPurchase.UpdatedAt = DateTime.Now;

                factory.GetBiddingPurchase4CompositeProductRepository().Store(bidPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return bidPurchase;
        }

        public static BiddingPurchase4CompositeProduct SaveOrUpdatePurchase4CompositeProd(BiddingPurchase4CompositeProduct biddingPurchase, IList<BiddingPurchase4CompositeProductPriceDetail> priceDetails,
            string sellerIds, string supplierIds)
        {

            var transactionManager = new TransactionManager();
            try
            {
                if (biddingPurchase.Uid != 0) biddingPurchase.RemoveAllInvitedSeller();
                IList<Organization> lstTradingOrgs = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(sellerIds)).ToList();
                foreach (Organization org in lstTradingOrgs) biddingPurchase.AddInvitedSeller(org);

                if (biddingPurchase.Uid != 0) biddingPurchase.RemoveAllAgreedSupplier();
                IList<Organization> lstSuppliers = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(supplierIds)).ToList();
                foreach (Organization supplier in lstSuppliers) biddingPurchase.AddAgreedSupplier(supplier);

                if (biddingPurchase.Uid != 0) biddingPurchase.RemoveAllPriceDetail();
                foreach (var priceDetail in priceDetails) biddingPurchase.AddPriceDetail(priceDetail);

                transactionManager.BeginTransaction();

                biddingPurchase.UpdatedAt = DateTime.Now;
                if (biddingPurchase.Uid != 0)
                    factory.GetBiddingPurchase4CompositeProductRepository().Store(biddingPurchase);
                else
                    factory.GetBiddingPurchase4CompositeProductRepository().Add(biddingPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return biddingPurchase;
        }

        public static void DeletePurchase4CompositeProd(BiddingPurchase4CompositeProduct bidPurchase)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                factory.GetBiddingPurchase4CompositeProductRepository().Remove(bidPurchase);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static BiddingPurchaseSellerBidded PostBid(BiddingPurchaseSellerBidded bid)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                factory.GetBiddingPurchaseSellerBiddedRepository().Add(bid);
                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return bid;
        }

        public static BiddingPurchase4CompositeProductSellerOffer PostBid(BiddingPurchase4CompositeProductSellerOffer sellerOffer, IList<BiddingPurchase4CompositeProductSellerOfferDetail> offerDetails)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                foreach (var sellerOfferDetail in offerDetails) sellerOffer.AddOfferPriceDetail(sellerOfferDetail);
                factory.GetBiddingPurchase4CompositeProductSellerOfferRepository().Add(sellerOffer);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return sellerOffer;
        }

        public static IList<BiddingPurchase> GetFinalBiddingProcess()
        {
            const string queryString = "select distinct bp from BiddingPurchase bp where (bp.BiddingCloseAt = :closeDateTime or bp.BiddingCloseAt = :closeDateTimeSub1)";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<BiddingPurchase>().ToList();
        }

        public static IList<BiddingPurchase4CompositeProduct> GetFinalBiddingProcess4CompositeProduct()
        {
            const string queryString = "select distinct bp from BiddingPurchase4CompositeProduct bp where (bp.CloseAt = :closeDateTime or bp.CloseAt = :closeDateTimeSub1)";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<BiddingPurchase4CompositeProduct>().ToList();
        }

        public static IList<BiddingPurchase> GetBiddingPurchase4Seller(string sellerId, string buyerId)
        {
            string hsql = "select distinct bp from BiddingPurchase bp join bp.Sellers as sl where sl.Uid = :sellerId and bp.IsMatched != 1";
            hsql += " and ((bp.BiddingStartAt <= :curDate and bp.BiddingCloseAt >= :curDate and bp.PurchaseTo >= :curDateOnly) or (bp.SellerWonId = :sellerId))";
            if (!string.IsNullOrEmpty(buyerId)) hsql += " and bp.BuyerUid = :buyerId";

            var session = NHibernateHttpModule.GetSession;

            var query = session.CreateQuery(hsql);
            query.SetParameter("sellerId", sellerId);
            query.SetParameter("curDate", DateTime.Now);
            query.SetParameter("curDateOnly", DateTime.Now.Date);
            if (!string.IsNullOrEmpty(buyerId)) query.SetParameter("buyerId", buyerId);

            return query.List().Cast<BiddingPurchase>().ToList();
        }

        public static IList<BiddingPurchaseSellerBidded> GetSellerBiddingOnBiddingPurchase(long bidPurchaseId)
        {
            const string hsql = "select bpsb from BiddingPurchaseSellerBidded bpsb where bpsb.BidPurchase.Uid = :bidPurchaseId order by bpsb.BiddingPrice";

            var session = NHibernateHttpModule.GetSession;

            var query = session.CreateQuery(hsql);
            query.SetParameter("bidPurchaseId", bidPurchaseId);

            return query.List().Cast<BiddingPurchaseSellerBidded>().ToList();
        }

        public static IList<BiddingPurchase4CompositeProduct> FindBiddingPurchase4CompositeProduct(string buyerOrgId, string fromDate, string toDate)
        {
            string hsql = "select distinct bid from BiddingPurchase4CompositeProduct bid where bid.BuyerId = :buyerOrgId";
            if (!string.IsNullOrEmpty(fromDate)) hsql += " and bid.StartAt >= :fromDate";
            if (!string.IsNullOrEmpty(toDate)) hsql += " and bid.StartAt <= :toDate";
            hsql += " order by bid.StartAt desc";

            var session = NHibernateHttpModule.GetSession;
            var query = session.CreateQuery(hsql);

            query.SetParameter("buyerOrgId", buyerOrgId);
            if (!string.IsNullOrEmpty(fromDate)) query.SetParameter("fromDate", Convert.ToDateTime(fromDate).Date);
            if (!string.IsNullOrEmpty(toDate)) query.SetParameter("toDate", Convert.ToDateTime(toDate).AddDays(1).Date);

            return query.List().Cast<BiddingPurchase4CompositeProduct>().ToList();
        }

        public static IList<BiddingPurchase4CompositeProduct> FindInvitedBidPurchase4CompositeProd(string fromBuyer, string toSeller)
        {
            try
            {
                var queryString = "select bid from BiddingPurchase4CompositeProduct as bid join bid.InvitedSellerOrgs as invtOrg where invtOrg.Uid = :sellerId";
                if (!string.IsNullOrEmpty(fromBuyer)) queryString += " and bid.BuyerId = :buyerId ";
                queryString += " and (bid.WonSellerId = :sellerId or (bid.WonSellerId is null and bid.CloseAt >= :curDateTime))";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                if (!string.IsNullOrEmpty(fromBuyer)) query.SetParameter("buyerId", fromBuyer);
                query.SetParameter("sellerId", toSeller);
                query.SetParameter("curDateTime", DateTime.Now);

                return query.List().Cast<BiddingPurchase4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static BiddingPurchase4CompositeProductSellerOffer FindBidOfferOnBiddingPurchaseByOrg(long bidPurchaseId, string orgId)
        {
            try
            {
                const string queryString = "select bidOffer from BiddingPurchase4CompositeProductSellerOffer as bidOffer where bidOffer.BiddingPurchase.Uid = :bidPurchaseId and bidOffer.SellerId = :sellerId";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("bidPurchaseId", bidPurchaseId);
                query.SetParameter("sellerId", orgId);

                query.SetMaxResults(1);
                return query.List().Cast<BiddingPurchase4CompositeProductSellerOffer>().ToList()[0];
            }
            catch
            {
                return null;
            }
        }

        public static IList<BiddingPurchase4CompositeProductSellerOffer> FindAllOfferOnBiddingPurchase(long bidPurchaseId)
        {
            try
            {
                const string queryString = "select bidOffer from BiddingPurchase4CompositeProductSellerOffer as bidOffer where bidOffer.BiddingPurchase.Uid = :bidPurchaseId order by bidOffer.OfferPrice desc";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("bidPurchaseId", bidPurchaseId);

                return query.List().Cast<BiddingPurchase4CompositeProductSellerOffer>().ToList();
            }
            catch
            {
                return null;
            }
        }
    }
}
