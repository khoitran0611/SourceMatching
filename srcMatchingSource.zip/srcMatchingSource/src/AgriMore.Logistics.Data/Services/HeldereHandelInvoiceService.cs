﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Web;
using System.Threading;
using System.Xml.XPath;
using System.Xml.Xsl;
using AgriMore.Logistics.Common.Utils;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Data.Services
{
    public class HeldereHandelInvoiceService : InvoiceService
    {
        private static readonly object sync = new object();
        public override string GetInvoiceNumber(AgriMore.Logistics.Domain.InvoiceType invoiceType)
        {
            lock (sync)
            {
                var factory = new NHibernateRepositoryFactory();
                var session = NHibernateHttpModule.CreateSession();
                try
                {

                    var q = session.CreateQuery("from InvoiceNumber where OrgId = :orgId and InvoiceType = :invoiceType order by Created desc");
                    q.SetString("orgId", Thread.CurrentPrincipal.Identity.Name);
                    q.SetInt32("invoiceType", (int)invoiceType);
                    q.SetMaxResults(1);
                    var invoiceNr = q.List().Cast<InvoiceNumber>().FirstOrDefault();

                    var prefix = (DateTime.Now.Year % 10).ToString();
                    if (invoiceNr == null)
                    {
                        invoiceNr = new InvoiceNumber
                        {
                            OrgId = Thread.CurrentPrincipal.Identity.Name,
                            InvoiceType = invoiceType,
                            InvoiceNr = prefix + (invoiceType == InvoiceType.Debit ? "76" : "66") + "00001",
                            Created = DateTime.Now
                        };
                    }
                    else
                    {
                        if (invoiceNr.InvoiceNr.StartsWith(prefix))
                        {
                            invoiceNr.InvoiceNr = invoiceNr.InvoiceNr.Substring(0, 3) + (int.Parse(invoiceNr.InvoiceNr.Substring(3)) + 1).ToString().PadLeft(5, '0');
                        }
                        else
                        {
                            invoiceNr.InvoiceNr = prefix + (invoiceType == InvoiceType.Debit ? "76" : "66") + "00001";
                        }
                        invoiceNr.Created = DateTime.Now;
                    }

                    session.Save(invoiceNr);
                    session.Flush();

                    return invoiceNr.InvoiceNr;

                }
                finally
                {
                    session.Close();
                }
            }
        }

        public override string GeneratePDF(Invoice invoice, string langCode, System.Web.HttpResponse response)
        {
            var xmlInvoice = new StringBuilder("<Root>");
            var invoiceXml = SerializationUtility<Invoice>.Serialize(invoice, true);

            var xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(invoiceXml);

            var xPathDoc = new XPathDocument(new XmlNodeReader(xmlDoc));
            var xslFile = new XslCompiledTransform();
            xslFile.Load(HttpContext.Current.Server.MapPath("~/Invoice/Template/RemoveNamespaces.xslt"));

            var writer = new StringWriter();
            var xsltArgs = new XsltArgumentList();
            xslFile.Transform(xPathDoc, xsltArgs, writer);

            string currentTheme = ((System.Web.UI.Page)HttpContext.Current.Handler).Theme;
            string logoXml = string.Format("<LogoUrl><![CDATA[{0}]]></LogoUrl>", HttpContext.Current.Server.MapPath(string.Format("/App_Themes/{0}/Images/pdfLogo.png", currentTheme)));
            xmlInvoice.Append(logoXml);

            string summaryXml = BuidingSummarySession(invoice);
            xmlInvoice.Append(summaryXml);

            string detailXml = BuidingDetailSession(invoice);
            xmlInvoice.Append(detailXml);

            string transformXml = writer.ToString().Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "");
            xmlInvoice.Append(transformXml);
            xmlInvoice.Append("</Root>");

            var xDoc = new XmlDocument();
            xDoc.LoadXml(xmlInvoice.ToString());
            if (response != null)
            {
                PdfHelper.CreatePDF(xDoc, HttpContext.Current.Server.MapPath(string.Format("~/Invoice/Template/BOFTC/Invoice_{0}.xslt", langCode)),
                                    Thread.CurrentThread.CurrentUICulture.EnglishName,
                                    "Invoice_" + (invoice.Uid > 0 ? invoice.InvoiceNr : "NEW") + ".pdf", response);
                return string.Empty;
            }

            string invFilename = string.Format("Invoice_{0}_{1}.pdf", invoice.InvoiceNr, langCode);
            string invStorePath = System.Web.Configuration.WebConfigurationManager.AppSettings["InvoiceStorePath"];
            string resFile = PdfHelper.SavePdf(xDoc, HttpContext.Current.Server.MapPath(string.Format("~/Invoice/Template/BOFTC/Invoice_{0}.xslt", langCode)), invStorePath, invFilename);
            return resFile;
        }

        private static string BuidingSummarySession(Invoice invoice)
        {
            var stringBuilder = new StringBuilder("<Summary><ProductAndPackages>");
            var factory = new  NHibernateRepositoryFactory();

            IDictionary<string, decimal> dicProdSummary = new Dictionary<string, decimal>();
            IDictionary<string, InvoiceProduct> dicInvProducts = new Dictionary<string, InvoiceProduct>();

            IDictionary<string, decimal> dicPackSummary = new Dictionary<string, decimal>();
            IDictionary<string, InvoicePackage> dicInvPacks = new Dictionary<string, InvoicePackage>();

            IDictionary<string, decimal> dicDeCmpSummary = new Dictionary<string, decimal>();
            IDictionary<string, InvoiceDecomposition> dicInvDeCmps = new Dictionary<string, InvoiceDecomposition>();

            IDictionary<string, decimal> dicAddOnSummary = new Dictionary<string, decimal>();
            IDictionary<string, InvoiceAddOn> dicInvAddOns = new Dictionary<string, InvoiceAddOn>();

            IDictionary<string, decimal> dicChargeSummary = new Dictionary<string, decimal>();
            IDictionary<string, InvoiceCharge1> dicInvCharges = new Dictionary<string, InvoiceCharge1>();

            IDictionary<string, decimal> vatBasicSummary = new Dictionary<string, decimal>();
            IDictionary<string, decimal> vatNetSummary = new Dictionary<string, decimal>();

            IDictionary<string, decimal> dicTreatmentSummary = new Dictionary<string, decimal>();
            IDictionary<string, InvoiceTreatment> dicInvTreatment = new Dictionary<string, InvoiceTreatment>();

            foreach (InvoiceProduct invProd in invoice.Products)
            {
                string prodName = invProd.Languages[0].SpeciesName;
                if (dicProdSummary.ContainsKey(prodName))
                    dicProdSummary[prodName] += invProd.TotalPrice;
                else
                {
                    dicProdSummary.Add(new KeyValuePair<string, decimal>(prodName, invProd.TotalPrice));
                    dicInvProducts.Add(new KeyValuePair<string, InvoiceProduct>(prodName, invProd));
                }

                string prodVatName = invProd.Languages[0].VAT;
                if (vatBasicSummary.ContainsKey(prodVatName))
                {
                    vatBasicSummary[prodVatName] += invProd.TotalPrice;
                    vatNetSummary[prodVatName] += invProd.TotalPrice * invProd.VAT / 100;
                }
                else
                {
                    vatBasicSummary.Add(new KeyValuePair<string, decimal>(prodVatName, invProd.TotalPrice));
                    vatNetSummary.Add(new KeyValuePair<string, decimal>(prodVatName, invProd.TotalPrice * invProd.VAT / 100));
                }

                foreach (InvoicePackage invPack in invProd.Packages)
                {
                    string packName = invPack.Languages[0].Name;
                    if (dicPackSummary.ContainsKey(packName))
                        dicPackSummary[packName] += invPack.TotalPrice;
                    else
                    {
                        dicPackSummary.Add(new KeyValuePair<string, decimal>(packName, invPack.TotalPrice));
                        dicInvPacks.Add(new KeyValuePair<string, InvoicePackage>(packName, invPack));
                    }

                    var packVatName = invPack.Languages[0].VAT;
                    if (vatBasicSummary.ContainsKey(packVatName))
                    {
                        vatBasicSummary[packVatName] += invPack.TotalPrice;
                        vatNetSummary[packVatName] += invPack.TotalPrice * invPack.VAT / 100;
                    }
                    else
                    {
                        vatBasicSummary.Add(new KeyValuePair<string, decimal>(packVatName, invPack.TotalPrice));
                        vatNetSummary.Add(new KeyValuePair<string, decimal>(packVatName, invPack.TotalPrice * invPack.VAT / 100));
                    }
                }

                foreach (InvoiceAddOn invAddOn in invProd.AddOns)
                {
                    string addonName = invAddOn.Languages[0].Name;
                    if (dicAddOnSummary.ContainsKey(addonName))
                        dicAddOnSummary[addonName] += invAddOn.TotalPrice;
                    else
                    {
                        dicAddOnSummary.Add(new KeyValuePair<string, decimal>(addonName, invAddOn.TotalPrice));
                        dicInvAddOns.Add(new KeyValuePair<string, InvoiceAddOn>(addonName, invAddOn));
                    }

                    var addOnVatName = invAddOn.Languages[0].VAT;
                    if (vatBasicSummary.ContainsKey(addOnVatName))
                    {
                        vatBasicSummary[addOnVatName] += invAddOn.TotalPrice;
                        vatNetSummary[addOnVatName] += invAddOn.TotalPrice * invAddOn.VAT / 100;
                    }
                    else
                    {
                        vatBasicSummary.Add(new KeyValuePair<string, decimal>(addOnVatName, invAddOn.TotalPrice));
                        vatNetSummary.Add(new KeyValuePair<string, decimal>(addOnVatName, invAddOn.TotalPrice * invAddOn.VAT / 100));
                    }
                }
            }

            foreach (var invDeCmp in invoice.Decompositions)
            {
                if (invDeCmp.DecomposeType == null) continue;

                string deCmpTypeName = invDeCmp.DecomposeType.GetName("en-US");
                if (dicDeCmpSummary.ContainsKey(deCmpTypeName))
                    dicDeCmpSummary[deCmpTypeName] += invDeCmp.TotalPrice;
                else
                {
                    dicDeCmpSummary.Add(new KeyValuePair<string, decimal>(deCmpTypeName, invDeCmp.TotalPrice));
                    dicInvDeCmps.Add(new KeyValuePair<string, InvoiceDecomposition>(deCmpTypeName, invDeCmp));
                }

                string deCmpVatName = invDeCmp.Languages[0].VAT;
                if (vatBasicSummary.ContainsKey(deCmpVatName))
                {
                    vatBasicSummary[deCmpVatName] += invDeCmp.TotalPrice;
                    vatNetSummary[deCmpVatName] += invDeCmp.TotalPrice * invDeCmp.VAT / 100;
                }
                else
                {
                    vatBasicSummary.Add(new KeyValuePair<string, decimal>(deCmpVatName, invDeCmp.TotalPrice));
                    vatNetSummary.Add(new KeyValuePair<string, decimal>(deCmpVatName, invDeCmp.TotalPrice * invDeCmp.VAT / 100));
                }
            }

            foreach (var cmpProd in invoice.CompositeProducts)
            {
                foreach (InvoicePackage invPack in cmpProd.Packages)
                {
                    string packName = invPack.Languages[0].Name;
                    if (dicPackSummary.ContainsKey(packName))
                        dicPackSummary[packName] += invPack.TotalPrice;
                    else
                    {
                        dicPackSummary.Add(new KeyValuePair<string, decimal>(packName, invPack.TotalPrice));
                        dicInvPacks.Add(new KeyValuePair<string, InvoicePackage>(packName, invPack));
                    }

                    var packVatName = invPack.Languages[0].VAT;
                    if (vatBasicSummary.ContainsKey(packVatName))
                    {
                        vatBasicSummary[packVatName] += invPack.TotalPrice;
                        vatNetSummary[packVatName] += invPack.TotalPrice * invPack.VAT / 100;
                    }
                    else
                    {
                        vatBasicSummary.Add(new KeyValuePair<string, decimal>(packVatName, invPack.TotalPrice));
                        vatNetSummary.Add(new KeyValuePair<string, decimal>(packVatName, invPack.TotalPrice * invPack.VAT / 100));
                    }
                }
            }

            //Treatments

            foreach (InvoiceTreatment iTreatment in invoice.InvoiceTreatments)
            {
                string treatmentTypeId = iTreatment.TreatmentTypeId.ToString();
                if (dicTreatmentSummary.ContainsKey(treatmentTypeId))
                    dicTreatmentSummary[treatmentTypeId] += iTreatment.TotalPrice;
                else
                {
                    dicTreatmentSummary.Add(new KeyValuePair<string, decimal>(treatmentTypeId, iTreatment.TotalPrice));
                    dicInvTreatment.Add(new KeyValuePair<string, InvoiceTreatment>(treatmentTypeId, iTreatment));
                }

                var treatmentVatName = iTreatment.Languages.Count > 0 ? iTreatment.Languages[0].VAT : "";
                if (vatBasicSummary.ContainsKey(treatmentVatName))
                {
                    vatBasicSummary[treatmentVatName] += iTreatment.TotalPrice;
                    vatNetSummary[treatmentVatName] += iTreatment.TotalPrice * iTreatment.VAT / 100;
                }
                else
                {
                    vatBasicSummary.Add(new KeyValuePair<string, decimal>(treatmentVatName, iTreatment.TotalPrice));
                    vatNetSummary.Add(new KeyValuePair<string, decimal>(treatmentVatName, iTreatment.TotalPrice * iTreatment.VAT / 100));
                }
            }

            int preSign = (invoice.InvoiceType == InvoiceType.Debit ? 1 : -1);
            foreach (InvoiceCharge1 invCharge in invoice.Charges)
            {
                string chargeName = invCharge.Languages[0].Name;
                if (dicChargeSummary.ContainsKey(chargeName))
                    dicChargeSummary[chargeName] += invCharge.TotalPrice * preSign;
                else
                {
                    dicChargeSummary.Add(new KeyValuePair<string, decimal>(chargeName, invCharge.TotalPrice * preSign));
                    dicInvCharges.Add(new KeyValuePair<string, InvoiceCharge1>(chargeName, invCharge));
                }

                var chargeVatName = invCharge.Languages[0].VAT;
                if (vatBasicSummary.ContainsKey(chargeVatName))
                {
                    vatBasicSummary[chargeVatName] += invCharge.TotalPrice * preSign;
                    vatNetSummary[chargeVatName] += (invCharge.TotalPrice * invCharge.VAT / 100) * preSign;
                }
                else
                {
                    vatBasicSummary.Add(new KeyValuePair<string, decimal>(chargeVatName, invCharge.TotalPrice * preSign));
                    vatNetSummary.Add(new KeyValuePair<string, decimal>(chargeVatName, (invCharge.TotalPrice * invCharge.VAT / 100) * preSign));
                }
            }

            decimal subTotal = 0, totalMeet = 0;
            //Product
            foreach (KeyValuePair<string, decimal> keyValuePair in dicProdSummary)
            {
                InvoiceProduct invProd = dicInvProducts[keyValuePair.Key];
                InvoiceProductLanguage enUs = invProd.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? invProd.Languages[0];
                InvoiceProductLanguage nlNl = invProd.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? invProd.Languages[0];
                InvoiceProductLanguage deDe = invProd.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? invProd.Languages[0];

                stringBuilder.Append(string.Format("<ProductPack><Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name><Net>{3}</Net></ProductPack>",
                    enUs.SpeciesName, nlNl.SpeciesName, deDe.SpeciesName, keyValuePair.Value.ToString("#,##0.00")));

                subTotal += keyValuePair.Value;
                totalMeet += keyValuePair.Value;
            }

            //Package 
            foreach (KeyValuePair<string, decimal> keyValuePair in dicPackSummary)
            {
                InvoicePackage invPack = dicInvPacks[keyValuePair.Key];
                InvoicePackageLanguage enUs = invPack.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? invPack.Languages[0];
                InvoicePackageLanguage nlNl = invPack.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? invPack.Languages[0];
                InvoicePackageLanguage deDe = invPack.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? invPack.Languages[0];

                stringBuilder.Append(string.Format("<ProductPack><Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name><Net>{3}</Net></ProductPack>",
                    enUs.Name, nlNl.Name, deDe.Name, keyValuePair.Value.ToString("#,##0.00")));

                subTotal += keyValuePair.Value;
                totalMeet += keyValuePair.Value;
            }

            //Decomposition
            foreach (KeyValuePair<string, decimal> keyValuePair in dicDeCmpSummary)
            {
                InvoiceDecomposition invDecomposition = dicInvDeCmps[keyValuePair.Key];
                var deCmpType = invDecomposition.DecomposeType;
                stringBuilder.Append(string.Format("<ProductPack>" +
                                                   "<Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name>" +
                                                   "<Net>{3}</Net></ProductPack>",
                   deCmpType.GetName("en-US"), deCmpType.GetName("nl-NL"), deCmpType.GetName("de-DE"), keyValuePair.Value.ToString("#,##0.00")));

                subTotal += keyValuePair.Value;
                totalMeet += keyValuePair.Value;
            }

            //AddOn
            foreach (KeyValuePair<string, decimal> keyValuePair in dicAddOnSummary)
            {
                InvoiceAddOn invAddOn = dicInvAddOns[keyValuePair.Key];
                InvoiceAddOnLanguage enUs = invAddOn.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? invAddOn.Languages[0];
                InvoiceAddOnLanguage nlNl = invAddOn.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? invAddOn.Languages[0];
                InvoiceAddOnLanguage deDe = invAddOn.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? invAddOn.Languages[0];

                stringBuilder.Append(string.Format("<ProductPack><Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name><Net>{3}</Net></ProductPack>",
                    enUs.Name, nlNl.Name, deDe.Name, keyValuePair.Value.ToString("#,##0.00")));

                subTotal += keyValuePair.Value;
                totalMeet += keyValuePair.Value;
            }

            //Charge
            foreach (KeyValuePair<string, decimal> keyValuePair in dicChargeSummary)
            {
                InvoiceCharge1 invCharge = dicInvCharges[keyValuePair.Key];
                InvoiceChargeLanguage enUs = invCharge.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? invCharge.Languages[0];
                InvoiceChargeLanguage nlNl = invCharge.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? invCharge.Languages[0];
                InvoiceChargeLanguage deDe = invCharge.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? invCharge.Languages[0];

                stringBuilder.Append(string.Format("<ProductPack><Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name><Net>{3}</Net></ProductPack>",
                    enUs.Name, nlNl.Name, deDe.Name, keyValuePair.Value.ToString("#,##0.00")));

                subTotal += keyValuePair.Value;
                totalMeet += keyValuePair.Value;
            }
            
            //Treatment
            foreach (KeyValuePair<string, decimal> keyValuePair in dicTreatmentSummary)
            {
                InvoiceTreatment invTreatment = dicInvTreatment[keyValuePair.Key];
                var treatmentType = factory.GetTreatmentTypeRepository().GetOne(invTreatment.TreatmentTypeId.ToString());
                
                stringBuilder.Append(string.Format("<ProductPack>" +
                                                   "<Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name>" +
                                                   "<Net>{3}</Net></ProductPack>",
                   treatmentType.GetName("en-US"), treatmentType.GetName("nl-NL"), treatmentType.GetName("de-DE"), keyValuePair.Value.ToString("#,##0.00")));

                subTotal += keyValuePair.Value;
                totalMeet += keyValuePair.Value;
            }

            stringBuilder.Append("</ProductAndPackages><Vats>");

            //Vat
            foreach (KeyValuePair<string, decimal> keyValuePair in vatBasicSummary)
            {
                stringBuilder.Append(string.Format("<vat><Name><![CDATA[{0}]]></Name><Basis>{1}</Basis><Net>{2}</Net></vat>",
                    keyValuePair.Key, keyValuePair.Value.ToString("#,##0.00"), vatNetSummary[keyValuePair.Key] > 0 ? vatNetSummary[keyValuePair.Key].ToString("#,##0.00") : string.Empty));

                totalMeet += vatNetSummary[keyValuePair.Key];
            }
            stringBuilder.Append("</Vats>");

            if (invoice.InvoiceStatus == InvoiceStatus.ReverseInvoice)
            {
                stringBuilder.Append(string.Format("<SubTotal>-{0}</SubTotal>", subTotal.ToString("#,##0.00")));
                stringBuilder.Append(string.Format("<TotalMeet>-{0}</TotalMeet>", totalMeet.ToString("#,##0.00")));
            }
            else
            {
                stringBuilder.Append(string.Format("<SubTotal>{0}</SubTotal>", subTotal.ToString("#,##0.00")));
                stringBuilder.Append(string.Format("<TotalMeet>{0}</TotalMeet>", totalMeet.ToString("#,##0.00")));
            }

            stringBuilder.Append("</Summary>");

            return stringBuilder.ToString();
        }

        private string BuidingDetailSession(Invoice invoice)
        {
            var stringBuilder = new StringBuilder("<Details><Producers>");

            IList<string> lstOrgIds = invoice.Products.Select(it => it.OrgId).Distinct().ToList();
            foreach (string orgId in lstOrgIds)
            {
                stringBuilder.Append("<Producer>");

                string id = orgId;
                Organization producer = orgRepo.GetOne(id);
                ChainEntity chainEntity = producer.ChainEntities[0];

                stringBuilder.Append(string.Format("<Info><Name><![CDATA[{0}]]></Name>", producer.Name));

                stringBuilder.Append(string.Format("<Address><![CDATA[{0}]]></Address>", chainEntity.Addresses.First().ToString()));
                stringBuilder.Append(string.Format("<VATNumber><![CDATA[{0}]]></VATNumber>", chainEntity.VatNumber));
                stringBuilder.Append(string.Format("<CoCNumber><![CDATA[{0}]]></CoCNumber>", chainEntity.CocNumber));
                stringBuilder.Append(string.Format("<BankAccountNumber><![CDATA[{0}]]></BankAccountNumber></Info>", chainEntity.BankAccount1));

                stringBuilder.Append("<Shipments>");
                foreach (InvoiceShipment shipment in invoice.Shipments.Where(it => it.FromOrgId.Equals(id)))
                {
                    stringBuilder.Append("<Shipment>");

                    InvoiceShipment shm = shipment;
                    stringBuilder.Append(string.Format("<Date val=\"{0}\">", shm.ShipmentDate.ToString("dd-MM-yyyy")));
                    stringBuilder.Append(string.Format("<DayOfWeek><![CDATA[{0}]]></DayOfWeek></Date>", shm.ShipmentDate.DayOfWeek));
                    stringBuilder.Append(string.Format("<ShipmentId><![CDATA[{0}]]></ShipmentId>", shm.ShipmentId));

                    var invoicePackages = new List<InvoicePackage>();
                    var invoiceAddOns = new List<InvoiceAddOn>();
                    decimal totalProdExVat = 0, totalPackExVat = 0;

                    //Binding Product
                    stringBuilder.Append(string.Format("<Products>"));
                    foreach (InvoiceProduct product in invoice.Products.Where(it => it.Shipment.ShipmentId == shm.ShipmentId))
                    {
                        decimal totalPrdExVat = product.Amount * product.Price;
                        totalProdExVat += totalPrdExVat;

                        stringBuilder.Append(string.Format("<Product><Id><![CDATA[{0}]]></Id>", product.ProductId));
                        InvoiceProductLanguage enUs = product.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? product.Languages[0];
                        InvoiceProductLanguage nlNl = product.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? product.Languages[0];
                        InvoiceProductLanguage deDe = product.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? product.Languages[0];

                        stringBuilder.Append(string.Format("<Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name>",
                            enUs.SpeciesName, nlNl.SpeciesName, deDe.SpeciesName));

                        stringBuilder.Append(string.Format("<ProdType><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></ProdType>",
                            enUs.ProdTypeName, nlNl.ProdTypeName, deDe.ProdTypeName));

                        stringBuilder.Append(string.Format("<Color><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Color>",
                            enUs.ColorName, nlNl.ColorName, deDe.ColorName));

                        stringBuilder.Append(string.Format("<CategoryType><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></CategoryType>",
                            enUs.CategoryTypeName, nlNl.CategoryTypeName, deDe.CategoryTypeName));

                        stringBuilder.Append(string.Format("<Category><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Category>",
                            enUs.CategoryName, nlNl.CategoryName, deDe.CategoryName));

                        stringBuilder.Append(string.Format("<ProdAttributes><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></ProdAttributes>",
                            enUs.AdditionalAttributes, nlNl.AdditionalAttributes, deDe.AdditionalAttributes));

                        stringBuilder.Append(string.Format("<Amount><![CDATA[{0}]]></Amount>", product.Amount));

                        stringBuilder.Append(string.Format("<Uom><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Uom>", enUs.UomName, nlNl.UomName, deDe.UomName));

                        stringBuilder.Append(string.Format("<Price><![CDATA[{0}]]></Price>", product.Price.ToString("#,##0.00")));
                        stringBuilder.Append(string.Format("<TotalExVat><![CDATA[{0}]]></TotalExVat>", totalPrdExVat.ToString("#,##0.00")));
                        stringBuilder.Append(string.Format("<Vat><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Vat>", enUs.VAT, nlNl.VAT, deDe.VAT));

                        stringBuilder.Append("</Product>");

                        invoicePackages.AddRange(product.Packages.ToArray());
                        invoiceAddOns.AddRange(product.AddOns.ToArray());
                    }

                    foreach (InvoiceCompositeProduct cmpProd in invoice.CompositeProducts.Where(it => it.ShipmentItemId == shm.ShipmentId)) invoicePackages.AddRange(cmpProd.Packages.ToArray());

                    stringBuilder.Append("</Products>");

                    //Binding Pacakge
                    if (invoicePackages.Count > 0)
                    {
                        stringBuilder.Append("<Packages>");
                        foreach (InvoicePackage package in invoicePackages)
                        {
                            stringBuilder.Append("<Package>");

                            decimal totalExVat = package.Price * package.Amount;
                            totalPackExVat += totalExVat;

                            InvoicePackageLanguage enUs = package.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? package.Languages[0];
                            InvoicePackageLanguage nlNl = package.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? package.Languages[0];
                            InvoicePackageLanguage deDe = package.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? package.Languages[0];

                            stringBuilder.Append(string.Format("<RefId><![CDATA[{0}]]></RefId>", (package.ProductId != null) ? Convert.ToString(package.ProductId) : string.Format("CMP_{0}", package.CmpProductId)));
                            stringBuilder.Append(string.Format("<Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name>", enUs.Name, nlNl.Name, deDe.Name));

                            stringBuilder.Append(string.Format("<PriceType><![CDATA[{0}]]></PriceType>", package.PriceType));
                            stringBuilder.Append(string.Format("<Amount><![CDATA[{0}]]></Amount>", package.Amount));
                            stringBuilder.Append(string.Format("<Price><![CDATA[{0}]]></Price>", package.Price.ToString("#,##0.00")));
                            stringBuilder.Append(string.Format("<TotalExVat><![CDATA[{0}]]></TotalExVat>", totalExVat.ToString("#,##0.00")));
                            stringBuilder.Append(string.Format("<Vat><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Vat>", enUs.VAT, nlNl.VAT, deDe.VAT));

                            stringBuilder.Append("</Package>");
                        }
                        stringBuilder.Append("</Packages>");
                    }

                    if (invoice.Decompositions.Count > 0)
                    {
                        stringBuilder.Append("<Decompositions>");
                        foreach (var invDecompose in invoice.Decompositions)
                        {
                            var dcmpProd = invDecompose.ProductSupply;
                            var dcmpType = invDecompose.DecomposeType;
                            var enUs = invDecompose.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? invDecompose.Languages[0];
                            var nlNl = invDecompose.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? invDecompose.Languages[0];
                            var deDe = invDecompose.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? invDecompose.Languages[0];

                            stringBuilder.Append(string.Format("<Decomposition><ProdParentId><![CDATA[{0}]]></ProdParentId>", dcmpProd.ParentId));
                            stringBuilder.Append(string.Format("<ProdId><![CDATA[{0}]]></ProdId>", dcmpProd.Uid));
                            stringBuilder.Append(string.Format("<ProdName><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></ProdName>",
                               dcmpProd.Species.GetName("en-US"), dcmpProd.Species.GetName("nl-NL"), dcmpProd.Species.GetName("de-DE")));

                            stringBuilder.Append(string.Format("<DecomposeTypeId><![CDATA[{0}]]></DecomposeTypeId>", (dcmpType != null) ? dcmpType.Uid.ToString() : string.Empty));
                            stringBuilder.Append(string.Format("<DecomposePeriod><![CDATA[{0}]]></DecomposePeriod>",
                                (dcmpType != null) ? string.Format("{0:dd/MM/yyyy HH:mm} - {1:dd/MM/yyyy HH:mm}", invDecompose.FromDateTime, invDecompose.ToDateTime) : string.Empty));
                            stringBuilder.Append(
                                string.Format("<DecomposeTypeName><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></DecomposeTypeName>",
                                (dcmpType != null) ? dcmpType.GetName("en-US") : string.Empty,
                                (dcmpType != null) ? dcmpType.GetName("nl-NL") : string.Empty,
                                (dcmpType != null) ? dcmpType.GetName("de-DE") : string.Empty));

                            stringBuilder.Append(string.Format("<Amount><![CDATA[{0}]]></Amount>", dcmpProd.AvailableForSale));
                            stringBuilder.Append(string.Format("<Uom><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Uom>",
                                dcmpProd.Uom.GetName("en-US"), dcmpProd.Uom.GetName("nl-NL"), dcmpProd.Uom.GetName("de-DE")));
                            stringBuilder.Append(string.Format("<Price><![CDATA[{0}]]></Price>", (dcmpType != null) ? invDecompose.Price.ToString("#,##0.00") : string.Empty));
                            stringBuilder.Append(string.Format("<TotalExVat><![CDATA[{0}]]></TotalExVat>",
                                (dcmpType != null) ? invDecompose.TotalPrice.ToString("#,##0.00") : string.Empty));
                            stringBuilder.Append(string.Format("<Vat><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Vat>",
                                (dcmpType != null) ? enUs.VAT : string.Empty, (dcmpType != null) ? nlNl.VAT : string.Empty, (dcmpType != null) ? deDe.VAT : string.Empty));
                            stringBuilder.Append("</Decomposition>");
                        }

                        stringBuilder.Append("</Decompositions>");
                    }

                    //Binding AddOns
                    if (invoiceAddOns.Count > 0)
                    {
                        stringBuilder.Append("<AddOns>");
                        foreach (InvoiceAddOn addOn in invoiceAddOns)
                        {
                            stringBuilder.Append("<AddOn>");

                            decimal totalExVat = addOn.Price * addOn.Amount;
                            totalPackExVat += totalExVat;

                            InvoiceAddOnLanguage enUs = addOn.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) ?? addOn.Languages[0];
                            InvoiceAddOnLanguage nlNl = addOn.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) ?? addOn.Languages[0];
                            InvoiceAddOnLanguage deDe = addOn.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) ?? addOn.Languages[0];

                            stringBuilder.Append(string.Format("<RefId><![CDATA[{0}]]></RefId>", addOn.InvoiceProduct.ProductId));
                            stringBuilder.Append(string.Format("<Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name>", enUs.Name, nlNl.Name, deDe.Name));

                            stringBuilder.Append(string.Format("<Amount><![CDATA[{0}]]></Amount>", addOn.Amount));
                            stringBuilder.Append(string.Format("<Price><![CDATA[{0}]]></Price>", addOn.Price.ToString("#,##0.00")));
                            stringBuilder.Append(string.Format("<TotalExVat><![CDATA[{0}]]></TotalExVat>", totalExVat.ToString("#,##0.00")));
                            stringBuilder.Append(string.Format("<Vat><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Vat>", enUs.VAT, nlNl.VAT, deDe.VAT));

                            stringBuilder.Append("</AddOn>");
                        }
                        stringBuilder.Append("</AddOns>");
                    }

                    //Binding Treatments
                    if (invoice.InvoiceTreatments.Count > 0)
                    {
                        stringBuilder.Append("<Treatments>");
                        foreach (var iTreatment in invoice.InvoiceTreatments)
                        {
                            stringBuilder.Append("<Treatment>");                            
                            var enUs = iTreatment.Languages.FirstOrDefault(it => it.LangCode.Equals("en-US")) != null ? iTreatment.Languages[0].VAT : iTreatment.VatName;
                            var nlNl = iTreatment.Languages.FirstOrDefault(it => it.LangCode.Equals("nl-NL")) != null ? iTreatment.Languages[0].VAT : iTreatment.VatName;
                            var deDe = iTreatment.Languages.FirstOrDefault(it => it.LangCode.Equals("de-DE")) != null ? iTreatment.Languages[0].VAT : iTreatment.VatName;

                            stringBuilder.Append(string.Format("<ProductId><![CDATA[{0}]]></ProductId>", iTreatment.ProductSupply.Uid));
                            //stringBuilder.Append(string.Format("<Name><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Name>", iTreatment.ProductSupply.Na., nlNl.Name, deDe.Name));

                            //stringBuilder.Append(string.Format("<#OfPackages><![CDATA[{0}]]></#OfPackage>", iTreatment.));
                            stringBuilder.Append(string.Format("<Cost><![CDATA[{0}]]></Cost>", iTreatment.Cost + " " + iTreatment.CostCurrency));
                            stringBuilder.Append(string.Format("<CostUnit><![CDATA[{0}]]></CostUnit>", iTreatment.CostUnit));                            
                            stringBuilder.Append(string.Format("<TotalExVat><![CDATA[{0}]]></TotalExVat>", invoice.TotalTreatmentPrice.ToString("#,##0.00")));
                            stringBuilder.Append(string.Format("<TotalInclVat><![CDATA[{0}]]></TotalInclVat>", invoice.TotalTreatmentVAT.ToString("#,##0.00")));
                            stringBuilder.Append(string.Format("<Vat><enUS><![CDATA[{0}]]></enUS><nlNL><![CDATA[{1}]]></nlNL><deDE><![CDATA[{2}]]></deDE></Vat>", enUs , nlNl, deDe));

                            stringBuilder.Append("</Treatment>");

                            
                        }

                        stringBuilder.Append("</Treatments>");
                    }


                    stringBuilder.Append(string.Format("<TotalProductPriceExVat><![CDATA[{0}]]></TotalProductPriceExVat>", totalProdExVat.ToString("#,##0.00")));
                    stringBuilder.Append(string.Format("<TotalPackagePriceExVat><![CDATA[{0}]]></TotalPackagePriceExVat>", totalPackExVat > 0 ? totalPackExVat.ToString("#,##0.00") : string.Empty));

                    stringBuilder.Append("</Shipment>");
                }
                stringBuilder.Append("</Shipments></Producer>");
            }

            stringBuilder.Append("</Producers></Details>");
            return stringBuilder.ToString();
        }
    }
}
