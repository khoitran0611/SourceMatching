﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class CompositeProductFavouriteServices : BaseService
    {
        public static IList<CompositeProductFavourite> FindBy(string orgId, string cmpPrdFavName)
        {
            return factory.GetCompositeProductFavouriteRepository().Find(new CompositeProductFavouriteByNameSpecification(orgId, cmpPrdFavName)).ToList();
        }

        public static CompositeProductFavourite SaveOrUpdate(CompositeProductFavourite cmpProdFav, IList<Products4CompositeProductFavourite> products4Composites)
        {
            if (cmpProdFav.Uid != 0)
            {
                //cmpProdFav.RemoveAllProd4CompositeFav();
                IList<Products4CompositeProductFavourite> removeProdFavs = cmpProdFav.Prod4CompositeFav.Where(
                    prodFav => !products4Composites.Any(it => it.Uid != 0 && it.ProdFavourite.Uid == prodFav.ProdFavourite.Uid)).ToList();
                foreach (var prodFav in removeProdFavs) cmpProdFav.RemoveProd4CompositeFav(prodFav);
            }

            foreach (var prodFav in products4Composites.Where(it => it.Uid == 0))
            {
                cmpProdFav.AddProd4CompositeFav(prodFav);

                //if (cmpProdFav.Uid != 0)
                //    cmpProdFav.AddProd4CompositeFav(prodFav);
                //else
                //{
                //var copyObj = prodFav.Copy();
                //cmpProdFav.AddProd4CompositeFav(copyObj);
                //}
            }

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                if (cmpProdFav.Uid == 0)
                    factory.GetCompositeProductFavouriteRepository().Add(cmpProdFav);
                else
                    factory.GetCompositeProductFavouriteRepository().Store(cmpProdFav);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return cmpProdFav;
        }

        public static void Delete(CompositeProductFavourite cmpProdFav)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                factory.GetCompositeProductFavouriteRepository().Remove(cmpProdFav);

                transactionManager.CommitTransaction();

            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

    }
}
