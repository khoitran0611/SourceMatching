﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class AgreementProcessServices : BaseService
    {
        public static AgreementProcess4CompositeProductBuyerOffer AddSellerOffer(AgreementProcess4CompositeProductBuyerOffer sellerOffer)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();


                factory.GetAgreementProcess4CompositeProductBuyerOfferRepository().Add(sellerOffer);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return sellerOffer;
        }

        public static AgreementProcess4CompositeProduct UpdateAgmtProcess4CompositeProd(AgreementProcess4CompositeProduct agmtProcess)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                agmtProcess.UpdatedAt = DateTime.Now;

                factory.GetAgreementProcess4CompositeProductRepository().Store(agmtProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return agmtProcess;
        }

        public static AgreementProcess4CompositeProduct SaveOrUpdateAgmtProcess4CompositeProd(AgreementProcess4CompositeProduct agmtProcess, IList<AgreementProcess4CompositeProductPriceDetail> priceDetails,
            string sellerIds, string supplierIds)
        {

            var transactionManager = new TransactionManager();
            try
            {
                if (agmtProcess.Uid != 0) agmtProcess.RemoveAllInvitedBuyer();
                IList<Organization> lstTradingOrgs = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(sellerIds)).ToList();
                foreach (Organization org in lstTradingOrgs) agmtProcess.AddInvitedBuyer(org);

                if (agmtProcess.Uid != 0) agmtProcess.RemoveAllSupplier();
                IList<Organization> lstSuppliers = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(supplierIds)).ToList();
                foreach (Organization supplier in lstSuppliers) agmtProcess.AddSupplier(supplier);

                if (agmtProcess.Uid != 0) agmtProcess.RemoveAllPriceDetail();
                foreach (var priceDetail in priceDetails) agmtProcess.AddPriceDetail(priceDetail);

                transactionManager.BeginTransaction();

                agmtProcess.UpdatedAt = DateTime.Now;
                if (agmtProcess.Uid != 0)
                    factory.GetAgreementProcess4CompositeProductRepository().Store(agmtProcess);
                else
                    factory.GetAgreementProcess4CompositeProductRepository().Add(agmtProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return agmtProcess;
        }

        public static void DeleteAgreementProcess4CompositeProd(AgreementProcess4CompositeProduct agmtProcess)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                factory.GetAgreementProcess4CompositeProductRepository().Remove(agmtProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static IList<AgreementProcess4CompositeProduct> FindAgmtProcess4CompositeProductInPeriod(string sellerId, string fromDate, string toDate)
        {
            try
            {
                string queryString = "select distinct agmt from AgreementProcess4CompositeProduct agmt where agmt.SellerId = :sellerOrgId";
                if (!string.IsNullOrEmpty(fromDate)) queryString += " and agmt.StartAt >= :fromDate";
                if (!string.IsNullOrEmpty(toDate)) queryString += " and agmt.StartAt <= :toDate";
                queryString += " order by agmt.StartAt desc";

                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameter("sellerOrgId", sellerId);
                if (!string.IsNullOrEmpty(fromDate)) query.SetParameter("fromDate", Convert.ToDateTime(fromDate).Date);
                if (!string.IsNullOrEmpty(toDate)) query.SetParameter("toDate", Convert.ToDateTime(toDate).AddDays(1).Date);

                return query.List().Cast<AgreementProcess4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<AgreementProcess4CompositeProduct> FindInvitedAgreementProcess4CompositeProd(string fromSeller, string toBuyer, string processType)
        {
            try
            {
                var queryString =
                    "select ap from AgreementProcess4CompositeProduct as ap join ap.InvitedBuyerOrgs as invtOrg where invtOrg.Uid = :buyerId";
                if (!string.IsNullOrEmpty(fromSeller)) queryString += " and ap.SellerId = :sellerId ";
                if (!string.IsNullOrEmpty(processType)) queryString += " and ap.ProcessType = :processType ";
                queryString +=
                    " and (ap.WonBuyerId = :buyerId or (ap.WonBuyerId is null and ap.CloseAt >= :curDateTime))";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                if (!string.IsNullOrEmpty(fromSeller)) query.SetParameter("sellerId", fromSeller);
                if (!string.IsNullOrEmpty(processType))
                {
                    var prcType = (SalesProcessType)Enum.Parse(typeof(SalesProcessType), processType);
                    query.SetParameter("processType", Convert.ToInt32(prcType));
                }
                query.SetParameter("buyerId", toBuyer);
                query.SetParameter("curDateTime", DateTime.Now);

                return query.List().Cast<AgreementProcess4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static AgreementProcess4CompositeProductBuyerOffer FindAgreementOfferOnAgmtProcessByOrg(long agmtProcessId, string orgId)
        {
            try
            {
                const string queryString = "select ap from AgreementProcess4CompositeProductBuyerOffer as ap where ap.AgmtProcess.Uid = :agmtProcessId and ap.BuyerId = :buyerId";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("agmtProcessId", agmtProcessId);
                query.SetParameter("buyerId", orgId);

                query.SetMaxResults(1);
                return query.List().Cast<AgreementProcess4CompositeProductBuyerOffer>().ToList()[0];
            }
            catch
            {
                return null;
            }
        }

        public static IList<AgreementProcess4CompositeProductBuyerOffer> FindAllOfferOnAgreementProcess(long agmtProcessId)
        {
            try
            {
                const string queryString = "select ap from AgreementProcess4CompositeProductBuyerOffer as ap where ap.AgmtProcess.Uid = :agmtProcessId order by ap.OfferPrice desc";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("agmtProcessId", agmtProcessId);

                query.SetMaxResults(1);
                return query.List().Cast<AgreementProcess4CompositeProductBuyerOffer>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<AgreementProcess4CompositeProduct> FindFinalAgreementProcess4CompsiteProd()
        {
            const string queryString = "select distinct ap from AgreementProcess4CompositeProduct ap where (ap.CloseAt = :closeDateTime or ap.CloseAt = :closeDateTimeSub1) and ap.IsMatched = 0";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<AgreementProcess4CompositeProduct>().ToList();
        }
    }
}
