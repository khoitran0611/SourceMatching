﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using Aspose.Pdf.Generator;

namespace AgriMore.Logistics.Data.Services
{
    public class ShipmentListServices : BaseService
    {
        private const string ShipmentListXslt = "/Templates/ShipmentList/xslt/Default.xslt";
        public static long UpdateShipmentList(IList<TmpShipmentItem4CmpProd> SelectedCmpProd4DispatchList, DateTime fromDate, DateTime toDate, string shipmentFile, string createdBy)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                string shipmentProdIds = SelectedCmpProd4DispatchList.Aggregate(string.Empty, (current, it) => current + (it.Uid + ","));
                if (!string.IsNullOrEmpty(shipmentProdIds)) shipmentProdIds = shipmentProdIds.Substring(0, shipmentProdIds.Length - 1);
                var shipmentList = new ShipmentList4CompositeProd
                {
                    ProductFromDate = fromDate,
                    ProductToDate = toDate,
                    ShipmentFile = shipmentFile,
                    CreatedBy = createdBy,
                    CreatedAt = DateTime.Now,
                    CompositeProdIds = shipmentProdIds
                };

                IList<string> listBuyerIds = SelectedCmpProd4DispatchList.Select(it => it.BuyerId).Distinct().ToList();
                foreach (var buyer in listBuyerIds)
                {
                    IList<TmpShipmentItem4CmpProd> item = SelectedCmpProd4DispatchList.Where(it => it.BuyerId.Equals(buyer)).ToList();

                    string cmpProdIds = item.Aggregate(string.Empty, (cur, it) => string.Format("{0}{1},", cur, it.Uid));
                    if (!string.IsNullOrEmpty(cmpProdIds)) cmpProdIds = cmpProdIds.Substring(0, cmpProdIds.Length - 1);

                    string dispatchProdIds = item.Aggregate(string.Empty, (cur, it) => string.Format("{0}{1},", cur, it.ProdUids.Replace(" ", string.Empty)));
                    if (!string.IsNullOrEmpty(dispatchProdIds)) dispatchProdIds = dispatchProdIds.Substring(0, dispatchProdIds.Length - 1);

                    var shipmentItem = new ShipmentItem4CompositeProd
                    {
                        Buyer = factory.GetOrganizationRepository().GetOne(buyer),
                        Seller = factory.GetOrganizationRepository().GetOne(item[0].SellerId),
                        CompositeProdIds = cmpProdIds,
                        DispatchProdUids = dispatchProdIds
                    };

                    shipmentList.AddShipmentItem4CompositeProd(shipmentItem);
                }

                factory.GetShipmentList4CompositeProdRepository().Add(shipmentList);
                factory.GetShipmentList4CompositeProdRepository().Flush();

                IList<ShipmentItem4CompositeProd> shipmentItems = shipmentList.ShipmentItems;
                foreach (var item in shipmentItems)
                {
                    IList<CompositeProductSupply> cmpProds = CompositeProductSupplyServices.GetCompositeProductByUids(item.CompositeProdIds);
                    foreach (CompositeProductSupply cmpProd in cmpProds)
                    {
                        CompositeProductSupply prod = cmpProd;
                        ShipmentItem4CompositeProd shmtItem = shipmentItems.Where(it => it.CompositeProdIds.Split(',').Contains(prod.Uid.ToString())).SingleOrDefault();

                        prod.DispatchDate = DateTime.Now;
                        prod.ShipmentItemId = shmtItem.Uid;
                        prod.Status = CompositeProdStatus.Ready4Invoice;
                        factory.GetCompositeProductSupplyRepository().Store(prod);

                        IList<ProductSupplyForecast> lstProdSupplies = ProductSupplyForecastServices.GetProductSupplyByIds(shmtItem.DispatchProdUids);
                        foreach (ProductSupplyForecast prodSupply in lstProdSupplies)
                        {
                            //prodSupply.ShipmentId = shmtItem.Uid;
                            prodSupply.DespatchDate = DateTime.Now;
                            prodSupply.SellerStatus = SellerStatus.Shipped;
                            prodSupply.AmountSoldShipped = prodSupply.AmountSoldPacked = prodSupply.CommitedAmount;
                            factory.GetProductSuppyForecastRepository().Store(prodSupply);
                        }
                    }
                }

                transactionManager.CommitTransaction();

                return shipmentList.Uid;
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static IList<ShipmentList4CompositeProd> GetShipmentList4CompositeProd(string buyerFilterId, string fromDate, string toDate)
        {
            try
            {
                string queryString = "select distinct shml from ShipmentList4CompositeProd shml join shml.ShipmentItems as shmit where 1 =1 ";
                if (!string.IsNullOrEmpty(buyerFilterId)) queryString += " and shmit.Buyer.Uid = :buyerId";
                if (!string.IsNullOrEmpty(fromDate)) queryString += " and shml.CreatedAt >= :fromDate";
                if (!string.IsNullOrEmpty(toDate)) queryString += " and shml.CreatedAt < :toDate";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                if (!string.IsNullOrEmpty(buyerFilterId)) query.SetParameter("buyerId", buyerFilterId);
                if (!string.IsNullOrEmpty(fromDate)) query.SetParameter("fromDate", Convert.ToDateTime(fromDate).Date);
                if (!string.IsNullOrEmpty(toDate)) query.SetParameter("toDate", Convert.ToDateTime(toDate).AddDays(1).Date);
                return query.List().Cast<ShipmentList4CompositeProd>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static void GenerateShipmentList(IList<ProductSupplyForecast> productSupplies, string receiverOrgId, DateTime prodFrom, DateTime prodTo, string createUserId,
            string xmlShipmentList, string shipmentStorePath, string loadingAdviceDocName, string loadingAdviceDocPath)
        {
            string shipmentListName = string.Empty;
            if (!string.IsNullOrEmpty(xmlShipmentList))
            {
                var pdf = new Pdf();
                var xmlData = new XmlDocument();
                xmlData.LoadXml(xmlShipmentList);

                var xslFo = new XmlDocument();
                xslFo.Load(System.Web.HttpContext.Current.Server.MapPath(ShipmentListXslt));

                string storePath =
                    System.Web.HttpContext.Current.Server.MapPath(string.Format("/{0}", shipmentStorePath));
                if (!System.IO.Directory.Exists(storePath)) System.IO.Directory.CreateDirectory(storePath);

                pdf.BindFO(xmlData, xslFo);
                shipmentListName = string.Format("ShipmentList_{0}.pdf", DateTime.Now.Ticks);
                pdf.Save(System.IO.Path.Combine(storePath, shipmentListName));
            }

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                string shipmentProdIds = string.Join(",", productSupplies.Select(it => it.Uid.ToString()).ToArray());
                var shipmentList = new ShipmentList
                {
                    ProdFromDate = prodFrom,
                    ProdToDate = prodTo,
                    ShipmentFile = shipmentListName,
                    CreatedBy = createUserId,
                    CreatedAt = DateTime.Now,
                    ShipmentProdIds = shipmentProdIds,
                    LoadingAdviceDocName = loadingAdviceDocName,
                    LoadingAdviceDocPath = loadingAdviceDocPath
                };

                foreach (var productSupply in productSupplies)
                {
                    var purchaseOrgId = string.IsNullOrEmpty(productSupply.PurchaseOrgId) ? receiverOrgId : productSupply.PurchaseOrgId;
                    var shipmentItem = new ShipmentItem
                                       {
                                           DispatchUids = productSupply.Uid.ToString(),
                                           Grower = productSupply.Organization,
                                           Buyer = factory.GetOrganizationRepository().GetOne(purchaseOrgId),
                                           Product = productSupply.Species,
                                           ShipmentList = shipmentList                                           
                                       };

                    shipmentList.AddShipmentItemToList(shipmentItem);
                }

                factory.GetShipmentListRepository().Add(shipmentList);
                factory.GetShipmentListRepository().Flush();

                IList<ShipmentItem> shipmentItems = shipmentList.ShipmentItems;
                IList<ProductSupplyForecast> shipmentProds = factory.GetProductSuppyForecastRepository().Find(new ProductForecastByIdsSpecification(shipmentProdIds)).ToList();
                foreach (ProductSupplyForecast shipmentProd in shipmentProds)
                {
                    ProductSupplyForecast prod = shipmentProd;
                    ShipmentItem shmtItem = shipmentItems.SingleOrDefault(it => it.DispatchUids.Split(',').Contains(prod.Uid.ToString()));

                    if (shmtItem != null) prod.ShipmentId = shmtItem.Uid;
                    shipmentProd.SellerStatus = SellerStatus.Shipped;
                    shipmentProd.AmountSoldPacked = shipmentProd.AvailableForSale;
                    shipmentProd.AmountSoldShipped = shipmentProd.AmountSoldPacked;
                    shipmentProd.DespatchDate = DateTime.Now;

                    factory.GetProductSuppyForecastRepository().Store(shipmentProd);
                }

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
            }
        }
    }
}
