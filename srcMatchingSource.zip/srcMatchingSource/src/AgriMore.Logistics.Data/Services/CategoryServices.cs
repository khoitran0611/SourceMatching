﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Data.NHibernate;

namespace AgriMore.Logistics.Data.Services
{
    public class CategoryServices : BaseService
    {        

        public static IEnumerable<Category> GetAvailableCategories(string currentProductId, string categoryIds)
        {
            try
            {
                const string queryString = "from Category c where c.Uid != :currentProductId and c.Uid not in (:categoryIds)";                               
                
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetInt64("currentProductId", Int64.Parse(currentProductId));
                query.SetString("categoryIds", categoryIds);
                
                return query.List().Cast<Category>().ToList();
            }
            catch
            {
                return null;
            }
        }        
    }
}
