﻿using System;
using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class PlanningPurchaseServices : BaseService
    {
        public static IList<PlanningPurchase> GetPlanningPurchaseByBuyer(string buyerId)
        {
            const string hsql = "from PlanningPurchase pp where pp.BuyerUid = :buyerId";

            var session = NHibernateHttpModule.GetSession;

            var query = session.CreateQuery(hsql);
            query.SetParameter("buyerId", buyerId);

            return query.List().Cast<PlanningPurchase>().ToList();
        }

        public static IList<PlanningPurchase> GetPlanningPurchase()
        {
            const string hsql = "select distinct pp from PlanningPurchase pp where pp.PeriodType = 2 or (pp.PurchaseTo >= :curDate and pp.PeriodType = 1)";

            var session = NHibernateHttpModule.GetSession;

            var query = session.CreateQuery(hsql);
            query.SetParameter("curDate", DateTime.Now.Date);

            return query.List().Cast<PlanningPurchase>().ToList();
        }

        public static PlanningPurchase SaveOrUpdate(PlanningPurchase plnPurchase, IList<PlanningPurchaseProcess> plnProcess)
        {
            if (plnPurchase.Uid != 0) plnPurchase.RemovePlanningPurchaseProcessFromList();
            foreach (PlanningPurchaseProcess process in plnProcess)
            {
                var purchProcess = new Domain.PlanningPurchaseProcess
                                       {
                                           ProcessType = process.ProcessType,
                                           PeriodType = process.PeriodType,
                                           Currency = process.Currency,
                                           FixedPrice = process.FixedPrice,
                                           OfferPrice = process.OfferPrice,
                                           CeilingPrice = process.CeilingPrice,
                                           BiddingMaxPrice = process.BiddingMaxPrice,
                                           AuctionMaxPrice = process.AuctionMaxPrice,
                                           AuctionMinPrice = process.AuctionMinPrice,
                                           StartAt = process.StartAt,
                                           CloseAt = process.CloseAt,
                                           StartNDays = process.StartNDays,
                                           CloseNDays = process.CloseNDays
                                       };

                plnPurchase.AddPlanningPurchaseProcessToList(purchProcess);
            }

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                plnPurchase.UpdatedAt = DateTime.Now;
                factory.GetPlanningPurchaseRepository().Store(plnPurchase);
                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return plnPurchase;
        }
    }
}
