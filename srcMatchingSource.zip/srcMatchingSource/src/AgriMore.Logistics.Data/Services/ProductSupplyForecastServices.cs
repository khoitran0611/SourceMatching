﻿using System;
using System.Configuration;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Common.Utils;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.DomainObjects;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Data.NHibernate;
using Aspose.Pdf;
using StaleObjectStateException = NHibernate.StaleObjectStateException;

namespace AgriMore.Logistics.Data.Services
{
    public class ProductSupplyForecastServices : BaseService
    {
        public static ProductSupplyForecast SplitProductSupply4AgmtPurchase(ProductSupplyForecast prodFc, string buyerId, decimal cmtAmount, decimal price)
        {
            var splitedProd = new ProductSupplyForecast(prodFc.Species, prodFc.ProdType, prodFc.Color, prodFc.CategoryType, prodFc.Category, prodFc.AvailableDate, prodFc.ExpectedAmount, prodFc.Uom,
                                                                          prodFc.User, prodFc.Organization)
                                  {
                                      SalePriodType = prodFc.SalePriodType,
                                      PurchaseOrgId = buyerId,
                                      SalesOrganization = prodFc.SalesOrganization,
                                      ParentId = prodFc.Uid,
                                      Remarks = prodFc.Remarks,
                                      Currency = prodFc.Currency,
                                      StatusType = ProductStatusType.Commited,
                                      SellerStatus = SellerStatus.CommittedSold,
                                      BuyerStatus = BuyerStatus.CommittedBought,
                                      AvailableForSale = prodFc.AvailableForSale,
                                      AvailableToOtherTcs = cmtAmount,
                                      CommitedAmount = cmtAmount,
                                      ActualAmount = cmtAmount,
                                      Price = price
                                  };

            splitedProd.PurchaseOrgId = buyerId;

            if (prodFc.AddressId != 0) splitedProd.AddressId = prodFc.AddressId;
            if (prodFc.LocationId != 0) splitedProd.LocationId = prodFc.LocationId;
            if (prodFc.Package != null) splitedProd.Package = prodFc.Package;

            if (prodFc.AdditionalAttrs != null)
                foreach (ProductAttribute prdAttr in prodFc.AdditionalAttrs)
                    splitedProd.AddProductAttributeToList(prdAttr);

            splitedProd.BuyerRefOne = prodFc.BuyerRefOne;
            splitedProd.BuyerRefTwo = prodFc.BuyerRefTwo;
            splitedProd.SellerRefOne = prodFc.SellerRefOne;
            splitedProd.SellerRefTwo = prodFc.SellerRefTwo;
            splitedProd.ProducerRefOne = prodFc.ProducerRefOne;
            splitedProd.ProducerRefTwo = prodFc.ProducerRefTwo;
            splitedProd.PackingSlip = prodFc.PackingSlip;

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                factory.GetProductSuppyForecastRepository().Add(splitedProd);

                prodFc.TotalDesiredAmount = prodFc.TotalDesiredAmount + cmtAmount;
                factory.GetProductSuppyForecastRepository().Store(prodFc);

                transactionManager.CommitTransaction();

            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return splitedProd;
        }

        public static ProductSupplyForecast CreateProduct4PurchaseProcess(string sellerOrgId, Organization supplier, string buyerOrgId, long prodFavId,
            decimal amount, decimal price, string currency, UnitOfMeasurement uom, AgriMore.Logistics.Domain.PackagingDefine packType, DateTime availDate, User createUser)
        {
            Organization seller = factory.GetOrganizationRepository().GetOne(sellerOrgId);
            ProductFavourites prodFav = factory.GetProductFavouritesRepository().GetOne(prodFavId);

            var transactionManager = new TransactionManager();
            try
            {
                //TODO:Hotfix for create product in Bidding Purchase. Will check and refactor this code later.
                try
                {
                    transactionManager.BeginTransaction();
                }
                catch (Exception)
                {
                    transactionManager.CommitTransaction();
                    transactionManager.BeginTransaction();
                }

                var prod4Purchase = new ProductSupplyForecast(prodFav.Species, prodFav.ProdType, prodFav.Color, prodFav.CategoryType, prodFav.Category, availDate, amount, uom, createUser, supplier)
                                        {
                                            Currency = currency,
                                            StatusType = ProductStatusType.Commited,
                                            SellerStatus = SellerStatus.CommittedSold,
                                            BuyerStatus = BuyerStatus.CommittedBought,
                                            PurchaseOrgId = buyerOrgId,
                                            SalesOrganization = seller,
                                            AvailableForSale = amount,
                                            CommitedAmount = amount,
                                            ActualAmount = amount,
                                            AvailableToOtherTcs = amount,
                                            Price = price
                                        };

                if (packType != null) prod4Purchase.Package = packType;
                foreach (ProductAttribute prodAttr in prodFav.AdditionalAttrs) prod4Purchase.AddProductAttributeToList(prodAttr);
                factory.GetProductSuppyForecastRepository().Add(prod4Purchase);

                transactionManager.CommitTransaction();

                return prod4Purchase;
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static void AddPackingCfm4Product(ProductSupplyForecast prod, AgriMore.Logistics.Domain.PackagingDefine packDefine, long packAmount)
        {
            if (packDefine == null) return;
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                if (packDefine.Price == 0 && packDefine.RentPrice == 0 && packDefine.DepositPrice == 0)
                {
                    var packCfm = new PackingConfirmed
                     {
                         Packing = packDefine,
                         PackingAmount = packAmount,
                         ProdConfirmed = prod,
                         PriceType = PriceType.Price,
                         AmountPerPack = packDefine.PackagingAmount
                     };

                    factory.GetPackingConfirmedRepository().Add(packCfm);
                }
                else
                {
                    for (int i = 1; i <= 3; i++)
                    {
                        var priceType = (PriceType)Enum.Parse(typeof(PriceType), i.ToString());
                        if (priceType == PriceType.Price && packDefine.Price == 0) continue;
                        if (priceType == PriceType.Rent && packDefine.RentPrice == 0) continue;
                        if (priceType == PriceType.Deposit && packDefine.DepositPrice == 0) continue;

                        var packCfm = new PackingConfirmed
                        {
                            Packing = packDefine,
                            PackingAmount = packAmount,
                            ProdConfirmed = prod,
                            PriceType = priceType,
                            AmountPerPack = packDefine.PackagingAmount
                        };

                        factory.GetPackingConfirmedRepository().Add(packCfm);
                    }
                }

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static IList<ProductSupplyForecast> GetProductSupplyByIds(string prodIds)
        {
            try
            {
                const string queryString = "select distinct prod from ProductSupplyForecast prod where prod.Uid in (:Uids)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameterList("Uids", Array.ConvertAll<string, long>(prodIds.Split(','), Convert.ToInt64));
                return query.List().Cast<ProductSupplyForecast>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<ProductSupplyForecast> GetDecomposedProduct(long[] prodIds)
        {
            var parentIds = prodIds;
            var lstDecomposedProds = new List<ProductSupplyForecast>();
            try
            {
                while (parentIds != null && parentIds.Length > 0)
                {
                    const string queryString = "select distinct prod from ProductSupplyForecast prod where prod.ParentId in (:Uids)";
                    var session = NHibernateHttpModule.GetSession;
                    var query = session.CreateQuery(queryString);

                    query.SetParameterList("Uids", parentIds);
                    var result = query.List().Cast<ProductSupplyForecast>().ToList();

                    parentIds = result.Select(it => it.Uid).ToArray();
                    lstDecomposedProds.AddRange(result.ToArray());
                }
            }
            catch
            {
                return null;
            }
            return lstDecomposedProds;
        }

        public static IList<DecompositionInfo> GetDecompositionInfo(long[] prodIds)
        {
            try
            {
                const string queryString = "select distinct prod from DecompositionInfo prod where prod.ProductId in (:Uids)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameterList("Uids", prodIds);
                return query.List().Cast<DecompositionInfo>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static ProductSupplyForecast GetProductByBarCode(string code)
        {
            try
            {
                const string queryString = "select distinct prod from ProductSupplyForecast prod where prod.BarCode = :code or prod.QRCode = :code";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("code", code);
                return query.List().Cast<ProductSupplyForecast>().First();
            }
            catch
            {
                return null;
            }
        }

        public static IList<ProductSupplyForecast> GetUnpackedProductByChain(string orgId, bool isPackedByChain = false)
        {
            try
            {
                var  queryString = "select distinct prod from ProductSupplyForecast prod where prod.IsPackedByChain = :isPackedByChain and (prod.Organization.Uid = :orgId or prod.PurchaseOrgId = :orgId or prod.ServiceProviderId = :serviceProviderId) "
                     + "and prod.AvailableForSale <> :availableForSale and prod.StatusType = 2";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("orgId", orgId);
                query.SetString("serviceProviderId", orgId);
                query.SetInt32("availableForSale", 0);
                query.SetBoolean("isPackedByChain", isPackedByChain);
                return query.List().Cast<ProductSupplyForecast>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static ProductSupplyForecast GetRootProduct(long childId)
        {
            try
            {
                var allParentId = new List<long>();
                using (var cmd = NHibernateHttpModule.GetSession.Connection.CreateCommand())
                {
                    string queryString = "SELECT  @id := (SELECT  ParentId FROM    productsupplyforecast WHERE   Uid = @id AND ParentId > 0) AS Parent " +
                        "FROM (SELECT  @id := " + childId + ") vars STRAIGHT_JOIN productsupplyforecast WHERE @id > 0";
                    cmd.CommandText = queryString;
                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            if (dr[0] is DBNull) continue;
                            allParentId.Add(Convert.ToInt64(dr[0]));
                        }
                    }
                }

                string hsql = "select distinct prod from ProductSupplyForecast prod where prod.Uid in (:ParentIds) and (prod.ParentId = 0 or prod.ParentId is null)";
                var query = NHibernateHttpModule.GetSession.CreateQuery(hsql);

                query.SetParameterList("ParentIds", allParentId);
                return query.List().Cast<ProductSupplyForecast>().First();
            }
            catch
            {
                return null;
            }
        }

        public static void ResetDecompositionInvoiceGeneration(long childId)
        {
            var rootProd = GetRootProduct(childId);
            if (rootProd == null) return;

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                rootProd.DecomposeDebitInvGenerated = false;
                rootProd.DecomposeCreditInvGenerated = false;
                factory.GetProductSuppyForecastRepository().Store(rootProd);

                transactionManager.CommitTransaction();
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }


        public static ProductSupplyForecast CreateOrUpdate(ProductSupplyForecast prodSupply)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                ProductSupplyForecast curProdSupply = prodSupply;

                if (prodSupply.Uid == 0)
                {
                    if (prodSupply.ParentId != 0)
                    {
                        var parentProd = factory.GetProductSuppyForecastRepository().GetOne(prodSupply.ParentId);

                        prodSupply.ProdType = parentProd.ProdType;
                        prodSupply.CategoryType = parentProd.CategoryType;
                        prodSupply.Category = parentProd.Category;
                        prodSupply.Color = parentProd.Color;
                    }
                    else
                    {
                        var prodTypeId = Convert.ToInt64(ConfigurationManager.AppSettings["DefaultProdTypeId"]);
                        var catTypeId = Convert.ToInt64(ConfigurationManager.AppSettings["DefaultCategoryTypeId"]);
                        var categoryId = Convert.ToInt64(ConfigurationManager.AppSettings["DefaultCategoryId"]);
                        var colorId = Convert.ToInt64(ConfigurationManager.AppSettings["DefaultColorId"]);

                        prodSupply.ProdType = factory.GetProdTypeRepository().GetOne(prodTypeId);
                        prodSupply.CategoryType = factory.GetCategoryTypeRepository().GetOne(catTypeId);
                        prodSupply.Category = factory.GetCategoryRepository().GetOne(categoryId);
                        prodSupply.Color = factory.GetColorRepository().GetOne(colorId);
                    }

                    prodSupply.FinalTime = Convert.ToInt16(ConfigurationManager.AppSettings["FinalTime4Input"]);
                    prodSupply.AvailableDate = DateTime.Now;
                    prodSupply.StatusType = ProductStatusType.ProductAvailableForSale;
                    factory.GetProductSuppyForecastRepository().Add(prodSupply);
                }
                else
                {
                    curProdSupply = factory.GetProductSuppyForecastRepository().GetOne(prodSupply.Uid);

                    if (curProdSupply.Version != prodSupply.Version)
                        throw new StaleObjectStateException(typeof(ProductSupplyForecast), curProdSupply);

                    curProdSupply.Organization = prodSupply.Organization;
                    curProdSupply.SalesOrganization = prodSupply.SalesOrganization;
                    curProdSupply.PurchaseOrgId = prodSupply.PurchaseOrgId;

                    curProdSupply.AddressId = prodSupply.AddressId;
                    curProdSupply.LocationId = prodSupply.LocationId;
                    curProdSupply.IsPackedByChain = prodSupply.IsPackedByChain;
                    curProdSupply.IsDecomposed = prodSupply.IsDecomposed;

                    if ((curProdSupply.SalesOrganization != null && !string.IsNullOrEmpty(curProdSupply.PurchaseOrgId)) ||
                        prodSupply.IsDecomposed)
                    {
                        if (prodSupply.SellerStatus == SellerStatus.Shipped || prodSupply.IsDecomposed)
                        {
                            curProdSupply.SellerStatus = SellerStatus.Shipped;
                            curProdSupply.AmountSoldPacked = prodSupply.AvailableForSale;
                            curProdSupply.AmountSoldShipped = prodSupply.AvailableForSale;
                            curProdSupply.SellerPerspective = prodSupply.AvailableForSale;
                            curProdSupply.DespatchDate = DateTime.Now;
                        }

                        if (prodSupply.BuyerStatus == BuyerStatus.ActualAmountBoughtAndReceived || prodSupply.IsDecomposed)
                        {
                            curProdSupply.IsBoughtSameReceived = true;
                            curProdSupply.BuyerStatus = BuyerStatus.ActualAmountBoughtAndReceived;
                            curProdSupply.BuyerPerspective = prodSupply.AvailableForSale;
                            curProdSupply.ReceiptDate = DateTime.Now;
                        }
                    }

                    curProdSupply.AvailableForSale = prodSupply.AvailableForSale;

                    factory.GetProductSuppyForecastRepository().Store(curProdSupply);
                    prodSupply = curProdSupply;

                    if (prodSupply.IsDecomposed && prodSupply.ParentId != 0)
                    {
                        var rootProd = GetRootProduct(curProdSupply.Uid);

                        rootProd.DecomposeDebitInvGenerated = false;
                        rootProd.DecomposeCreditInvGenerated = false;
                        factory.GetProductSuppyForecastRepository().Store(rootProd);
                    }
                }
                transactionManager.CommitTransaction();
                return prodSupply;
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static void GenerateShipment(ShipmentInfo shipmentInfo, string receiverOrgId, string xmlShipmentList, string shipmentStorePath)
        {
            Log.Debug("Start generate Shippment");
            try
            {
                var productSupplies = factory.GetProductSuppyForecastRepository().Find(new ProductForecastByIdsSpecification(shipmentInfo.ProductSupplyIds)).ToList();
                ShipmentListServices.GenerateShipmentList(productSupplies, receiverOrgId, shipmentInfo.FromDate, shipmentInfo.ToDate, shipmentInfo.CreatedUserId,
                    xmlShipmentList, shipmentStorePath, shipmentInfo.LoadingAdviceDocName, shipmentInfo.LoadingAdviceDocPath);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex);
                throw;
            }
        }

        public static void AddProductTreatmentInvoices(string treatmentInvoiceDatas)
        {
            var transactionManager = new TransactionManager();
            Log.Debug("Start Add Product Treatment for Invoice");
            try
            {
                try
                {
                    transactionManager.BeginTransaction();

                    //Extract the product treatment invoice data to insert to matching
                    var invoiceInfos = treatmentInvoiceDatas.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var invoiceData in invoiceInfos)
                    {
                        var data = invoiceData.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        //Create domain object and insert to Matching table 
                        var treatmentInvoice = new ProductTreatmentInvoice()
                        {
                            ProductSuplyId = long.Parse(data[0]),
                            TreatmentId = long.Parse(data[1]),
                        };

                        factory.GetProductTreatmentInvoiceRepository().Add(treatmentInvoice);
                    }

                    transactionManager.CommitTransaction();

                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception.Message, exception);
                    throw;
                }
            }
            catch (Exception ex)
            {
                transactionManager.RollbackTransaction();
                Log.Error(ex.Message, ex);
                throw;
            }
        }

        public static void UpdateDataForPackagingInvoiceInMatching(string packagingInvoiceInfo)
        {
            //Extract the packaging invoice data to insert to matching
            //packagingInvoiceInfo = "packageType_id|packagetype_name|#OfPackages|MatchingProdId"
            var invoiceData = packagingInvoiceInfo.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

            var packageType = factory.GetPackagingDefineRepository().GetOne(invoiceData[0]);
            var supplyRepo = factory.GetProductSuppyForecastRepository();            
            var prodSupply = supplyRepo.GetOne(invoiceData[3]);

            var transactionManager = new TransactionManager();
            Log.Debug("Start Update Packaging Info for Invoice");

            try
            {
                try
                {                                        
                    transactionManager.BeginTransaction();                    
                    
                    if (packageType.Price == 0 && packageType.RentPrice == 0 && packageType.DepositPrice == 0)
                    {                        
                        var packCfm = new PackingConfirmed
                        {
                            Packing = packageType, //Package Type
                            PackingAmount = long.Parse(invoiceData[2]), //#OfPackages
                            ProdConfirmed = prodSupply,
                            PriceType = PriceType.Price,
                            AmountPerPack = packageType.PackagingAmount,
                            DebitVat = 0
                            
                        };
                        
                        factory.GetPackingConfirmedRepository().Add(packCfm);
                        factory.GetPackingConfirmedRepository().Flush();

                        //Update status for the product supply so that we can search the product in create invoice page
                        packCfm.ProdConfirmed.SellerStatus = SellerStatus.Shipped;
                        packCfm.ProdConfirmed.BuyerStatus = BuyerStatus.ActualAmountBoughtAndReceived;

                        factory.GetProductSuppyForecastRepository().Store(packCfm.ProdConfirmed);
                    }
                    else
                    {
                        for (int j = 1; j <= 3; j++)
                        {
                            var priceType = (PriceType)Enum.Parse(typeof(PriceType), j.ToString());
                            if (priceType == PriceType.Price && packageType.Price == 0) continue;
                            if (priceType == PriceType.Rent && packageType.RentPrice == 0) continue;
                            if (priceType == PriceType.Deposit && packageType.DepositPrice == 0) continue;
                            //Create PackingConfirmed object and insert to Matching
                            var packingConfirmed = new PackingConfirmed
                            {
                                Packing = packageType, //Package Type
                                PackingAmount = long.Parse(invoiceData[2]), //#OfPackages
                                ProdConfirmed = prodSupply,
                                PriceType = priceType,
                                AmountPerPack = packageType.PackagingAmount,
                                DebitVat = 0
                            };
                           
                            factory.GetPackingConfirmedRepository().Add(packingConfirmed);
                            factory.GetPackingConfirmedRepository().Flush();

                            //Update status for the product supply so that we can search the product in create invoice page
                            packingConfirmed.ProdConfirmed.SellerStatus = SellerStatus.Shipped;
                            packingConfirmed.ProdConfirmed.BuyerStatus = BuyerStatus.ActualAmountBoughtAndReceived;
                            factory.GetProductSuppyForecastRepository().Store(packingConfirmed.ProdConfirmed);
                        }
                    }
                    
                    transactionManager.CommitTransaction();
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception.Message, exception);
                    throw;
                }
            }
            catch (Exception ex)
            {
                transactionManager.RollbackTransaction();
                Log.Error(ex.Message, ex);
                throw;
            }
        }

        public static ICollection<ProductSupplyForecast> GetListProductsForProductForecast(int pageSize, int currPage, out int totalCount,
            DateTime startDate, DateTime endDate, int productId, long prodTypeId, long colorId, int catTypeId, string categoryIds, string organizationIds, string unPreferredOrgIds,
            bool isOwner, string loginOrgUid, string sortDirection, long uniqueId, string exceptIds, string includeProdIds, int frcStkFilter,
            int iProductStatus, int iSallerStatus, int iBuyerStatus, bool inDebitInv, bool inCreditInv, string adtAttrIds, int prodFilter = 0)
        {
            var productSupplyForecastWithPagingSpecification = new ProductSupplyForecastWithPagingSpecification(startDate, endDate,
              productId, prodTypeId, colorId, catTypeId, categoryIds, organizationIds, unPreferredOrgIds,
                isOwner, loginOrgUid, "AvailableDate", sortDirection, uniqueId, exceptIds, includeProdIds, frcStkFilter,
                iProductStatus, iSallerStatus, iBuyerStatus, inDebitInv, inCreditInv, adtAttrIds);
            productSupplyForecastWithPagingSpecification.SortExpression = "Uid";
            productSupplyForecastWithPagingSpecification.SortDirection = "DESC";
            productSupplyForecastWithPagingSpecification.ProductFilter = prodFilter;

            ICollection<ProductSupplyForecast> colectProdForecasts = factory.GetProductSuppyForecastRepository().Find(productSupplyForecastWithPagingSpecification, (currPage - 1) * pageSize, pageSize);

            productSupplyForecastWithPagingSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(productSupplyForecastWithPagingSpecification));

            return colectProdForecasts;
        }

        public static List<ProductSupplyForecast> GetListProductsForMakeAvailable4Sales(int pageSize, int currPage, string sortDirection, out int totalCount,
            DateTime startDate, DateTime endDate, int productId, int categoryTypeId, string categoryIds, string organizationIds, string unPreferredOrgIds,
            bool isOwner, string loginOrgUid, long uniqueId, int prodStatusTypeid, bool isExcludeCmtRltItem)
        {
            var listRes = new List<ProductSupplyForecast>();
            var productSupplyForecastWithPagingSpecification = new ProductSupplyForecastWithPagingSpecification(startDate, endDate, productId, categoryTypeId, categoryIds, organizationIds, unPreferredOrgIds,
                isOwner, loginOrgUid, "AvailableDate", sortDirection, uniqueId, string.Empty, 0, prodStatusTypeid, isExcludeCmtRltItem);

            listRes = factory.GetProductSuppyForecastRepository().Find(productSupplyForecastWithPagingSpecification, (currPage - 1) * pageSize, pageSize).ToList();

            productSupplyForecastWithPagingSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(productSupplyForecastWithPagingSpecification));

            return listRes;
        }

        public static List<ProductSupplyForecast> GetForShipperPackagingProcess(int pageSize, int currPage, out int totalCount, DateTime dateFrom, DateTime dateTo,
            long locationId, string orgIds, int prodStatus, int saleStatus)
        {
            var productCommittedSoldByLocationWithPagingSpecification = new ProductCommittedSoldByLocationWithPagingSpecification(dateFrom, dateTo, locationId, orgIds, prodStatus, saleStatus);
            List<ProductSupplyForecast> listRes = factory.GetProductSuppyForecastRepository().Find(productCommittedSoldByLocationWithPagingSpecification, (currPage - 1) * pageSize, pageSize).ToList();

            productCommittedSoldByLocationWithPagingSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(productCommittedSoldByLocationWithPagingSpecification));

            return listRes;
        }


        //=============================
        public static ICollection<ProductSupplyForecast> GetForUpdateProductSoldAndDispatched(int pageSize, int currPage, out int totalCount, DateTime dateFrom, DateTime dateTo,
            int productId, int cateTypeId, string categoryIds, string organizationIds, string unPreferredOrgIds, bool isOwner, string loginOrgUid, string sortDirection, long uniqueId, int productStatusId)
        {
            var productSupplyForecastWithPagingSpecification = new ProductSupplyForecastWithPagingSpecification(dateFrom, dateTo,
                productId, cateTypeId, categoryIds, organizationIds, unPreferredOrgIds,
                isOwner, loginOrgUid, "AvailableDate", sortDirection, uniqueId, string.Empty, 0, 3, productStatusId, 0);

            ICollection<ProductSupplyForecast> colectProdForecasts = factory.GetProductSuppyForecastRepository().Find(
                productSupplyForecastWithPagingSpecification, (currPage - 1) * pageSize, pageSize);

            productSupplyForecastWithPagingSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(productSupplyForecastWithPagingSpecification));
            return colectProdForecasts;
        }

        public static ICollection<ProductSupplyForecast> GetForUpdateProductBoughtAndReceived(int pageSize, int currPage, out int totalCount, DateTime dateFrom, DateTime dateTo,
            int productId, int cateTypeId, string categoryIds, string organizationIds, string unPreferredOrgIds, bool isOwner, string loginOrgUid, string sortDirection, long uniqueId, int productStatusId)
        {
            var productSupplyForecastWithPagingSpecification = new ProductSupplyForecastWithPagingSpecification(dateFrom, dateTo,
                productId, cateTypeId, categoryIds, organizationIds, unPreferredOrgIds,
                isOwner, loginOrgUid, "AvailableDate", sortDirection, uniqueId, string.Empty, 0, 3, Convert.ToInt32(SellerStatus.Shipped), productStatusId);
            ICollection<ProductSupplyForecast> colectProdForecasts = factory.GetProductSuppyForecastRepository().Find(
                productSupplyForecastWithPagingSpecification, (currPage - 1) * pageSize, pageSize);

            productSupplyForecastWithPagingSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(productSupplyForecastWithPagingSpecification));
            return colectProdForecasts;
        }
        //=============================


        public static ICollection<ProductSupplyForecast> GetForUpdateTobeDetermined2FixPrice(int pageSize, int currPage, out int totalCount, DateTime dateFrom, DateTime dateTo,
            int productId, int cateTypeId, string categoryIds, string preferredOrgIds, string unPreferredOrgIds, string loginOrgUid, long uniqueId, string sortDirection, string adtAttrIds)
        {
            var roductSupplyTobeDeterminedSpecification = new ProductSupplyTobeDeterminedSpecification(dateFrom, dateTo,
                productId, cateTypeId, categoryIds, false, preferredOrgIds, unPreferredOrgIds, loginOrgUid, uniqueId, "AvailableDate", sortDirection, adtAttrIds);
            ICollection<ProductSupplyForecast> colectProdForecasts = factory.GetProductSuppyForecastRepository().Find(
               roductSupplyTobeDeterminedSpecification, (currPage - 1) * pageSize, pageSize);
            roductSupplyTobeDeterminedSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(roductSupplyTobeDeterminedSpecification));

            return colectProdForecasts;
        }

        public static ICollection<ProductSupplyForecast> GetForManagePriceOfferBelowAskingPrice(int pageSize, int currPage, out int totalCount, string loginOrgUid, DateTime dateFrom)
        {
            var prodSupplyInAskingFloorProcessOfferByOrgIdSpecification = new ProdSupplyInAskingFloorProcessOfferByOrgIdSpecification(loginOrgUid, dateFrom);
            var listRes = factory.GetProductSuppyForecastRepository().Find(prodSupplyInAskingFloorProcessOfferByOrgIdSpecification, (currPage - 1) * pageSize, pageSize);

            prodSupplyInAskingFloorProcessOfferByOrgIdSpecification.IsCount = true;

            totalCount = Convert.ToInt32(factory.GetProductSuppyForecastRepository().Count(prodSupplyInAskingFloorProcessOfferByOrgIdSpecification));
            return listRes;
        }




        public static List<ShipmentList> GetForDispatchShipmentList(int pageSize, int currPage, out int totalCount, string supplierId, DateTime dateFrom, DateTime dateTo)
        {
            var shipmentListSpecification = new ShipmentListSpecification(supplierId, dateFrom, dateTo);
            List<ShipmentList> listRes = factory.GetShipmentListRepository().Find(shipmentListSpecification, (currPage - 1) * pageSize, pageSize).ToList();

            shipmentListSpecification.IsCount = true;
            totalCount = Convert.ToInt32(factory.GetShipmentListRepository().Count(shipmentListSpecification));
            return listRes;
        }

        public static IList<ProductSupplyForecast> GetProductsByOrgId(string orgId)
        {
            try
            {
                const string queryString = "select distinct prod from ProductSupplyForecast prod where 1 = 1 and (prod.Organization.Uid = :orgId or prod.PurchaseOrgId = :orgId)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("orgId", orgId);                
                return query.List().Cast<ProductSupplyForecast>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<ProductSupplyForecast> GetUnpackedProductByChainFilterByProducer(string orgId, bool isPackedByChain = false)
        {
            try
            {
                var currentOrgId = "0";
                var data = orgId.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                var chainEntityId = data[0];
                var producerId = data[1];

                ICollection<Organization> orgs = factory.GetOrganizationRepository().AsCollection();

                foreach (var org in orgs)
                {
                    if (org.ChainEntities.Count > 0 && org.ChainEntities[0].Uid == Int64.Parse(chainEntityId))
                    {
                        currentOrgId = org.Uid;
                    }
                }

                var  queryString = "select distinct prod from ProductSupplyForecast prod where prod.IsPackedByChain = :isPackedByChain and (prod.Organization.Uid = :orgId or prod.PurchaseOrgId = :orgId) "
                     + "and prod.AvailableForSale <> :availableForSale and prod.StatusType = 2 or (prod.ServiceProviderId = :serviceProviderId)";// or prod.ServiceProviderId =:empty or prod.ServiceProviderId is null)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("orgId", producerId);
                query.SetInt32("availableForSale", 0);
                query.SetString("serviceProviderId", currentOrgId);
                query.SetBoolean("isPackedByChain", isPackedByChain);
                return query.List().Cast<ProductSupplyForecast>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<ProductSupplyForecast> GetProductsByProducerId(string currentOrgId, string producerId)
        {
            try
            {
                const string queryString = "select distinct prod from ProductSupplyForecast prod where 1 = 1 and (prod.Organization.Uid = :orgId or prod.PurchaseOrgId = :orgId) or (prod.ServiceProviderId = :serviceProviderId or prod.ServiceProviderId is null)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetString("orgId", producerId);
                query.SetString("serviceProviderId", currentOrgId);
                
                return query.List().Cast<ProductSupplyForecast>().ToList();
            }
            catch
            {
                return null;
            }
        }
    }
}
