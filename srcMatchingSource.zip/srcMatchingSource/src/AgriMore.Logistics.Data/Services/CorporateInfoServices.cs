﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Data.Services
{
    public class CorporateInfoServices : BaseService
    {
        public static IList<CorporateInfo> GetCorporateInfoByOrgId(string orgId)
        {
            try
            {
                const string hsql = "select cif from CorporateInfo cif where cif.OrgId = :orgId";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(hsql);
                query.SetParameter("orgId", orgId);

                return query.List().Cast<CorporateInfo>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<CorporateInfo> GetCorporationInfoForOrgId(string orgId, string loginOrgId)
        {
            try
            {
                const string hsql = "select distinct cif from CorporateInfo cif where cif.OrgId = :orgId and (cif.IsVisibleAll = 1 or cif.OrgId = :loginOrgId or (exists ( select vorg from cif.VisibleOrgs as vorg where vorg.Uid = :loginOrgId)))";
                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(hsql);
                query.SetParameter("orgId", orgId);
                query.SetParameter("loginOrgId", loginOrgId);

                return query.List().Cast<CorporateInfo>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<CorporateInfo> GetCorporationInfoShowDirectly(string orgId)
        {
            try
            {
                const string hsql = "select distinct cif from CorporateInfo cif where cif.OrgId = :orgId and cif.IsShowDirectly = 1";
                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(hsql);
                query.SetParameter("orgId", orgId);

                return query.List().Cast<CorporateInfo>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<QualityDocumentUpload> GetQualityDocumentUpload(string orgId)
        {
            try
            {
                const string hsql = "select distinct qd from QualityDocumentUpload qd where qd.OrgId = :orgId";
                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(hsql);
                query.SetParameter("orgId", orgId);

                return query.List().Cast<QualityDocumentUpload>().ToList();
            }
            catch
            {
                return null;
            }
        }
    }
}
