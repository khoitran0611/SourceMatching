﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;
using AgriMore.Logistics.Common.Utils;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;
using NHibernate.Collection;

namespace AgriMore.Logistics.Data.Services
{
    public class InvoiceService
    {
        protected IRepositoryFactory factory;
        private IRepository<Invoice> invoiceRepo;
        protected IRepository<Organization, string> orgRepo;
        private IRepository<VatSetting> vatSettingsRepo;

        public InvoiceService()
        {
            factory = new NHibernateRepositoryFactory();
            invoiceRepo = factory.GetInvoiceRepository();
            orgRepo = factory.GetOrganizationRepository();
            vatSettingsRepo = factory.GetVatSettingRepository();
        }

        private static readonly object sync = new object();
        public virtual string GetInvoiceNumber(InvoiceType invoiceType)
        {
            lock (sync)
            {
                var session = NHibernateHttpModule.CreateSession();
                try
                {

                    var q = session.CreateQuery("from InvoiceNumber where OrgId = :orgId and InvoiceType = :invoiceType order by Created desc");
                    q.SetString("orgId", Thread.CurrentPrincipal.Identity.Name);
                    q.SetInt32("invoiceType", (int)invoiceType);
                    q.SetMaxResults(1);
                    var invoiceNr = q.List().Cast<InvoiceNumber>().FirstOrDefault();

                    if (invoiceNr == null)
                    {
                        invoiceNr = new InvoiceNumber
                        {
                            OrgId = Thread.CurrentPrincipal.Identity.Name,
                            InvoiceType = invoiceType,
                            InvoiceNr = "1",
                            Created = DateTime.Now
                        };
                    }
                    else
                    {
                        invoiceNr.InvoiceNr = (long.Parse(invoiceNr.InvoiceNr) + 1).ToString();
                        invoiceNr.Created = DateTime.Now;
                    }

                    session.Save(invoiceNr);
                    session.Flush();

                    return invoiceNr.InvoiceNr;

                }
                finally
                {
                    session.Close();
                }
            }
        }

        public static IEnumerable<long> GetProducts(long invoiceId)
        {
            try
            {
                const string queryString = "select prod.ProductId from InvoiceProduct prod where prod.Invoice.Uid = :Uid";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetInt64("Uid", invoiceId);
                return query.List().Cast<long>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public virtual IEnumerable<InvoiceDecomposition> GetDecompositionInvForProductIds(long[] prodIds, int invType)
        {
            try
            {
                const string queryString = "select invd from InvoiceDecomposition invd where " +
                                           "invd.DecomposeType is not null and invd.Invoice.InvoiceType = :invType and invd.ProductSupply.Uid in (:prodUids)";
                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetInt32("invType", invType);
                query.SetParameterList("prodUids", prodIds);
                return query.List().Cast<InvoiceDecomposition>().ToList();
            }
            catch
            {
                return new List<InvoiceDecomposition>();
            }
        }

        public virtual Invoice GetOne(long invoiceId, Organization organization)
        {
            var invoice = invoiceRepo.GetOne(invoiceId);

            if (Thread.CurrentPrincipal.IsInRole("SysAdmin") || Thread.CurrentPrincipal.IsInRole("Admin")
                || organization.Uid.Equals(invoice.BuyerOrgId) || organization.Uid.Equals(invoice.SellerOrgId))
            {
                return invoice;
            }

            return null;
        }

        public virtual Invoice FindLatest(long invoiceId)
        {
            var invoice = invoiceRepo.GetOne(invoiceId);

            while (!invoice.Latest)
            {
                var invoices = invoiceRepo.FindByHsql(string.Format("from Invoice where ParentUid = {0} and InvoiceType = {1} and InvoiceStatus <> {2}", invoice.Uid, (int)invoice.InvoiceType, (int)InvoiceStatus.ReverseInvoice));
                if (invoices.Count != 1) return null;

                invoice = invoices[0] as Invoice;
            }

            return invoice;
        }

        public virtual long Count(string invoiceNr, string[] orgIds, InvoiceType invoiceType, DateTime invoiceFrom, DateTime invoiceTo, DateTime paymentFromDate, DateTime paymentToDate)
        {
            var session = NHibernateHttpModule.GetSession;

            var sb = new StringBuilder();
            sb.Append("select count(*) from Invoice i where  1 = 1");

            if (invoiceType != 0)
            {
                sb.Append(" and i.InvoiceType = :invoiceType");
            }
            if (!string.IsNullOrEmpty(invoiceNr))
            {
                sb.Append(" and i.InvoiceNr = :invoiceNr");
            }
            if (orgIds != null && orgIds.Length > 0)
            {
                sb.Append(" and (i.SellerOrgId in (:orgIds) or i.BuyerOrgId in (:orgIds))");
            }
            if (invoiceFrom != DateTime.MinValue && invoiceFrom != DateTime.MaxValue)
            {
                sb.Append(" and i.Modified >= :invoiceFrom");
            }
            if (invoiceTo != DateTime.MinValue)
            {
                sb.Append(" and i.Modified <= :invoiceTo");
            }

            if (paymentFromDate != DateTime.MinValue && paymentToDate == DateTime.MinValue)
            {
                sb.Append(" and i.PaymentPeriodFrom >= :paymentFromDate");
            }
            if (paymentFromDate == DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                sb.Append(" and i.PaymentPeriodTo <= :paymentToDate");
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                sb.Append("and (");
                sb.Append("(i.PaymentPeriodFrom <= :paymentFromDate and i.PaymentPeriodTo >= :paymentToDate)");
                sb.Append(" or (i.PaymentPeriodFrom <= :paymentFromDate and i.PaymentPeriodTo <= :paymentToDate and i.PaymentPeriodTo >= :paymentFromDate)");
                sb.Append(" or (i.PaymentPeriodFrom >= :paymentFromDate and i.PaymentPeriodTo >= :paymentToDate and i.PaymentPeriodFrom <= :paymentToDate)");
                sb.Append(" or (i.PaymentPeriodFrom >= :paymentFromDate and i.PaymentPeriodTo <= :paymentToDate)");
                sb.Append(")");
            }

            var query = session.CreateQuery(sb.ToString());
            if (invoiceType != 0)
            {
                query.SetParameter("invoiceType", (int)invoiceType);
            }
            if (!string.IsNullOrEmpty(invoiceNr))
            {
                query.SetString("invoiceNr", invoiceNr);
            }
            if (orgIds != null && orgIds.Length > 0)
            {
                query.SetParameterList("orgIds", orgIds);
            }
            if (invoiceFrom != DateTime.MinValue)
            {
                query.SetDateTime("invoiceFrom", invoiceFrom);
            }
            if (invoiceTo != DateTime.MinValue && invoiceTo != DateTime.MaxValue)
            {
                query.SetDateTime("invoiceTo", invoiceTo);
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate == DateTime.MinValue)
            {
                query.SetDateTime("paymentFromDate", paymentFromDate);
            }
            if (paymentFromDate == DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                query.SetDateTime("paymentToDate", paymentFromDate);
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                query.SetDateTime("paymentFromDate", paymentFromDate);
                query.SetDateTime("paymentToDate", paymentFromDate);
            }

            return Convert.ToInt64(query.UniqueResult());
        }

        public virtual IEnumerable<Invoice> Find(string invoiceNr, string[] orgIds, InvoiceType invoiceType, DateTime invoiceFrom, DateTime invoiceTo, DateTime paymentFromDate, DateTime paymentToDate, int startRowIndex, int maximumRows)
        {
            var session = NHibernateHttpModule.GetSession;

            var sb = new StringBuilder();
            sb.Append("from Invoice i where 1 = 1");

            if (invoiceType != 0)
            {
                sb.Append(" and i.InvoiceType = :invoiceType");
            }
            if (!string.IsNullOrEmpty(invoiceNr))
            {
                sb.Append(" and i.InvoiceNr = :invoiceNr");
            }
            if (orgIds != null && orgIds.Length > 0)
            {
                sb.Append(" and (i.SellerOrgId in (:orgIds) or i.BuyerOrgId in (:orgIds))");
            }
            if (invoiceFrom != DateTime.MinValue && invoiceFrom != DateTime.MaxValue)
            {
                sb.Append(" and i.Modified >= :invoiceFrom");
            }
            if (invoiceTo != DateTime.MinValue)
            {
                sb.Append(" and i.Modified <= :invoiceTo");
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate == DateTime.MinValue)
            {
                sb.Append(" and i.PaymentPeriodFrom >= :paymentFromDate");
            }
            if (paymentFromDate == DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                sb.Append(" and i.PaymentPeriodTo <= :paymentToDate");
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                sb.Append("and (");
                sb.Append("(i.PaymentPeriodFrom <= :paymentFromDate and i.PaymentPeriodTo >= :paymentToDate)");
                sb.Append(" or (i.PaymentPeriodFrom <= :paymentFromDate and i.PaymentPeriodTo <= :paymentToDate and i.PaymentPeriodTo >= :paymentFromDate)");
                sb.Append(" or (i.PaymentPeriodFrom >= :paymentFromDate and i.PaymentPeriodTo >= :paymentToDate and i.PaymentPeriodFrom <= :paymentToDate)");
                sb.Append(" or (i.PaymentPeriodFrom >= :paymentFromDate and i.PaymentPeriodTo <= :paymentToDate)");
                sb.Append(")");
            }

            var query = session.CreateQuery(sb.ToString());
            if (invoiceType != 0)
            {
                query.SetParameter("invoiceType", (int)invoiceType);
            }
            if (!string.IsNullOrEmpty(invoiceNr))
            {
                query.SetString("invoiceNr", invoiceNr);
            }
            if (orgIds != null && orgIds.Length > 0)
            {
                query.SetParameterList("orgIds", orgIds);
            }
            if (invoiceFrom != DateTime.MinValue)
            {
                query.SetDateTime("invoiceFrom", invoiceFrom);
            }
            if (invoiceTo != DateTime.MinValue && invoiceTo != DateTime.MaxValue)
            {
                query.SetDateTime("invoiceTo", invoiceTo);
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate == DateTime.MinValue)
            {
                query.SetDateTime("paymentFromDate", paymentFromDate);
            }
            if (paymentFromDate == DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                query.SetDateTime("paymentToDate", paymentFromDate);
            }
            if (paymentFromDate != DateTime.MinValue && paymentToDate != DateTime.MinValue)
            {
                query.SetDateTime("paymentFromDate", paymentFromDate);
                query.SetDateTime("paymentToDate", paymentFromDate);
            }

            var invoices = query.SetFirstResult(startRowIndex).SetMaxResults(maximumRows).List().Cast<Invoice>();

            return invoices;
        }

        public virtual InvoiceProduct AddProduct(Invoice invoice, ProductSupplyForecast prodSupply, ShipmentItem shipmentItem, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddProduct(invoice, prodSupply, shipmentItem, new VatSetting
                {
                    VatDefine = VATSettings.VatDefine,
                    VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                    Gs1Code = VATSettings.Gs1Code,
                    LedgerCode = VATSettings.LedgerCode,
                    OtherCode = VATSettings.OtherCode,
                    Type = VATSettings.Type
                });
        }

        public virtual InvoiceProduct AddProduct(Invoice invoice, ProductSupplyForecast prodSupply, ShipmentItem4CompositeProd shipmentItem, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddProduct(invoice, prodSupply, shipmentItem, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoiceCompositeProduct AddProduct(Invoice invoice, CompositeProductSupply cmpProdSupply, ShipmentItem4CompositeProd shipmentItem, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddProduct(invoice, cmpProdSupply, shipmentItem, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoiceProduct AddProduct(Invoice invoice, ProductSupplyForecast prodSupply, ShipmentItem shipmentItem, VatSetting VATSettings)
        {
            var product = new InvoiceProduct
            {
                ProductId = prodSupply.Uid,
                SpeciesId = prodSupply.Species.Uid,
                ProdTypeId = prodSupply.ProdType.Uid,
                ColorId = prodSupply.Color.Uid,
                CategoryTypeId = prodSupply.CategoryType.Uid,
                CategoryId = prodSupply.Category.Uid,
                AdditionalAttributeIds = string.Join(",", prodSupply.AdditionalAttrs.OrderBy(a => a.Uid).Select(a => a.Uid.ToString()).ToArray()),
                UomId = prodSupply.Uom.Uid,
                OrgId = prodSupply.Organization.Uid,
                DispatchDate = prodSupply.DespatchDate,
                Price = prodSupply.Price,
                Amount = prodSupply.AmountSoldShipped,
                Currency = prodSupply.Currency ?? "EUR",
                SellerOrgId = prodSupply.SalesOrganization.Uid,
                BuyerOrgId = prodSupply.PurchaseOrgId,
                SellerRef1 = prodSupply.SellerRefOne,
                SellerRef2 = prodSupply.SellerRefTwo,
                BuyerRef1 = prodSupply.BuyerRefOne,
                BuyerRef2 = prodSupply.BuyerRefTwo,
                ProducerRef1 = prodSupply.ProducerRefOne,
                ProducerRef2 = prodSupply.ProducerRefTwo,
                PackSlipNumber = prodSupply.PackingSlip,
                Remarks = prodSupply.Remarks,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type
            };

            var buyerLangCode = invoice.BuyerLanguage;
            product.AddLanguage(new InvoiceProductLanguage
            {
                LangCode = buyerLangCode,
                SpeciesName = prodSupply.Species.GetName(buyerLangCode),
                ProdTypeName = prodSupply.ProdType.GetName(buyerLangCode),
                ColorName = prodSupply.Color.GetName(buyerLangCode),
                CategoryTypeName = prodSupply.CategoryType.GetName(buyerLangCode),
                CategoryName = prodSupply.Category.GetName(buyerLangCode),
                AdditionalAttributes = string.Join(", ", prodSupply.AdditionalAttrs.OrderBy(a => a.Name).Select(a => a.GetName(buyerLangCode)).ToArray()),
                UomName = prodSupply.Uom.Name,
                OrgName = prodSupply.Organization.GetName(buyerLangCode),
                VAT = VATSettings.VatSettingLangs.Where(l => l.LangCode == buyerLangCode).FirstOrDefault() != null ? VATSettings.VatSettingLangs.Where(l => l.LangCode == buyerLangCode).FirstOrDefault().Name : VATSettings.VatTextField                
            });

            var issuerLangCode = invoice.SellerLanguage;
            product.AddLanguage(new InvoiceProductLanguage
            {
                LangCode = issuerLangCode,
                SpeciesName = prodSupply.Species.GetName(issuerLangCode),
                ProdTypeName = prodSupply.ProdType.GetName(issuerLangCode),
                ColorName = prodSupply.Color.GetName(issuerLangCode),
                CategoryTypeName = prodSupply.CategoryType.GetName(issuerLangCode),
                CategoryName = prodSupply.Category.GetName(issuerLangCode),
                AdditionalAttributes = string.Join(", ", prodSupply.AdditionalAttrs.OrderBy(a => a.Name).Select(a => a.GetName(issuerLangCode)).ToArray()),
                UomName = prodSupply.Uom.Name,
                OrgName = prodSupply.Organization.GetName(issuerLangCode),
                VAT = VATSettings.VatSettingLangs.Where(l => l.LangCode == issuerLangCode).FirstOrDefault() != null ? VATSettings.VatSettingLangs.Where(l => l.LangCode == issuerLangCode).FirstOrDefault().Name : VATSettings.VatTextField    
            });

            invoice.AddProduct(product);

            var shipment = invoice.Shipments.Where(s => s.ShipmentId == shipmentItem.Uid).SingleOrDefault();
            if (shipment != null)
            {
                shipment.AddProduct(product);
            }
            else
            {
                shipment = new InvoiceShipment
                {
                    Invoice = invoice,
                    ShipmentId = shipmentItem.Uid,
                    ShipmentDate = shipmentItem.ShipmentList.CreatedAt,
                    ShipmentRef = string.Empty,
                    FromOrgId = shipmentItem.Grower.Uid,
                    FromAddressId = shipmentItem.AddressId,
                    FromLocationId = shipmentItem.LocationId,
                    FromLocation = string.Empty,
                    FromStreetName = string.Empty,
                    FromStreetNumber = string.Empty,
                    FromZipCode = string.Empty,
                    FromProvince = string.Empty,
                    FromCity = string.Empty,
                    FromCountry = string.Empty,
                    ToOrgId = shipmentItem.Buyer.Uid,
                    ToAddressId = 0,
                    ToLocationId = 0,
                    ToStreetName = string.Empty,
                    ToStreetNumber = string.Empty,
                    ToZipCode = string.Empty,
                    ToProvince = string.Empty,
                    ToCity = string.Empty,
                    ToCountry = string.Empty
                };
                shipment.AddProduct(product);

                invoice.AddShipment(shipment);
            }

            return product;
        }

        public virtual InvoiceProduct AddProduct(Invoice invoice, ProductSupplyForecast prodSupply, ShipmentItem4CompositeProd shipmentItem, VatSetting VATSettings)
        {
            var product = new InvoiceProduct
            {
                ProductId = prodSupply.Uid,
                SpeciesId = prodSupply.Species.Uid,
                ProdTypeId = prodSupply.ProdType.Uid,
                ColorId = prodSupply.Color.Uid,
                CategoryTypeId = prodSupply.CategoryType.Uid,
                CategoryId = prodSupply.Category.Uid,
                AdditionalAttributeIds = string.Join(",", prodSupply.AdditionalAttrs.OrderBy(a => a.Uid).Select(a => a.Uid.ToString()).ToArray()),
                UomId = prodSupply.Uom.Uid,
                OrgId = prodSupply.Organization.Uid,
                DispatchDate = prodSupply.DespatchDate,
                Price = prodSupply.Price,
                Amount = prodSupply.AmountSoldShipped,
                Currency = prodSupply.Currency ?? "EUR",
                SellerOrgId = prodSupply.SalesOrganization.Uid,
                BuyerOrgId = prodSupply.PurchaseOrgId,
                SellerRef1 = prodSupply.SellerRefOne,
                SellerRef2 = prodSupply.SellerRefTwo,
                BuyerRef1 = prodSupply.BuyerRefOne,
                BuyerRef2 = prodSupply.BuyerRefTwo,
                ProducerRef1 = prodSupply.ProducerRefOne,
                ProducerRef2 = prodSupply.ProducerRefTwo,
                PackSlipNumber = prodSupply.PackingSlip,
                Remarks = prodSupply.Remarks,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type
            };

            var buyerLangCode = invoice.BuyerLanguage;
            product.AddLanguage(new InvoiceProductLanguage
            {
                LangCode = buyerLangCode,
                SpeciesName = prodSupply.Species.GetName(buyerLangCode),
                ProdTypeName = prodSupply.ProdType.GetName(buyerLangCode),
                ColorName = prodSupply.Color.GetName(buyerLangCode),
                CategoryTypeName = prodSupply.CategoryType.GetName(buyerLangCode),
                CategoryName = prodSupply.Category.GetName(buyerLangCode),
                AdditionalAttributes = string.Join(", ", prodSupply.AdditionalAttrs.OrderBy(a => a.Name).Select(a => a.GetName(buyerLangCode)).ToArray()),
                UomName = prodSupply.Uom.Name,
                OrgName = prodSupply.Organization.GetName(buyerLangCode),
                VAT = VATSettings.VatSettingLangs.Where(l => l.LangCode == buyerLangCode).FirstOrDefault() != null ? VATSettings.VatSettingLangs.Where(l => l.LangCode == buyerLangCode).FirstOrDefault().Name : VATSettings.VatTextField                
            });

            var issuerLangCode = invoice.SellerLanguage;
            product.AddLanguage(new InvoiceProductLanguage
            {
                LangCode = issuerLangCode,
                SpeciesName = prodSupply.Species.GetName(issuerLangCode),
                ProdTypeName = prodSupply.ProdType.GetName(issuerLangCode),
                ColorName = prodSupply.Color.GetName(issuerLangCode),
                CategoryTypeName = prodSupply.CategoryType.GetName(issuerLangCode),
                CategoryName = prodSupply.Category.GetName(issuerLangCode),
                AdditionalAttributes = string.Join(", ", prodSupply.AdditionalAttrs.OrderBy(a => a.Name).Select(a => a.GetName(issuerLangCode)).ToArray()),
                UomName = prodSupply.Uom.Name,
                OrgName = prodSupply.Organization.GetName(issuerLangCode),
                VAT = VATSettings.VatSettingLangs.Where(l => l.LangCode == issuerLangCode).FirstOrDefault() != null ? VATSettings.VatSettingLangs.Where(l => l.LangCode == issuerLangCode).FirstOrDefault().Name : VATSettings.VatTextField                
            });

            invoice.AddProduct(product);

            var shipment = invoice.Shipments.Where(s => s.ShipmentId == shipmentItem.Uid).SingleOrDefault();
            if (shipment != null)
            {
                shipment.AddProduct(product);
            }
            else
            {
                shipment = new InvoiceShipment
                {
                    Invoice = invoice,
                    ShipmentId = shipmentItem.Uid,
                    ShipmentDate = shipmentItem.ShipmentList.CreatedAt,
                    ShipmentRef = string.Empty,
                    FromOrgId = prodSupply.Organization.Uid, //shipmentItem.Seller.Uid,//.Grower.Uid,
                    FromAddressId = 0, //shipmentItem.AddressId,
                    FromLocationId = 0,//shipmentItem.LocationId,
                    FromLocation = string.Empty,
                    FromStreetName = string.Empty,
                    FromStreetNumber = string.Empty,
                    FromZipCode = string.Empty,
                    FromProvince = string.Empty,
                    FromCity = string.Empty,
                    FromCountry = string.Empty,
                    ToOrgId = shipmentItem.Buyer.Uid,
                    ToAddressId = 0,
                    ToLocationId = 0,
                    ToStreetName = string.Empty,
                    ToStreetNumber = string.Empty,
                    ToZipCode = string.Empty,
                    ToProvince = string.Empty,
                    ToCity = string.Empty,
                    ToCountry = string.Empty
                };
                shipment.AddProduct(product);

                invoice.AddShipment(shipment);
            }

            return product;
        }

        public virtual InvoiceCompositeProduct AddProduct(Invoice invoice, CompositeProductSupply prodSupply, ShipmentItem4CompositeProd shipmentItem, VatSetting VATSettings)
        {
            var product = new InvoiceCompositeProduct
            {
                ProductId = prodSupply.Uid,
                ShipmentItemId = shipmentItem.Uid,
                OrgId = prodSupply.SellerId,//.Organization.Uid,
                DispatchDate = prodSupply.DispatchDate,
                Price = prodSupply.Price,
                //Amount = prodSupply.AmountSoldShipped,
                Currency = prodSupply.Currency ?? "EUR",
                SellerOrgId = prodSupply.SellerId,//.SalesOrganization.Uid,
                BuyerOrgId = prodSupply.BuyerId,//.PurchaseOrgId,
            };

            //var buyerLangCode = invoice.BuyerLanguage;
            //product.AddLanguage(new InvoiceProductLanguage
            //{
            //    LangCode = buyerLangCode,
            //    SpeciesName = prodSupply.Species.GetName(buyerLangCode),
            //    ProdTypeName = prodSupply.ProdType.GetName(buyerLangCode),
            //    ColorName = prodSupply.Color.GetName(buyerLangCode),
            //    CategoryTypeName = prodSupply.CategoryType.GetName(buyerLangCode),
            //    CategoryName = prodSupply.Category.GetName(buyerLangCode),
            //    AdditionalAttributes = string.Join(", ", prodSupply.AdditionalAttrs.OrderBy(a => a.Name).Select(a => a.GetName(buyerLangCode)).ToArray()),
            //    UomName = prodSupply.Uom.Name,
            //    OrgName = prodSupply.Organization.GetName(buyerLangCode),
            //    VAT = VATSettings.VatTextField
            //});

            //var issuerLangCode = invoice.SellerLanguage;
            //product.AddLanguage(new InvoiceProductLanguage
            //{
            //    LangCode = issuerLangCode,
            //    SpeciesName = prodSupply.Species.GetName(issuerLangCode),
            //    ProdTypeName = prodSupply.ProdType.GetName(issuerLangCode),
            //    ColorName = prodSupply.Color.GetName(issuerLangCode),
            //    CategoryTypeName = prodSupply.CategoryType.GetName(issuerLangCode),
            //    CategoryName = prodSupply.Category.GetName(issuerLangCode),
            //    AdditionalAttributes = string.Join(", ", prodSupply.AdditionalAttrs.OrderBy(a => a.Name).Select(a => a.GetName(issuerLangCode)).ToArray()),
            //    UomName = prodSupply.Uom.Name,
            //    OrgName = prodSupply.Organization.GetName(issuerLangCode),
            //    VAT = VATSettings.VatTextField
            //});

            invoice.AddProduct(product);

            ////var shipment = invoice.Shipments.Where(s => s.ShipmentId == shipmentItem.Uid).SingleOrDefault();
            ////if (shipment != null)
            ////{
            ////    shipment.AddProduct(product);
            ////}
            ////else
            ////{
            ////    shipment = new InvoiceShipment
            ////    {
            ////        Invoice = invoice,
            ////        ShipmentId = shipmentItem.Uid,
            ////        ShipmentDate = shipmentItem.ShipmentList.CreatedAt,
            ////        ShipmentRef = string.Empty,
            ////        FromOrgId = shipmentItem.Seller.Uid,//.Grower.Uid,
            ////        FromAddressId = 0, //shipmentItem.AddressId,
            ////        FromLocationId = 0,//shipmentItem.LocationId,
            ////        FromLocation = string.Empty,
            ////        FromStreetName = string.Empty,
            ////        FromStreetNumber = string.Empty,
            ////        FromZipCode = string.Empty,
            ////        FromProvince = string.Empty,
            ////        FromCity = string.Empty,
            ////        FromCountry = string.Empty,
            ////        ToOrgId = shipmentItem.Buyer.Uid,
            ////        ToAddressId = 0,
            ////        ToLocationId = 0,
            ////        ToStreetName = string.Empty,
            ////        ToStreetNumber = string.Empty,
            ////        ToZipCode = string.Empty,
            ////        ToProvince = string.Empty,
            ////        ToCity = string.Empty,
            ////        ToCountry = string.Empty
            ////    };
            ////    shipment.AddProduct(product);

            //    invoice.AddShipment(shipment);
            //}

            return product;
        }

        public virtual InvoicePackage AddPackage(Invoice invoice, PackingConfirmed packingConfirmed, string VAT)
        {
            var product = invoice.Products.Where(p => p.ProductId == packingConfirmed.ProdConfirmed.Uid).Single();

            return AddPackage(product, packingConfirmed, VAT);
        }

        public virtual InvoicePackage AddPackage(InvoiceProduct product, PackingConfirmed packingConfirmed, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddPackage(product, packingConfirmed, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoicePackage AddPackage(InvoiceCompositeProduct product, PackingConfirmed packingConfirmed, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddPackage(product, packingConfirmed, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoicePackage AddPackage(InvoiceProduct product, PackingConfirmed packingConfirmed, VatSetting VATSettings)
        {
            var package = new InvoicePackage
            {
                ProductId = product.ProductId,
                PackingConfirmedId = packingConfirmed.Uid,
                PackagingDefineId = packingConfirmed.Packing.Uid,
                Price = packingConfirmed.PricePerUnit,
                PriceType = packingConfirmed.PriceType,
                Amount = packingConfirmed.PackingAmount,
                Currency = packingConfirmed.Packing.Currency,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type,
                InvoiceProduct = product
            };

            var buyerLangCode = product.Invoice.BuyerLanguage;
            package.AddLanguage(new InvoicePackageLanguage
            {
                InvoicePackage = package,
                LangCode = buyerLangCode,
                Name = packingConfirmed.Packing.GetName(buyerLangCode),
                VAT = VATSettings.VatTextField
            });

            var issuerLangCode = product.Invoice.SellerLanguage;
            package.AddLanguage(new InvoicePackageLanguage
            {
                InvoicePackage = package,
                LangCode = issuerLangCode,
                Name = packingConfirmed.Packing.GetName(issuerLangCode),
                VAT = VATSettings.VatTextField
            });

            product.AddPackage(package);

            return package;
        }

        public virtual InvoicePackage AddPackage(InvoiceCompositeProduct product, PackingConfirmed packingConfirmed, VatSetting VATSettings)
        {
            var package = new InvoicePackage
            {
                CmpProductId = product.ProductId,
                PackingConfirmedId = packingConfirmed.Uid,
                PackagingDefineId = packingConfirmed.Packing.Uid,
                Price = packingConfirmed.PricePerUnit,
                PriceType = packingConfirmed.PriceType,
                Amount = packingConfirmed.PackingAmount,
                Currency = packingConfirmed.Packing.Currency,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type,
                InvoiceCompositeProduct = product
            };

            var buyerLangCode = product.Invoice.BuyerLanguage;
            package.AddLanguage(new InvoicePackageLanguage
            {
                InvoicePackage = package,
                LangCode = buyerLangCode,
                Name = packingConfirmed.Packing.GetName(buyerLangCode),
                VAT = VATSettings.VatTextField
            });

            var issuerLangCode = product.Invoice.SellerLanguage;
            package.AddLanguage(new InvoicePackageLanguage
            {
                InvoicePackage = package,
                LangCode = issuerLangCode,
                Name = packingConfirmed.Packing.GetName(issuerLangCode),
                VAT = VATSettings.VatTextField
            });

            product.AddPackage(package);

            return package;
        }

        public virtual InvoiceAddOn AddPackageAddOn(Invoice invoice, PackingConfirmed packingConfirmed, AddonsConfirmed addOnsConfirmed, string VAT)
        {
            if (addOnsConfirmed.PackConfirmed == null || addOnsConfirmed.PackConfirmed.Uid != packingConfirmed.Uid) throw new ArgumentException();

            var package = invoice.Products.Where(p => p.ProductId == addOnsConfirmed.ProdConfirmed.Uid).SelectMany(p => p.Packages).Where(p => p.PackingConfirmedId == addOnsConfirmed.PackConfirmed.Uid).Single();

            return AddPackageAddOn(package, packingConfirmed, addOnsConfirmed, VAT);
        }

        public virtual InvoiceAddOn AddPackageAddOn(InvoicePackage package, PackingConfirmed packingConfirmed, AddonsConfirmed addOnsConfirmed, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddPackageAddOn(package, packingConfirmed, addOnsConfirmed, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoiceAddOn AddPackageAddOn(InvoicePackage package, PackingConfirmed packingConfirmed, AddonsConfirmed addOnsConfirmed, VatSetting VATSettings)
        {
            if (addOnsConfirmed.PackConfirmed == null || addOnsConfirmed.PackConfirmed.Uid != packingConfirmed.Uid) throw new ArgumentException();

            var paRepo = factory.CreateRepository<PackagingAddOns>();

            var addOn = new InvoiceAddOn
            {
                PackingConfirmedId = packingConfirmed.Uid,
                PackagingDefineId = packingConfirmed.Packing.Uid,
                AddOnsConfirmedId = addOnsConfirmed.Uid,
                AddOnsDefineId = addOnsConfirmed.AddOns.Uid,
                Price = paRepo.Find(new PackageAddOnsByPackageIdAddOnIdSpecification(packingConfirmed.Packing.Uid, addOnsConfirmed.AddOns.Uid)).Single().Price,
                Amount = package.Amount,
                Currency = addOnsConfirmed.AddOns.Currency,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type
            };

            var buyerLangCode = package.InvoiceProduct.Invoice.BuyerLanguage;
            addOn.AddLanguage(new InvoiceAddOnLanguage
            {
                LangCode = buyerLangCode,
                Name = addOnsConfirmed.AddOns.GetName(buyerLangCode),
                VAT = VATSettings.VatTextField
            });

            var issuerLangCode = package.InvoiceProduct.Invoice.SellerLanguage;
            addOn.AddLanguage(new InvoiceAddOnLanguage
            {
                LangCode = issuerLangCode,
                Name = addOnsConfirmed.AddOns.GetName(issuerLangCode),
                VAT = VATSettings.VatTextField
            });

            package.InvoiceProduct.AddAddOn(addOn);

            return addOn;
        }

        public virtual InvoiceAddOn AddAddOn(Invoice invoice, AddonsConfirmed addOnsConfirmed, string VAT)
        {
            var product = invoice.Products.Where(p => p.ProductId == addOnsConfirmed.ProdConfirmed.Uid).Single();

            return AddAddOn(product, addOnsConfirmed, VAT);
        }

        public virtual InvoiceAddOn AddAddOn(InvoiceProduct product, AddonsConfirmed addOnsConfirmed, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));

            return AddAddOn(product, addOnsConfirmed, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoiceAddOn AddAddOn(InvoiceProduct product, AddonsConfirmed addOnsConfirmed, VatSetting VATSettings)
        {
            if (product.ProductId != addOnsConfirmed.ProdConfirmed.Uid) throw new ArgumentException();
            if (addOnsConfirmed.PackConfirmed != null) throw new ArgumentException();

            var addOn = new InvoiceAddOn
            {
                AddOnsConfirmedId = addOnsConfirmed.Uid,
                AddOnsDefineId = addOnsConfirmed.AddOns.Uid,
                Price = addOnsConfirmed.AddOns.WithoutPackPrice,
                Amount = addOnsConfirmed.Amount,
                Currency = addOnsConfirmed.AddOns.Currency,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type
            };
            addOn.AddLanguage(new InvoiceAddOnLanguage
            {
                LangCode = product.Invoice.BuyerLanguage,
                Name = addOnsConfirmed.AddOns.GetName(product.Invoice.BuyerLanguage),
                VAT = VATSettings.VatTextField
            });
            addOn.AddLanguage(new InvoiceAddOnLanguage
            {
                LangCode = product.Invoice.SellerLanguage,
                Name = addOnsConfirmed.AddOns.GetName(product.Invoice.SellerLanguage),
                VAT = VATSettings.VatTextField
            });

            product.AddAddOn(addOn);

            return addOn;
        }

        public virtual InvoiceDecomposition AddDecomposition(Invoice invoice, DecompositionInfo decompositionInfo, ProductSupplyForecast productSupply, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            var invDecomposition = new InvoiceDecomposition
            {
                ProductSupply = productSupply,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type,
            };

            if (decompositionInfo != null)
            {
                invDecomposition.DecomposeType = decompositionInfo.DecomposeType;
                invDecomposition.Price = decompositionInfo.Cost;
                invDecomposition.Currency = decompositionInfo.CostCurrency;
                invDecomposition.Amount = decompositionInfo.NumberPackage;
                invDecomposition.PriceType = (PriceUnitType)Enum.Parse(typeof(PriceUnitType), decompositionInfo.CostUnit);
                invDecomposition.FromDateTime = decompositionInfo.PeriodFromDate;
                invDecomposition.ToDateTime = decompositionInfo.PeriodToDate;
            }

            invDecomposition.AddLanguage(new InvoiceDecompositionLanguage
                                         {
                                             LangCode = invoice.BuyerLanguage,
                                             VAT = VATSettings.VatTextField
                                         });

            invDecomposition.AddLanguage(new InvoiceDecompositionLanguage
            {
                LangCode = invoice.SellerLanguage,
                VAT = VATSettings.VatTextField
            });

            invoice.AddDecomposition(invDecomposition);
            return invDecomposition;
        }

        public virtual InvoiceCharge1 AddCharge(Invoice invoice, InvoiceCharge invoiceCharge, string VAT)
        {
            var VATSettings = vatSettingsRepo.GetOne(long.Parse(VAT.Substring(VAT.LastIndexOf('_') + 1)));
            return AddCharge(invoice, invoiceCharge, new VatSetting
            {
                VatDefine = VATSettings.VatDefine,
                VatTextField = string.IsNullOrEmpty(VATSettings.VatTextField) ? (VATSettings.VatDefine / 100.0M).ToString("0.#%") : VATSettings.VatTextField,
                Gs1Code = VATSettings.Gs1Code,
                LedgerCode = VATSettings.LedgerCode,
                OtherCode = VATSettings.OtherCode,
                Type = VATSettings.Type
            });
        }

        public virtual InvoiceCharge1 AddCharge(Invoice invoice, InvoiceCharge invoiceCharge, VatSetting VATSettings)
        {
            InvoiceCharge1 charge = new InvoiceCharge1
            {
                InvoiceChargeId = invoiceCharge.Uid,
                Price = invoiceCharge.Price,
                PriceType = invoiceCharge.ChargePriceType,
                VAT = VATSettings.VatDefine,
                VAT_Gs1Code = VATSettings.Gs1Code,
                VAT_LedgerCode = VATSettings.LedgerCode,
                VAT_OtherCode = VATSettings.OtherCode,
                VAT_Type = VATSettings.Type,
                Currency = invoiceCharge.Currency,
            };
            if (invoiceCharge.InvChargeCategory != null) charge.CategoryId = invoiceCharge.InvChargeCategory.Uid;

            switch (charge.PriceType)
            {
                case InvChargePriceType.FixedAmountPerInvoice:
                    charge.Amount = invoiceCharge.Amount;
                    charge.TotalPrice = Math.Round(charge.Price * charge.Amount, 2);
                    break;
                case InvChargePriceType.PercentChargePerUnit:
                    charge.Amount = 1;
                    charge.TotalPrice = Math.Round(invoice.TotalPackagePrice * charge.Price / 100, 2);
                    break;
                case InvChargePriceType.PercentOfProductValueInvoice:
                    charge.Amount = 1;
                    charge.TotalPrice = Math.Round(invoice.TotalProductPrice * charge.Price / 100, 2);
                    break;
            }

            charge.AddLanguage(new InvoiceChargeLanguage
            {
                LangCode = invoice.BuyerLanguage,
                Name = invoiceCharge.GetName(invoice.BuyerLanguage),
                VAT = VATSettings.VatTextField,
                CategoryName = (invoiceCharge.InvChargeCategory != null) ? invoiceCharge.InvChargeCategory.GetName(invoice.BuyerLanguage) : string.Empty

            });

            charge.AddLanguage(new InvoiceChargeLanguage
            {
                LangCode = invoice.SellerLanguage,
                Name = invoiceCharge.GetName(invoice.SellerLanguage),
                VAT = VATSettings.VatTextField,
                CategoryName = (invoiceCharge.InvChargeCategory != null) ? invoiceCharge.InvChargeCategory.GetName(invoice.SellerLanguage) : string.Empty
            });

            invoice.AddCharge(charge);

            return charge;
        }

        public virtual void Recalculate(Invoice invoice, bool updateProducts, bool updatePackages, bool updateCharges, bool updateDecompose = false)
        {
            if (updateProducts)
            {
                invoice.TotalProductPrice = Math.Round(invoice.Products.Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => p.TotalPrice), 2);
                invoice.TotalProductVAT = Math.Round(invoice.Products.Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => p.TotalPrice * p.VAT / 100), 2);
            }

            if (updatePackages)
            {
                invoice.TotalPackagePrice = invoice.Products.SelectMany(p => p.Packages).Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => p.TotalPrice) + invoice.Products.SelectMany(p => p.AddOns).Where(a => a.RecordStatus != RecordStatus.Deleting).Sum(a => a.TotalPrice);
                invoice.TotalPackageVAT = invoice.Products.SelectMany(p => p.Packages).Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => Math.Round(p.TotalPrice * p.VAT / 100, 2)) + invoice.Products.SelectMany(p => p.AddOns).Where(a => a.RecordStatus != RecordStatus.Deleting).Sum(a => Math.Round(a.TotalPrice * a.VAT / 100, 2));

                //Composite Product Package Price
                invoice.TotalPackagePrice += invoice.CompositeProducts.SelectMany(p => p.Packages).Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => p.TotalPrice);
                invoice.TotalPackageVAT += invoice.CompositeProducts.SelectMany(p => p.Packages).Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => Math.Round(p.TotalPrice * p.VAT / 100, 2));
            }

            if (updateDecompose)
            {
                invoice.TotalDecompositionPrice = Math.Round(invoice.Decompositions.Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => p.TotalPrice), 2);
                invoice.TotalDecompositionVAT = Math.Round(invoice.Decompositions.Where(p => p.RecordStatus != RecordStatus.Deleting).Sum(p => p.TotalPrice * p.VAT / 100), 2);
            }

            if (updateCharges)
            {
                foreach (var charge in invoice.Charges)
                {
                    switch (charge.PriceType)
                    {
                        case InvChargePriceType.FixedAmountPerInvoice:
                            charge.TotalPrice = Math.Round(charge.Price * charge.Amount, 2);
                            break;
                        case InvChargePriceType.PercentChargePerUnit:
                            charge.TotalPrice = Math.Round(invoice.TotalPackagePrice * charge.Price / 100, 2);
                            break;
                        case InvChargePriceType.PercentOfProductValueInvoice:
                            charge.TotalPrice = Math.Round(invoice.TotalProductPrice * charge.Price / 100, 2);
                            break;
                    }
                }

                invoice.TotalChargePrice = Math.Round(invoice.Charges.Where(c => c.RecordStatus != RecordStatus.Deleting).Sum(c => c.TotalPrice), 2) * (invoice.InvoiceType == InvoiceType.Debit ? 1 : -1);
                invoice.TotalChargeVAT = Math.Round(invoice.Charges.Where(c => c.RecordStatus != RecordStatus.Deleting).Sum(c => c.TotalPrice * c.VAT / 100), 2) * (invoice.InvoiceType == InvoiceType.Debit ? 1 : -1);
            }

            invoice.TotalPrice = invoice.TotalProductPrice + invoice.TotalPackagePrice + invoice.TotalChargePrice + invoice.TotalDecompositionPrice;
            invoice.TotalVAT = invoice.TotalProductVAT + invoice.TotalPackageVAT + invoice.TotalChargeVAT + invoice.TotalDecompositionVAT;
        }

        public virtual Invoice AddInvoice(Invoice invoice)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                invoice.InvoiceNr = GetInvoiceNumber(invoice.InvoiceType);
                invoice.InvoiceStatus = InvoiceStatus.GeneratedAndIssued;
                invoice.Latest = true;
                invoice.Created = invoice.Modified = DateTime.Now;
                invoice.CreatedBy = invoice.ModifiedBy = Thread.CurrentPrincipal.Identity.Name;

                invoiceRepo.Add(invoice);
                invoiceRepo.Flush();

                var productSupplyRepo = factory.CreateRepository<ProductSupplyForecast>();
                var products = productSupplyRepo.Find(invoice.ProductIds);
                foreach (var product in products)
                {
                    switch (invoice.InvoiceType)
                    {
                        case InvoiceType.Debit:

                            product.DebitInvoiceId = invoice.Uid;
                            product.SoldInvoicedAmount = product.BuyerPerspective;
                            if (product.IsDecomposed)
                            {
                                product.DecomposeDebitInvGenerated = true;
                                if (string.IsNullOrEmpty(product.DecomposeDebitInvIds))
                                    product.DecomposeDebitInvIds = invoice.Uid.ToString();
                                else
                                {
                                    var invIds = product.DecomposeDebitInvIds.Split(',').ToList();
                                    invIds.Add(invoice.Uid.ToString());
                                    product.DecomposeDebitInvIds = string.Join(",", invIds.ToArray());
                                }
                            }

                            break;
                        case InvoiceType.Credit:
                            product.CreditInvoiceId = invoice.Uid;
                            product.BoughtInvoicedAmount = product.SellerPerspective;
                            if (product.IsDecomposed)
                            {
                                product.DecomposeCreditInvGenerated = true;
                                if (string.IsNullOrEmpty(product.DecomposeCreditInvIds))
                                    product.DecomposeCreditInvIds = invoice.Uid.ToString();
                                else
                                {
                                    var invIds = product.DecomposeCreditInvIds.Split(',').ToList();
                                    invIds.Add(invoice.Uid.ToString());
                                    product.DecomposeCreditInvIds = string.Join(",", invIds.ToArray());
                                }
                            }

                            break;
                    }

                    productSupplyRepo.Store(product);
                }
                if (!string.IsNullOrEmpty(invoice.CompositeProductIds))
                {
                    var cmpProducts = CompositeProductSupplyServices.GetCompositeProductByUids(invoice.CompositeProductIds);
                    foreach (var cmpProd in cmpProducts)
                    {
                        switch (invoice.InvoiceType)
                        {
                            case InvoiceType.Debit:
                                cmpProd.DebitInvId = invoice.Uid;
                                if (cmpProd.DebitInvId > 0 && cmpProd.CreditInvId > 0)
                                    cmpProd.Status = CompositeProdStatus.Invoiced;
                                break;
                            case InvoiceType.Credit:
                                cmpProd.CreditInvId = invoice.Uid;
                                if (cmpProd.DebitInvId > 0 && cmpProd.CreditInvId > 0)
                                    cmpProd.Status = CompositeProdStatus.Invoiced;

                                break;
                        }
                        factory.GetCompositeProductSupplyRepository().Store(cmpProd);
                    }
                }

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            Organization receiveOrg = orgRepo.GetOne(invoice.BuyerOrgId);
            Organization sellerOrg = orgRepo.GetOne(invoice.SellerOrgId);
            string receiveUser = receiveOrg.ChainEntities[0].Users.First().Username;

            string invPdf = GeneratePDF(invoice, invoice.BuyerLanguage, null);
            EmailSender.SendInvoiceMail(receiveOrg.ChainEntities[0].InvoiceEmail, invPdf, invoice.BuyerLanguage, Convert.ToString(invoice.InvoiceType)
                , receiveUser, receiveOrg.Name, sellerOrg.Name, invoice.InvoiceNr);

            return invoice;
        }

        public virtual Invoice CreateCreditInvoice(Invoice inv)
        {
            if (inv.InvoiceType == InvoiceType.Credit) throw new ArgumentException();

            var orgRepo = factory.GetOrganizationRepository();
            var icRepo = factory.GetInvoiceChargeRepository();
            var pcRepo = factory.GetPackingConfirmedRepository();
            var paRepo = factory.GetPackagingAddOnsRepository();
            var acRepo = factory.GetAddonsConfirmedRepository();
            var psfRepo = factory.GetProductSuppyForecastRepository();

            var sellerOrg = orgRepo.GetOne(inv.SellerOrgId);
            var buyerOrg = orgRepo.GetOne(inv.Products.First().OrgId);
            var issuerLangCode = sellerOrg.ChainEntities[0].PreferredLanguage;
            var buyerLangCode = buyerOrg.ChainEntities[0].PreferredLanguage;

            var invoice = new Invoice
            {
                InvoiceType = InvoiceType.Credit,
                InvoiceNr = string.Empty,
                InvoiceFrom = inv.InvoiceFrom,
                InvoiceTo = inv.InvoiceTo,
                PaymentPeriodFrom = inv.PaymentPeriodFrom,
                PaymentPeriodTo = inv.PaymentPeriodTo,
                Currency = inv.Currency,
                InvoiceStatus = InvoiceStatus.GeneratedAndIssued,
                SellerOrgId = sellerOrg.Uid,
                SellerVATNr = sellerOrg.ChainEntities[0].VatNumber,
                SellerBankAccountNr = sellerOrg.ChainEntities[0].BankAccount1 ?? sellerOrg.ChainEntities[0].BankAccount2,
                SellerChamberOfCommerceNr = sellerOrg.ChainEntities[0].CocNumber,
                SellerLanguage = issuerLangCode,
                BuyerOrgId = buyerOrg.Uid,
                BuyerVATNr = buyerOrg.ChainEntities[0].VatNumber,
                BuyerBankAccountNr = buyerOrg.ChainEntities[0].BankAccount1 ?? buyerOrg.ChainEntities[0].BankAccount2,
                BuyerChamberOfCommerceNr = buyerOrg.ChainEntities[0].CocNumber,
                BuyerLanguage = buyerLangCode,
                SellerRef1 = inv.SellerRef1,
                SellerRef2 = inv.SellerRef2,
                BuyerRef1 = inv.BuyerRef1,
                BuyerRef2 = inv.BuyerRef2,
                ProducerRef1 = inv.ProducerRef1,
                ProducerRef2 = inv.ProducerRef2,
                PackSlipNumber = inv.PackSlipNumber,
                Remarks = inv.Remarks,
                Latest = true
            };
            invoice.AddLanguage(new InvoiceLanguage
            {
                LangCode = buyerLangCode,
                BuyerOrgName = buyerOrg.GetName(buyerLangCode),
                BuyerAddress = buyerOrg.ChainEntities[0].Addresses.First().ToString(),
                SellerOrgName = sellerOrg.GetName(buyerLangCode),
                SellerAddress = sellerOrg.ChainEntities[0].Addresses.First().ToString()
            });
            invoice.AddLanguage(new InvoiceLanguage
            {
                LangCode = issuerLangCode,
                BuyerOrgName = buyerOrg.GetName(issuerLangCode),
                BuyerAddress = buyerOrg.ChainEntities[0].Addresses.First().ToString(),
                SellerOrgName = sellerOrg.GetName(issuerLangCode),
                SellerAddress = sellerOrg.ChainEntities[0].Addresses.First().ToString()
            });

            foreach (var shipment in inv.Shipments)
            {
                var newShipment = (InvoiceShipment)shipment.Clone();
                invoice.AddShipment(newShipment);

                foreach (var product in inv.Products)
                {
                    var prodSupply = psfRepo.GetOne(product.ProductId);

                    var newProduct = AddProduct(invoice, prodSupply,
                        new ShipmentItem { Uid = shipment.ShipmentId.Value },
                        new VatSetting { VatDefine = product.VAT, VatTextField = product.Languages[0].VAT, Gs1Code = product.VAT_Gs1Code, LedgerCode = product.VAT_LedgerCode, OtherCode = product.VAT_OtherCode, Type = (product.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });

                    foreach (var package in product.Packages)
                    {
                        var packingConfirmed = pcRepo.GetOne(package.PackingConfirmedId.Value);
                        var newPackage = AddPackage(newProduct, packingConfirmed,
                            new VatSetting { VatDefine = package.VAT, VatTextField = package.Languages[0].VAT, Gs1Code = package.VAT_Gs1Code, LedgerCode = package.VAT_LedgerCode, OtherCode = package.VAT_OtherCode, Type = (package.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });

                        foreach (var addOn in product.AddOns.Where(a => a.PackingConfirmedId.HasValue && a.PackingConfirmedId == packingConfirmed.Uid))
                        {
                            AddPackageAddOn(newPackage, packingConfirmed, acRepo.GetOne(addOn.AddOnsConfirmedId.Value),
                                new VatSetting { VatDefine = addOn.VAT, VatTextField = addOn.Languages[0].VAT, Gs1Code = addOn.VAT_Gs1Code, LedgerCode = addOn.VAT_LedgerCode, OtherCode = addOn.VAT_OtherCode, Type = (addOn.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });
                        }
                    }

                    foreach (var addOn in product.AddOns)
                    {
                        if (!addOn.PackingConfirmedId.HasValue)
                        {
                            AddAddOn(newProduct, acRepo.GetOne(addOn.AddOnsConfirmedId.Value),
                                new VatSetting { VatDefine = addOn.VAT, VatTextField = addOn.Languages[0].VAT, Gs1Code = addOn.VAT_Gs1Code, LedgerCode = addOn.VAT_LedgerCode, OtherCode = addOn.VAT_OtherCode, Type = (addOn.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });
                        }
                    }

                    newShipment.AddProduct(newProduct);
                }

                foreach (var invCmpProd in inv.CompositeProducts)
                {
                    var cmpProd = factory.GetCompositeProductSupplyRepository().GetOne(invCmpProd.ProductId);

                    var newCmpProduct = AddProduct(invoice, cmpProd, new ShipmentItem4CompositeProd { Uid = shipment.ShipmentId.Value }, new VatSetting());
                    foreach (var cmpPack in invCmpProd.Packages)
                    {
                        var packingConfirmed = pcRepo.GetOne(cmpPack.PackingConfirmedId.Value);
                        var newPackage = AddPackage(newCmpProduct, packingConfirmed,
                            new VatSetting { VatDefine = cmpPack.VAT, VatTextField = cmpPack.Languages[0].VAT, Gs1Code = cmpPack.VAT_Gs1Code, LedgerCode = cmpPack.VAT_LedgerCode, OtherCode = cmpPack.VAT_OtherCode, Type = (cmpPack.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });
                    }
                }
            }

            foreach (var charge in inv.Charges)
            {
                var invoiceCharge = icRepo.GetOne(charge.InvoiceChargeId.Value);
                if (invoiceCharge != null)
                    AddCharge(invoice, invoiceCharge,
                        new VatSetting { VatDefine = charge.VAT, VatTextField = charge.Languages[0].VAT, Gs1Code = charge.VAT_Gs1Code, LedgerCode = charge.VAT_LedgerCode, OtherCode = charge.VAT_OtherCode, Type = (charge.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });
                else
                {
                    InvoiceCharge1 newInvoiceCharge = (InvoiceCharge1)charge.Clone();
                    invoice.AddCharge(newInvoiceCharge);
                }
            }

            Recalculate(invoice, true, true, true);

            return invoice;
        }

        public virtual Invoice NewInvoice(Invoice invoice)
        {
            var newInvoice = (Invoice)invoice.Clone();
            newInvoice.InvoiceStatus = InvoiceStatus.GeneratedAndIssued;
            newInvoice.ParentUid = invoice.Uid;

            foreach (var shipment in invoice.Shipments)
            {
                var newShipment = (InvoiceShipment)shipment.Clone();

                foreach (var product in shipment.Products)
                {
                    var newProduct = (InvoiceProduct)product.Clone();

                    newShipment.AddProduct(newProduct);
                    newInvoice.AddProduct(newProduct);

                    foreach (var package in product.Packages)
                    {
                        var newPackage = (InvoicePackage)package.Clone();
                        newProduct.AddPackage(newPackage);
                    }

                    foreach (var addOn in product.AddOns)
                    {
                        var newAddOn = (InvoiceAddOn)addOn.Clone();
                        newProduct.AddAddOn(newAddOn);
                    }
                }

                newInvoice.AddShipment(newShipment);

                foreach (var invCmpProd in invoice.CompositeProducts)
                {
                    var cmpProd = factory.GetCompositeProductSupplyRepository().GetOne(invCmpProd.ProductId);

                    var newCmpProduct = AddProduct(newInvoice, cmpProd, new ShipmentItem4CompositeProd { Uid = shipment.ShipmentId.Value }, new VatSetting());
                    foreach (var cmpPack in invCmpProd.Packages)
                    {
                        var packingConfirmed = factory.GetPackingConfirmedRepository().GetOne(cmpPack.PackingConfirmedId.Value);
                        var newPackage = AddPackage(newCmpProduct, packingConfirmed,
                            new VatSetting { VatDefine = cmpPack.VAT, VatTextField = cmpPack.Languages[0].VAT, Gs1Code = cmpPack.VAT_Gs1Code, LedgerCode = cmpPack.VAT_LedgerCode, OtherCode = cmpPack.VAT_OtherCode, Type = (cmpPack.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });
                    }
                }
            }

            foreach (var invDecomposition in invoice.Decompositions)
            {
                var newInvDecomposition = (InvoiceDecomposition)invDecomposition.Clone();
                newInvoice.AddDecomposition(newInvDecomposition);
            }

            foreach (var charge in invoice.Charges)
            {
                var newCharge = (InvoiceCharge1)charge.Clone();
                newInvoice.AddCharge(newCharge);
            }

            return newInvoice;
        }

        public virtual Invoice CleanUp(Invoice invoice)
        {
            var newInvoice = (Invoice)invoice.Clone();

            foreach (var shipment in invoice.Shipments)
            {
                var newShipment = (InvoiceShipment)shipment.Clone();

                foreach (var product in shipment.Products)
                {
                    if (product.RecordStatus == RecordStatus.Deleting) continue;

                    var newProduct = (InvoiceProduct)product.Clone();

                    newShipment.AddProduct(newProduct);
                    newInvoice.AddProduct(newProduct);

                    foreach (var package in product.Packages)
                    {
                        if (package.RecordStatus == RecordStatus.Deleting) continue;

                        var newPackage = (InvoicePackage)package.Clone();
                        newProduct.AddPackage(newPackage);
                    }

                    foreach (var addOn in product.AddOns)
                    {
                        if (addOn.RecordStatus == RecordStatus.Deleting) continue;

                        var newAddOn = (InvoiceAddOn)addOn.Clone();
                        newProduct.AddAddOn(newAddOn);
                    }
                }

                foreach (var product in shipment.Products)
                {
                    if (product.RecordStatus != RecordStatus.Deleting) continue;

                    var newProduct = newShipment.Products.Where(p => p.ProductId == product.ProductId).First();

                    foreach (var package in product.Packages)
                    {
                        if (package.RecordStatus == RecordStatus.Deleting) continue;

                        var newPackage = (InvoicePackage)package.Clone();
                        newProduct.AddPackage(newPackage);
                    }

                    foreach (var addOn in product.AddOns)
                    {
                        if (addOn.RecordStatus == RecordStatus.Deleting) continue;

                        var newAddOn = (InvoiceAddOn)addOn.Clone();
                        newProduct.AddAddOn(newAddOn);
                    }
                }

                newInvoice.AddShipment(newShipment);

                //TODO: Need to check for correction invoice function
                foreach (var invCmpProd in invoice.CompositeProducts)
                {
                    var cmpProd = factory.GetCompositeProductSupplyRepository().GetOne(invCmpProd.ProductId);

                    var newCmpProduct = AddProduct(newInvoice, cmpProd, new ShipmentItem4CompositeProd { Uid = shipment.ShipmentId.Value }, new VatSetting());
                    foreach (var cmpPack in invCmpProd.Packages)
                    {
                        if (cmpPack.RecordStatus == RecordStatus.Deleting) continue;
                        var packingConfirmed = factory.GetPackingConfirmedRepository().GetOne(cmpPack.PackingConfirmedId.Value);
                        var newPackage = AddPackage(newCmpProduct, packingConfirmed,
                            new VatSetting { VatDefine = cmpPack.VAT, VatTextField = cmpPack.Languages[0].VAT, Gs1Code = cmpPack.VAT_Gs1Code, LedgerCode = cmpPack.VAT_LedgerCode, OtherCode = cmpPack.VAT_OtherCode, Type = (cmpPack.VAT_Type == VatType.NotApplicable ? VatType.NotApplicable : VatType.Received) });
                    }
                }
            }

            foreach (var invDcmp in invoice.Decompositions)
            {
                if (invDcmp.RecordStatus == RecordStatus.Deleting) continue;
                var newDcmpInv = (InvoiceDecomposition)invDcmp.Clone();
                newInvoice.AddDecomposition(newDcmpInv);
            }

            foreach (var charge in invoice.Charges)
            {
                if (charge.RecordStatus == RecordStatus.New)
                {
                    var newCharge = (InvoiceCharge1)charge.Clone();
                    newInvoice.AddCharge(newCharge);
                }
            }

            return newInvoice;
        }

        public virtual Invoice CorrectInvoice(Invoice invoice)
        {
            Invoice reverse = null;
            Invoice correct = null;
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                var oldInvoice = invoiceRepo.GetOne(invoice.ParentUid);
                oldInvoice.InvoiceStatus = InvoiceStatus.InvoiceReversed;
                oldInvoice.Latest = false;

                // reverse invoice
                reverse = NewInvoice(oldInvoice);
                reverse.InvoiceNr = GetInvoiceNumber(reverse.InvoiceType);
                reverse.TotalPrice = -oldInvoice.TotalPrice;
                reverse.TotalVAT = -oldInvoice.TotalVAT;
                reverse.TotalProductPrice = -oldInvoice.TotalProductPrice;
                reverse.TotalProductVAT = -oldInvoice.TotalProductVAT;
                reverse.TotalDecompositionPrice = -oldInvoice.TotalDecompositionPrice;
                reverse.TotalDecompositionVAT = -oldInvoice.TotalDecompositionVAT;
                reverse.TotalPackagePrice = -oldInvoice.TotalPackagePrice;
                reverse.TotalPackageVAT = -oldInvoice.TotalPackageVAT;
                reverse.TotalChargePrice = -oldInvoice.TotalChargePrice;
                reverse.TotalChargeVAT = -oldInvoice.TotalChargeVAT;
                reverse.InvoiceStatus = InvoiceStatus.ReverseInvoice;
                reverse.ParentUid = oldInvoice.Uid;
                reverse.Latest = true;
                reverse.Modified = DateTime.Now;
                reverse.ModifiedBy = Thread.CurrentPrincipal.Identity.Name;

                // add the corrective invoice
                correct = NewInvoice(invoice);
                correct.InvoiceNr = GetInvoiceNumber(correct.InvoiceType);
                correct.ParentUid = oldInvoice.Uid;
                correct.Latest = true;
                correct.Modified = DateTime.Now;
                correct.ModifiedBy = Thread.CurrentPrincipal.Identity.Name;

                invoiceRepo.Store(oldInvoice);
                invoiceRepo.Add(reverse);
                invoiceRepo.Add(correct);

                transactionManager.CommitTransaction();
                //return correct;
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            string revPdf = GeneratePDF(reverse, reverse.BuyerLanguage, null);
            string crtPdf = GeneratePDF(correct, correct.BuyerLanguage, null);

            Organization receiveOrg = orgRepo.GetOne(invoice.BuyerOrgId);
            Organization sellerOrg = orgRepo.GetOne(invoice.SellerOrgId);
            string receiveUser = receiveOrg.ChainEntities[0].Users.First().Username;

            EmailSender.SendCorrectInvoiceEmail(receiveOrg.ChainEntities[0].InvoiceEmail, revPdf, crtPdf, correct.BuyerLanguage, Convert.ToString(invoice.InvoiceType),
                receiveUser, receiveOrg.Name, invoice.InvoiceNr, reverse.InvoiceNr, correct.InvoiceNr, sellerOrg.Name);

            return correct;
        }

        public virtual string GeneratePDF(Invoice invoice, string langCode, System.Web.HttpResponse response)
        {
            throw new NotImplementedException();
        }

        public virtual IEnumerable<VatSetting> GetProductVATSettings(Invoice invoice, ProductType productType = ProductType.Product)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                //return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, true, false, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
                return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, false))
                    .Where(vat => (vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received)) || vat.ProductType == productType);
            }
            catch
            {
                return new List<VatSetting>();
            }
        }

        public virtual IEnumerable<VatSetting> GetTreatmentVATSettings(Invoice invoice)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                //return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, true, false, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
                return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, false,0,false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
            }
            catch
            {
                return new List<VatSetting>();
            }
        }

        public virtual IEnumerable<VatSetting> GetDecomposeVATSettings(Invoice invoice)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, false, 0, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
            }
            catch
            {
                return new List<VatSetting>();
            }
        }

        public virtual IEnumerable<VatSetting> GetPackageVATSettings(Invoice invoice)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                //return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, true, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
                return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
            }
            catch
            {
                return new List<VatSetting>();
            }
        }

        public virtual IEnumerable<VatSetting> GetAddOnVATSettings(Invoice invoice)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                //return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, true, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
                return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
            }
            catch
            {
                return new List<VatSetting>();
            }
        }

        public virtual IEnumerable<VatSetting> GetChargeVATSettings(Invoice invoice)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                //return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, true)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
                return vatSettingsRepo.Find(new VatSettingDefaultSpecification(countryId, false, false, false, false)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
            }
            catch
            {
                return new List<VatSetting>();
            }
        }

        public virtual IEnumerable<VatSetting> GetVATSettings(Invoice invoice)
        {
            try
            {
                var org = orgRepo.GetOne(invoice.SellerOrgId);
                var countryId = org.ChainEntities[0].Addresses.FirstOrDefault(a => a.Country != null).Country.Uid;

                return vatSettingsRepo.Find(new VatSettingForCountrySpecification(countryId)).Where(vat => vat.Type == VatType.NotApplicable || vat.Type == (invoice.InvoiceType == InvoiceType.Debit ? VatType.Paid : VatType.Received));
            }
            catch
            {
                return new List<VatSetting>();
            }
        }
    }
}
