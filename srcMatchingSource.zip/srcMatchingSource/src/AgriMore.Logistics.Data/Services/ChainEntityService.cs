﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;
using NHibernate;
using AgriMore.Logistics.Common.Utils;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Common.Data;

namespace AgriMore.Logistics.Data.Services
{
    public class ChainEntityService
    {
        public readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        #region //ConfirmInterestedAmount.aspx
        public ICollection<DesiredAmount> GetForConfirmInterestedAmount(int pageSize, int currPage, out int totalCount, string tradingOrgId, DateTime avaiFrom)
        {
            var desiredAmountByOrganizationSpecification = new DesiredAmountByOrganizationSpecification(tradingOrgId, avaiFrom);
            ICollection<DesiredAmount> listRes = repositoryFactory.GetDesiredAmountRepository().Find(desiredAmountByOrganizationSpecification, (currPage - 1) * pageSize, pageSize);
            desiredAmountByOrganizationSpecification.IsCount = true;
            totalCount = Convert.ToInt32(repositoryFactory.GetDesiredAmountRepository().Count(desiredAmountByOrganizationSpecification));

            return listRes;
        }
        #endregion

        #region //ViewOutstandingRequests.aspx
        public ICollection<SpecificDemand> GetForViewOutstandingRequests(int pageSize, int currPage, out int totalCount, string demandFromOrgId, int productId, int colorId, int catTypeId,
            int categoryId, string demand2OrgIds, DateTime startDate, DateTime endDate, string sortExpression, string sortDirection)
        {
            var specificDemandByTcSpecification = new SpecificDemandByTcSpecification(demandFromOrgId, productId, colorId, catTypeId, categoryId, demand2OrgIds, startDate, endDate,
                sortExpression, sortDirection);

            var listRes = repositoryFactory.GetSpecificDemandRepository().Find(specificDemandByTcSpecification, (currPage - 1) * pageSize, pageSize);
            specificDemandByTcSpecification.IsCount = true;

            totalCount = Convert.ToInt32(repositoryFactory.GetSpecificDemandRepository().Count(specificDemandByTcSpecification));
            return listRes;
        }
        #endregion

        #region //ViewOutstandingDemands.aspx
        public ICollection<SpecificDemand> GetForViewOutstandingDemands(int pageSize, int currPage, out int totalCount, string demandFromOrgId, int productId, int colorId, int catTypeId,
            int categoryId, string demand2OrgIds, DateTime startDate, DateTime endDate, string sortExpression, string sortDirection)
        {
            var specificDemandToTcsSpecification = new SpecificDemandToTcsSpecification(demandFromOrgId, productId, colorId, catTypeId, categoryId, demand2OrgIds, startDate, endDate,
                sortExpression, sortDirection);

            var listRes = repositoryFactory.GetSpecificDemandRepository().Find(specificDemandToTcsSpecification, (currPage - 1) * pageSize, pageSize);
            specificDemandToTcsSpecification.IsCount = true;

            totalCount = Convert.ToInt32(repositoryFactory.GetSpecificDemandRepository().Count(specificDemandToTcsSpecification));
            return listRes;
        }
        #endregion

        #region //OutstandingBidOffers.aspx
        public ICollection<BiddingProcess> GetForOutstandingBidOffers(int pageSize, int currPage, out int totalCount, string loginId, string suppliers, int productId, int colorId, int catTypeId, int categoryId, DateTime startDate,
            DateTime endDate, string sortExpression, string sortDirection)
        {
            var outstandingBidOffersSpecification = new OutstandingBidOffersSpecification(loginId, suppliers, productId, colorId, catTypeId, categoryId, startDate, endDate, sortExpression, sortDirection);
            var listRes = repositoryFactory.GetBiddingProcessRepository().Find(outstandingBidOffersSpecification, (currPage - 1) * pageSize, pageSize);
            outstandingBidOffersSpecification.IsCount = true;
            totalCount = Convert.ToInt32(repositoryFactory.GetBiddingProcessRepository().Count(outstandingBidOffersSpecification));

            return listRes;
        }
        #endregion

        #region //OutstandingInvitations2Bid.aspx
        public ICollection<BiddingDefine> GetForOutstandingInvitations2Bid(int pageSize, int currPage, out int totalCount, string suppliers, int productId, int colorId, int catTypeId, int categoryId, DateTime startDate,
            DateTime endDate, string sortExpression, string sortDirection)
        {
            var outstandingInvitationsSpecification = new OutstandingInvitationsSpecification(suppliers, productId, colorId, catTypeId, categoryId, startDate, endDate, sortExpression, sortDirection);
            var listRes = repositoryFactory.GetBiddingDefineRepository().Find(outstandingInvitationsSpecification, (currPage - 1) * pageSize, pageSize);
            outstandingInvitationsSpecification.IsCount = true;
            totalCount = Convert.ToInt32(repositoryFactory.GetBiddingDefineRepository().Count(outstandingInvitationsSpecification));

            return listRes;
        }
        #endregion

        #region //PackagingDefineSettings.aspx
        public ICollection<PackagingDefine> GetForPackagingDefineSettings(int pageSize, int currPage, out int totalCount, string curLang, string packageTypeName, long packageTypeCategoryId, long packageTypeSubCategoryId, long productId, string orgId)
        {
            var packagingDefineSettingSpecification = new PackagingDefineSettingSpecification(curLang, packageTypeName, packageTypeCategoryId, packageTypeSubCategoryId, productId, orgId);
            ICollection<PackagingDefine> listRes = repositoryFactory.GetPackagingDefineRepository().Find(packagingDefineSettingSpecification, (currPage - 1) * pageSize, pageSize);
            packagingDefineSettingSpecification.IsCount = true;
            totalCount = Convert.ToInt32(repositoryFactory.GetPackagingDefineRepository().Count(packagingDefineSettingSpecification));
            return listRes;
        }

        public IList<PackagingDefine> GetForPackagingDefineSettings4API(string langCode, long packageTypeCategoryId, long productId, string orgId)
        {
            var list = new List<PackagingDefine>();
            var packagingDefineSettingSpecification = new PackagingDefineSetting4APISpecification(langCode, packageTypeCategoryId, productId, orgId);
            IList<PackagingDefine> listRes = repositoryFactory.GetPackagingDefineRepository().Find(packagingDefineSettingSpecification).ToList();
            foreach (var packageType in listRes)
            {
                PackagingDefine pack = packageType;

                foreach (var lang in packageType.PackingDefLangs)
                {
                    if (lang.LangCode == langCode)
                    {
                        pack.Name = lang.Name;
                    }
                }

                list.Add(pack);

            }

            return list;
        }

        public PackagingDefine GetPackagingDefineByLangCode(long id, string langCode)
        {
            var packagingDefineSettingByLanguageSpecification = new PackagingDefineSettingByLanguageCodeSpecification(id, langCode);
            PackagingDefine packageType = repositoryFactory.GetPackagingDefineRepository().Find(packagingDefineSettingByLanguageSpecification).FirstOrDefault();

            PackagingDefine pack = packageType;

            if (pack == null) return new PackagingDefine() { Name = "" };


            foreach (var lang in packageType.PackingDefLangs)
            {
                if (lang.LangCode == langCode)
                {
                    pack.Name = lang.Name;
                }
            }

            return pack;
        }

        #endregion

        #region //DutchAuctions.aspx
        public ICollection<DutchAuctionDefine> GetForDutchAuctions(int pageSize, int currPage, out int totalCount, string tradingOrgId)
        {
            ICollection<DutchAuctionDefine> listRes;
            var dutchAuctionsFromOtherCompanySpecification = new DutchAuctionsFromOtherCompanySpecification(tradingOrgId);
            listRes = repositoryFactory.GetDutchAuctionDefineRepository().Find(dutchAuctionsFromOtherCompanySpecification, (currPage - 1) * pageSize, pageSize);
            dutchAuctionsFromOtherCompanySpecification.IsCount = true;
            totalCount = Convert.ToInt32(repositoryFactory.GetDutchAuctionDefineRepository().Count(dutchAuctionsFromOtherCompanySpecification));
            return listRes;
        }
        #endregion

        #region //ViewDutchAuctions.aspx
        public ICollection<DutchAuctionDefine> GetForViewDutchAuctions(int pageSize, int currPage, out int totalCount, string tradingOrgId)
        {
            ICollection<DutchAuctionDefine> listRes;
            var dutchAuctionsFromOtherCompanySpecification = new DutchAuctionMadeByOrganizationSpecification(tradingOrgId);
            listRes = repositoryFactory.GetDutchAuctionDefineRepository().Find(dutchAuctionsFromOtherCompanySpecification, (currPage - 1) * pageSize, pageSize);
            dutchAuctionsFromOtherCompanySpecification.IsCount = true;
            totalCount = Convert.ToInt32(repositoryFactory.GetDutchAuctionDefineRepository().Count(dutchAuctionsFromOtherCompanySpecification));
            return listRes;
        }
        #endregion
    }
}
