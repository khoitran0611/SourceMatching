﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Data.NHibernate;
using System.Data;

namespace AgriMore.Logistics.Data.Services
{
    public class ProductGroupServices : BaseService
    {
        public ProductGroup GetProductGroupByProductId(long productUid)
        {
            var product = factory.GetSpeciesRepository().GetOne(productUid);
            if (product != null)
            {
                return product.ProdGroup;
            }

            return null;
        }

        public List<Species> GetAllProductsByParentProductGroup(long parentProductGroupId)
        {
            var childProductGrps = new List<ProductGroup>();
            var speciesList = new List<Species>();            

            //Add the current parent product group to the returned list 
            childProductGrps.Add(factory.GetProductGroupRepository().GetOne(parentProductGroupId));

            //First, Get all the childs product groups of the current parent product group id
            var parentProductGrps = factory.GetParentProductGroupInfoRepository().Where(pg => pg.ParentProductGrpId == parentProductGroupId).ToList();
            foreach (var parentPg in parentProductGrps)
            {
                var productGrp = factory.GetProductGroupRepository().Where(pg => pg.Uid == parentPg.ProductGroupId).FirstOrDefault();
                childProductGrps.Add(productGrp);
            }

            //Then get all the products of the child product groups and return
            if (childProductGrps.Any())
            {
                foreach (var pg in childProductGrps)
                {
                    speciesList.AddRange(pg.Products);
                }
            }

            return speciesList;
        }
    }
}
