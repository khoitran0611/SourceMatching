﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class ReverseAuctionServices : BaseService
    {
        public static IList<ReverseAuction> GetReverseAuctionByBuyer(string buyerId)
        {
            const string hsql = "from ReverseAuction ru where ru.BuyerUid = :buyerId";

            var session = NHibernateHttpModule.GetSession;

            var query = session.CreateQuery(hsql);
            query.SetParameter("buyerId", buyerId);

            return query.List().Cast<ReverseAuction>().ToList();
        }

        public static IList<ReverseAuction> GetReverseAuction4Seller(string sellerId, string buyerId)
        {
            string hsql = "select distinct ra from ReverseAuction ra join ra.Sellers as sl where sl.Uid = :sellerId";
            hsql += " and ra.AuctionStartAt <= :curDate and ra.AuctionCloseAt >= :curDate and ra.PurchaseTo >= :curDateOnly";
            if (!string.IsNullOrEmpty(buyerId)) hsql += " and ra.BuyerUid = :buyerId";

            var session = NHibernateHttpModule.GetSession;

            var query = session.CreateQuery(hsql);
            query.SetParameter("sellerId", sellerId);
            query.SetParameter("curDate", DateTime.Now);
            query.SetParameter("curDateOnly", DateTime.Now.Date);
            if (!string.IsNullOrEmpty(buyerId)) query.SetParameter("buyerId", buyerId);

            return query.List().Cast<ReverseAuction>().ToList();
        }

        public static IList<ReverseAuction> GetReverseAuctionJustTimeOut()
        {
            const string queryString = "select distinct ra from ReverseAuction ra where (ra.AuctionCloseAt = :closeDateTime or ra.AuctionCloseAt = :closeDateTimeSub1) and ra.SellerWonId is null";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<ReverseAuction>().ToList();
        }

        public static IList<ReverseAuction4CompositeProduct> GetReverseAuction4CompositeProductJustTimeOut()
        {
            const string queryString = "select distinct ra from ReverseAuction4CompositeProduct ra where (ra.CloseAt = :closeDateTime or ra.CloseAt = :closeDateTimeSub1) and ra.WonSellerId is null";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<ReverseAuction4CompositeProduct>().ToList();
        }

        public static ReverseAuction GetReverseAuction(long planningId, long issuedSeq)
        {
            try
            {
                const string queryString = "select ra from ReverseAuction ra where ra.PlanningId = :planningId and ra.IssuedSeq = :issueSeq";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                query.SetParameter("planningId", planningId);
                query.SetParameter("issueSeq", issuedSeq);

                return (ReverseAuction)query.UniqueResult();
            }
            catch
            {
                return null;
            }
        }

        public static IList<ReverseAuction4CompositeProduct> FindReverseAuction4CompositeProduct(string buyerOrgId, string fromDate, string toDate)
        {
            string hsql = "select distinct rvsa from ReverseAuction4CompositeProduct rvsa where rvsa.BuyerId = :buyerOrgId";
            if (!string.IsNullOrEmpty(fromDate)) hsql += " and rvsa.StartAt >= :fromDate";
            if (!string.IsNullOrEmpty(toDate)) hsql += " and rvsa.StartAt <= :toDate";
            hsql += " order by rvsa.StartAt desc";

            var session = NHibernateHttpModule.GetSession;
            var query = session.CreateQuery(hsql);

            query.SetParameter("buyerOrgId", buyerOrgId);
            if (!string.IsNullOrEmpty(fromDate)) query.SetParameter("fromDate", Convert.ToDateTime(fromDate).Date);
            if (!string.IsNullOrEmpty(toDate)) query.SetParameter("toDate", Convert.ToDateTime(toDate).AddDays(1).Date);

            return query.List().Cast<ReverseAuction4CompositeProduct>().ToList();
        }

        public static IList<ReverseAuction4CompositeProduct> FindInvitedReverseAuction4CompositeProd(string fromBuyer, string toSeller)
        {
            try
            {
                var queryString = "select rvsa from ReverseAuction4CompositeProduct as rvsa join rvsa.InvitedSellerOrgs as invtOrg where invtOrg.Uid = :sellerId";
                if (!string.IsNullOrEmpty(fromBuyer)) queryString += " and rvsa.BuyerId = :buyerId ";
                queryString += " and (rvsa.WonSellerId = :sellerId or (rvsa.WonSellerId is null and rvsa.CloseAt >= :curDateTime))";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                if (!string.IsNullOrEmpty(fromBuyer)) query.SetParameter("buyerId", fromBuyer);
                query.SetParameter("sellerId", toSeller);
                query.SetParameter("curDateTime", DateTime.Now);

                return query.List().Cast<ReverseAuction4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static ReverseAuction SaveOrUpdate(ReverseAuction rvsAuction)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                rvsAuction.UpdatedAt = DateTime.Now;
                factory.GetReverseAuctionRepository().Store(rvsAuction);
                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return rvsAuction;
        }

        public static ReverseAuction4CompositeProduct UpdateReverseAuction4CompositeProd(ReverseAuction4CompositeProduct rvsAuction)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                rvsAuction.UpdatedAt = DateTime.Now;
                factory.GetReverseAuction4CompositeProductRepository().Store(rvsAuction);
                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            return rvsAuction;
        }

        public static ReverseAuction4CompositeProduct SaveOrUpdatePurchase4CompositeProd(ReverseAuction4CompositeProduct rvsAuction, IList<ReverseAuction4CompositeProductPriceDetail> priceDetails,
            string sellerIds, string supplierIds)
        {

            var transactionManager = new TransactionManager();
            try
            {
                if (rvsAuction.Uid != 0) rvsAuction.RemoveAllInvitedSeller();
                IList<Organization> lstTradingOrgs = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(sellerIds)).ToList();
                foreach (Organization org in lstTradingOrgs) rvsAuction.AddInvitedSeller(org);

                if (rvsAuction.Uid != 0) rvsAuction.RemoveAllAgreedSupplier();
                IList<Organization> lstSuppliers = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(supplierIds)).ToList();
                foreach (Organization supplier in lstSuppliers) rvsAuction.AddAgreedSupplier(supplier);

                if (rvsAuction.Uid != 0) rvsAuction.RemoveAllPriceDetail();
                foreach (var priceDetail in priceDetails) rvsAuction.AddPriceDetail(priceDetail);

                transactionManager.BeginTransaction();

                rvsAuction.UpdatedAt = DateTime.Now;
                if (rvsAuction.Uid != 0)
                    factory.GetReverseAuction4CompositeProductRepository().Store(rvsAuction);
                else
                    factory.GetReverseAuction4CompositeProductRepository().Add(rvsAuction);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return rvsAuction;
        }

        public static void DeleteReverseAuction4CompositeProd(ReverseAuction4CompositeProduct rvsAuction)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                factory.GetReverseAuction4CompositeProductRepository().Remove(rvsAuction);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        private static readonly object Obj = new object();
        public static ReverseAuction IndicateProd4ReverseAuction(ReverseAuction rvsAuction, ReverseAuctionSellerBidded rvsAuctionSellerBidded,
            ProductSupplyForecast prod, Organization sellerOrg, bool isUdp4Prod, string errAptMsg)
        {
            lock (Obj)
            {
                factory.GetReverseAuctionRepository().Refresh(rvsAuction);
                if (!string.IsNullOrEmpty(rvsAuction.SellerWonId)) throw new Exception(errAptMsg);

                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    rvsAuction.IsMatched = true;
                    rvsAuction.MatchedProdId = prod.Uid;
                    rvsAuction.WonPrice = rvsAuctionSellerBidded.BiddingPrice;
                    rvsAuction.SellerWonId = rvsAuctionSellerBidded.SellerId;

                    factory.GetReverseAuctionRepository().Store(rvsAuction);
                    factory.GetReverseAuctionSellerBiddedRepository().Add(rvsAuctionSellerBidded);

                    if (isUdp4Prod)
                    {
                        prod.CommitedAmount = prod.AvailableForSale;
                        prod.ActualAmount = prod.AvailableForSale;
                        prod.AvailableToOtherTcs = prod.AvailableForSale;

                        prod.StatusType = ProductStatusType.Commited;
                        prod.SellerStatus = SellerStatus.CommittedSold;
                        prod.BuyerStatus = BuyerStatus.CommittedBought;

                        prod.Price = rvsAuction.WonPrice;
                        prod.Currency = rvsAuction.Currency;
                        prod.PurchaseOrgId = rvsAuction.BuyerUid;
                        prod.SalesOrganization = sellerOrg;
                        factory.GetProductSuppyForecastRepository().Store(prod);
                    }

                    //Check and remove other puchase process that come from Planning Purchase.
                    if (rvsAuction.PlanningId != 0 && rvsAuction.IssuedSeq != 0)
                    {
                        IList<AgreementPurchase> lstAps = AgreementPurchaseServices.GetAgreementPurchase(rvsAuction.PlanningId, rvsAuction.IssuedSeq);
                        foreach (var ap in lstAps) factory.GetAgreementPurchaseRepository().Remove(ap);

                        var bp = BiddingPurchaseServices.GetBiddingPurchase(rvsAuction.PlanningId, rvsAuction.IssuedSeq);
                        if (bp != null) factory.GetBiddingPurchaseRepository().Remove(bp);
                    }

                    transactionManager.CommitTransaction();
                }
                catch
                {
                    transactionManager.RollbackTransaction();
                    throw;
                }
            }
            return rvsAuction;
        }
    }
}
