﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class BiddingProcessServices : BaseService
    {
        public static BiddingProcess4CompositeProductBuyerOffer PostBid(BiddingProcess4CompositeProductBuyerOffer buyerOffer, IList<BiddingProcess4CompositeProductBuyerOfferDetail> offerDetails)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                foreach (var sellerOfferDetail in offerDetails) buyerOffer.AddOfferPriceDetail(sellerOfferDetail);
                factory.GetBiddingProcess4CompositeProductBuyerOfferRepository().Add(buyerOffer);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return buyerOffer;
        }

        public static void DeleteBiddingProcess4CompositeProd(BiddingProcess4CompositeProduct bidProcess)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();
                factory.GetBiddingProcess4CompositeProductRepository().Remove(bidProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static BiddingProcess4CompositeProduct UpdateBiddingProcess4CompositeProd(BiddingProcess4CompositeProduct bidProcess)
        {
            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                bidProcess.UpdatedAt = DateTime.Now;

                factory.GetBiddingProcess4CompositeProductRepository().Store(bidProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return bidProcess;
        }

        public static BiddingProcess4CompositeProduct SaveOrUpdatePurchase4CompositeProd(BiddingProcess4CompositeProduct bidProcess, IList<BiddingProcess4CompositeProductPriceDetail> priceDetails,
            string sellerIds, string supplierIds)
        {
            var transactionManager = new TransactionManager();
            try
            {
                if (bidProcess.Uid != 0) bidProcess.RemoveAllInvitedBuyer();
                IList<Organization> lstTradingOrgs = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(sellerIds)).ToList();
                foreach (Organization org in lstTradingOrgs) bidProcess.AddInvitedBuyer(org);

                if (bidProcess.Uid != 0) bidProcess.RemoveAllSupplier();
                IList<Organization> lstSuppliers = factory.GetOrganizationRepository().Find(new OrganizationByListIdSpecification(supplierIds)).ToList();
                foreach (Organization supplier in lstSuppliers) bidProcess.AddSupplier(supplier);

                if (bidProcess.Uid != 0) bidProcess.RemoveAllPriceDetail();
                foreach (var priceDetail in priceDetails) bidProcess.AddPriceDetail(priceDetail);

                transactionManager.BeginTransaction();

                bidProcess.UpdatedAt = DateTime.Now;
                if (bidProcess.Uid != 0)
                    factory.GetBiddingProcess4CompositeProductRepository().Store(bidProcess);
                else
                    factory.GetBiddingProcess4CompositeProductRepository().Add(bidProcess);

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
            return bidProcess;
        }

        public static IList<BiddingProcess4CompositeProduct> FindBiddingProcess4CompositeProductInPeriod(string sellerId, string fromDate, string toDate)
        {
            try
            {
                string queryString = "select distinct bid from BiddingProcess4CompositeProduct bid where bid.SellerId = :sellerOrgId";
                if (!string.IsNullOrEmpty(fromDate)) queryString += " and bid.StartAt >= :fromDate";
                if (!string.IsNullOrEmpty(toDate)) queryString += " and bid.StartAt <= :toDate";
                queryString += " order by bid.StartAt desc";

                var session = NHibernateHttpModule.GetSession;
                var query = session.CreateQuery(queryString);

                query.SetParameter("sellerOrgId", sellerId);
                if (!string.IsNullOrEmpty(fromDate)) query.SetParameter("fromDate", Convert.ToDateTime(fromDate).Date);
                if (!string.IsNullOrEmpty(toDate)) query.SetParameter("toDate", Convert.ToDateTime(toDate).AddDays(1).Date);

                return query.List().Cast<BiddingProcess4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<BiddingProcess4CompositeProduct> FindInvitedBiddingProcess4CompositeProd(string fromSeller, string toBuyer)
        {
            try
            {
                var queryString = "select bid from BiddingProcess4CompositeProduct as bid join bid.InvitedBuyerOrgs as invtOrg where invtOrg.Uid = :buyerId";
                if (!string.IsNullOrEmpty(fromSeller)) queryString += " and bid.SellerId = :sellerId ";
                queryString += " and (bid.WonBuyerId = :buyerId or (bid.WonBuyerId is null and bid.CloseAt >= :curDateTime))";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);
                if (!string.IsNullOrEmpty(fromSeller)) query.SetParameter("sellerId", fromSeller);
                query.SetParameter("buyerId", toBuyer);
                query.SetParameter("curDateTime", DateTime.Now);

                return query.List().Cast<BiddingProcess4CompositeProduct>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static BiddingProcess4CompositeProductBuyerOffer FindBidOfferOnBiddingProcessByOrg(long bidProcessId, string orgId)
        {
            try
            {
                const string queryString = "select bid from BiddingProcess4CompositeProductBuyerOffer as bid where bid.BiddingProcess.Uid = :bidProcessId and ap.BuyerId = :buyerId";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("bidProcessId", bidProcessId);
                query.SetParameter("buyerId", orgId);

                query.SetMaxResults(1);
                return query.List().Cast<BiddingProcess4CompositeProductBuyerOffer>().ToList()[0];
            }
            catch
            {
                return null;
            }
        }

        public static IList<BiddingProcess4CompositeProductBuyerOffer> FindAllOfferOnBiddingProcess(long bidProcessId)
        {
            try
            {
                const string queryString = "select bidOffer from BiddingProcess4CompositeProductBuyerOffer as bidOffer where bidOffer.BiddingProcess.Uid = :bidProcessId order by bidOffer.OfferPrice desc";

                var session = NHibernateHttpModule.GetSession;

                var query = session.CreateQuery(queryString);

                query.SetParameter("bidProcessId", bidProcessId);

                return query.List().Cast<BiddingProcess4CompositeProductBuyerOffer>().ToList();
            }
            catch
            {
                return null;
            }
        }

        public static IList<BiddingProcess4CompositeProduct> FindFinalBidProcess4CompsiteProd()
        {
            const string queryString = "select distinct bid from BiddingProcess4CompositeProduct bid where (bid.CloseAt = :closeDateTime or bid.CloseAt = :closeDateTimeSub1) and bid.IsMatched = 0";

            var session = NHibernateHttpModule.GetSession;

            DateTime closeDateTime = DateTime.Now.Date;
            closeDateTime = closeDateTime.AddHours(DateTime.Now.Hour);
            closeDateTime = closeDateTime.AddMinutes(DateTime.Now.Minute);

            var query = session.CreateQuery(queryString);
            query.SetDateTime("closeDateTime", closeDateTime);
            query.SetDateTime("closeDateTimeSub1", closeDateTime.AddMinutes(-1));

            return query.List().Cast<BiddingProcess4CompositeProduct>().ToList();
        }
    }
}
