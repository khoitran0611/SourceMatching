﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.Services
{
    public class SubAdministrativeGroupServices : BaseService
    {
        public static void SaveOrUpdate(IList<string> orgIds2Group, string subAdmGroupId)
        {
            var subAdmOrg = factory.GetOrganizationRepository().GetOne(subAdmGroupId);
            var lstOrgInSubGoO = subAdmOrg.GroupOrganizations.Where(it => it.Activated == 1).Select(it => it.Organization.Uid).ToList();

            IList<SubAdministrativeGroup> curSubAdmGroups = GetBySubAdministrativeId(subAdmGroupId);
            var addingOrgIds = orgIds2Group.Where(it => !curSubAdmGroups.Any(subAdm => subAdm.Organization.Uid.Equals(it))).ToList();
            var remSubAdminGroups = curSubAdmGroups.Where(it => !orgIds2Group.Any(orgId => orgId.Equals(it.Organization.Uid))).ToList();
            var unchangeOrgIds = curSubAdmGroups.Where(it => !remSubAdminGroups.Any(remOrg => remOrg.Organization.Uid.Equals(it.Organization.Uid)))
                    .Select(it => it.Organization.Uid).ToList();

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                if (remSubAdminGroups.Count > 0)
                {
                    string remOrgIds = string.Join("','", remSubAdminGroups.Where(it => !lstOrgInSubGoO.Any(orgId => orgId.Equals(it.Organization.Uid)))
                        .Select(it => it.Organization.Uid).ToArray());

                    string strUnchangeOrgIds = unchangeOrgIds.Count > 0 ? string.Join("','", unchangeOrgIds.ToArray()) : string.Empty;
                    string remGoOSql = "delete from base_groupoforganization WHERE GroupOrgId = '" + subAdmGroupId + "' AND " + "OrgId IN ('" + remOrgIds + "'); ";
                    if (!string.IsNullOrEmpty(strUnchangeOrgIds))
                        remGoOSql += "delete from base_groupoforganization WHERE GroupOrgId IN ('" + strUnchangeOrgIds + "') AND " + "OrgId IN ('" + remOrgIds + "');";

                    foreach (var subAdminGroup in remSubAdminGroups)
                        factory.GetSubAdministrativeGroupRepository().Remove(subAdminGroup);
                    factory.GetGroupOrganizationsRepository().ExecuteSql(remGoOSql);
                }

                if (addingOrgIds.Count > 0)
                {
                    var strAddingOrgIds = string.Join("','", addingOrgIds.ToArray());
                    var strCurrentOrgIdInSubAdmin = string.Join("','", orgIds2Group.Where(it => !lstOrgInSubGoO.Any(orgId => orgId.Equals(it))).ToArray());
                    IList<Organization> addingOrgs = OrganizationServices.GetByIds(addingOrgIds.ToArray());
                    foreach (var addingSubAdmin in addingOrgs.Select(org => new SubAdministrativeGroup
                                                                            {
                                                                                Organization = org,
                                                                                SubAdminUid = subAdmGroupId
                                                                            }))
                    {
                        factory.GetSubAdministrativeGroupRepository().Add(addingSubAdmin);
                    }
                    var adminGroupId = ConfigurationManager.AppSettings["AdministrativeGroup"];
                    var remGoOSql = "delete from base_groupoforganization WHERE GroupOrgId IN ('" + strAddingOrgIds + "') AND " + "OrgId NOT IN " +
                                    "('" + strCurrentOrgIdInSubAdmin + "','" + adminGroupId + "' );";
                    factory.GetGroupOrganizationsRepository().ExecuteSql(remGoOSql);
                }

                transactionManager.CommitTransaction();
            }
            catch
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static IList<SubAdministrativeGroup> GetBySubAdministrativeId(string subAdmGroupId)
        {
            const string queryString = "FROM SubAdministrativeGroup subAdm WHERE subAdm.SubAdminUid = :subAdmGroupId";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            iQuery.SetString("subAdmGroupId", subAdmGroupId);
            return iQuery.List().Cast<SubAdministrativeGroup>().ToList();
        }

        public static IList<Organization> GetOrganizationInAdminGroup(string subAdmGroupId)
        {
            const string queryString = "SELECT subAdm.Organization FROM SubAdministrativeGroup subAdm WHERE subAdm.SubAdminUid = :subAdmGroupId";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            iQuery.SetString("subAdmGroupId", subAdmGroupId);
            return iQuery.List().Cast<Organization>().ToList();
        }

        public static IList<Organization> GetOrganizationInAdminGroups(string[] subAdmGroupIds)
        {
            const string queryString = "SELECT subAdm.Organization FROM SubAdministrativeGroup subAdm WHERE subAdm.SubAdminUid in (:subAdmGroupIds)";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            iQuery.SetParameterList("subAdmGroupIds", subAdmGroupIds);
            return iQuery.List().Cast<Organization>().ToList();
        }

        public static IList<string> GetSubAdminIdOfOrganization(string orgId)
        {
            const string queryString = "SELECT DISTINCT subAdm.SubAdminUid FROM SubAdministrativeGroup subAdm WHERE subAdm.Organization.Uid = :orgId";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            iQuery.SetString("orgId", orgId);
            return iQuery.List().Cast<String>().ToList();
        }
    }
}
