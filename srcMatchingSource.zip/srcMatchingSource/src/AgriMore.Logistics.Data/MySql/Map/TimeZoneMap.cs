using System;
using System.Collections.Generic;
using System.Text;
using Timezone = AgriMore.Logistics.Domain.agriMoreTimeZone;
using DtoTimezone = AgriMore.Logistics.Data.MySql.DTO.Timezone;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class TimeZoneMap : IMap<Timezone, DtoTimezone>
    {
        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public Timezone Create(DtoTimezone dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<Timezone>(dto.Uid))
                return session.GetObject<Timezone>(dto.Uid);

            Timezone timezone = new Timezone(dto.Name);

            timezone.Uid = dto.Uid;
            session.Add(timezone);

            return timezone;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return null;
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return false;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoTimezone dto, Timezone element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<Timezone> Convert(IEnumerable<DtoTimezone> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoTimezone dto in dtoValues)
                yield return Create(dto, session);
        }
    }
}
