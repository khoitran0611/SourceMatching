using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;

using Address = AgriMore.Logistics.Domain.Address;
using DtoAddress = AgriMore.Logistics.Data.MySql.DTO.Address;

using DtoCountry = AgriMore.Logistics.Data.MySql.DTO.Country;
using DtoChainEntity = AgriMore.Logistics.Data.MySql.DTO.Chainentity;

using Location = AgriMore.Logistics.Domain.Location;
using DtoLocation = AgriMore.Logistics.Data.MySql.DTO.Location;

using Timezone = AgriMore.Logistics.Domain.agriMoreTimeZone;
using DtoTimezone = AgriMore.Logistics.Data.MySql.DTO.Timezone;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class AddressMap : IMap<Address, DtoAddress>
    {
        #region IMap<Address,Address> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public Address Create(DtoAddress dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<Address>(dto.Uid))
                return session.GetObject<Address>(dto.Uid);

            Country country = new CountryMap().Create(dto.Country, session);
            Timezone timeZone = new TimeZoneMap().Create(dto.Timezone, session);
            
            Address address = new Address(
                dto.City,
                country,
                dto.Email,
                dto.Fax,
                dto.NumberExtension,
                dto.StateProvince,
                dto.StreetName,
                dto.StreetNumber,
                dto.Telephone,
                timeZone,
                dto.ZipCode);

            address.Uid = dto.Uid;
            session.Add(address);

            return address;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return null;
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return false;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoAddress dto, Address element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            // assert that address is always inserted or updated within the context of a chainentity
            session.CurrentContext.Assert("Address can only be persisted as a child of ChainEntity", typeof(ChainEntity));
            
            dto.ChainEntityId = session.CurrentContext[typeof(ChainEntity)].Uid;

            dto.City = element.City;
            dto.CountryId = element.Country.Uid;
            dto.Email = element.Email;
            dto.Fax = element.Fax;
            dto.NumberExtension = element.NumberExtension;
            dto.StateProvince = element.StateProvence;
            dto.StreetName = element.StreetName;
            dto.StreetNumber = element.StreetNumber;
            dto.Telephone = element.Telephone;
            dto.TimezoneId = element.TimeZone.Uid;
            dto.ZipCode = element.ZipCode;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<Address> Convert(IEnumerable<DtoAddress> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoAddress dto in dtoValues)
                yield return Create(dto, session);
        }


        #endregion
    }
}