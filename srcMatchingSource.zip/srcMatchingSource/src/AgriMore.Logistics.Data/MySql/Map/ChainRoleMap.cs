using System;
using System.Collections.Generic;
using AgriMore.Logistics.Data.MySql.DTO;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class ChainRoleMap : IMap<Role, Chainrole>
    {
        #region IMap<Role,Chainrole> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public Role Create(Chainrole dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<Role>(dto.Uid))
                return session.GetObject<Role>(dto.Uid);

            Role role = new Role(dto.Name);

            role.Uid = dto.Uid;
            session.Add(role);

            return role;
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(Chainrole dto, Role element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<Role> Convert(IEnumerable<Chainrole> dtoValues, IRepositorySession session)
        {
            foreach (Chainrole dto in dtoValues)
                yield return Create(dto, session);
        }

        #endregion
    }
}