using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;

using ChainEntity = AgriMore.Logistics.Domain.ChainEntity;
using DtoChainEntity = AgriMore.Logistics.Data.MySql.DTO.Chainentity;

using DtoAddress = AgriMore.Logistics.Data.MySql.DTO.Address;
using DtoLocation = AgriMore.Logistics.Data.MySql.DTO.Location;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class ChainEntityMap : IMap<ChainEntity, DtoChainEntity>
    {
        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public ChainEntity Create(DtoChainEntity dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<ChainEntity>(dto.Uid))
                return session.GetObject<ChainEntity>(dto.Uid);

            IEnumerable<Address> addresses = new AddressMap().Convert(dto.AddressRecords(), session);
            // TODO: ChainUser table needs new foreign key "chainEntityId". After regeneneration of DTO's, this should result
            // in a new method ChainuserRecords() on the Chainentity DTO.
            IEnumerable<User> users = null;// = new ChainUserMap().Convert(dto.ChainuserRecords(), session);

            ChainEntity chainEntity = new ChainEntity(dto.Name, addresses, users);

            chainEntity.Uid = dto.Uid;
            session.Add(chainEntity);
            
            return chainEntity;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoChainEntity dto, ChainEntity element, IRepositorySession session)
        {
            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<ChainEntity> Convert(IEnumerable<DtoChainEntity> dtoValues, IRepositorySession session)
        {
            foreach (DtoChainEntity dto in dtoValues)
                yield return Create(dto, session);
        }

        //private IList<Address> GetAddresses(DtoChainEntity dto, IRepositorySession session)
        //{
        //    IMap<Address, DtoAddress> addressMap = new AddressMap();
        //    IList<Address> addresses = new List<Address>(addressMap.Convert(dto.AddressRecords(), session));
        //    return addresses;
        //}

        //private IList<Location> GetLocations(DtoChainEntity dto, IRepositorySession session)
        //{
        //    IMap<Location, DtoLocation> locationMap = new LocationMap();
        //    IList<Location> locations = new List<Location>();
        //    foreach (DtoAddress dtoAddress in dto.AddressRecords())
        //    {
        //        foreach (DtoLocation dtoLocation in dtoAddress.LocationRecords())
        //        {
        //            Location location = locationMap.Create(dtoLocation, session);
        //            if (!locations.Contains(location))
        //            {
        //                locations.Add(location);
        //            }
        //        }
        //    }
        //    return locations;
        //}
    }
}