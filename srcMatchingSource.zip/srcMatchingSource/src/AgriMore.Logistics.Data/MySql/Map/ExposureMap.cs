using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;

using Exposure = AgriMore.Logistics.Domain.Exposure;
using DtoExposure = AgriMore.Logistics.Data.MySql.DTO.Exposure;

using ExposureActualValue = AgriMore.Logistics.Domain.MeasuredValue;
using DtoExposureActualValue = AgriMore.Logistics.Data.MySql.DTO.Exposureactualvalue;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class ExposureMap : IMap<Exposure, DtoExposure>
    {
        #region IMap<Exposure, DtoExposure> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public Exposure Create(DtoExposure dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<Exposure>(dto.Uid))
                return session.GetObject<Exposure>(dto.Uid);

            ExposureType exposureType = new ExposureTypeMap().Create(dto.Exposuretype, session);
            IEnumerable<ExposureActualValue> actualValues = new ExposureActualValueMap().Convert(dto.ExposureactualvalueRecords(), session);

            Exposure exposure = new Exposure((double)dto.StartRange, (double)dto.EndRange, dto.PrescribeDateTime, actualValues, exposureType);

            exposure.Uid = dto.Uid;
            session.Add(exposure);

            return exposure;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return false;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoExposure dto, Exposure element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            //
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<Exposure> Convert(IEnumerable<DtoExposure> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoExposure dto in dtoValues)
                yield return Create(dto, session);
        }

        #endregion
    }
}