using System;
using System.Collections.Generic;

using UnitOfMeasurement = AgriMore.Logistics.Domain.UnitOfMeasurement;
using DtoUnitOfMeasurement = AgriMore.Logistics.Data.MySql.DTO.Unitofmeasurement;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class UnitOfMeasurementMap : IMap<UnitOfMeasurement, DtoUnitOfMeasurement>
    {
        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public UnitOfMeasurement Create(DtoUnitOfMeasurement dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<UnitOfMeasurement>(dto.Uid))
                return session.GetObject<UnitOfMeasurement>(dto.Uid);

            UnitOfMeasurement uom = new UnitOfMeasurement(dto.Name);

            uom.Uid = dto.Uid;
            session.Add(uom);

            return uom;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoUnitOfMeasurement dto, UnitOfMeasurement element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<UnitOfMeasurement> Convert(IEnumerable<DtoUnitOfMeasurement> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoUnitOfMeasurement dto in dtoValues)
                yield return Create(dto, session);
        }
    }
}
