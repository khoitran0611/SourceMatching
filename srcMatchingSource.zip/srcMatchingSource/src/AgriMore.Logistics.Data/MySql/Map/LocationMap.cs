using System;
using System.Collections.Generic;

using Address = AgriMore.Logistics.Domain.Address;
using DtoAddress = AgriMore.Logistics.Data.MySql.DTO.Address;

using Location = AgriMore.Logistics.Domain.Location;
using DtoLocation = AgriMore.Logistics.Data.MySql.DTO.Location;

using Exposure = AgriMore.Logistics.Domain.Exposure;
using DtoExposure = AgriMore.Logistics.Data.MySql.DTO.Exposure;


namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class LocationMap : IMap<Location, DtoLocation>
    {
        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public Location Create(DtoLocation dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<Location>(dto.Uid))
                return session.GetObject<Location>(dto.Uid);

            Location location = new Location(dto.Name);

            location.Uid = dto.Uid;
            session.Add(location);

            return location;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoLocation dto, Location element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null) 
                throw new ArgumentNullException("element");

            // assert that location is always inserted or updated within the context of an address
            session.CurrentContext.Assert("Location can only be persisted as a child of Address", typeof(Address));

            dto.AddressId = session.CurrentContext[typeof(Address)].Uid;

            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<Location> Convert(IEnumerable<DtoLocation> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null) 
                throw new ArgumentNullException("dtoValues");

            foreach (DtoLocation dto in dtoValues)
                yield return Create(dto, session);
        }        
    }
}
