using System;
using System.Collections.Generic;

using PackageTypeCategory = AgriMore.Logistics.Domain.PackageTypeCategory;
using DtoPackageTypeCategory = AgriMore.Logistics.Data.MySql.DTO.Packagetypecategory;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class PackageTypeCategoryMap : IMap<PackageTypeCategory, DtoPackageTypeCategory>
    {
        #region IMap<PackageTypeCategory, DtoPackageTypeCategory> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public PackageTypeCategory Create(DtoPackageTypeCategory dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<PackageTypeCategory>(dto.Uid))
                return session.GetObject<PackageTypeCategory>(dto.Uid);

            PackageTypeCategory ptc = new PackageTypeCategory(dto.Name);

            ptc.Uid = dto.Uid;
            session.Add(ptc);

            return ptc;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoPackageTypeCategory dto, PackageTypeCategory element, IRepositorySession session)
        {
            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<PackageTypeCategory> Convert(IEnumerable<DtoPackageTypeCategory> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoPackageTypeCategory dto in dtoValues)
                yield return Create(dto, session);
        }

        #endregion
    }
}