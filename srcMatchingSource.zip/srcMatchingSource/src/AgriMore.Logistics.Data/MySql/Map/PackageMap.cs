//using System;
//using System.Collections.Generic;
//using AgriMore.Logistics.Domain;
//using DtoPackage = AgriMore.Logistics.Data.MySql.DTO.Package;
//using DtoPackageType = AgriMore.Logistics.Data.MySql.DTO.Packagetype;
//using DtoIdentification = AgriMore.Logistics.Data.MySql.DTO.Packageidentification;
//using DtoPrimaryProduct = AgriMore.Logistics.Data.MySql.DTO.Primaryproduct;
//using DtoPrimaryProductPackage = AgriMore.Logistics.Data.MySql.DTO.Primaryproductpackage;

//namespace AgriMore.Logistics.Data.MySql.Map
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public class PackageMap : IMap<Package, DtoPackage>
//    {
//        #region IMap<Package,Package> Members

//        /// <summary>
//        /// Creates the element using data from the specified dto.
//        /// </summary>
//        /// <param name="dto">The dto.</param>
//        /// <param name="session">The session.</param>
//        /// <returns></returns>
//        public Package Create(DtoPackage dto, IRepositorySession session)
//        {
//            if (dto == null)
//                throw new ArgumentNullException("dto");

//            if (session.Contains<Package>(dto.Uid))
//                return session.GetObject<Package>(dto.Uid);

//            PackageTypeMap packageTypeMap = new PackageTypeMap();
//            PackageType packageType = packageTypeMap.Create(dto.Packagetype, session);
//            IList<PrimaryProduct> primaryProducts = GetPrimaryProducts(dto, session);
//            IList<Identification> packIdentifications = GetIdentifications(dto, session);
//            Package package =
//                new Package(packageType, primaryProducts, dto.PackingDateTime, packIdentifications, dto.ProductCode);

//            package.Uid = dto.Uid;
//            session.Add(package);
            
//            return package;
//        }

//        /// <summary>
//        /// Indicates whether or not the type supports unique name lookup.
//        /// </summary>
//        /// <returns></returns>
//        public bool SupportsUniqueNameLookup()
//        {
//            return false;
//        }

//        /// <summary>
//        /// Gets the unique name column.
//        /// </summary>
//        /// <returns></returns>
//        public string GetUniqueNameColumn()
//        {
//            return null;
//        }

//        /// <summary>
//        /// Writes the dto using data from the element.
//        /// </summary>
//        /// <param name="dto">The dto.</param>
//        /// <param name="element">The element.</param>
//        /// <param name="session">The session.</param>
//        public void WriteDto(DtoPackage dto, Package element, IRepositorySession session)
//        {
//            if (dto == null)
//                throw new ArgumentNullException("dto");
//            if (element == null)
//                throw new ArgumentNullException("element");

//            dto.PackingDateTime = element.PackingDateTime;
//            dto.PackageTypeId = element.PackageType.Uid;
//            dto.ProductCode = element.ProductCode;
//        }

//        /// <summary>
//        /// Converts the specified values.
//        /// </summary>
//        /// <param name="dtoValues">The dto values.</param>
//        /// <param name="session">The session.</param>
//        /// <returns></returns>
//        public IEnumerable<Package> Convert(IEnumerable<DtoPackage> dtoValues, IRepositorySession session)
//        {
//            foreach (DtoPackage dto in dtoValues)
//                yield return Create(dto, session);
//        }

//        #endregion

//        private IList<PrimaryProduct> GetPrimaryProducts(DtoPackage dto, IRepositorySession session)
//        {
//            IMap<PrimaryProduct, DtoPrimaryProduct> primaryProductMap = new PrimaryProductMap();
//            IList<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
//            foreach (DtoPrimaryProductPackage dtoPPP in dto.PrimaryproductpackageRecords())
//                primaryProducts.Add(
//                    primaryProductMap.Create(dtoPPP.Primaryproduct, session));
//            return primaryProducts;
//        }

//        private IList<Identification> GetIdentifications(DtoPackage dto, IRepositorySession session)
//        {
//            IMap<Identification, DtoIdentification> identificationMap = new IdentificationMap();
//            IList<Identification> packIdentifications = new List<Identification>(
//                identificationMap.Convert(dto.PackageidentificationRecords(), session));
//            return packIdentifications;
//        }
//    }
//}