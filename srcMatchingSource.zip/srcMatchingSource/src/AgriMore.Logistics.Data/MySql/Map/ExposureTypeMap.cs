using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;

using ExposureType = AgriMore.Logistics.Domain.ExposureType;
using DtoExposureType = AgriMore.Logistics.Data.MySql.DTO.Exposuretype;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class ExposureTypeMap : IMap<ExposureType, DtoExposureType>
    {
        #region IMap<ExposureType,DtoExposureType> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public ExposureType Create(DtoExposureType dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<ExposureType>(dto.Uid))
                return session.GetObject<ExposureType>(dto.Uid);

            UnitOfMeasurement uom = new UnitOfMeasurementMap().Create(dto.Unitofmeasurement, session);

            ExposureType exposureType = new ExposureType(dto.Name, uom);

            exposureType.Uid = dto.Uid;
            session.Add(exposureType);

            return exposureType;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoExposureType dto, ExposureType element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            dto.Name = element.Name;
            dto.UomId = element.UnitOfMeasurement.Uid;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<ExposureType> Convert(IEnumerable<DtoExposureType> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoExposureType dto in dtoValues)
                yield return Create(dto, session);
        }


        #endregion
    }
}