using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using DtoPrimaryProduct = AgriMore.Logistics.Data.MySql.DTO.Primaryproduct;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class PrimaryProductMap : IMap<PrimaryProduct, DtoPrimaryProduct>
    {
        #region IMap<PrimaryProduct,Primaryproduct> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public PrimaryProduct Create(DtoPrimaryProduct dto, IRepositorySession session)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoPrimaryProduct dto, PrimaryProduct element, IRepositorySession session)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<PrimaryProduct> Convert(IEnumerable<DtoPrimaryProduct> dtoValues, IRepositorySession session)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}