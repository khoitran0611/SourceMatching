using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Contexts;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Data.MySql
{
    /// <summary>
    /// The RepositorySession object is used to keep track of all objects created in a graph.
    /// </summary>
    public class RepositorySession : IRepositorySession
    {
        private readonly Dictionary<Type, Dictionary<long, IIdentifyable>> cache = 
            new Dictionary<Type, Dictionary<long, IIdentifyable>>();

        private readonly Stack<RepositorySessionContext> context = new Stack<RepositorySessionContext>();

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositorySession"/> class.
        /// </summary>
        /// <param name="objects">The objects.</param>
        public RepositorySession(params IIdentifyable[] objects)
        {
            if (objects != null
                && objects.Length != 0)
                BeginContext(objects);
        }

        /// <summary>
        /// Begins a context.
        /// </summary>
        /// <param name="objects">The objects.</param>
        public void BeginContext(params IIdentifyable[] objects)
        {
            this.context.Push(new RepositorySessionContext(this.context.Count, objects));
            
            // add the element
            foreach(IIdentifyable obj in objects)
                Add(obj);
        }

        /// <summary>
        /// Ends a context.
        /// </summary>
        public void EndContext()
        {
            this.context.Pop();
        }

        /// <summary>
        /// Gets the context set by the last call to BeginContext.
        /// </summary>
        /// <value>The owner.</value>
        public RepositorySessionContext CurrentContext
        {
            get
            {
                if (this.context.Count != 0)
                    return this.context.Peek();
                return RepositorySessionContext.Empty;
            }
        }

        /// <summary>
        /// Adds the specified obj.
        /// </summary>
        /// <param name="obj">The obj.</param>
        public void Add(IIdentifyable obj)
        {
            Type t = obj.GetType();
            if(!cache.ContainsKey(t))
                cache[t] = new Dictionary<long, IIdentifyable>();
            if (obj.Uid != 0)
                cache[t][obj.Uid] = obj;
        }

        /// <summary>
        /// Removes the specified obj.
        /// </summary>
        /// <param name="obj">The obj.</param>
        public void Remove(IIdentifyable obj)
        {
            Type t = obj.GetType();
            Remove(t, obj.Uid);
        }

        /// <summary>
        /// Removes the specified object.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <param name="uid">The uid.</param>
        public void Remove(Type t, long uid)
        {
            if (!cache.ContainsKey(t))
                cache[t] = new Dictionary<long, IIdentifyable>();
            if (uid != 0)
                if (cache[t].ContainsKey(uid))
                    cache[t].Remove(uid);
        }

        /// <summary>
        /// Clears the cache for the specified type.
        /// </summary>
        /// <param name="t">The t.</param>
        public void Clear(Type t)
        {
            if (cache.ContainsKey(t))
                cache.Remove(t);
        }

        /// <summary>
        /// Clears the cache.
        /// </summary>
        public void Clear()
        {
            cache.Clear();
        }

        /// <summary>
        /// Determines whether the cache contains the specified object.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <param name="uid">The uid.</param>
        /// <returns>
        /// 	<c>true</c> if the cache contains the specified object; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Type t, long uid)
        {
            if (!cache.ContainsKey(t))
                cache[t] = new Dictionary<long, IIdentifyable>();
            return cache[t].ContainsKey(uid);
        }

        /// <summary>
        /// Determines whether the cache contains the specified object.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <param name="uid">The uid.</param>
        /// <returns>
        /// 	<c>true</c> if the cache contains the specified object; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains<TElement>(long uid) where TElement : class, IIdentifyable
        {
            Type t = typeof(TElement);
            if (!cache.ContainsKey(t))
                cache[t] = new Dictionary<long, IIdentifyable>();
            return cache[t].ContainsKey(uid);
        }

        /// <summary>
        /// Gets the specified object.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        public IIdentifyable GetObject(Type t, long uid)
        {
            if (Contains(t, uid))
            {
                return cache[t][uid];
            }
            return null;
        }

        /// <summary>
        /// Gets the specified object.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        public TElement GetObject<TElement>(long uid) where TElement : class, IIdentifyable
        {
            Type t = typeof(TElement);
            if (Contains(t, uid))
            {
                return (TElement) cache[t][uid];
            }
            return null;
        }

        #region IDisposable Members

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Clear();
        }

        #endregion
    }
}
