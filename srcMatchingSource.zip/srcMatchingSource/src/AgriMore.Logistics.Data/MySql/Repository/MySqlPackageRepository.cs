//using AgriMore.Logistics.Data.MySql.Map;
//using AgriMore.Logistics.Domain;
//using DtoPackage = AgriMore.Logistics.Data.MySql.DTO.Package;

//namespace AgriMore.Logistics.Data.MySql.Repository
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public class MySqlPackageRepository : AbstractMySqlRepository<Package, DtoPackage, PackageMap>
//    {
//    }
//}