using AgriMore.Logistics.Data.MySql.Map;
using AgriMore.Logistics.Domain.Repository;

using ChainEntity = AgriMore.Logistics.Domain.ChainEntity;
using DtoChainEntity = AgriMore.Logistics.Data.MySql.DTO.Chainentity;

using Address = AgriMore.Logistics.Domain.Address;
using DtoAddress = AgriMore.Logistics.Data.MySql.DTO.Address;

using Country = AgriMore.Logistics.Domain.Country;
using DtoCountry = AgriMore.Logistics.Data.MySql.DTO.Country;

using Location = AgriMore.Logistics.Domain.Location;
using DtoLocation = AgriMore.Logistics.Data.MySql.DTO.Location;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlAddressRepository : AbstractMySqlRepository<Address, DtoAddress, AddressMap>
    {
        /// <summary>
        /// Called after the record is added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterAdd(Address element, DtoAddress dto, IRepositorySession session)
        {
            MySqlLocationRepository repLocation = new MySqlLocationRepository();
            foreach (Location location in element.Locations)
                repLocation.Store(location);
            //base.OnAfterAdd(element, dto);
        }

        /// <summary>
        /// Called after the record is updated.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterUpdate(Address element, DtoAddress dto, IRepositorySession session)
        {
            MySqlLocationRepository repLocation = new MySqlLocationRepository();
            foreach (Location location in element.Locations)
                repLocation.StoreInternalTM(location, session);
            //base.OnAfterUpdate(element, dto);
        }

        /// <summary>
        /// Called after the record is removed.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterRemove(Address element, IRepositorySession session)
        {
            MySqlLocationRepository repLocation = new MySqlLocationRepository();
            foreach (Location location in element.Locations)
                repLocation.RemoveInternalTM(location, session);
            //base.OnAfterRemove(element);
        }
    }
}