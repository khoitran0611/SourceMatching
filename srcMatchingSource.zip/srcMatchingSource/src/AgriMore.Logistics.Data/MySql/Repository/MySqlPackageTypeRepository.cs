//using AgriMore.Logistics.Data.MySql.Map;
//using AgriMore.Logistics.Domain;
//using DtoPackageType = AgriMore.Logistics.Data.MySql.DTO.Packagetype;

//namespace AgriMore.Logistics.Data.MySql.Repository
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public class MySqlPackageTypeRepository : AbstractMySqlRepository<PackageType, DtoPackageType, PackageTypeMap>
//    {
//    }
//}