using AgriMore.Logistics.Data.MySql.Map;
using AgriMore.Logistics.Domain;
using DtoPackageTypeCategory = AgriMore.Logistics.Data.MySql.DTO.Packagetypecategory;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlPackageTypeCategoryRepository :
        AbstractMySqlRepository<PackageTypeCategory, DtoPackageTypeCategory, PackageTypeCategoryMap>
    {
    }
}