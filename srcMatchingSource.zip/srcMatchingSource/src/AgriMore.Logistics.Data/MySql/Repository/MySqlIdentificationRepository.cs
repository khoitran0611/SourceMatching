//using AgriMore.Logistics.Data.MySql.Map;
//using AgriMore.Logistics.Domain;
//using DtoIdentification = AgriMore.Logistics.Data.MySql.DTO.Packageidentification;

//namespace AgriMore.Logistics.Data.MySql.Repository
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public class MySqlIdentificationRepository :
//        AbstractMySqlRepository<Identification, DtoIdentification, IdentificationMap>
//    {
//    }
//}