using AgriMore.Logistics.Data.MySql.DTO;
using AgriMore.Logistics.Data.MySql.Map;
using AgriMore.Logistics.Domain;
using DtoUser = AgriMore.Logistics.Data.MySql.DTO.Chainuser;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlChainUserRepository : AbstractMySqlRepository<User, DtoUser, ChainUserMap>
    {
        /// <summary>
        /// Called after the record is added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterAdd(User element, DtoUser dto, IRepositorySession session)
        {
            EnsureUserRolesManyToMany(element, dto);
        }

        /// <summary>
        /// Called before the record is removed.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected override void OnBeforeRemove(User element, IRepositorySession session)
        {
            // delete Chainuserrole records for this user
            Chainuserrole.Delete(Chainuserrole.Columns.ChainUserId, element.Uid);
        }

        /// <summary>
        /// Called after the record is updated.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterUpdate(User element, DtoUser dto, IRepositorySession session)
        {
            EnsureUserRolesManyToMany(element, dto);
        }


        /// <summary>
        /// Ensures the user roles many to many.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="chainUser">The chain user.</param>
        internal static void EnsureUserRolesManyToMany(User element, DtoUser chainUser)
        {
            ChainuserroleCollection userRoles = chainUser.ChainuserroleRecords();
            foreach (Role role in element.Roles)
            {
                bool chainRoleExists = false;
                foreach (Chainuserrole chainUserRole in userRoles)
                {
                    if (chainUserRole.Chainrole.Uid == role.Uid)
                    {
                        chainRoleExists = true;
                        break;
                    }
                }
                if (!chainRoleExists)
                {
                    // add chainuserrole
                    Chainrole chainRole = new Chainrole(role.Uid);
                    Chainuserrole chainUserRole = new Chainuserrole();
                    chainUserRole.Chainuser = chainUser;
                    chainUserRole.Chainrole = chainRole;
                    chainUserRole.Save();
                }
            }

            foreach (Chainuserrole chainUserRole in userRoles)
            {
                bool roleExists = false;
                foreach (Role role in element.Roles)
                {
                    if (role.Uid == chainUserRole.Chainrole.Uid)
                    {
                        roleExists = true;
                        break;
                    }
                }
                if (!roleExists)
                {
                    // remove chainuserrole
                    Chainuserrole.Delete(chainUserRole.Uid);
                }
            }
        }
    }
}