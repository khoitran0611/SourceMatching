using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Data.MySql
{
    /// <summary>
    /// 
    /// </summary>
    public class RepositorySessionContext
    {
        /// <summary>
        /// Gets an empty context.
        /// </summary>
        /// <value>The empty.</value>
        public static RepositorySessionContext Empty
        {
            get { return new RepositorySessionContext(); }
        }

        private readonly IIdentifyable[] objects;
        private readonly bool isEmpty;
        private readonly int level;

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositorySessionContext"/> class.
        /// </summary>
        /// <param name="level">The level.</param>
        /// <param name="objects">The objects.</param>
        public RepositorySessionContext(int level, params IIdentifyable[] objects)
        {
            if (level < 0)
                throw new ArgumentException("level cannot be less than 0.", "level");
            if (objects == null)
                throw new ArgumentNullException("objects");
            if (objects.Length == 0)
                throw new ArgumentException("objects cannot be empty.", "objects");

            this.objects = objects;
            this.level = level;
            this.isEmpty = false;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositorySessionContext"/> class.
        /// </summary>
        private RepositorySessionContext()
        {
            this.objects = new IIdentifyable[0];
            this.level = 0;
            this.isEmpty = true;
        }

        /// <summary>
        /// Gets a value indicating whether this instance is empty.
        /// </summary>
        /// <value><c>true</c> if this instance is empty; otherwise, <c>false</c>.</value>
        public bool IsEmpty
        {
            get { return isEmpty; }
        }

        /// <summary>
        /// Gets the level.
        /// </summary>
        /// <value>The level.</value>
        public int Level
        {
            get { return level; }
        }

        /// <summary>
        /// Gets the objects.
        /// </summary>
        /// <value>The objects.</value>
        public IIdentifyable[] Objects
        {
            get { return objects; }
        }

        /// <summary>
        /// Gets the <see cref="AgriMore.Logistics.Domain.Repository.IIdentifyable"/> of the specified type.
        /// </summary>
        /// <value></value>
        public IIdentifyable this[Type type]
        {
            get
            {
                for (int i = 0; i < this.objects.Length; i++)
                    if (this.objects[i].GetType() == type)
                        return this.objects[i];
                throw new IndexOutOfRangeException("No object of the specified type exists.");
            }
        }

        /// <summary>
        /// Asserts the specified number and types of objects in this context.
        /// </summary>
        /// <param name="message">The message that should appear in the exception.</param>
        /// <param name="objectTypes">The object types.</param>
        public void Assert(string message, params Type[] objectTypes)
        {
            if (this.isEmpty)
                throw new InvalidOperationException("The context is empty.");
            if (objectTypes == null)
                throw new ArgumentNullException("objectTypes");
            if (objectTypes.Length != this.objects.Length)
                throw new Exception("Invalid Context. The number of objects expected was not the number of objects in the current context.");
            if (string.IsNullOrEmpty(message))
                message = "The types of objects that were expected did not match the actual types in the current context.";

            for (int i = 0; i < objectTypes.Length; i++)
            {
                if (objectTypes[i] != this.objects.GetType())
                    throw new Exception(string.Format("Invalid Context. {0}", message));
            }
        }
    }
}
