﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Data.Logging
{
    public static class Logger
    {
        private static readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        public static void LogEntry(Domain.Logging logEntry)
        {
            repositoryFactory.GetLoggingRepository().Add(logEntry);
        }

        /*private static string GetMessageUpdatePrice(decimal fromValuePrice, decimal toValuePrice)
        {
            return string.Format(Resources.ResStrings.Logging_UpdatedPriceFrom + " {0} " + Resources.ResStrings.Logging_To + " {1}", fromValuePrice, toValuePrice);
        }

        public static void LogUpdatingPrice(string Username, string Object, long ObjectUid, decimal fromValuePrice, decimal toValuePrice)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_UpdatedPrice, Object, ObjectUid, GetMessageUpdatePrice(fromValuePrice,toValuePrice));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageUpdateAmount(long fromAmount, long toAmount)
        {
            return string.Format(Resources.ResStrings.Logging_UpdatedAmountFrom + " {0} " + Resources.ResStrings.Logging_To + " {1}", fromAmount, toAmount);
        }

        public static void LogUpdatingExpectedAmount(string Username, long ObjectUid, long fromValuePrice, long toValuePrice)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_UpdatedAmount, Resources.ResStrings.Logging_ProductSupplyForcast, ObjectUid, GetMessageUpdateAmount(fromValuePrice, toValuePrice));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageCreateProductSupplyForecast(long expectedAmount)
        {
            return string.Format(Resources.ResStrings.Logging_CreatedProductSupplyForecastWithExpectedAmount + " {0} ",
                                 expectedAmount);
        }

        public  static void LogCreateProductSupplyForecast(string Username, long ObjectUid, long expectedAmount)        
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_CreateProductSupplyForecast, Resources.ResStrings.Logging_ProductSupplyForcast, ObjectUid, GetMessageCreateProductSupplyForecast(expectedAmount));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageResetPassword(string userName, string newPass)
        {
            return string.Format(Resources.ResStrings.Logging_ResetPasswordOf + " {0} " + Resources.ResStrings.Logging_To + " {1}",
                                 userName,newPass);
        }

        public static void LogResetPassword(string Username, long ObjectUid, string userName, string newPass)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_ResetPassword, Resources.ResStrings.Logging_UserAccounts, ObjectUid, GetMessageResetPassword(userName,newPass));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageChangePassword(string oldPass, string newPass)
        {
            return string.Format(Resources.ResStrings.Logging_ChangePasswordFrom + " {0} " + Resources.ResStrings.Logging_To + " {1}",
                                 oldPass, newPass);
        }

        public static void LogChangePassword(string Username, long ObjectUid, string oldPass, string newPass)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_ChangedPassword, Resources.ResStrings.Logging_ChangePassword, ObjectUid, GetMessageChangePassword(oldPass, newPass));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageLogInSuccessfully(string Username)
        {
            return string.Format("{0} "+ Resources.ResStrings.Logging_LogInSuccessfully,
                                 Username);
        }

        public static void LogSignInSuccesfully(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_LoggedIn, Resources.ResStrings.Logging_LogIn, ObjectUid, GetMessageLogInSuccessfully(Username));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageLogOutSuccessfully(string Username)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_LogOutSuccessfully,
                                 Username);
        }

        public static void LogSignOutSuccesfully(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_LoggedOut, Resources.ResStrings.Logging_LogOut, ObjectUid, GetMessageLogOutSuccessfully(Username));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageUpdateProductSupplyForecast(string Username)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_UpdateProductSupplyForecast,
                                 Username);
        }

        public static void LogUpdateProductSupplyForecast(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_UpdatedProductSupplyForecast, Resources.ResStrings.Logging_ConfirmInteretedAmount, ObjectUid, GetMessageUpdateProductSupplyForecast(Username));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageAddAddOnsConfirmed(string Username)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_AddAddOnsConfirmed,
                                 Username);
        }

        public static void LogAddAddOnsConfirmed(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_AddedAddOnsConfirmed, Resources.ResStrings.Logging_ConfirmInteretedAmount, ObjectUid, GetMessageAddAddOnsConfirmed(Username));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageDeleteAddOnsConfirmed(string Username,long Uid)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_DeleteAddOnsConfirmed + " {1}",
                                 Username,Uid);
        }

        public static void LogDeleteAddOnsConfirmed(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_DeletedAddOnsConfirmed, Resources.ResStrings.Logging_ConfirmInteretedAmount, ObjectUid, GetMessageDeleteAddOnsConfirmed(Username,ObjectUid));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageAddPackagingConfirmed(string Username)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_AddPackagingConfirmed,
                                 Username);
        }
        
        public static void LogAddPackagingConfirmed(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_AddedPackagingConfirmed, Resources.ResStrings.Logging_ConfirmInteretedAmount, ObjectUid, GetMessageAddPackagingConfirmed(Username));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }


        private static string GetMessageDeletePackagingConfirmed(string Username,long Uid)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_DeletePackagingConfirmed + " {1}",
                                 Username,Uid);
        }

        public static void LogDeletePackagingConfirmed(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_DeletedPackagingConfirmed, Resources.ResStrings.Logging_ConfirmInteretedAmount, ObjectUid, GetMessageDeletePackagingConfirmed(Username,ObjectUid));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }

        private static string GetMessageConfirmedDesiredAmount(string Username)
        {
            return string.Format("{0} " + Resources.ResStrings.Logging_ConfirmedDesiredAmount,
                                 Username);
        }

        public static void LogConfirmedDesiredAmount(string Username, long ObjectUid)
        {
            var logger = new Domain.Logging(Resources.ResStrings.Logging_Info, Username, Resources.ResStrings.Logging_ConfirmedDesiredAmount, Resources.ResStrings.Logging_ConfirmInteretedAmount, ObjectUid, GetMessageConfirmedDesiredAmount(Username));

            repositoryFactory.GetLoggingRepository().Add(logger);
        }*/
    }
}