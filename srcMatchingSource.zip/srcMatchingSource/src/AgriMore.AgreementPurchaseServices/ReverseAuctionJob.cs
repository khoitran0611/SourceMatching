﻿using System;
using System.Collections.Generic;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.AgreementPurchaseServices
{
    public class ReverseAuctionJob : Job
    {
        private static readonly RepositoryFactory RepositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            Log.Info("Find Reverse Auction just time out");
            IList<Logistics.Domain.ReverseAuction> rvsAuctions = ReverseAuctionServices.GetReverseAuctionJustTimeOut();
            if (rvsAuctions.Count <= 0)
            {
                Log.Info("Not found Reverse Auction just time out");
                return;
            }

            Log.Info(string.Format("Found {0} Reverse Auction just time out", rvsAuctions.Count));

            foreach (var rvsAuction in rvsAuctions)
            {
                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    RepositoryFactory.GetReverseAuctionRepository().Refresh(rvsAuction);

                    int clockRunningTime = rvsAuction.ClockRunningTime;
                    if (clockRunningTime <= 0) clockRunningTime = (int)(rvsAuction.AuctionCloseAt - rvsAuction.AuctionStartAt).TotalMinutes;

                    rvsAuction.AuctionStartAt = DateTime.Now.AddMinutes(1);
                    rvsAuction.AuctionCloseAt = rvsAuction.AuctionStartAt.AddMinutes(clockRunningTime);

                    RepositoryFactory.GetReverseAuctionRepository().Store(rvsAuction);
                    transactionManager.CommitTransaction();

                    Log.Info(string.Format("----> Already reset auction time for : {0}", rvsAuction.Uid));
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }
            Log.Info("Finish");
        }
    }
}
