﻿using System.ServiceProcess;

namespace AgriMore.AgreementPurchaseServices
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
#if DEBUG
            AgreementProcess svc = new AgreementProcess();
            svc.Run();
#else

            ServiceBase[] servicesToRun = new ServiceBase[] { new AgreementProcess() };
            ServiceBase.Run(servicesToRun);
#endif
        }
    }
}
