﻿using System;
using AgriMore.Logistics.Domain;
using System.Collections.Generic;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.AgreementPurchaseServices
{
    public class BiddingPurchaseJob : Job
    {
        private static readonly RepositoryFactory RepositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            Log.Info("Find Bidding Purchase Process");
            IList<Logistics.Domain.BiddingPurchase> bidPchs = BiddingPurchaseServices.GetFinalBiddingProcess();
            if (bidPchs.Count <= 0)
            {
                Log.Info("Not found Bidding Purchase Process");
                return;
            }

            Log.Info(string.Format("Found {0} Bidding Process", bidPchs.Count));

            foreach (var bidPch in bidPchs)
            {
                IList<BiddingPurchaseSellerBidded> sellerBiddeds = BiddingPurchaseServices.GetSellerBiddingOnBiddingPurchase(bidPch.Uid);
                if (sellerBiddeds.Count <= 0) continue;

                BiddingPurchaseSellerBidded wonBid = sellerBiddeds[0];
                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    Log.Info(string.Format("{0} Won offer at: {1} {2} for Bidding PurchaseId: {3}", wonBid.SellerId, wonBid.BiddingPrice, wonBid.Currency, bidPch.Uid));
                    bidPch.BiddingPrice = wonBid.BiddingPrice;
                    bidPch.SellerWonId = wonBid.SellerId;

                    RepositoryFactory.GetBiddingPurchaseRepository().Store(bidPch);
                    transactionManager.CommitTransaction();
                    Log.Info(string.Format("----> Already set seller won for bidding purchase: {0}", bidPch.Uid));
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }

            Log.Info("Finish");
        }
    }
}
