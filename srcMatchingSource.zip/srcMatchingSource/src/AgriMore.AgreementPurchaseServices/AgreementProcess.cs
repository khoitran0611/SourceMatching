﻿using System.ComponentModel;
using System.ServiceProcess;
using System.Threading;
using log4net;

namespace AgriMore.AgreementPurchaseServices
{
    [RunInstaller(true)]
    public class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            // This call is required by the Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitComponent call 
            //string keyName = "AgriMORESchedulerAutoRestart";
            //string assemblyLocation = Assembly.GetExecutingAssembly().Location;  // Or the EXE path.

            //// Set Auto-start.
            //Util.SetAutoStart(keyName, assemblyLocation);
        }

        private void InitializeComponent()
        {
            var serviceInstall = new ServiceInstaller();
            var serviceProcessInstall = new ServiceProcessInstaller();

            serviceInstall.ServiceName = "AgriMOREAgreementPurchase"; // this must match the ServiceName specified in WindowsService1.
            serviceInstall.DisplayName = "AgriMORE Agreement Purchase"; // this will be displayed in the Services Manager.
            serviceInstall.Description = "AgriMORE applications";
            serviceInstall.StartType = ServiceStartMode.Automatic;
            this.Installers.Add(serviceInstall);

            serviceProcessInstall.Account = System.ServiceProcess.ServiceAccount.LocalSystem; // run under the system account.
            serviceProcessInstall.Password = null;
            serviceProcessInstall.Username = null;
            this.Installers.Add(serviceProcessInstall);
        }
    }

    public partial class AgreementProcess : ServiceBase
    {
        private Job _agmtPurchaseJob;//, _biddingPrchJob, _rvsAuctionJob;
        private Timer _agmtPurchaseStateTimer;//, _biddingPrchStateTimer, _rvsAuctionStateTimer;
        private TimerCallback _agmtPurchaseDelegate;//, _biddingPrchDelegate, _rvsAuctionDelegate;
        private static readonly ILog Log = LogManager.GetLogger("GeneralLog");

        public AgreementProcess()
        {
            InitializeComponent();
            log4net.Config.XmlConfigurator.Configure();
        }

#if DEBUG
        public void Run()
        {
            OnStart(null);
        }
#endif

        protected override void OnStart(string[] args)
        {
            Log.Info("AgriMORE Agreement Purchase Process Service OnStart");

            _agmtPurchaseJob = new AgreementPurchaseJob();
            //_biddingPrchJob = new BiddingPurchaseJob();
            //_rvsAuctionJob = new ReverseAuctionJob();

#if DEBUG
            _agmtPurchaseJob.Execute(null);
            //_biddingPrchJob.Execute(null);
            //_rvsAuctionJob.Execute(null);
#else
            _agmtPurchaseDelegate = new TimerCallback(_agmtPurchaseJob.Execute);
            //_biddingPrchDelegate = new TimerCallback(_biddingPrchJob.Execute);
            //_rvsAuctionDelegate = new TimerCallback(_rvsAuctionJob.Execute);

            _agmtPurchaseStateTimer = new Timer(_agmtPurchaseDelegate, this, 1000, 60000);
            //_biddingPrchStateTimer = new Timer(_biddingPrchDelegate, this, 1000, 60000);
            //_rvsAuctionStateTimer = new Timer(_rvsAuctionDelegate, this, 1000, 60000);
#endif
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            Log.Info("AgriMORE Agreement Purchase Process Service OnStop");
            _agmtPurchaseStateTimer.Dispose();
            //_biddingPrchStateTimer.Dispose();
            //_rvsAuctionStateTimer.Dispose();
        }
    }
}
