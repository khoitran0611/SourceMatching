﻿using System;
using System.Linq;
using System.Collections.Generic;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.AgreementPurchaseServices
{
    public class AgreementPurchaseJob : Job
    {
        private static readonly RepositoryFactory RepositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            AgreementPurchase4NormalProduct();

            AgreementPurchase4CompositeProduct();

            Log.Info("Finish");
        }

        private void AgreementPurchase4NormalProduct()
        {
            Log.Info("Find Agreement Purchase Process");
            IList<AgreementPurchase> agmtPchs = new List<AgreementPurchase>(RepositoryFactory.GetAgreementPurchaseRepository().Find(new AgreementPurchaseFinalProcessSpecification()));
            if (agmtPchs.Count <= 0)
            {
                Log.Info("Not found Agreement Purchase Process");
                return;
            }

            Log.Info(string.Format("Found {0} Agreement Process", agmtPchs.Count));

            foreach (var agmtPch in agmtPchs)
            {
                if (agmtPch.PurchaseType != PurchaseType.OfferWithCeiling) continue;
                IList<AgreementPurchaseSellerOffer> agmtPchOffers = RepositoryFactory.GetAgreementPurchaseSellerOfferRepository().Find(new AgreementPurchaseSellerOfferByPurchaseIdSpecification(agmtPch.Uid)).OrderBy(it => it.OfferPrice).ToList();
                if (agmtPchOffers.Count <= 0) continue;

                AgreementPurchaseSellerOffer wonOffer = agmtPchOffers[0];
                if (wonOffer.OfferPrice > agmtPch.CeilingPrice) continue;

                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    Log.Info(string.Format("{0} Won offer at: {1} {2} for Agreement PurchaseId: {3}", wonOffer.SellerId, wonOffer.OfferPrice, wonOffer.Currency, agmtPch.Uid));
                    agmtPch.AgreePrice = wonOffer.OfferPrice;
                    agmtPch.SellerWonId = wonOffer.SellerId;

                    //Check and remove other puchase process that come from Planning Purchase.
                    if (agmtPch.PlanningId != 0 && agmtPch.IssuedSeq != 0)
                    {
                        var bp = BiddingPurchaseServices.GetBiddingPurchase(agmtPch.PlanningId, agmtPch.IssuedSeq);
                        if (bp != null) RepositoryFactory.GetBiddingPurchaseRepository().Remove(bp);

                        var ra = ReverseAuctionServices.GetReverseAuction(agmtPch.PlanningId, agmtPch.IssuedSeq);
                        if (ra != null) RepositoryFactory.GetReverseAuctionRepository().Remove(ra);
                    }

                    RepositoryFactory.GetAgreementPurchaseRepository().Store(agmtPch);
                    transactionManager.CommitTransaction();
                    Log.Info(string.Format("----> Already set seller won for agreement purchase: {0}", agmtPch.Uid));
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }
        }

        public void AgreementPurchase4CompositeProduct()
        {
            Log.Info("Find Agreement Purchase Process for Composite Product");
            IList<AgreementPurchase4CompositeProduct> agmtPurchase4CmpProd = new List<AgreementPurchase4CompositeProduct>(
                RepositoryFactory.GetAgreementPurchase4CompositeProductRepository().Find(new AgreementPurchaseFinalProcess4CompositeProdSpecification()));
            if (agmtPurchase4CmpProd.Count <= 0)
            {
                Log.Info("Not found Agreement Purchase Process for Composite Product");
                return;
            }

            foreach (var agmtPch in agmtPurchase4CmpProd)
            {
                if (agmtPch.PurchaseType != PurchaseType.OfferWithCeiling) continue;
                IList<AgreementPurchase4CompositeProductSellerOffer> agmtPchOffers = RepositoryFactory.GetAgreementPurchase4CompositeProductSellerOfferRepository().Find(
                    new AgreementPurchaseSellerOfferByCompositePurchaseIdSpecification(agmtPch.Uid)).OrderBy(it => it.OfferPrice).ToList();
                if (agmtPchOffers.Count <= 0) continue;

                AgreementPurchase4CompositeProductSellerOffer wonOffer = agmtPchOffers[0];
                if (wonOffer.OfferPrice > agmtPch.CeilingPrice) continue;

                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    Log.Info(string.Format("{0} Won offer at: {1} {2} for Composite Product Agreement PurchaseId: {3}", wonOffer.SellerId, wonOffer.OfferPrice, wonOffer.Currency, agmtPch.Uid));
                    agmtPch.AgreedPrice = wonOffer.OfferPrice;
                    agmtPch.WonSellerId = wonOffer.SellerId;
                    agmtPch.IsMatched = true;

                    foreach (var priceDetail in agmtPch.PriceDetails)
                    {
                        var offerPriceDetail = wonOffer.OfferPriceDetails.SingleOrDefault(it => it.Product4CompositeProdFav.Uid == priceDetail.Product4CompositeProdFav.Uid);
                        priceDetail.OfferPrice = offerPriceDetail.OfferPrice;
                        priceDetail.AgreedPrice = offerPriceDetail.OfferPrice;
                        priceDetail.Currency = offerPriceDetail.Currency;
                    }

                    //Check and remove other puchase process that come from Planning Purchase.
                    //if (agmtPch.PlanningId != 0 && agmtPch.IssuedSeq != 0)
                    //{
                    //    var bp = BiddingPurchaseServices.GetBiddingPurchase(agmtPch.PlanningId, agmtPch.IssuedSeq);
                    //    if (bp != null) RepositoryFactory.GetBiddingPurchaseRepository().Remove(bp);

                    //    var ra = ReverseAuctionServices.GetReverseAuction(agmtPch.PlanningId, agmtPch.IssuedSeq);
                    //    if (ra != null) RepositoryFactory.GetReverseAuctionRepository().Remove(ra);
                    //}

                    RepositoryFactory.GetAgreementPurchase4CompositeProductRepository().Store(agmtPch);
                    transactionManager.CommitTransaction();
                    Log.Info(string.Format("----> Already set seller won for Composite product agreement purchase: {0}", agmtPch.Uid));
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }
        }
    }
}
