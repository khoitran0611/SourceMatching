﻿using System;
using log4net;

namespace AgriMore.AgreementPurchaseServices
{
    public abstract class Job
    {
        protected static readonly ILog Log = LogManager.GetLogger("GeneralLog");

        public virtual void Execute(object stateObject)
        {
            try
            {
                Run();
            }
            catch (Exception ge)
            {
                Log.Error(ge);  // in case transaction rollback is failed
            }
        }

        public virtual void Run()
        {
        }
    }
}
