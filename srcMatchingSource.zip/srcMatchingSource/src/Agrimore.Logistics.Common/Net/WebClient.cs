﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Common.Net
{
    public class WebClient : System.Net.WebClient
    {
        private System.Net.CookieContainer cookieContainer;
        private int timeout;

        public System.Net.CookieContainer CookieContainer
        {
            get { return cookieContainer; }
            set { cookieContainer = value; }
        }

        public int Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }

        public WebClient()
        {
            timeout = -1;
            cookieContainer = new System.Net.CookieContainer();
        }

        protected override System.Net.WebRequest GetWebRequest(Uri address)
        {
            System.Net.WebRequest request = base.GetWebRequest(address);

            if (request.GetType() == typeof(System.Net.HttpWebRequest))
            {
                ((System.Net.HttpWebRequest)request).CookieContainer = cookieContainer;
                ((System.Net.HttpWebRequest)request).Timeout = timeout;
            }
            return request;
        }
    }

}
