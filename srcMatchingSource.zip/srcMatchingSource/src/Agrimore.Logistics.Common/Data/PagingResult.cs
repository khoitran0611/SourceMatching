﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Common.Data
{
    public class PagingResult<T> where T : class
    {
        public long Total { get; set; }
        public IEnumerable<T> Result { get; set; }
    }
}
