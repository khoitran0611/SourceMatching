using System;

namespace AgriMore.Logistics.Common.Exception
{
    /// <summary>
    /// Summary description for ObjectLoginException.
    /// </summary>
    [Serializable]
    public class ObjectLoginException : ObjectException
    {
        /// <summary>
        /// Initializes a new instance of the ObjectLoginException class with a specified error message and a reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message string.</param>
        /// <param name="innerException">The inner exception reference.</param>
        public ObjectLoginException(string message, System.Exception innerException)
            : base(message, innerException)
        {
        }
    }
}