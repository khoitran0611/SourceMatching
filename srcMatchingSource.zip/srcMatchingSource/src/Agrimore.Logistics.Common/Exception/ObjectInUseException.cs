using System;

namespace AgriMore.Logistics.Common.Exception
{
    /// <summary>
    /// Summary description for ObjectInUseException.
    /// </summary>
    [Serializable]
    public class ObjectInUseException : ObjectException
    {
        private const string ITEM_CANNOT_BE_DELETED = "The item is in use and cannot be deleted.";

        /// <summary>
        /// Initializes a new instance of the ObjectInUseException class with a specified error message and a reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message string.</param>
        /// <param name="innerException">The inner exception reference.</param>
        public ObjectInUseException(string message, System.Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the ObjectInUseException class with a specified error message.
        /// </summary>
        /// <param name="innerException">The inner exception.</param>
        public ObjectInUseException(System.Exception innerException)
            : base(ITEM_CANNOT_BE_DELETED, innerException)
        {
        }
    }
}