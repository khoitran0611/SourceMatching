using System;

namespace AgriMore.Logistics.Common.Exception
{
    /// <summary>
    /// Summary description for ObjectNotFoundException.
    /// </summary>
    [Serializable]
    public class ObjectNotFoundException : ObjectException
    {
        private const string ITEM_CANNOT_BE_FOUND = "The item cannot be found";

        /// <summary>
        /// Initializes a new instance of the ObjectInUseException class with a specified error message.
        /// </summary>
        /// <param name="innerException">The inner exception.</param>
        public ObjectNotFoundException(System.Exception innerException)
            : base(ITEM_CANNOT_BE_FOUND, innerException)
        {
        }
    }
}