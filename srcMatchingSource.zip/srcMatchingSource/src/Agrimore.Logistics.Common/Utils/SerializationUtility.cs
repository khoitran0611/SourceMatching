﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Runtime.Serialization;

namespace AgriMore.Logistics.Common.Utils
{
    public static class SerializationUtility<T> where T : class
    {
        public static string Serialize(T obj)
		{
			return SerializationUtility<T>.Serialize(obj, string.Empty, true);
		}

        public static string Serialize(T obj, bool removeXmlDeclaratiuon)
		{
			return SerializationUtility<T>.Serialize(obj, string.Empty, removeXmlDeclaratiuon);
		}

		public static string Serialize(T obj, string xmlRootName, bool removeXmlDeclaratiuon)
		{
			/*XmlWriterSettings settings = new XmlWriterSettings
			{
				OmitXmlDeclaration = removeXmlDeclaratiuon,
			};
			StringWriter stringWriter = new StringWriter();
			XmlSerializer xmlSerializer = string.IsNullOrEmpty(xmlRootName) ? new XmlSerializer(typeof(T)) : new XmlSerializer(typeof(T), new XmlRootAttribute(xmlRootName));
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add("", "");
			using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, settings))
			{
				xmlSerializer.Serialize(xmlWriter, obj, ns);
			}
			return stringWriter.ToString();*/

            var serializer = new DataContractSerializer(typeof(T));
            var document = new XDocument();

            using (var writer = document.CreateWriter())
            {
                serializer.WriteObject(writer, obj);
                writer.Close();
            }

            return document.ToString();

		}

		public static T Deserialize(string xml)
		{
			T result;
			if (string.IsNullOrEmpty(xml))
			{
				result = default(T);
			}
			else
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
				StringReader textReader = new StringReader(xml);
				result = (T)xmlSerializer.Deserialize(textReader);
			}
			return result;
		}
    }
}
