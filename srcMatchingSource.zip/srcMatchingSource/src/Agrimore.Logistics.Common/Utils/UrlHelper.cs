﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace AgriMore.Logistics.Common.Utils
{
    public static class UrlHelper
    {
        public static string GetRootUrl()
        {
            HttpContext ctx = HttpContext.Current;
            return ctx.Request.Url.AbsoluteUri.Replace(ctx.Request.Url.AbsolutePath, string.Empty);
            /*
            Uri uri = ctx.Request.Url;
            return string.Format("{0}://{1}{2}{3}", uri.Scheme, uri.Host, uri.IsDefaultPort ? "" : (":" + uri.Port), uri.AbsolutePath);*/
        }
    }
}
