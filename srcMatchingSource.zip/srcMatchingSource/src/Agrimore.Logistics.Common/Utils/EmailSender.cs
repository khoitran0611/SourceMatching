﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Mail;

namespace AgriMore.Logistics.Common.Utils
{
    public static class EmailSender
    {
        public static void SendInvoiceMail(string to, string attachFile, string langCode, string invType, string receiveUser, string reveiveOrg, string sellerOrg, string invNumber)
        {
            if (string.IsNullOrEmpty(to)) return;

            string mailContentPath = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath);
            mailContentPath = string.Format("{0}\\Invoice\\EmailTmps\\{1}", mailContentPath, string.Format("InvoiceEmail{0}_{1}.xml", invType, langCode));

            var comfirmEmail = new DataSet("InvoiceEmail");
            comfirmEmail.ReadXml(mailContentPath);
            DataRow[] rows = comfirmEmail.Tables["InvoiceEmail"].Select();

            string strSubject = Convert.ToString(rows[0]["subject"]);
            string strBody = Convert.ToString(rows[0]["body"]);

            strBody = strBody.Replace("${OrgBuyerUser}", receiveUser);
            strBody = strBody.Replace("${OrgProducerUser}", receiveUser);

            strBody = strBody.Replace("${BuyerOrg}", reveiveOrg);
            strBody = strBody.Replace("${ProducerOrg}", reveiveOrg);

            strBody = strBody.Replace("${SellerOrg}", sellerOrg);
            strBody = strBody.Replace("${InvoiceNbr}", invNumber);

            var message = new MailMessage
                              {
                                  From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]),
                                  Subject = strSubject,
                                  Body = strBody
                              };

            var invPdf = new Attachment(attachFile);
            message.Attachments.Add(invPdf);

            if (!string.IsNullOrEmpty(to))
            {
                to = to.Replace(';', ',');
                string[] toAddress = to.Split(',');

                foreach (string t in toAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                {
                    message.To.Add(new MailAddress(t.Trim()));
                }
            }

            GetSmtpClient().Send(message);
        }

        public static void SendCorrectInvoiceEmail(string to, string revPdfFile, string crtPdfFile, string langCode, string invType,
            string receiveUser, string receiveOrg, string invNumber, string revInvNumber, string crtInvNumber, string sellerOrg)
        {
            if (string.IsNullOrEmpty(to)) return;

            string mailContentPath = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath);
            mailContentPath = string.Format("{0}\\Invoice\\EmailTmps\\{1}", mailContentPath, string.Format("InvoiceEmailCrt{0}_{1}.xml", invType, langCode));

            var comfirmEmail = new DataSet("InvoiceEmail");
            comfirmEmail.ReadXml(mailContentPath);
            DataRow[] rows = comfirmEmail.Tables["InvoiceEmail"].Select();

            string strSubject = Convert.ToString(rows[0]["subject"]);
            string strBody = Convert.ToString(rows[0]["body"]);

            strBody = strBody.Replace("${OrgBuyerUser}", receiveUser);
            strBody = strBody.Replace("${OrgProducerUser}", receiveUser);

            strBody = strBody.Replace("${InvoiceNbr}", invNumber);
            strBody = strBody.Replace("${RevInvoiceNbr}", revInvNumber);
            strBody = strBody.Replace("${CrtInvoiceNbr}", crtInvNumber);

            strBody = strBody.Replace("${BuyerOrg}", receiveOrg);
            strBody = strBody.Replace("${ProducerOrg}", receiveOrg);

            strBody = strBody.Replace("${SellerOrg}", sellerOrg);

            var message = new MailMessage
            {
                From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]),
                Subject = strSubject,
                Body = strBody
            };

            var invPdf = new Attachment(revPdfFile);
            message.Attachments.Add(invPdf);

            //var crtPdf = new Attachment(new System.IO.FileInfo(crtPdfFile).OpenRead(), "XXX", "application/pdf");
            var crtPdf = new Attachment(crtPdfFile);
            message.Attachments.Add(crtPdf);

            if (!string.IsNullOrEmpty(to))
            {
                to = to.Replace(';', ',');
                string[] toAddress = to.Split(',');

                foreach (string t in toAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                {
                    message.To.Add(new MailAddress(t.Trim()));
                }
            }

            GetSmtpClient().Send(message);
        }

        public static SmtpClient GetSmtpClient()
        {
            string username = ConfigurationManager.AppSettings["smtp.username"];
            var smtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtp.host"], int.Parse(ConfigurationManager.AppSettings["smtp.port"]))
                                        {
                                            EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"])
                                        };

            if (!string.IsNullOrEmpty(username))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential(username,
                    ConfigurationManager.AppSettings["smtp.password"]);
            }

            return smtpClient;
        }
    }
}
