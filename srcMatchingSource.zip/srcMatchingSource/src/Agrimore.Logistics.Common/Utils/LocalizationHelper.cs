﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Common.Localization;

namespace AgriMore.Logistics.Common.Utils
{
    public static class LocalizationHelper
    {
        public static T Get<T>(this IList<T> languages, string langCode) where T : class, IEntityLanguage
        {
            return languages.Where(l => l.LangCode == langCode).FirstOrDefault() ?? languages.First();
        }

        public static string Get<T>(this IList<T> languages, Func<T, string> selector, string langCode) where T : IEntityLanguage
        {
            return languages.Where(l => l.LangCode == langCode).Select(selector).FirstOrDefault() ?? languages.Select(selector).First();
        }

        public static string Get<T>(this IList<T> languages, Func<T, string> selector, int index) where T : IEntityLanguage
        {
            return languages.Select(selector).Skip(index).FirstOrDefault();
        }

        public static void Set<T>(this IList<T> languages, Action<T> setter) where T : IEntityLanguage
        {
            foreach (var lang in languages)
            {
                setter(lang);
            }
        }
    }
}
