﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AgriMore.Logistics.Common.Utils
{
    public static class StringHelper
    {
        private static readonly Regex REGEX_HTML_TAGS = new Regex("</?[A-Za-z ][^>]+>", RegexOptions.Compiled);

        public static string StripTags(string html)
        {
            if (string.IsNullOrEmpty(html)) return "";

            return REGEX_HTML_TAGS.Replace(html, "");
        }

        public static string TruncateAtWord<T>(T[] values, int length)
        {
            bool truncated;

            return TruncateAtWord(string.Join(", ", values.Select(o => o.ToString()).ToArray()), length, out truncated);
        }

        public static string TruncateAtWord(string value, int length)
        {
            bool truncated;

            return TruncateAtWord(value, length, out truncated);
        }

        public static string TruncateAtWord(string value, int length, out bool truncated)
        {
            if (value == null || value.Trim().Length <= length)
            {
                truncated = false;
                return value;
            }

            int index = value.Trim().LastIndexOf(' ');

            while ((index + 3) > length)
            {
                index = value.Substring(0, index).Trim().LastIndexOf(' ');
            }

            truncated = true;

            if (index > 0)
            {
                return value.Substring(0, index) + "...";
            }
            else
            {
                return value.Substring(0, length - 3) + "...";
            }
        }

    }
}
