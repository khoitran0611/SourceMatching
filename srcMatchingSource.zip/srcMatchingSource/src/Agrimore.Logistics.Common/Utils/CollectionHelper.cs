﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Common.Utils
{
    public static class CollectionHelper
    {
        public static int IndexOf<T>(this IEnumerable<T> collection, Func<T, bool> comparer)
        {
            var enumerator = collection.GetEnumerator();
            int i = 0;
            while (enumerator.MoveNext())
            {
                if (comparer(enumerator.Current))
                {
                    return i;
                }

                i++;
            }

            return -1;
        }
    }
}
