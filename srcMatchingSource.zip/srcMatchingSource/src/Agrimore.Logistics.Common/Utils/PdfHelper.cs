﻿using System.Xml;
using Aspose.Pdf.Generator;

namespace AgriMore.Logistics.Common.Utils
{
    public static class PdfHelper
    {
        public static string SavePdf(XmlDocument xmlDoc, string foXsltPath, string storePath, string fileName)
        {
            var pdf = new Pdf();

            var xslFo = new XmlDocument();
            xslFo.Load(foXsltPath);

            storePath = System.Web.HttpContext.Current.Server.MapPath(string.Format("~/{0}",storePath));
            if (!System.IO.Directory.Exists(storePath)) System.IO.Directory.CreateDirectory(storePath);

            string pathFile = System.IO.Path.Combine(storePath, fileName);

            pdf.BindFO(xmlDoc, xslFo);
            pdf.Save(pathFile);

            return pathFile;
        }

        public static void CreatePDF(XmlDocument doc, string xslPath, string culture, string filename, System.Web.HttpResponse response)
        {
            var pdf = new Pdf();
            var foXslt = new XmlDocument();
            foXslt.Load(xslPath);

            pdf.BindFO(doc, foXslt);
            pdf.Save(filename, Aspose.Pdf.Generator.SaveType.OpenInAcrobat, response);
            response.End();

            /*XmlDocument xsl = new XmlDocument();
            xsl.Load(xslPath);

            CreatePDF(doc, xsl, culture, filename, response);*/
        }

        public static void CreatePDF(XmlDocument doc, XmlDocument xsl, string culture, string filename, System.Web.HttpResponse response)
        {
            //FileInfo fi = new FileInfo(Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/App_GlobalResources/"), "ResStrings." + culture + ".resx"));
            //if (!fi.Exists) fi = new FileInfo(Path.Combine(fi.DirectoryName, "ResStrings.resx"));
            //XmlDocument lang = new XmlDocument();
            //lang.Load(fi.FullName);
            //doc.DocumentElement.InnerXml += "<language>" + lang.DocumentElement.InnerXml + "</language>";

            Pdf pdf = new Pdf();
            pdf.TextInfo.IsUnicode = true;
            pdf.TextInfo.FontName = "Arial Unicode MS";
            pdf.TextInfo.FontSize = 9;
            pdf.BindFO(doc, xsl);
            pdf.Save(filename, Aspose.Pdf.Generator.SaveType.OpenInAcrobat, response);
            response.End();
        }
    }
}
