﻿using System;
using System.Linq;
using AgriMore.AgreementPurchaseServices;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.BiddingPurchaseServices
{
    public class BiddingPurchaseJob : Job
    {
        private static readonly RepositoryFactory RepositoryFactory = new RepositoryFactory();

        public override void Run()
        {
            BiddingPurchase4NormalProduct();

            BiddingPurchase4CompositeProduct();

            Log.Info("Finish");
        }

        private void BiddingPurchase4NormalProduct()
        {
            Log.Info("Find Bidding Purchase Process");
            IList<Logistics.Domain.BiddingPurchase> bidPchs = Logistics.Data.Services.BiddingPurchaseServices.GetFinalBiddingProcess();
            if (bidPchs.Count <= 0)
            {
                Log.Info("Not found Bidding Purchase Process");
                return;
            }

            Log.Info(string.Format("Found {0} Bidding Process", bidPchs.Count));

            foreach (var bidPch in bidPchs)
            {
                IList<BiddingPurchaseSellerBidded> sellerBiddeds = Logistics.Data.Services.BiddingPurchaseServices.GetSellerBiddingOnBiddingPurchase(bidPch.Uid);
                if (sellerBiddeds.Count <= 0) continue;

                BiddingPurchaseSellerBidded wonBid = sellerBiddeds[0];
                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    Log.Info(string.Format("{0} Won offer at: {1} {2} for Bidding PurchaseId: {3}", wonBid.SellerId, wonBid.BiddingPrice, wonBid.Currency, bidPch.Uid));
                    bidPch.BiddingPrice = wonBid.BiddingPrice;
                    bidPch.SellerWonId = wonBid.SellerId;

                    //Check and remove other puchase process that come from Planning Purchase.
                    if (bidPch.PlanningId != 0 && bidPch.IssuedSeq != 0)
                    {
                        IList<AgreementPurchase> lstAps = Logistics.Data.Services.AgreementPurchaseServices.GetAgreementPurchase(bidPch.PlanningId, bidPch.IssuedSeq);
                        foreach (var ap in lstAps) RepositoryFactory.GetAgreementPurchaseRepository().Remove(ap);

                        var ra = ReverseAuctionServices.GetReverseAuction(bidPch.PlanningId, bidPch.IssuedSeq);
                        if (ra != null) RepositoryFactory.GetReverseAuctionRepository().Remove(ra);
                    }

                    RepositoryFactory.GetBiddingPurchaseRepository().Store(bidPch);
                    transactionManager.CommitTransaction();
                    Log.Info(string.Format("----> Already set seller won for bidding purchase: {0}", bidPch.Uid));
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }
        }

        private void BiddingPurchase4CompositeProduct()
        {
            Log.Info("Find Bidding Purchase Process for Composite Product ");
            IList<BiddingPurchase4CompositeProduct> bidPchs = Logistics.Data.Services.BiddingPurchaseServices.GetFinalBiddingProcess4CompositeProduct();
            if (bidPchs.Count <= 0)
            {
                Log.Info("Not found Bidding Purchase Process for Composite Product");
                return;
            }

            Log.Info(string.Format("Found {0} Bidding Process for Composite Product", bidPchs.Count));

            foreach (var bidPch in bidPchs)
            {
                IList<BiddingPurchase4CompositeProductSellerOffer> sellerBiddeds = Logistics.Data.Services.BiddingPurchaseServices.FindAllOfferOnBiddingPurchase(bidPch.Uid);
                if (sellerBiddeds.Count <= 0) continue;

                BiddingPurchase4CompositeProductSellerOffer wonBid = sellerBiddeds[0];
                var transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    Log.Info(string.Format("{0} Won offer at: {1} {2} for Bidding PurchaseId: {3}", wonBid.SellerId, wonBid.OfferPrice, wonBid.Currency, bidPch.Uid));
                    bidPch.WonPrice = wonBid.OfferPrice;
                    bidPch.WonSellerId = wonBid.SellerId;
                    bidPch.IsMatched = true;


                    foreach (var priceDetail in bidPch.PriceDetails)
                    {
                        var offerPriceDetail = wonBid.OfferPriceDetails.SingleOrDefault(it => it.Product4CompositeProdFav.Uid == priceDetail.Product4CompositeProdFav.Uid);
                        priceDetail.AgreedPrice = offerPriceDetail.OfferPrice;
                        priceDetail.Currency = offerPriceDetail.Currency;
                    }
                    //Check and remove other puchase process that come from Planning Purchase.
                    //if (bidPch.PlanningId != 0 && bidPch.IssuedSeq != 0)
                    //{
                    //    IList<AgreementPurchase> lstAps = Logistics.Data.Services.AgreementPurchaseServices.GetAgreementPurchase(bidPch.PlanningId, bidPch.IssuedSeq);
                    //    foreach (var ap in lstAps) RepositoryFactory.GetAgreementPurchaseRepository().Remove(ap);

                    //    var ra = ReverseAuctionServices.GetReverseAuction(bidPch.PlanningId, bidPch.IssuedSeq);
                    //    if (ra != null) RepositoryFactory.GetReverseAuctionRepository().Remove(ra);
                    //}

                    RepositoryFactory.GetBiddingPurchase4CompositeProductRepository().Store(bidPch);
                    transactionManager.CommitTransaction();
                    Log.Info(string.Format("----> Already set seller won for bidding purchase: {0}", bidPch.Uid));
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    Log.Error(exception);
                }
            }
        }
    }
}
